// GameEngineInput.h / GameEngineInput.cpp 의 전사
// GetAsyncKeyState 대신 DOM 이벤트로 관리되는 "물리 키 눌림 집합"을 사용한다.
// 원본의 IsAnyKeyOff() 버그(IsAnyKeyValue = true)는 그대로 보존한다.
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { DomKeyToVK } from "../WinAPI.js";

export class GameEngineInput {
	static Keys = new Map();
	static IsAnyKeyValue = false;
	static PressedCodes = new Set(); // 물리적 눌림 상태 (KeyCheck 용)

	static IsAnyKeyOn() {
		this.IsAnyKeyValue = true;
	}

	static IsAnyKeyOff() {
		// 원본 그대로: IsAnyKeyValue = true (버그 보존)
		this.IsAnyKeyValue = true;
	}

	static IsAnyKey() {
		return this.IsAnyKeyValue;
	}

	static Update(_DeltaTime) {
		for (const [, i] of this.Keys) {
			i.Update(_DeltaTime);
		}
	}

	static CreateKey(_Name, _Key) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (this.Keys.has(UpperName)) {
			MsgAssert("이미 존재하는 이름의 키를 재 등록하려고 했습니다.");
		}
		this.Keys.set(UpperName, new GameEngineKey(_Key));
	}

	static IsKey(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		return this.Keys.has(UpperName);
	}

	static IsDown(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Down;
	}

	static IsUp(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Up;
	}

	static IsPress(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Press;
	}

	static IsFree(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Free;
	}

	static GetPressTime(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).PressTime;
	}

	static MouseCursorOff() {
		// 원본: ShowCursor(FALSE)
		const canvas = document.getElementById("GameEngineWindowDefault");
		if (canvas) {
			canvas.style.cursor = "none";
		}
	}

	// === 브라우저 물리 입력 바인딩 (GetAsyncKeyState 대체) ===
	static Install(canvas) {
		window.addEventListener("keydown", (e) => {
			const code = DomKeyToVK(e);
			if (null !== code) {
				GameEngineInput.PressedCodes.add(code);
				GameEngineInput.IsAnyKeyOn();
			}
		});
		window.addEventListener("keyup", (e) => {
			const code = DomKeyToVK(e);
			if (null !== code) {
				GameEngineInput.PressedCodes.delete(code);
			}
		});
		window.addEventListener("blur", () => {
			GameEngineInput.PressedCodes.clear();
		});
		canvas.addEventListener("mousedown", (e) => {
			if (0 === e.button) { GameEngineInput.PressedCodes.add(0x01); }  // VK_LBUTTON
			if (2 === e.button) { GameEngineInput.PressedCodes.add(0x02); }  // VK_RBUTTON
			if (1 === e.button) { GameEngineInput.PressedCodes.add(0x04); }  // VK_MBUTTON
			e.preventDefault();
		});
		window.addEventListener("mouseup", (e) => {
			if (0 === e.button) { GameEngineInput.PressedCodes.delete(0x01); }
			if (2 === e.button) { GameEngineInput.PressedCodes.delete(0x02); }
			if (1 === e.button) { GameEngineInput.PressedCodes.delete(0x04); }
		});
		canvas.addEventListener("contextmenu", (e) => e.preventDefault());
	}

	static IsPhysicalDown(_Key) {
		return this.PressedCodes.has(_Key);
	}
}

class GameEngineKey {
	constructor(_Key) {
		this.Down = false;
		this.Press = false;
		this.Up = false;
		this.Free = true;
		this.PressTime = 0;
		this.Key = _Key;
	}

	KeyCheck() {
		// 원본: 0 != GetAsyncKeyState(Key)
		return GameEngineInput.IsPhysicalDown(this.Key);
	}

	Update(_DeltaTime) {
		if (true === this.KeyCheck()) {
			this.PressTime += _DeltaTime;
			if (true === this.Free) {
				this.Down = true;
				this.Press = true;
				this.Up = false;
				this.Free = false;
			} else if (true === this.Press) {
				this.Down = false;
				this.Press = true;
				this.Up = false;
				this.Free = false;
			}
		} else {
			this.PressTime = 0.0;
			if (true === this.Press) {
				this.Down = false;
				this.Press = false;
				this.Up = true;
				this.Free = true;
			} else if (true === this.Up) {
				this.Down = false;
				this.Press = false;
				this.Up = false;
				this.Free = true;
			}
		}
	}
}
