// GameEngineImage.h / GameEngineImage.cpp 의 전사
// HBITMAP/HDC 대신 canvas + ImageData 캐시를 사용한다.
// TransCopy의 색상키 투명(기본 RGB(255,0,255))은 로드 시 픽셀 처리로 구현한다.
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";

export class ImageCutData {
	constructor() {
		this.StartX = 0.0;
		this.StartY = 0.0;
		this.SizeX = 0.0;
		this.SizeY = 0.0;
	}

	GetStartPos() {
		return new float4(this.StartX, this.StartY);
	}

	GetScale() {
		return new float4(this.SizeX, this.SizeY);
	}
}

export class GameEngineImage {
	constructor() {
		this.canvas = null;   // HTMLCanvasElement (비트맵 본체)
		this.ctx = null;      // CanvasRenderingContext2D (원본 ImageDC)
		this.bmWidth = 0;     // 원본 BITMAP Info.bmWidth
		this.bmHeight = 0;    // 원본 BITMAP Info.bmHeight
		this.IsCut = false;
		this.ImageCutDatas = [];
		this._ImageDataCache = null;   // GetPixelColor 용
		this._KeyedCache = new Map();  // colorKey int → canvas
	}

	// 원본 ImageCreate(HDC): 이미 존재하는 표면을 감쌀 때 (백버퍼)
	// 원본 ImageCreate(float4): 빈 이미지 생성
	ImageCreate(_Scale) {
		if (_Scale instanceof GameEngineImage) {
			MsgAssert("잘못된 ImageCreate 호출");
			return false;
		}
		if (_Scale instanceof CanvasRenderingContext2D) {
			this.ctx = _Scale;
			this.canvas = _Scale.canvas;
			this.ImageScaleCheck();
			return true;
		}
		if (_Scale instanceof HTMLCanvasElement) {
			this.canvas = _Scale;
			this.ctx = _Scale.getContext("2d");
			this.ImageScaleCheck();
			return true;
		}
		if (true === _Scale.IsZero()) {
			MsgAssert("크기가 0인 이미지를 만들 수 는 없습니다");
			return false;
		}
		this.canvas = document.createElement("canvas");
		this.canvas.width = _Scale.ix();
		this.canvas.height = _Scale.iy();
		this.ctx = this.canvas.getContext("2d");
		this.ImageScaleCheck();
		this.ImageClear();
		return true;
	}

	ImageClear() {
		// 원본: Rectangle(ImageDC, 0, 0, w, h) — 기본 흰 브러시 채움
		this.ctx.fillStyle = "#ffffff";
		this.ctx.fillRect(0, 0, this.bmWidth, this.bmHeight);
	}

	ImageLoad(_Path) {
		const Url = GameEngineImage.ResolveResourceUrl(_Path);
		const Preloaded = (window.PM2_PRELOADED && window.PM2_PRELOADED.images) ? window.PM2_PRELOADED.images.get(Url.toLowerCase()) : null;
		if (null !== Preloaded && undefined !== Preloaded) {
			this.canvas = document.createElement("canvas");
			this.canvas.width = Preloaded.naturalWidth;
			this.canvas.height = Preloaded.naturalHeight;
			this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
			this.ctx.drawImage(Preloaded, 0, 0);
		} else {
			// 프리로드에 없으면 즉석 로드 (원본과 달리 비동기 — 매니페스트에 있으면 미리 로드됨)
			this.canvas = document.createElement("canvas");
			this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
			const img = new Image();
			img.src = Url;
			this.canvas.width = 0;
			this.canvas.height = 0;
			img.addEventListener("load", () => {
				this.canvas.width = img.naturalWidth;
				this.canvas.height = img.naturalHeight;
				this.ctx.drawImage(img, 0, 0);
				this.ImageScaleCheck();
			});
			img.addEventListener("error", () => {
				MsgAssert(_Path + " 이미지 로드에 실패했습니다.");
			});
		}
		this.ImageScaleCheck();
		return true;
	}

	ImageScaleCheck() {
		this.bmWidth = this.canvas ? this.canvas.width : 0;
		this.bmHeight = this.canvas ? this.canvas.height : 0;
	}

	GetImageDC() {
		return this.ctx;
	}

	GetImageScale() {
		return new float4(this.bmWidth, this.bmHeight, 0, 1);
	}

	IsImageCutting() {
		return this.IsCut;
	}

	GetImageCuttingCount() {
		return this.ImageCutDatas.length;
	}

	IsCutIndexValid(_Index) {
		if (0 > _Index) {
			return false;
		}
		if (this.ImageCutDatas.length <= _Index) {
			return false;
		}
		return true;
	}

	GetCutData(_Index) {
		if (false === this.IsCutIndexValid(_Index)) {
			MsgAssert("유효하지 않은 컷 인덱스 입니다.");
		}
		return this.ImageCutDatas[_Index];
	}

	// Cut(int _X, int _Y) / Cut(float4 _Start, float4 _End, int _X, int _Y)
	Cut(...args) {
		if (2 === args.length) {
			const _X = args[0];
			const _Y = args[1];
			const Data = new ImageCutData();
			Data.SizeX = this.GetImageScale().ix() / _X;
			Data.SizeY = this.GetImageScale().iy() / _Y;
			for (let j = 0; j < _Y; j++) {
				for (let i = 0; i < _X; i++) {
					this.ImageCutDatas.push(Data);
					Data.StartX += Data.SizeX;
				}
				Data.StartX = 0.0;
				Data.StartY += Data.SizeY;
			}
			this.IsCut = true;
			return;
		}

		const _Start = args[0];
		const _End = args[1];
		const _X = args[2];
		const _Y = args[3];
		const Data = new ImageCutData();
		Data.SizeX = (_End.x - _Start.x) / _X;
		Data.SizeY = (_End.y - _Start.y) / _Y;
		Data.StartX = _Start.x;
		Data.StartY = _Start.y;
		for (let j = 0; j < _Y; j++) {
			for (let i = 0; i < _X; i++) {
				this.ImageCutDatas.push(Data);
				Data.StartX += Data.SizeX;
			}
			Data.StartX = _Start.x;
			Data.StartY += Data.SizeY;
		}
		this.IsCut = true;
	}

	// BitBlt(SRCCOPY): 1:1 복사(스케일 없음) — 원본 동일
	BitCopy(_OtherImage, _CenterPos, _Scale) {
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		this.ctx.drawImage(
			_OtherImage.canvas,
			0, 0,
			Math.max(0, _Scale.ix()), Math.max(0, _Scale.iy()),
			_CenterPos.ix() - _Scale.hix(),
			_CenterPos.iy() - _Scale.hiy(),
			Math.max(0, _Scale.ix()), Math.max(0, _Scale.iy())
		);
	}

	// TransCopy(other, cutIndex, center, size[, color])
	// TransCopy(other, center, size, srcPos, srcSize[, color])
	TransCopy(...args) {
		let _OtherImage, _CopyCenterPos, _CopySize, _OtherImagePos, _OtherImageSize, _Color;
		if (4 === args.length || 5 === args.length) {
			_OtherImage = args[0];
			const _CutIndex = args[1];
			_CopyCenterPos = args[2];
			_CopySize = args[3];
			_Color = 5 === args.length ? args[4] : 0xff00ff; // RGB(255, 0, 255)
			if (false === _OtherImage.IsCut) {
				MsgAssert(" 잘못된 컷 이미지를 cut하려는 함수를 사용하려고 했습니다.");
				return;
			}
			const Data = _OtherImage.GetCutData(_CutIndex);
			_OtherImagePos = Data.GetStartPos();
			_OtherImageSize = Data.GetScale();
		} else {
			_OtherImage = args[0];
			_CopyCenterPos = args[1];
			_CopySize = args[2];
			_OtherImagePos = args[3];
			_OtherImageSize = args[4];
			_Color = 6 === args.length ? args[5] : 0xff00ff; // RGB(255, 0, 255)
		}
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		const Src = _OtherImage.GetKeyedCanvas(_Color);
		this.ctx.drawImage(
			Src,
			_OtherImagePos.ix(), _OtherImagePos.iy(),
			Math.max(0, _OtherImageSize.ix()), Math.max(0, _OtherImageSize.iy()),
			_CopyCenterPos.ix() - _CopySize.hix(),
			_CopyCenterPos.iy() - _CopySize.hiy(),
			Math.max(1, _CopySize.ix()), Math.max(1, _CopySize.iy())
		);
	}

	// AlphaCopy(other, cutIndex, center, size[, color])
	// AlphaCopy(other, center, size, srcPos, srcSize, alpha)
	AlphaCopy(...args) {
		let _OtherImage, _CopyCenterPos, _CopySize, _OtherImagePos, _OtherImageSize, _Alpha;
		if (4 === args.length || 5 === args.length) {
			_OtherImage = args[0];
			const _CutIndex = args[1];
			_CopyCenterPos = args[2];
			_CopySize = args[3];
			if (false === _OtherImage.IsCut) {
				MsgAssert(" 잘못된 컷 이미지를 cut하려는 함수를 사용하려고 했습니다.");
				return;
			}
			const Data = _OtherImage.GetCutData(_CutIndex);
			_OtherImagePos = Data.GetStartPos();
			_OtherImageSize = Data.GetScale();
			_Alpha = args[4];
		} else {
			_OtherImage = args[0];
			_CopyCenterPos = args[1];
			_CopySize = args[2];
			_OtherImagePos = args[3];
			_OtherImageSize = args[4];
			_Alpha = args[5];
		}
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		this.ctx.globalAlpha = _Alpha / 255.0;
		this.ctx.drawImage(
			_OtherImage.canvas,
			_OtherImagePos.ix(), _OtherImagePos.iy(),
			Math.max(0, _OtherImageSize.ix()), Math.max(0, _OtherImageSize.iy()),
			_CopyCenterPos.ix() - _CopySize.hix(),
			_CopyCenterPos.iy() - _CopySize.hiy(),
			Math.max(1, _CopySize.ix()), Math.max(1, _CopySize.iy())
		);
		this.ctx.globalAlpha = 1.0;
	}

	// 색상키가 적용된 소스 캔버스 (캐시)
	GetKeyedCanvas(_Color) {
		if (null === this.canvas || 0 === this.bmWidth) {
			return this.canvas;
		}
		const Key = null === _Color || undefined === _Color ? -1 : _Color;
		if (-1 === Key) {
			return this.canvas;
		}
		if (this._KeyedCache.has(Key)) {
			return this._KeyedCache.get(Key);
		}
		const Out = document.createElement("canvas");
		Out.width = this.bmWidth;
		Out.height = this.bmHeight;
		const octx = Out.getContext("2d");
		octx.drawImage(this.canvas, 0, 0);
		const Data = octx.getImageData(0, 0, Out.width, Out.height);
		const px = Data.data;
		for (let i = 0; i < px.length; i += 4) {
			const color = px[i] | (px[i + 1] << 8) | (px[i + 2] << 16);
			if (color === Key) {
				px[i + 3] = 0;
			}
		}
		octx.putImageData(Data, 0, 0);
		this._KeyedCache.set(Key, Out);
		return Out;
	}

	GetImageDataCache() {
		if (null === this._ImageDataCache && null !== this.ctx && this.bmWidth > 0) {
			this._ImageDataCache = this.ctx.getImageData(0, 0, this.bmWidth, this.bmHeight);
		}
		return this._ImageDataCache;
	}

	GetPixelColor(...args) {
		let _X, _Y;
		if (1 === args.length) {
			_X = args[0].ix();
			_Y = args[0].iy();
		} else {
			_X = args[0];
			_Y = args[1];
		}
		const _OutColor = args[args.length - 1];
		if (_X < 0) { return _OutColor; }
		if (_X >= this.GetImageScale().ix()) { return _OutColor; }
		if (_Y < 0) { return _OutColor; }
		if (_Y >= this.GetImageScale().iy()) { return _OutColor; }
		const Data = this.GetImageDataCache();
		if (null === Data) { return _OutColor; }
		const idx = (_Y * this.bmWidth + _X) * 4;
		// COLORREF = 0x00BBGGRR
		return Data.data[idx] | (Data.data[idx + 1] << 8) | (Data.data[idx + 2] << 16);
	}
}

// 리소스 경로 → 웹 URL 변환 (빌드 시 .bmp → .png 변환됨, 매니페스트로 대소문자 무시 매핑)
GameEngineImage.ResolveResourceUrl = function (_Path) {
	let p = String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/");
	if (p.startsWith("./")) {
		p = p.slice(2);
	}
	while (p.startsWith("/")) {
		p = p.slice(1); // 웹 루트 기준 상대 경로로 정규화 (서버/매니페스트 키 일치)
	}
	if (/\.bmp$/i.test(p)) {
		p = p.slice(0, -4) + ".png";
	}
	if (window.PM2_MANIFEST_PATHS) {
		const lower = p.toLowerCase();
		const Found = window.PM2_MANIFEST_PATHS.find((x) => x.toLowerCase() === lower);
		if (Found) {
			p = Found;
		}
	}
	return p;
};
