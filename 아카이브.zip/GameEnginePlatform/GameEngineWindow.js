// GameEngineWindow.h / GameEngineWindow.cpp 의 전사
// HWND/HDC/백버퍼 대신 canvas 2D 컨텍스트를 사용한다.
// - BackBufferImage  : 화면에 보이는 canvas를 감싼 이미지 (원본: 윈도우 DC)
// - DoubleBufferImage: 800x600 오프스크린 canvas (원본: 호환 비트맵 DC)
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineImage } from "./GameEngineImage.js";
import { GameEngineInput } from "./GameEngineInput.js";

export class GameEngineWindow {
	static HWnd = null;              // HTMLCanvasElement
	static WindowBackBufferHdc = null; // CanvasRenderingContext2D
	static WindowSize = new float4(800, 600);
	static ScreenSize = new float4(800, 600);
	static WindowPos = new float4(100, 100);
	static BackBufferImage = null;
	static DoubleBufferImage = null;
	static IsWindowUpdate = true;
	static MousePos = new float4(0, 0, 0, 0);

	static MessageFunction() {
		// 원본 WndProc: 브라우저 이벤트는 GameEngineInput.Install 에서 처리
	}

	static WindowCreate(_hInstance, _TitleName, _Size, _Pos) {
		const canvas = document.createElement("canvas");
		canvas.id = "GameEngineWindowDefault";
		canvas.width = _Size.ix();
		canvas.height = _Size.iy();
		canvas.style.position = "absolute";
		canvas.style.left = "50%";
		canvas.style.top = "50%";
		canvas.style.transform = "translate(-50%, -50%)";
		canvas.style.imageRendering = "pixelated";
		canvas.style.background = "#000";
		document.body.appendChild(canvas);

		// 창 크기에 맞게 비율 유지 스케일 (AdjustWindowRect 비해상당: 웹은 비클라이언트 영역 없음)
		const Fit = () => {
			const Scale = Math.min(window.innerWidth / _Size.ix(), window.innerHeight / _Size.iy());
			canvas.style.width = Math.floor(_Size.ix() * Scale) + "px";
			canvas.style.height = Math.floor(_Size.iy() * Scale) + "px";
		};
		window.addEventListener("resize", Fit);
		Fit();

		this.HWnd = canvas;
		this.WindowBackBufferHdc = canvas.getContext("2d");
		this.WindowBackBufferHdc.imageSmoothingEnabled = false;

		// 마우스 추적 (원본: GetCursorPos + ScreenToClient)
		const UpdateMouse = (e) => {
			const Rect = canvas.getBoundingClientRect();
			this.MousePos = new float4(
				(e.clientX - Rect.left) * (canvas.width / Rect.width),
				(e.clientY - Rect.top) * (canvas.height / Rect.height),
				0, 0
			);
		};
		window.addEventListener("mousemove", UpdateMouse);

		this.SettingWindowSize(_Size);
		this.SettingWindowPos(_Pos);

		this.BackBufferImage = new GameEngineImage();
		this.BackBufferImage.ImageCreate(this.WindowBackBufferHdc);

		GameEngineInput.Install(canvas);
	}

	static SettingWindowSize(_Size) {
		this.ScreenSize = _Size.copy();
		this.WindowSize = _Size.copy();

		if (null !== this.DoubleBufferImage) {
			// 원본: delete 후 재생성
		}

		this.DoubleBufferImage = new GameEngineImage();
		this.DoubleBufferImage.ImageCreate(this.ScreenSize);
	}

	static SettingWindowPos(_Pos) {
		this.WindowPos = _Pos.copy();
	}

	static GetScreenSize() {
		return this.ScreenSize;
	}

	static GetHWnd() {
		return this.HWnd;
	}

	static GetWindowBackBufferHdc() {
		return this.WindowBackBufferHdc;
	}

	static GetDoubleBufferImage() {
		return this.DoubleBufferImage;
	}

	static AppOff() {
		this.IsWindowUpdate = false;
	}

	static DoubleBufferClear() {
		this.DoubleBufferImage.ImageClear();
	}

	static DoubleBufferRender() {
		this.BackBufferImage.BitCopy(this.DoubleBufferImage, this.WindowSize.half(), this.WindowSize);
	}

	static GetMousePosition() {
		return this.MousePos.copy();
	}

	static WindowLoop(_Start, _Loop, _End) {
		if (null !== _Start && undefined !== _Start) {
			_Start();
		}

		const Frame = () => {
			if (false === this.IsWindowUpdate) {
				if (null !== _End && undefined !== _End) {
					_End();
				}
				return;
			}
			if (null !== _Loop && undefined !== _Loop) {
				_Loop();
			}
			GameEngineInput.IsAnyKeyOff();
			requestAnimationFrame(Frame);
		};
		requestAnimationFrame(Frame);
	}
}
