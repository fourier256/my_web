// GameEngineSound.h / GameEngineSound.cpp 의 전사
// FMOD 대신 HTMLAudioElement를 사용한다. SoundLoad는 FMOD_LOOP_NORMAL로 로드하므로
// 기본 loop = true 이며, GameEngineResources.SoundPlay 가 채널에 setLoopCount(0)을
// 호출해 한 번만 재생된다(원본 의미 동일).
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";

export class GameEngineSound {
	constructor() {
		this.audio = null;   // 원본: FMOD::Sound*
	}

	static SoundUpdate() {
		// 원본: SoundSystem->update() — 브라우저에서는 불필요
	}

	SoundLoad(_Path) {
		const Url = GameEngineSound.ResolveSoundUrl(_Path);
		const Preloaded = (window.PM2_PRELOADED && window.PM2_PRELOADED.sounds) ? window.PM2_PRELOADED.sounds.get(Url.toLowerCase()) : null;
		if (null !== Preloaded && undefined !== Preloaded) {
			this.audio = Preloaded;
		} else {
			this.audio = new Audio(Url);
		}
		if (null === this.audio) {
			MsgAssert(`사운드 로드에 실패했습니다.\n 경로 : ` + _Path);
		}
	}

	Play() {
		if (null === this.audio) {
			MsgAssert(`FMODSound가 nullptr 입니다 `);
		}
		const Ch = new SoundChannel(this.audio);
		Ch.Play();
		return Ch;
	}
}

GameEngineSound.ResolveSoundUrl = function (_Path) {
	let p = String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/");
	if (p.startsWith("./")) {
		p = p.slice(2);
	}
	while (p.startsWith("/")) {
		p = p.slice(1); // 웹 루트 기준 상대 경로로 정규화
	}
	if (window.PM2_MANIFEST_PATHS) {
		const lower = p.toLowerCase();
		const Found = window.PM2_MANIFEST_PATHS.find((x) => x.toLowerCase() === lower);
		if (Found) {
			p = Found;
		}
	}
	return p;
};

// FMOD::Channel* 대응
export class SoundChannel {
	constructor(_Audio) {
		this.audio = _Audio; // 사운드 원본(프리로드된 엘리먼트)
		this.node = null;    // 재생 중인 클론
		this.LoopMode = true; // FMOD_LOOP_NORMAL
	}

	Play() {
		this.node = this.audio.cloneNode(false);
		this.node.loop = this.LoopMode;
		this.node.volume = 1.0;
		const p = this.node.play();
		if (p !== undefined) {
			p.catch(() => {
				// 브라우저 자동재생 정책: 첫 사용자 입력 전에는 재생이 거부될 수 있다.
				this._Pending = true;
			});
		}
		return this.node;
	}

	setLoopCount(_Count) {
		if (null === this.node) { return; }
		if (_Count <= 0) {
			this.node.loop = false; // 원본: setLoopCount(0) → 현재 재생 후 정지
		} else {
			this.node.loop = true;
		}
	}

	setVolume(_Volume) {
		if (null === this.node) { return; }
		this.node.volume = Math.max(0, Math.min(1, _Volume));
	}

	stop() {
		if (null === this.node) { return; }
		this.node.pause();
		this.node.currentTime = 0;
	}
}
