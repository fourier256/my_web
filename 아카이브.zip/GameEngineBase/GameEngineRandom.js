// GameEngineRandom.h / GameEngineRandom.cpp 의 전사
// std::mt19937_64 + uniform_distribution 대신 Math.random 사용 (분포 의미 동일)

export class GameEngineRandom {
	static MainRandom = new GameEngineRandom();

	constructor() {
		// 원본: 시드 = 현재 시각
		this.Seed = Date.now();
	}

	SetSeed(_Seed) {
		this.Seed = _Seed;
	}

	RandomInt(_Min, _Max) {
		// uniform_int_distribution: [Min, Max] 포함 균등 분포
		return Math.floor(Math.random() * (_Max - _Min + 1)) + _Min;
	}

	RandomFloat(_Min, _Max) {
		// uniform_real_distribution: [Min, Max) 균등 분포
		return Math.random() * (_Max - _Min) + _Min;
	}
}
