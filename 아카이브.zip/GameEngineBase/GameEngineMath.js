// GameEngineMath.h / GameEngineMath.cpp 의 전사
export class GameEngineMath {
	static PIE = 3.141592653589793238462643383279502884197169399375105820974944;
	static PIE2 = GameEngineMath.PIE * 2.0;
	static DegToRad = GameEngineMath.PIE / 180;
	static RadToDeg = 180 / GameEngineMath.PIE;

	static GetDigits(_Value) {
		const ResultValue = [];
		const StringValue = GameEngineString.ToString(_Value);
		for (let i = 0; i < StringValue.length; i++) {
			ResultValue.push(StringValue.charCodeAt(i) - 48);
		}
		return ResultValue;
	}

	static GetLenth(_Value) {
		const StringValue = GameEngineString.ToString(_Value);
		let StartIndex = 0;
		if (0 !== StringValue.length && StringValue[0] === '-') {
			StartIndex = 1;
		}
		return StringValue.length - StartIndex;
	}
}

import { GameEngineString } from "./GameEngineString.js";

export class float4 {
	static Left = new float4(-1.0, 0.0, 0.0, 1.0);
	static Right = new float4(1.0, 0.0, 0.0, 1.0);
	static Up = new float4(0.0, -1.0, 0.0, 1.0);
	static Down = new float4(0.0, 1.0, 0.0, 1.0);
	static Forward = new float4(0.0, 0.0, 1.0, 1.0);
	static Back = new float4(0.0, 0.0, -1.0, 1.0);
	static Zero = new float4(0.0, 0.0, 0.0, 1.0);
	static Null = new float4(0.0, 0.0, 0.0, 0.0);

	static AngleToDirection2DToDeg(_Deg) {
		return float4.AngleToDirection2DToRad(_Deg * GameEngineMath.DegToRad);
	}

	static AngleToDirection2DToRad(_Rad) {
		return new float4(Math.cos(_Rad), Math.sin(_Rad), 0.0, 1.0);
	}

	constructor(x = 0.0, y = 0.0, z = 0.0, w = 1.0) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}

	copy() {
		return new float4(this.x, this.y, this.z, this.w);
	}

	ix() { return Math.trunc(this.x); }
	iy() { return Math.trunc(this.y); }
	iz() { return Math.trunc(this.z); }
	iw() { return Math.trunc(this.w); }
	hix() { return Math.trunc(this.x * 0.5); }
	hiy() { return Math.trunc(this.y * 0.5); }
	hiz() { return Math.trunc(this.z * 0.5); }
	hiw() { return Math.trunc(this.w * 0.5); }
	hx() { return this.x * 0.5; }
	hy() { return this.y * 0.5; }
	hz() { return this.z * 0.5; }
	hw() { return this.w * 0.5; }

	GetAnagleDeg() {
		return this.GetAnagleRad() * GameEngineMath.RadToDeg;
	}

	GetAnagleRad() {
		const AngleCheck = this.copy();
		AngleCheck.Normalize();
		let Result = Math.acos(AngleCheck.x);
		if (AngleCheck.y > 0) {
			Result = GameEngineMath.PIE2 - Result;
		}
		return Result;
	}

	half() {
		return new float4(this.x * 0.5, this.y * 0.5, this.z * 0.5, this.w);
	}

	IsZero() {
		return this.x === 0.0 && this.y === 0.0 && this.z === 0.0;
	}

	Size() {
		return Math.sqrt(this.x * this.x + this.y * this.y);
	}

	Normalize() {
		const SizeValue = this.Size();
		this.x /= SizeValue;
		this.y /= SizeValue;
		this.z /= SizeValue;
	}

	static Lerp(Start, End, Ratio) {
		return Start.scale(1.0 - Ratio).add(End.scale(Ratio));
	}

	static LerpClamp(Start, End, Ratio) {
		if (0 >= Ratio) {
			Ratio = 0.0;
		}
		if (1.0 <= Ratio) {
			Ratio = 1.0;
		}
		return float4.Lerp(Start, End, Ratio);
	}

	scale(_Value) {
		return new float4(this.x * _Value, this.y * _Value, this.z * _Value, this.w);
	}

	add(_Value) {
		return new float4(this.x + _Value.x, this.y + _Value.y, this.z + _Value.z, this.w);
	}

	sub(_Value) {
		return new float4(this.x - _Value.x, this.y - _Value.y, this.z - _Value.z, this.w);
	}

	mul(_Value) {
		return new float4(this.x * _Value.x, this.y * _Value.y, this.z * _Value.z, this.w);
	}

	div(_Value) {
		return new float4(this.x / _Value.x, this.y / _Value.y, this.z / _Value.z, this.w);
	}

	neg() {
		return new float4(-this.x, -this.y, -this.z, 1.0);
	}

	ToString() {
		return `x: ${this.x}, y: ${this.y}, z: ${this.z}, w: ${this.w}`;
	}
}
