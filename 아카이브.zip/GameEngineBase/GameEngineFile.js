// GameEngineFile.h / GameEngineFile.cpp 의 전사
import { GameEnginePath } from "./GameEnginePath.js";

export class GameEngineFile {
	constructor(_Path) {
		this.Path = new GameEnginePath(undefined === _Path ? null : _Path);
	}

	GetFullPath() {
		return this.Path.GetPathToString();
	}
}
