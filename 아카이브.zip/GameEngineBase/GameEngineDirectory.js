// GameEngineDirectory.h / GameEngineDirectory.cpp 의 전사
// 원본은 구분자로 "\"를 조립하지만, 웹 버전은 "/"를 사용한다(콘텐츠 코드에는 영향 없음).
import { GameEnginePath } from "./GameEnginePath.js";
import { GameEngineFile } from "./GameEngineFile.js";
import { MsgAssert } from "./GameEngineDebug.js";

export class GameEngineDirectory {
	constructor() {
		this.Path = new GameEnginePath(null);
	}

	MoveParentToDirectory(_String) {
		// 원본: MovePath = "\" + _String; Path.MoveParentToChildPath(MovePath);
		this.Path.MoveParentToChildPath("/" + _String);
	}

	Move(_String) {
		return this.Path.Move("/" + _String);
	}

	GetPlusFileName(_String) {
		return new GameEnginePath(this.Path.GetPathToString() + "/" + _String);
	}

	MoveParent() {
		if (true === this.Path.IsRoot()) {
			MsgAssert("루트 디렉터리의 부모디렉터리로 이동할수 없습니다.");
			return false;
		}
		this.Path.MoveParent();
		return true;
	}

	GetAllFile(_Ext = "") {
		// 원본: std::filesystem::directory_iterator — 브라우저에서는 매니페스트로 대체
		const Files = [];
		if (null === GameEnginePath.Manifest) {
			return Files;
		}
		const Base = GameEnginePath.Normalize(this.Path.GetPathToString());
		for (const p of GameEnginePath.Manifest) {
			if (!p.startsWith(Base + "/")) {
				continue;
			}
			const rest = p.slice(Base.length + 1);
			if (rest.includes("/")) {
				continue; // 하위 디렉터리 파일 제외
			}
			if ("" === _Ext || p.endsWith(_Ext.toLowerCase())) {
				Files.push(new GameEngineFile(new GameEnginePath(p)));
			}
		}
		return Files;
	}
}
