// GameEngineTime.h / GameEngineTime.cpp 의 전사
// QueryPerformanceCounter 대신 performance.now() 사용 (초 단위 float 반환은 동일)

export class GameEngineTime {
	static GlobalTime = new GameEngineTime();

	constructor() {
		this.Prev = performance.now();
		this.Second = 1000.0; // performance.now()의 "주파수" (ms → s 변환용)
	}

	Reset() {
		this.Prev = performance.now();
	}

	TimeCheck() {
		const Current = performance.now();
		const Tick = Current - this.Prev;
		const DoubleDeltaTime = (Current - this.Prev) / this.Second;
		this.Prev = Current;
		return DoubleDeltaTime;
	}
}
