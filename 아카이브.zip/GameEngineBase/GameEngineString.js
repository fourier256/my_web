// GameEngineString.h / GameEngineString.cpp 의 전사
// 브라우저는 UTF-8 문자열을 사용하므로 인코딩 변환 함수들은 항등 함수가 된다.

export class GameEngineString {
	static ToUpper(_Str) {
		return String(_Str).toUpperCase();
	}

	static ToString(Value) {
		return String(Value);
	}

	static AnsiToUniCode(_Text) {
		return String(_Text);
	}

	static UniCodeToAnsi(_Text) {
		return String(_Text);
	}

	static UniCodeToUTF8(_Text) {
		return String(_Text);
	}

	static AnsiToUTF8(_Text) {
		return String(_Text);
	}
}
