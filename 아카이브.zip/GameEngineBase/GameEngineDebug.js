// GameEngineDebug.h / GameEngineDebug.cpp 의 전사
// MsgAssert 매크로: 원본은 MessageBoxA + assert. 브라우저에서는 치명적이지 않은
// 오버레이 + console.error 로 동일한 "보이는 실패"를 제공한다(원본 Release 동작:
// 박스 확인 후 계속 진행).

let _ErrorOverlay = null;
let _ErrorCount = 0;

function EnsureOverlay() {
	if (_ErrorOverlay) {
		return _ErrorOverlay;
	}
	_ErrorOverlay = document.createElement("div");
	_ErrorOverlay.style.cssText = "position:fixed;left:0;top:0;right:0;z-index:99999;background:rgba(120,0,0,0.85);color:#fff;font:12px/1.5 monospace;padding:4px 8px;max-height:40%;overflow:auto;display:none;white-space:pre-wrap;";
	document.body.appendChild(_ErrorOverlay);
	return _ErrorOverlay;
}

export function MsgAssert(MsgText) {
	const ErrorText = String(MsgText);
	console.error("MsgAssert: " + ErrorText);
	if (_ErrorCount < 8) {
		const Overlay = EnsureOverlay();
		Overlay.style.display = "block";
		Overlay.textContent += "[MsgAssert] " + ErrorText + "\n";
	}
	_ErrorCount++;
	return;
}

export class GameEngineDebug {
	static LeakCheck() {
		// 원본: _CrtSetDbgFlag — 브라우저에서는 해당 없음
	}

	static LeakPointBreak(_Point) {
		// 원본: _CrtSetBreakAlloc — 브라우저에서는 해당 없음
	}

	constructor() {
	}
	// delete Function
}
