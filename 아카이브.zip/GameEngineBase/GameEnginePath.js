// GameEnginePath.h / GameEnginePath.cpp 의 전사
// 원본은 std::filesystem::path (Windows 구분자 '\'), 웹에서는 '/' 구분자를 사용한다.
// 콘텐츠 코드는 구분자를 직접 쓰지 않으므로(GameEngineDirectory 내부에서만 조립) 영향 없음.
// IsExists / IsExistsToPlusString 은 파일시스템 대신 로드 매니페스트(Boot.js에서 주입)를 본다.
import { MsgAssert } from "./GameEngineDebug.js";

export class GameEnginePath {
	static Manifest = null; // Set<string> — 실제 존재하는 리소스 경로(소문자 정규화), 파일 또는 디렉터리 프리픽스

	static SetManifest(paths) {
		GameEnginePath.Manifest = new Set(paths.map((p) => GameEnginePath.Normalize(p)));
	}

	static Normalize(_Path) {
		return String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/").replace(/^\.\//, "").toLowerCase();
	}

	// 정규화된 키가 매니페스트에 있는지 (파일 또는 그 아래 파일이 있는 디렉터리)
	static ExistsInManifest(_Path) {
		if (null === GameEnginePath.Manifest) {
			return true; // 매니페스트 미주입 시 항상 존재한다고 본다(원본 파일시스템 동작)
		}
		const Key = GameEnginePath.Normalize(_Path);
		if ("" === Key) {
			return true;
		}
		if (GameEnginePath.Manifest.has(Key)) {
			return true;
		}
		for (const p of GameEnginePath.Manifest) {
			if (p.startsWith(Key) && p.charAt(Key.length) === "/") {
				return true;
			}
		}
		return false;
	}

	constructor(_Path) {
		if (undefined === _Path || null === _Path) {
			this.Path = "./"; // 원본: std::filesystem::current_path()
		} else if ("string" === typeof _Path) {
			this.Path = _Path;
		} else if (_Path instanceof GameEnginePath) {
			this.Path = _Path.GetPathToString(); // 원본 복사 생성자
		} else {
			this.Path = _Path;
		}
	}

	GetFileName() {
		const parts = this.Path.split("/");
		return parts[parts.length - 1];
	}

	GetPathToString() {
		return this.Path;
	}

	MoveParent() {
		const parts = this.Path.split("/").filter((s) => s.length > 0 && s !== ".");
		parts.pop();
		this.Path = parts.length === 0 ? "./" : "./" + parts.join("/");
	}

	MoveParentToChildPath(_String) {
		// 원본: 루트에 도달할 때까지 위로 올라가며 _String 자식이 있는 dir을 찾는다.
		// 웹 버전은 exe 대신 웹 루트("./")가 시작점이므로, 현재 위치의 존재 확인을
		// 루트 판정보다 먼저 수행해야 한다(원본 의미: 현재 dir부터 자식을 확인).
		while (true) {
			if (true === this.IsExistsToPlusString(_String)) {
				return;
			}
			if (true === this.IsRoot()) {
				break;
			}
			this.MoveParent();
		}
		MsgAssert("이런 경로의 자식이나 부모의 경로가 존재하지 않습니다.");
	}

	IsRoot() {
		// 상대 순회가 끝난(남은 경로 세그먼트가 없는) 상태만 루트로 본다
		return "" === this.Path.replace(/^\.\//, "").replace(/\//g, "");
	}

	IsExistsToPlusString(_String) {
		return GameEnginePath.ExistsInManifest(this.Path + _String);
	}

	IsExists() {
		return GameEnginePath.ExistsInManifest(this.Path);
	}

	Move(_Path) {
		// 원본: Path += _Path ("\" 조립) — 웹 버전은 "/" 조립 후 구분자를 정리한다
		this.Path = (this.Path + _Path).replace(/\/{2,}/g, "/");
		if (false === this.IsExists()) {
			MsgAssert(`이 존재하지 않는 경로로 이동하려고 했습니다.`);
			return false;
		}
		return true;
	}
}
