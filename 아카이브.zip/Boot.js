// Boot.js — 브라우저 실행용 부트 스트랩 (게임 로직 아님)
// C++에서는 exe 시작 즉시 파일시스템에서 이미지를 동기 로드하지만,
// 브라우저는 비동기이므로 모든 리소스를 먼저 받은 뒤 게임(main.js의 wWinMain)을 시작한다.
import { GameEnginePath } from "./GameEngineBase/GameEnginePath.js";

window.PM2_MANIFEST_PATHS = [...(window.PM2_MANIFEST.images || []), ...(window.PM2_MANIFEST.sounds || [])];
window.PM2_PRELOADED = { images: new Map(), sounds: new Map() };

function LoadImage(url) {
	return new Promise((resolve) => {
		const img = new Image();
		img.onload = () => { window.PM2_PRELOADED.images.set(url.toLowerCase(), img); resolve(); };
		img.onerror = () => { console.error("이미지 프리로드 실패: " + url); resolve(); };
		img.src = encodeURI(url);
	});
}

function LoadSound(url) {
	return new Promise((resolve) => {
		const audio = new Audio();
		audio.loop = true; // FMOD_LOOP_NORMAL
		audio.preload = "auto";
		let settled = false;
		const finish = () => { if (!settled) { settled = true; window.PM2_PRELOADED.sounds.set(url.toLowerCase(), audio); resolve(); } };
		audio.addEventListener("canplaythrough", finish, { once: true });
		audio.addEventListener("error", () => { console.error("사운드 프리로드 실패: " + url); finish(); }, { once: true });
		setTimeout(finish, 10000); // 실패해도 게임은 계속
		audio.src = encodeURI(url);
		audio.load();
	});
}

// 모든 실패를 화면에 표시한다 (조용한 실패 방지)
function ShowFatal(msg) {
	console.error(msg);
	const overlay = document.createElement("div");
	overlay.style.cssText = "position:fixed;left:0;top:0;right:0;z-index:99999;background:rgba(120,0,0,0.85);color:#fff;font:12px/1.5 monospace;padding:4px 8px;max-height:50%;overflow:auto;white-space:pre-wrap;";
	overlay.textContent = "[오류] " + msg;
	document.body.appendChild(overlay);
	const L = document.getElementById("loading");
	if (L) { L.remove(); }
}

window.addEventListener("unhandledrejection", (e) => {
	const r = e.reason;
	ShowFatal("처리되지 않은 오류: " + (r && r.stack ? r.stack : (r && r.message) || String(r)));
});

window.addEventListener("error", (e) => {
	ShowFatal("런타임 오류: " + ((e.error && e.error.stack) || e.message));
});

async function Boot() {
	const all = [];
	let done = 0;
	const total = window.PM2_MANIFEST_PATHS.length;
	const Update = () => {
		done++;
		const pct = Math.floor((done / total) * 100);
		document.getElementById("loadpct").textContent = pct;
		document.getElementById("loadbar").style.width = pct + "%";
	};

	for (const p of window.PM2_MANIFEST.images) all.push(LoadImage(p).then(Update));
	for (const p of window.PM2_MANIFEST.sounds) all.push(LoadSound(p).then(Update));
	await Promise.all(all);

	GameEnginePath.SetManifest(window.PM2_MANIFEST_PATHS);

	document.getElementById("loadtxt").textContent = "게임 모듈 로딩 중...";
}

// 모듈 로딩 실패 시 클래식 번들(game_compat.js)로 자동 폴백한다.
Boot().then(() => {
	return import("./main.js").then(() => {
		requestAnimationFrame(() => {
			const L = document.getElementById("loading");
			if (L) { L.remove(); }
		});
	}).catch((err) => {
		console.error("ES 모듈 로딩 실패 — 클래식 번들로 재시도", err);
		const s = document.createElement("script");
		s.src = "./game_compat.js";
		s.onerror = () => ShowFatal("모듈 로딩 실패: " + ((err && err.message) || err) + "\n클래식 번들(game_compat.js) 로드에도 실패했습니다.");
		document.body.appendChild(s);
		s.addEventListener("load", () => {
			const L = document.getElementById("loading");
			if (L) { L.remove(); }
		});
	});
}).catch((e) => ShowFatal("부트 실패: " + ((e && e.stack) || e)));
