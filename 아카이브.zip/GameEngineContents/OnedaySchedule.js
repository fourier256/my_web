// OnedaySchedule.h / OnedaySchedule.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { GameEngineMath, float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { Date } from "./Date.js";
import { PM2RenderOrder, ScheduleLabel, IconCode } from "./ContentsEnums.js";

export class OnedaySchedule extends GameEngineActor {
	constructor() {
		super();
		this.DateValue = new Date();
		this.ScheduleValue = ScheduleLabel.Null;
		this.Today = new Date();
		this.NextDate = new Date();
		this.ScheduleOrder = 0;
		this.DayNumRender = new NumberRenderObject();
		this.DayNumRenderScale_1 = new float4(20, 20);
		this.DayNumRenderScale_2 = new float4(10, 20);
		this.DayNumRenderPos_1 = new float4(10, 10);
		this.DayNumRenderPos_2 = new float4(15, 10);
		this.IconRender = null;
		this.IconRenderScale = new float4(40, 40);
	}

	UpdateDayNumRender() {
		if (this.DateValue.IsNullDate() || this.NextDate.Greater(this.DateValue)) {
			this.DayNumRender.Off();
		}
		else {
			this.DayNumRender.On();

			if (1 === GameEngineMath.GetLenth(this.DateValue.GetDay())) {
				this.DayNumRender.SetImage("Num_Age.bmp", this.DayNumRenderScale_1, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
				this.DayNumRender.SetValue(this.DateValue.GetDay());
				this.DayNumRender.SetRenderPos(this.DayNumRenderPos_1);
			}
			else if (2 === GameEngineMath.GetLenth(this.DateValue.GetDay())) {
				this.DayNumRender.SetImage("Num.bmp", this.DayNumRenderScale_2, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
				this.DayNumRender.SetValue(this.DateValue.GetDay());
				this.DayNumRender.SetRenderPos(this.DayNumRenderPos_2);
			}
		}
	}

	GetScheduleOrder() {
		return this.ScheduleOrder;
	}

	SetScheduleOrder(_Order) {
		this.ScheduleOrder = _Order;
	}

	Start() {
		this.SetDayNumRender();
		this.IconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu1_Display_Shadow);
		this.IconRender.SetScale(this.IconRenderScale);
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.NextDate = this.Today.GetNextDate();
		}

		switch (this.ScheduleValue) {
			case ScheduleLabel.Null:
				this.IconRender.SetFrame(IconCode["빈칸"]);
				break;
			case ScheduleLabel["자연과학"]:
				this.IconRender.SetFrame(IconCode["자연과학"]);
				break;
			case ScheduleLabel["신학"]:
				this.IconRender.SetFrame(IconCode["신학"]);
				break;
			case ScheduleLabel["군사학"]:
				this.IconRender.SetFrame(IconCode["군사학"]);
				break;
			case ScheduleLabel["검술"]:
				this.IconRender.SetFrame(IconCode["검술"]);
				break;
			case ScheduleLabel["격투술"]:
				this.IconRender.SetFrame(IconCode["격투술"]);
				break;
			case ScheduleLabel["마법"]:
				this.IconRender.SetFrame(IconCode["마법"]);
				break;
			case ScheduleLabel["시문학"]:
				this.IconRender.SetFrame(IconCode["시문학"]);
				break;
			case ScheduleLabel["예법"]:
				this.IconRender.SetFrame(IconCode["예법"]);
				break;
			case ScheduleLabel["무용"]:
				this.IconRender.SetFrame(IconCode["무용"]);
				break;
			case ScheduleLabel["미술"]:
				this.IconRender.SetFrame(IconCode["미술"]);
				break;
			case ScheduleLabel["집안일"]:
				this.IconRender.SetFrame(IconCode["집안일"]);
				break;
			case ScheduleLabel["보모"]:
				this.IconRender.SetFrame(IconCode["아이보기"]);
				break;
			case ScheduleLabel["여관"]:
				this.IconRender.SetFrame(IconCode["여관"]);
				break;
			case ScheduleLabel["농장"]:
				this.IconRender.SetFrame(IconCode["농장"]);
				break;
			case ScheduleLabel["교회"]:
				this.IconRender.SetFrame(IconCode["신학"]);
				break;
			case ScheduleLabel["요리점"]:
				this.IconRender.SetFrame(IconCode["레스토랑"]);
				break;
			case ScheduleLabel["나무꾼"]:
				this.IconRender.SetFrame(IconCode["나무꾼"]);
				break;
			case ScheduleLabel["미용실"]:
				this.IconRender.SetFrame(IconCode["미용실"]);
				break;
			case ScheduleLabel["미장이"]:
				this.IconRender.SetFrame(IconCode["미장이"]);
				break;
			case ScheduleLabel["사냥꾼"]:
				this.IconRender.SetFrame(IconCode["사냥꾼"]);
				break;
			case ScheduleLabel["묘지기"]:
				this.IconRender.SetFrame(IconCode["묘지기"]);
				break;
			case ScheduleLabel["가정교사"]:
				this.IconRender.SetFrame(IconCode["가정교사"]);
				break;
			case ScheduleLabel["주점"]:
				this.IconRender.SetFrame(IconCode["주점"]);
				break;
			case ScheduleLabel["어둠의주점"]:
				this.IconRender.SetFrame(IconCode["어둠의주점"]);
				break;
			case ScheduleLabel["어둠의전당"]:
				this.IconRender.SetFrame(IconCode["어둠의전당"]);
				break;
			case ScheduleLabel["동부수풀지대"]:
				this.IconRender.SetFrame(IconCode["무사수행_동부산림지대"]);
				break;
			case ScheduleLabel["남부폭포지대"]:
				this.IconRender.SetFrame(IconCode["남부폭포지대"]);
				break;
			case ScheduleLabel["북부빙산지대"]:
				this.IconRender.SetFrame(IconCode["북부빙산지대"]);
				break;
			case ScheduleLabel["서부사막지대"]:
				this.IconRender.SetFrame(IconCode["서부사막지대"]);
				break;
			case ScheduleLabel["자유행동"]:
				this.IconRender.SetFrame(IconCode["자유행동"]);
				break;
			case ScheduleLabel["바캉스"]:
				this.IconRender.SetFrame(IconCode["바캉스"]);
				break;
			case ScheduleLabel["간호"]:
				this.IconRender.SetFrame(IconCode["간호"]);
				break;
			case ScheduleLabel["요양"]:
				this.IconRender.SetFrame(IconCode["요양"]);
				break;
			case ScheduleLabel["감시"]:
				this.IconRender.SetFrame(IconCode["감시"]);
				break;
			default:
				break;
		}

	}

	SetDayNumRender() {
		this.DayNumRender.SetOwner(this);
		this.DayNumRender.SetImage("Num.bmp", this.DayNumRenderScale_2, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.DayNumRender.SetAlign(Align.Right);
		this.DayNumRender.SetValue(10);
	}
}
