// TitleBackground.h / TitleBackground.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export class TitleBackground extends GameEngineActor {
	constructor() {
		super();
		this.Render = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.Render = this.CreateRender("blackbackground.BMP", 0);
		this.Render.SetScaleToImage();
	}
}
