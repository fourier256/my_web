// RPGOlive.h / RPGOlive.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineRender, FrameAnimationParameter } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

// enum class PlayerState
export const PlayerState = Object.freeze({
	IDLE: 0,
	MOVE: 1,
});


export class RPGOlive extends GameEngineActor {
	static MainPlayer = null;

	constructor() {
		super();
		this.AccTime = 0.0;
		this.StartFrame = 0;
		this.MoveSpeed = 100.0;
		this.AnimationRender = null;
		this.StateValue = PlayerState.IDLE;
		this.DirString = "Right_";
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		RPGOlive.MainPlayer = this;
		if (false === GameEngineInput.IsKey("LeftMove"))
		{
			GameEngineInput.CreateKey("LeftMove", 'A'.charCodeAt(0));
			GameEngineInput.CreateKey("RightMove", 'D'.charCodeAt(0));
			GameEngineInput.CreateKey("DownMove", 'S'.charCodeAt(0));
			GameEngineInput.CreateKey("UpMove", 'W'.charCodeAt(0));
		}

		this.AnimationRender = this.CreateRender(1);
		this.AnimationRender.SetScale(new float4(40, 60));

		// 원본: CreateAnimation({ .AnimationName = "Down_Move", .ImageName = "Olive.bmp", .Start = 0, .End = 1, .InterTime = 0.2f });
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Down_Move", "Olive.bmp", 0, 1, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Down_Idle", "Olive.bmp", 0, 0, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Up_Move", "Olive.bmp", 2, 3, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Up_Idle", "Olive.bmp", 2, 2, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Left_Move", "Olive.bmp", 4, 5, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Left_Idle", "Olive.bmp", 4, 4, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Right_Move", "Olive.bmp", 6, 7, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Right_Idle", "Olive.bmp", 6, 6, 0, 0.2, true));

		this.ChangeState(PlayerState.IDLE);
	}

	Update(_DeltaTime) {
		this.UpdateState(_DeltaTime);

	}

	Render(_Time) {
	}


	DirCheck(_AnimationName) {
		const PrevDirString = this.DirString;
		this.AnimationRender.ChangeAnimation(this.DirString + _AnimationName);

		if (GameEngineInput.IsPress("LeftMove"))
		{
			this.DirString = "Left_";
		}
		else if (GameEngineInput.IsPress("RightMove"))
		{
			this.DirString = "Right_";
		}
		else if (GameEngineInput.IsPress("UpMove"))
		{
			this.DirString = "Up_";
		}
		else if (GameEngineInput.IsPress("DownMove"))
		{
			this.DirString = "Down_";
		}

		if (PrevDirString !== this.DirString)
		{
			this.AnimationRender.ChangeAnimation(this.DirString + _AnimationName);
		}
	}


	ChangeState(_State) {
		const NextState = _State;
		const PrevState = this.StateValue;

		this.StateValue = NextState;

		switch (NextState)
		{
			case PlayerState.IDLE:
				this.IdleStart();
				break;

			case PlayerState.MOVE:
				this.MoveStart();
				break;

			default:
				break;
		}
	}

	UpdateState(_Time) {
		switch (this.StateValue)
		{
			case PlayerState.IDLE:
				this.IdleUpdate(_Time);
				break;

			case PlayerState.MOVE:
				this.MoveUpdate(_Time);
				break;

			default:
				break;
		}
	}

	IdleStart() {
		this.DirCheck("Idle");
	}

	IdleUpdate(_DeltaTime) {
		if (GameEngineInput.IsPress("LeftMove") || GameEngineInput.IsPress("RightMove") || GameEngineInput.IsPress("UpMove") || GameEngineInput.IsPress("DownMove"))
		{
			this.ChangeState(PlayerState.MOVE);
			return;
		}
	}

	IdleEnd() {
	}

	MoveStart() {
		this.DirCheck("Move");
	}

	MoveUpdate(_DeltaTime) {
		if (false === GameEngineInput.IsPress("LeftMove") &&
			false === GameEngineInput.IsPress("RightMove") &&
			false === GameEngineInput.IsPress("UpMove") &&
			false === GameEngineInput.IsPress("DownMove"))
		{
			this.ChangeState(PlayerState.IDLE);
			return;
		}

		if (GameEngineInput.IsPress("LeftMove"))
		{
			this.SetMove(float4.Left.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("RightMove"))
		{
			this.SetMove(float4.Right.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("UpMove"))
		{
			this.SetMove(float4.Up.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("DownMove"))
		{
			this.SetMove(float4.Down.scale(this.MoveSpeed * _DeltaTime));
		}
		this.DirCheck("Move");
	}

	MoveEnd() {
	}
}
