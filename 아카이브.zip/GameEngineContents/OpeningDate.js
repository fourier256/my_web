// OpeningDate.h / OpeningDate.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { Date } from "./Date.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class OpeningDate extends GameEngineActor {
	constructor() {
		super();
		this.OpeningDateRender = null;
		this.MonthNum = new NumberRenderObject();
		this.DayNum = new NumberRenderObject();
		this.OliveBirthDay = new Date();
	}

	UpdateOliveBirthDay() {
		this.OliveBirthDay = Olive.OlivePlayer.GetOliveBirthDay();
		this.MonthNum.SetValue(this.OliveBirthDay.GetMonth());
		this.DayNum.SetValue(this.OliveBirthDay.GetDay());
		this.MonthNum.SetMove(new float4(120, 0));
		this.DayNum.SetMove(new float4(250, 0));
	}

	Start() {
		this.SetPos(new float4(400, 300));

		this.OpeningDateRender = this.CreateRender("OpeningDate.bmp", PM2RenderOrder.Menu0);
		this.OpeningDateRender.SetScaleToImage();

		this.MonthNum.SetOwner(this);
		this.MonthNum.SetImage("OpeningDayNum.bmp", new float4(40, 63), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.MonthNum.SetAlign(Align.Right);
		this.MonthNum.SetValue(11);
		this.MonthNum.SetMove(new float4(120, 0));

		this.DayNum.SetOwner(this);
		this.DayNum.SetImage("OpeningDayNum.bmp", new float4(40, 63), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.DayNum.SetAlign(Align.Right);
		this.DayNum.SetValue(11);
		this.DayNum.SetMove(new float4(250, 0));

		this.Off();
	}
}
