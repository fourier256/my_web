// ContentsEnums.h 의 전사
// enum class X { ... } → Object.freeze({ "멤버": 값, ... })
// 값: 선언 순서대로 0부터, 명시 초기화가 있으면 그 값(이후 멤버는 +1씩)

export const PM2RenderOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

export const PM2ActorOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

export const PM2CollisionOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

// ── 이하 추가 전사: ContentsEnums.h의 나머지 enum들 ──

// enum class IconCode
export const IconCode = Object.freeze({
	"Null": -1,

	//무기
	"곤봉": 0,
	"구리검": 1,
	"철제단검": 2,
	"철제장검": 3,
	"양손철검": 4,
	"미스릴검": 5,
	"동방도": 6,
	"은사의검": 7,
	"무신의검": 8,
	"발키리의검": 9,

	//방어구
	"가죽갑옷": 10,
	"쇠사슬갑옷": 11,
	"철갑옷": 12,
	"미스릴갑옷": 13,
	"실크갑옷": 14,

	//아이템
	"쾌유환": 15,
	"폭탄": 16,
	"인형": 17,
	"찻잔": 18,
	"책": 19,
	"시집": 20,
	"정령의반지": 21,
	"유니콘뿔피리": 22,
	"악마의펜던트": 23,
	"비너스목걸이": 24,
	"칠흑의비늘": 25,
	"고양이의눈": 26,
	"드래곤의이빨": 27,
	"인어의눈물": 28,
	"은색모피": 29,
	"유혹의향수": 30,
	"축복의빵가루": 31,
	"귀부인의반지": 32,
	"극락조의알": 33,
	"명장의붓": 34,
	"얼음의조각": 35,
	"무적의반지": 36,
	"왕가의비파": 37,
	"케이크": 38,
	"생선조개": 39, //??
	"고기요리": 40, //??
	"요정의꿀": 41,

	//의류
	"평상복": 42,
	"하복": 43,
	"동복": 44,
	"목면드레스": 45,
	"실크드레스": 46,
	"가죽드레스": 47,
	"가시드레스": 48,
	"경국의로브": 49,
	"빈칸": 50,
	"악마의드레스": 51,
	"용의레오타드": 52,

	//교육
	"자연과학": 53,
	"시문학": 54,
	"신학": 55,
	"군사학": 56,
	"검술": 57,
	"격투술": 58,
	"마법": 59,
	"예법": 60,
	"미술": 61,
	"무용": 62,

	//아르바이트
	"집안일": 63,
	"아이보기": 64,
	"여관": 65,
	"농장": 66,
	"레스토랑": 67,
	"나무꾼": 68,
	"미용실": 69,
	"미장이": 70,
	"사냥꾼": 71,
	"묘지기": 72,
	"가정교사": 73,
	"주점": 74,
	"어둠의주점": 75,
	"어둠의전당": 76,

	//휴식
	"무사수행_동부산림지대": 77,
	"자유행동": 78,
	"바캉스": 79,
	"간호": 80,
	"요양": 81,
	"감시": 82,

	//상점가
	"무기점": 83,
	"의류점": 84,
	"잡화점": 85,
	"병원": 86,

	//수호신
	"태양신_솔": 87,
	"달신_더문": 88,
	"화성신_마르스": 89,
	"수성신_머큐리": 90,
	"목성신_주피터": 91,
	"금성신_비너스": 92,
	"토성신_새턴": 93,
	"천왕성신_우라누스": 94,
	"해왕성신_넵튠": 95,
	"명왕성신_하데스": 96,

	//무사수행
	"서부사막지대": 97,
	"남부폭포지대": 98,
	"북부빙산지대": 99,

	//상태
	"불량상태": 100,
	"질병상태": 101,
	"연애상태": 102,

	//떠돌이행상인
	"고대의우유": 103,
	"풍유환": 104

});

// enum class StatusName
export const StatusName = Object.freeze({
	"Null": -1,

	"체력": 0,
	"근력": 1,
	"지능": 2,
	"기품": 3,
	"색기": 4,
	"도덕성": 5,
	"신앙": 6,
	"업보": 7,
	"감수성": 8,
	"스트레스": 9,

	"전사평가": 10,
	"전투기술": 11,
	"공격력": 12,
	"방어력": 13,

	"마법평가": 14,
	"마법기술": 15,
	"마력": 16,
	"항마력": 17,

	"사교평가": 18,
	"예의범절": 19,
	"예술": 20,
	"화술": 21,

	"가사평가": 22,
	"요리": 23,
	"청소세탁": 24,
	"성품": 25,

	"신장": 26,
	"체중": 27,
	"가슴": 28,
	"허리": 29,
	"엉덩이": 30,

	"인맥": 31,

	"모성": 32,
	"왕자관계": 33,
	"아버지관계": 34,
	"집사관계": 35,
	"몬스터살육수": 36,
	"교육및알바횟수": 37,
	"마왕이벤트횟수": 38
});

// enum class BloodType
export const BloodType = Object.freeze({
	"Null": -1,
	A: 0,
	B: 1,
	O: 2,
	AB: 3
});

// enum class Zodiac
export const Zodiac = Object.freeze({
	"Null": -1,
	"염소자리": 0,
	"물병자리": 1,
	"물고기자리": 2,
	"양자리": 3,
	"황소자리": 4,
	"쌍둥이자리": 5,
	"게자리": 6,
	"사자자리": 7,
	"처녀자리": 8,
	"천칭자리": 9,
	"전갈자리": 10,
	"사수자리": 11
});

// enum class PatronGod
export const PatronGod = Object.freeze({
	"Null": -1,
	"태양신_솔": 87,
	"달신_더문": 88,
	"화성신_마르스": 89,
	"수성신_머큐리": 90,
	"목성신_주피터": 91,
	"금성신_비너스": 92,
	"토성신_새턴": 93,
	"천왕성신_우라누스": 94,
	"해왕성신_넵튠": 95,
	"명왕성신_하데스": 96
});

// enum class Diet
export const Diet = Object.freeze({
	"Null": -1,
	"무리하지_않는다": 0,
	"어쨌든_튼튼하게": 1,
	"얌전한_아이로": 2,
	"다이어트_시킨다": 3
});

// enum class ScheduleLabel
export const ScheduleLabel = Object.freeze({
	"Null": -1,

	//교육
	"자연과학": 0,
	"신학": 1,
	"군사학": 2,
	"검술": 3,
	"격투술": 4,
	"마법": 5,
	"시문학": 6,
	"예법": 7,
	"무용": 8,
	"미술": 9,

	//아르바이트
	"집안일": 10,
	"보모": 11,
	"여관": 12,
	"농장": 13,
	"교회": 14,
	"요리점": 15,
	"나무꾼": 16,
	"미용실": 17,
	"미장이": 18,
	"사냥꾼": 19,
	"묘지기": 20,
	"가정교사": 21,
	"주점": 22,
	"어둠의주점": 23,
	"어둠의전당": 24,

	//무사수행
	"동부수풀지대": 25,
	"남부폭포지대": 26,
	"북부빙산지대": 27,
	"서부사막지대": 28,

	//휴식
	"자유행동": 29,
	"바캉스": 30,
	"간호": 31,
	"요양": 32,
	"감시": 33,

	End: 34

});

// enum class Season
export const Season = Object.freeze({
	"Null": -1,
	Spring: 0,
	Summer: 1,
	Fall: 2,
	Winter: 3
});

// ─── 이하: ContentsEnums.h의 나머지 enum들 (기존 파일에 누락되어 h 원문 그대로 전사) ───

// enum class IconCode
