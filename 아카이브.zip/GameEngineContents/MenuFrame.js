// MenuFrame.h / MenuFrame.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { PM2RenderOrder } from "./ContentsEnums.js"; // 원본 include (본문에서는 매개변수 타입으로만 사용 — JS에서는 int로 통일)

// enum class MenuFrameStyleEnum
export const MenuFrameStyleEnum = Object.freeze({
	"Null": -1,
	Gold: 0,
	Silver: 1,
	Nomal: 2
});

export class MenuFrame extends GameEngineActor {
	constructor() {
		super();
		this.MenuFrameScale = new float4(0, 0, 0, 1); // float4 MenuFrameScale = {};
		this.MenuFrameStyle = MenuFrameStyleEnum.Null;
		this.FrameRender = [null, null, null, null, null, null, null, null, null]; // GameEngineRender* FrameRender[9] = {};
		this.FrameRenderOrder = 0;
	}

	// 원본: InitMenuFrameRender(int) 오버로드와 InitMenuFrameRender(PM2RenderOrder) 오버로드
	// (후자는 static_cast<int> 위임) — JS에서 하나로 통합. 기본 인자 _style = Nomal 은 h의 디폴트 값.
	InitMenuFrameRender(_Order, _style = MenuFrameStyleEnum.Nomal) {
		this.FrameRenderOrder = _Order;

		for (const i of this.FrameRender) {
			if (null !== i) {
				MsgAssert("이미 사용하고 있는 MenuFrameRender를 초기화하려고 했습니다")
			}
		}

		this.MenuFrameStyle = _style;

		switch (this.MenuFrameStyle) {
			case MenuFrameStyleEnum.Gold:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample1.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			case MenuFrameStyleEnum.Silver:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample2.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			case MenuFrameStyleEnum.Nomal:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample3.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			default:
				break;
		}
	}

	SetMenuFrameScale(_Scale) {
		if (_Scale.x < 34 || _Scale.y < 34) {
			MsgAssert("메뉴프레임의 최소 크기는 34*34입니다")
		}

		this.MenuFrameScale = _Scale;

		for (let i = 0; i < 9; i++) {
			if (i == 0 || i == 2 || i == 6 || i == 8) {
				this.FrameRender[i].SetScale(new float4(16, 16));
			}
			else if (i == 1 || i == 7) {
				this.FrameRender[i].SetScale(new float4(this.MenuFrameScale.x - 32, 16));
			}
			else if (i == 3 || i == 5) {
				this.FrameRender[i].SetScale(new float4(16, this.MenuFrameScale.y - 32));
			}
			else if (i == 4) {
				this.FrameRender[i].SetScale(this.MenuFrameScale.sub(new float4(32, 32)));
			}

			switch (i) {
				case 0:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, -this.MenuFrameScale.hy() + 8));
					break;
				case 1:
					this.FrameRender[i].SetPosition(new float4(0, -this.MenuFrameScale.hy() + 8));
					break;
				case 2:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, -this.MenuFrameScale.hy() + 8));
					break;
				case 3:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, 0));
					break;
				case 4:
					this.FrameRender[i].SetPosition(new float4(0, 0));
					break;
				case 5:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, 0));
					break;
				case 6:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, this.MenuFrameScale.hy() - 8));
					break;
				case 7:
					this.FrameRender[i].SetPosition(new float4(0, this.MenuFrameScale.hy() - 8));
					break;
				case 8:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, this.MenuFrameScale.hy() - 8));
					break;
				default:
					break;
			}
		}
	}

	GetFrameRender() {
		return this.FrameRender;
	}

	GetMenuFrameScale() {
		return this.MenuFrameScale;
	}

	GetFrameRenderOrder() {
		return this.FrameRenderOrder;
	}

	FrameRenderOn() {
		for (const i of this.FrameRender) {
			i.On();
		}
	}

	FrameRenderOff() {
		for (const i of this.FrameRender) {
			i.Off();
		}
	}

	SetMoveFrameRender(_Pos) {
		for (const i of this.FrameRender) {
			i.SetMove(_Pos);
		}
	}

	SetPosFrameRender(_Pos) {
		for (let i = 0; i < 9; i++) {
			switch (i) {
				case 0:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, -this.MenuFrameScale.hy() + 8)));
					break;
				case 1:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, -this.MenuFrameScale.hy() + 8)));
					break;
				case 2:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, -this.MenuFrameScale.hy() + 8)));
					break;
				case 3:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, 0)));
					break;
				case 4:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, 0)));
					break;
				case 5:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, 0)));
					break;
				case 6:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, this.MenuFrameScale.hy() - 8)));
					break;
				case 7:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, this.MenuFrameScale.hy() - 8)));
					break;
				case 8:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, this.MenuFrameScale.hy() - 8)));
					break;
				default:
					break;
			}
		}

	}

	Start() {

	}

	Update(_Deltatime) {

	}

	Render(_Time) {

	}
}
