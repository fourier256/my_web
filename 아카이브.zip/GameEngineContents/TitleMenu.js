// TitleMenu.h / TitleMenu.cpp 의 전사
import { GameEngineRender } from "../GameEngineCore/GameEngineRender.js";
import { Button } from "../GameEngineCore/Button.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { SelectionMenu } from "./SelectionMenu.js";
import { GaugeRenderObject } from "./GaugeRenderObject.js"; // 원본 include (본문 미사용)
import { MenuFrameStyleEnum } from "./MenuFrame.js";
import { PM2ActorOrder, PM2RenderOrder } from "./ContentsEnums.js";

export class TitleMenu extends SelectionMenu {
	constructor() {
		super();
		this.TextRender = null;
	}

	static LevelChangeToFirstSet(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("FirstSet");
	}

	static LevelChangeToOpening(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("Opening");
	}

	static LevelChangeToRaisingSim(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("RaisingSim");
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(3, new float4(400, 250), 230.0, PM2ActorOrder.Menu0_Button, PM2RenderOrder.Menu0_Button);
		this.GetSelectButtons()[0].SetClickCallBack(TitleMenu.LevelChangeToFirstSet);
		this.GetSelectButtons()[1].SetClickCallBack(TitleMenu.LevelChangeToOpening);
		this.GetSelectButtons()[2].SetClickCallBack(TitleMenu.LevelChangeToRaisingSim);
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 0, "처음부터 시작");
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 1, "처음부터 (오프닝 스킵)");
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 2, "시간을 되돌린다");
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['LevelChangeToFirstSet', 'LevelChangeToOpening', 'LevelChangeToRaisingSim']) {
	Object.defineProperty(TitleMenu.prototype, __m, { value: function (...args) { return TitleMenu[__m](...args); }, writable: true, configurable: true });
}

