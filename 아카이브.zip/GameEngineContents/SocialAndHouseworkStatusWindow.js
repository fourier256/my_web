// SocialAndHouseworkStatusWindow.h / SocialAndHouseworkStatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class SocialAndHouseworkStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(670, 455);

		this.Decorum = 0;
		this.DecorumRender = null;
		this.Art = 0;
		this.ArtRender = null;
		this.Conversation = 0;
		this.ConversationRender = null;

		this.Cooking = 0;
		this.CookingRender = null;
		this.Cleaning = 0;
		this.CleaningRender = null;
		this.Temperament = 0;
		this.TemperamentRender = null;

		this.Max = 100;

		this.Style = GaugeFrameStyle.Detail;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.DecorumRender = this.InsertStatus("예의범절", this.Max, this.Style);
		this.ArtRender = this.InsertStatus("예술", this.Max, this.Style);
		this.ConversationRender = this.InsertStatus("화술", this.Max, this.Style);

		this.CookingRender = this.InsertStatus("요리", this.Max, this.Style);
		this.CleaningRender = this.InsertStatus("청소세탁", this.Max, this.Style);
		this.TemperamentRender = this.InsertStatus("성품", this.Max, this.Style);

		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.Decorum !== Olive.OlivePlayer.GetStatue().Decorum) {
			this.Decorum = Olive.OlivePlayer.GetStatue().Decorum;
			this.DecorumRender.UpdateValue(this.Decorum);
		}
		if (this.Art !== Olive.OlivePlayer.GetStatue().Art) {
			this.Art = Olive.OlivePlayer.GetStatue().Art;
			this.ArtRender.UpdateValue(this.Art);
		}
		if (this.Conversation !== Olive.OlivePlayer.GetStatue().Conversation) {
			this.Conversation = Olive.OlivePlayer.GetStatue().Conversation;
			this.ConversationRender.UpdateValue(this.Conversation);
		}
		if (this.Cooking !== Olive.OlivePlayer.GetStatue().Cooking) {
			this.Cooking = Olive.OlivePlayer.GetStatue().Cooking;
			this.CookingRender.UpdateValue(this.Cooking);
		}
		if (this.Cleaning !== Olive.OlivePlayer.GetStatue().Cleaning) {
			this.Cleaning = Olive.OlivePlayer.GetStatue().Cleaning;
			this.CleaningRender.UpdateValue(this.Cleaning);
		}
		if (this.Temperament !== Olive.OlivePlayer.GetStatue().Temperament) {
			this.Temperament = Olive.OlivePlayer.GetStatue().Temperament;
			this.TemperamentRender.UpdateValue(this.Temperament);
		}
	}
}
