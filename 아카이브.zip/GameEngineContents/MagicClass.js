// MagicClass.h / MagicClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class MagicClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Magic.bmp", "Animation_Background_Magic.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 11, 0, 3, 12, 13, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 14, 17, new float4(-85, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 18, 19, new float4(-25, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_1, 20, 21, new float4(115, -30));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_1, 22, 23, new float4(-87, -30));
		this.SetObj5(PM2RenderOrder.Menu2_Obj_1, 24, 27, new float4(-165, -37));

		// 원본: GetStatusVarianceMin().SetStatus({.Stress = 0, .MagicSkill = 1, .MagicAttack = 0});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicSkill = 1;
		StatusParaMin.MagicAttack = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({.Stress = 1,.MagicSkill = 1, .MagicAttack = 2 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicSkill = 1;
		StatusParaMax.MagicAttack = 2;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-60);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
