// EndingPortrait.h / EndingPortrait.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { Ending } from "./EndingLevel.js";
import { EndingDialog } from "./EndingDialog.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PM2ActorOrder } from "./ContentsEnums.js";

export class EndingPortrait extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.Background = null;
		// 원본: Ending* OliveEnding = nullptr; — EndingLevel::OliveEnding 멤버를 가리키는 포인터.
		// JS에는 값(열거형)에 대한 참조가 없으므로 현재값을 읽는 클로저로 전사했다.
		// (원본 *OliveEnding 역참조 → this.OliveEnding() 호출, Update 참고)
		this.OliveEnding = null;
		this.Potrait = null;
		this.AcEndingDialog = null;
		this.AcOlive = null;
	}

	On() {
		// 원본: GameEngineObject::On();
		GameEngineObject.prototype.On.call(this);
		this.AcEndingDialog.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		GameEngineObject.prototype.Off.call(this);
		this.AcEndingDialog.Off();
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.Background = this.CreateRender("EndingPortrait.bmp", PM2RenderOrder.BackGround);
		this.Background.SetScaleToImage();
		// 원본: OliveEnding = dynamic_cast<EndingLevel*>(GetLevel())->GetOliveEnding();
		this.OliveEnding = () => this.GetLevel().GetOliveEnding();
		this.Potrait = this.CreateRender(PM2RenderOrder.BackGroundObj);
		this.AcEndingDialog = this.GetLevel().CreateActor(EndingDialog, PM2ActorOrder.Dialog1);
		this.Off();
	}

	Update(_DeltaTime) {
		switch (this.OliveEnding())
		{
			case Ending.Null:
				break;
			case Ending["마왕"]:
				this.Potrait.SetImage("PrincessOfDarkness.bmp");
				this.AcEndingDialog.UpdateText("다음날, " + Olive.OlivePlayer.GetOliveFirstName() + "는 홀연히 모습을 감추고,\n 두번 다시 집에 돌아오지 않았다고 한다……\n올리브의 소식은 아직도 아무도 모른다.\n단, 떠돌이 검사가 용암지대의 동굴에서,\n 마왕의 축제를 잠시 보았는데, 그 마왕은 \n젊은 여자의 모습이었다고 한다……\n");
				break;
			case Ending["SM여왕"]:
				this.Potrait.SetImage("BondageQueen.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 비밀 클럽에서 쇼를 하게 되었다…\n 아- 아…");
				break;
			case Ending["암흑가의보스"]:
				this.Potrait.SetImage("CrimeBoss.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 집에서 가져온 돈으로 무시무시한 옷을 입고, 암흑가의 불략배를 두드리는 나날을 보내게 되었다…\n 아- 아…");
				break;
			case Ending["폭력배"]:
				this.Potrait.SetImage("Bandit.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 뒷골목의 암흑가에 있으면서, 불량배들의 친구가 되었다…\n 아- 아…");
				break;
			case Ending["고급창부"]:
				this.Potrait.SetImage("RefineHarlot.bmp");
				this.AcEndingDialog.UpdateText("호기심에 들렀던 뒷골목의 거리에 발을 딛게 된 " + Olive.OlivePlayer.GetOliveFirstName() + "…\n 그것이" + Olive.OlivePlayer.GetOliveFirstName() + "의 운명의 길이었다……");
				break;
			case Ending["사기꾼"]:
				this.Potrait.SetImage("ConArtist.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 사기꾼의 길을 걷게 되었다…\n 아- 아…");
				break;
			case Ending["창부"]:
				this.Potrait.SetImage("Harlot.bmp");
				this.AcEndingDialog.UpdateText("호기심에 들렀던 뒷골목의 거리에 발을 딛게 된 " + Olive.OlivePlayer.GetOliveFirstName() + "…\n 그것이" + Olive.OlivePlayer.GetOliveFirstName() + "의 운명의 길이었다……");
				break;
			case Ending["여왕"]:
				this.Potrait.SetImage("Queen.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 국왕으로부터 왕위를 \n계승받아, 왕국의 새로운 여왕이 되었다.");
				break;
			case Ending["재상"]:
				this.Potrait.SetImage("PrimeMinister.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 재상이 되기\n위해 왕궁에서 정치 공부를 시작했다…");
				break;
			case Ending["박사"]:
				this.Potrait.SetImage("Scholar.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕립 대학원에서 학문\n을 추구하는 생활을 시작했다…");
				break;
			case Ending["대신"]:
				this.Potrait.SetImage("CabinetMinister.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 대신이 되어, \n성에 들어가 정치 공부를 시작했다…");
				break;
			case Ending["대주교"]:
				this.Potrait.SetImage("ArchBishop.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 주교가 되기 위\n하여, 왕궁에서 공부를 시작했다…");
				break;
			case Ending["학사"]:
				this.Potrait.SetImage("Researcher.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕립 대학원의 학사가 되\n어, 학문의 길을 걸었다…");
				break;
			case Ending["재판관"]:
				this.Potrait.SetImage("Judge.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국 최초의 여성 재판관\n이 되었다…");
				break;
			case Ending["수녀"]:
				this.Potrait.SetImage("Nun.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 성당에 들어가, 성직자\n로서의 인생을 시작했다…");
				break;
			case Ending["궁녀"]:
				this.Potrait.SetImage("LadyInWaiting.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 성의 궁녀로서의 인생\n을 시작했다…");
				break;
			default:
				break;
		}

		this.Potrait.SetScaleToImage();
	}
}
