// GaugeRenderObject.h / GaugeRenderObject.cpp 의 전사
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { PM2RenderOrder } from "./ContentsEnums.js"; // 원본 include (본문 미사용)

// enum class GaugeFrameStyle
export const GaugeFrameStyle = Object.freeze({
	"Null": -1,
	Nomal: 0,
	Estemate: 1,
	Detail: 2,
	Physical: 3
});

export class GaugeRenderObject extends GameEngineObject {
	constructor() {
		super();
		this.Min = 0;
		this.Max = 0;
		this.StatusValue = 0;

		this.StartPos = float4.Zero;
		this.EndPos = float4.Zero;

		this.Style = GaugeFrameStyle.Null;

		this.Name = "";
		this.NameRender = null;
		this.TextHeight = 19;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(80, 20);
		this.TextRenderPos = new float4(-70, 0);

		this.StatusGaugeFrameRender_Layer1 = null;
		this.StatusGaugeEmptyRender = null;
		this.StatusGaugeRender = null;
		this.StatusGaugeFrameRender_Layer2 = null;
		this.StatusValueRender = new NumberRenderObject();
		this.DemicalPoint = null;
		this.StatusValueDemicalRender = new NumberRenderObject();
	}

	SetGaugeRender(_Order, _Name, _MaxValue, _Style) {
		this.Name = _Name;
		this.Style = _Style;
		this.Max = _MaxValue;

		// 원본: GameEngineActor* Actor = GetOwner<GameEngineActor>();
		const Actor = this.GetOwner();
		switch (this.Style) {
			case GaugeFrameStyle.Nomal:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Detail:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Detail.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Detail.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Estemate:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Estemate.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Estemate.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Physical:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Physical.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Physical.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(-5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));

				this.DemicalPoint = Actor.CreateRender("Num_Status_etc.bmp", _Order + 4);
				this.DemicalPoint.SetScale(new float4(10, 20));
				this.DemicalPoint.SetFrame(0);
				this.DemicalPoint.SetPosition(new float4(5, 0));

				this.StatusValueDemicalRender.SetOwner(Actor);
				this.StatusValueDemicalRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueDemicalRender.SetAlign(Align.Left);
				this.StatusValueDemicalRender.SetRenderPos(new float4(15, 0));
				this.StatusValueDemicalRender.SetNumOfDigits(2);
				{
					const DemicalValue = Math.trunc(this.StatusValue * 100) % 100;
					this.StatusValueDemicalRender.SetValue(DemicalValue);
				}
				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition().add(new float4(30, 0));
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			default:
				break;
		}

		this.UpdateValue(this.StatusValue);
	}

	UpdateValue(_Value) {
		if (this.Min > _Value || this.Max < _Value) {
			MsgAssert("범위를 초과하는 값을 입력하였습니다.")
		}

		if (0 >= _Value) {
			this.StatusGaugeEmptyRender.Off();
			this.StatusGaugeRender.Off();
		}
		else {
			this.StatusGaugeEmptyRender.On();
			this.StatusGaugeRender.On();
		}

		this.StatusValue = _Value;
		this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));

		if (this.Style === GaugeFrameStyle.Physical) {
			const DemicalValue = Math.trunc(this.StatusValue * 100) % 100;
			this.StatusValueDemicalRender.SetValue(DemicalValue);
		}
		this.StatusGaugeRender.SetPosition(float4.LerpClamp(this.StartPos, this.EndPos, _Value / (this.Max - this.Min)));
	}

	SetMove(_Move) {
		this.StatusGaugeFrameRender_Layer1.SetMove(_Move);
		this.StatusGaugeEmptyRender.SetMove(_Move);
		this.StatusGaugeRender.SetMove(_Move);
		this.StatusGaugeFrameRender_Layer2.SetMove(_Move);
		this.StatusValueRender.SetMove(_Move);
	}

	SetPosition(_Position) {
		this.StatusGaugeFrameRender_Layer1.SetPosition(_Position);
		this.StatusGaugeEmptyRender.SetPosition(_Position.add(float4.Right.scale(55.0)));
		this.StatusGaugeRender.SetPosition(_Position.add(float4.Left.scale(55.0)));
		this.StatusGaugeFrameRender_Layer2.SetPosition(_Position);
		this.StatusValueRender.SetRenderPos(_Position.add(float4.Left.scale(5.0)));
		this.NameRender.SetPosition(_Position.add(this.TextRenderPos).sub(this.TextBoxScale.half()));
		if (this.Style === GaugeFrameStyle.Physical) {
			this.StartPos = this.StatusGaugeRender.GetPosition().add(new float4(30, 0));
			this.DemicalPoint.SetPosition(_Position.add(float4.Right.scale(5.0)));
			this.StatusValueDemicalRender.SetRenderPos(_Position.add(float4.Right.scale(15.0)));
		}
		else {
			this.StartPos = this.StatusGaugeRender.GetPosition();
		}
		this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
		this.UpdateValue(this.StatusValue);
	}

	SetMin(_Min) {
		this.Min = _Min;
	}

	SetMax(_Max) {
		this.Max = _Max;
	}

	SetNameRender(_Name) {
		this.Name = _Name;
		this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}
}
