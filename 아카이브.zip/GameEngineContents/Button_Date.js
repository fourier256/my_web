// Button_Date.h / Button_Date.cpp 의 전사
import { GlobalButton } from "./GlobalButton.js";
import { Date } from "./Date.js";

export class Button_Date extends GlobalButton {
	constructor() {
		super();
		this.Value = new Date();
	}
}
