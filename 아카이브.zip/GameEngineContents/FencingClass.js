// FencingClass.h / FencingClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class FencingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Fencing.bmp", "Animation_Background_Fencing.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 5, 6, 7, new float4(165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 8, 11, new float4(105, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-85, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 16, 20, new float4(-155, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 21, 24, new float4(5, -20));

		// 원본: GetStatusVarianceMin().SetStatus({ .Stress = 0, .CombatSkill = 0, .CombatAttack = 1});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 0;
		StatusParaMin.CombatAttack = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Stress = 1,.CombatSkill = 1, .CombatAttack = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		StatusParaMax.CombatAttack = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
