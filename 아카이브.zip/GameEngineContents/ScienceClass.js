// ScienceClass.h / ScienceClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class ScienceClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Science.bmp", "Animation_Background_Science.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(-35, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(45, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-165, 12));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Faith = 0, .Stress = 0,.MagicDefense = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Faith = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 4, .Faith = 0,.Stress = 1, .MagicDefense = 0 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 4;
		StatusParaMax.Faith = 0;
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicDefense = 0;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-30);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
