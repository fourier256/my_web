// StatusWindow.h / StatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MenuFrame } from "./MenuFrame.js";
import { GaugeRenderObject, GaugeFrameStyle } from "./GaugeRenderObject.js";

export class StatusWindow extends MenuFrame {
	constructor() {
		super();
		this.StatusCount = 0;
		this.Gauges = [];
	}

	InsertStatus(_StatusName, _Max, _Style) {
		++this.StatusCount;
		this.SetMenuFrameScale(new float4(220.0 + 20.0, (this.StatusCount * 20.0) + 20.0));
		const InsertGaugePtr = new GaugeRenderObject();
		InsertGaugePtr.SetOwner(this);
		InsertGaugePtr.SetGaugeRender(this.GetFrameRenderOrder() + 1, _StatusName, _Max, _Style);
		this.Gauges.push(InsertGaugePtr);
		for (let i = 0; i < this.Gauges.length; ++i) {
			this.Gauges[i].SetPosition(float4.Up.scale(10).scale(this.Gauges.length - 1).add(float4.Down.scale(20).scale(i)));
		}
		return InsertGaugePtr;
	}

	Start() {

	}

	Update(_DeltaTime) {

	}
}
