// SecondScene.h / SecondScene.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class SecondScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.BackgroundRedner = null;

		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-300, -200);

		this.TextRenderShadow = null;
		this.TextShadowColor = RGB(0, 0, 0);
		this.TextShadowRenderPos = new float4(-300, -199);

		this.Script = "아버지.\n\n그동안 저를 애지중지 키워주셔서 고마워요.\n\n저는 아버지의 지도로, 이렇게 훌륭하게 성장했어요.\n\n아버지와 함께한 소녀 시절을 되돌아보면 여러가지가 떠올라요.\n\n모두 함께 공부한것도 즐거운 추억이에요.\n\n좋은 경험을 하게 해줘서 감사하고 있어요.";
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("SecondSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);

		this.TextRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.TextRenderShadow.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
		this.TextRenderShadow.SetPosition(this.TextShadowRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRenderShadow.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
	}
}
