// SchedulePlayer.h / SchedulePlayer.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineResources } from "../GameEngineCore/GameEngineResources.js";
import { Date } from "./Date.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { ScheduleAnimationPlayer } from "./ScheduleAnimationPlayer.js";
import { Olive } from "./Olive.js";
import { FoodCostDialog } from "./FoodCostDialog.js";
import { ScheduleDialog, ScheduleSituation } from "./ScheduleDialog.js";
import { MainMenu } from "./MainMenu.js";
import { SchedulePlayerGuage } from "./SchedulePlayerGuage.js";
import { ScheduleMessageBox } from "./ScheduleMessageBox.js";
import { PM2ActorOrder, Season, Diet, ScheduleLabel } from "./ContentsEnums.js";

// 원본: struct ScheduleSave
export class ScheduleSave {
	constructor(_Order = 0, _Date = new Date(), _Schedule = ScheduleLabel.Null) {
		this.Order = _Order;
		this.DateSave = _Date;
		this.Schedule = _Schedule;
	}
}

export class SchedulePlayer extends GameEngineActor {
	static AcSchedulePlayer = null;
	static IsPartOfScheduleEnd = false;

	constructor() {
		super();		this.IsPartOfScheduleEnd = false; // 원본 SchedulePlayer.h: bool IsPartOfScheduleEnd = 선언

		// construtor destructor
		SchedulePlayer.AcSchedulePlayer = this;
		this.Time = 1;
		this.Save = [];
		this.FirstUpdateCheck = false;
		this.ParentLevel = null;
		this.AcScheduleAnimationPlayer = null;
		this.AcScheduleCalendar = null;
		this.AcSchedulePlayerGuage = null;
		this.AcScheduleMessageBox = null;
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;
		this.AcFoodCostDialog = null;
		this.AcScheduleDialog = null;
		this.FirstScheduleUpdateCheck = false;
		this.DayCount = 0;
		this.BGMPlayer = null;
	}

	static GetAcSchedulePlayer() {
		return SchedulePlayer.AcSchedulePlayer;
	}

	GetSave() {
		return this.Save;
	}

	Off() {
		super.Off();
		this.AcScheduleAnimationPlayer.Off();
		this.AcFoodCostDialog.Off();
		this.AcPaintingClass.Off();
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();
		this.AcScheduleAnimationPlayer = this.ParentLevel.CreateActor(ScheduleAnimationPlayer, PM2ActorOrder.Menu2);
		this.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();

		this.AcDanceClass = this.ParentLevel.AcDanceClass;
		this.AcFencingClass = this.ParentLevel.AcFencingClass;
		this.AcFightingClass = this.ParentLevel.AcFightingClass;
		this.AcMagicClass = this.ParentLevel.AcMagicClass;
		this.AcPaintingClass = this.ParentLevel.AcPaintingClass;
		this.AcPoetryClass = this.ParentLevel.AcPoetryClass;
		this.AcProtocolClass = this.ParentLevel.AcProtocolClass;
		this.AcScienceClass = this.ParentLevel.AcScienceClass;
		this.AcStrategyClass = this.ParentLevel.AcStrategyClass;
		this.AcTheologyClass = this.ParentLevel.AcTheologyClass;

		this.AcFoodCostDialog = this.ParentLevel.CreateActor(FoodCostDialog, PM2ActorOrder.Menu2);
		this.AcScheduleDialog = this.ParentLevel.GetAcScheduleDialog();
		this.AcSchedulePlayerGuage = this.ParentLevel.CreateActor(SchedulePlayerGuage, PM2ActorOrder.Menu2);
		this.AcScheduleMessageBox = this.ParentLevel.CreateActor(ScheduleMessageBox, PM2ActorOrder.Menu2);

		this.BGMPlayer = this.ParentLevel.GetBGMPlayer();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!this.FirstUpdateCheck) {
			this.FirstUpdateCheck = true;
			this.PayDiet();
			this.AcFoodCostDialog.On();
			this.BGMPlayer.Stop();
			// 원본: *BGMPlayer = GameEngineResources::GetInst().SoundPlayToControl("13_Training.mp3");
			// (GetBGMPlayer() 가 &BGMPlayer 반환 — 참조 대상인 RaisingSimLevel.BGMPlayer 에 대입)
			this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("13_Training.mp3");
			this.BGMPlayer = this.ParentLevel.BGMPlayer;
		}
		else if (!this.AcFoodCostDialog.IsUpdate()) {
			if (!this.FirstScheduleUpdateCheck) {
				SchedulePlayer.IsPartOfScheduleEnd = false;
				this.FirstScheduleUpdateCheck = true;
				this.AcScheduleDialog.UpdateScheduleDialog(this.Save[0].Schedule, ScheduleSituation.ScheduleStart);
			}
			else if (!this.AcScheduleDialog.IsUpdate()) {
				// 원본: ScheduleSave Prev = *(Save.begin()); — 값 복사이나 JS 참조로 동등(팝된 객체 수명 유지)
				const Prev = this.Save[0];

				this.Time += _DeltaTime;
				if (this.Time >= 1) {
					SchedulePlayer.IsPartOfScheduleEnd = false;
					this.Time = 0;
					this.AnimationPlay();
					this.PlayOneDaySchedule();
					this.Save.shift();
				}

				if (this.Save.length === 0) {
					SchedulePlayer.IsPartOfScheduleEnd = true;
					this.AnimationOff();
					this.AcScheduleDialog.UpdateScheduleDialog(Prev.Schedule, ScheduleSituation.ScheduleEnd);
					this.FirstUpdateCheck = false;
					this.FirstScheduleUpdateCheck = false;
					MainMenu.GetAcMainMenu().On();
					this.AcScheduleCalendar.Reset();
					this.Off();
					this.BGMPlayer.Stop();
					switch (this.ParentLevel.GetTodaySeason()) {
						case Season.Spring:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Summer:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Fall:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Winter:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						default:
							break;
					}
					return;
				}

				const Next = this.Save[0];

				if (Prev.Order !== Next.Order) {
					SchedulePlayer.IsPartOfScheduleEnd = true;
					this.AnimationOff();
					this.AcScheduleDialog.UpdateScheduleDialog(Prev.Schedule, ScheduleSituation.ScheduleEnd);
				}

				if (!this.AcScheduleDialog.IsUpdate() && SchedulePlayer.IsPartOfScheduleEnd) {
					this.FirstScheduleUpdateCheck = false;
				}
			}
		}
	}

	PlayOneDaySchedule() {
		this.AcScheduleAnimationPlayer.On();
		this.AcSchedulePlayerGuage.On();
		this.AcScheduleMessageBox.On();
		this.AcScheduleMessageBox.SetDayCount(++this.DayCount);
		this.AcScheduleMessageBox.SetScheduleString(this.Save[0].Schedule);
		this.AcSchedulePlayerGuage.SetSchedule(this.Save[0].Schedule);
		switch (this.Save[0].Schedule) {
			case ScheduleLabel["무용"]:
				this.AcDanceClass.On();
				// 원본: Olive::OlivePlayer->OliveStatus += AcDanceClass->GetStatusVariance();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcDanceClass.GetStatusVariance());
				// 원본: Olive::OlivePlayer->GetGold() += AcDanceClass->GetPayGold(); (int& 반환 — 참조 대상 Gold 에 대입)
				Olive.OlivePlayer.Gold += this.AcDanceClass.GetPayGold();
				break;
			case ScheduleLabel["검술"]:
				this.AcFencingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcFencingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcFencingClass.GetPayGold();
				break;
			case ScheduleLabel["격투술"]:
				this.AcFightingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcFightingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcFightingClass.GetPayGold();
				break;
			case ScheduleLabel["마법"]:
				this.AcMagicClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcMagicClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcMagicClass.GetPayGold();
				break;
			case ScheduleLabel["미술"]:
				this.AcPaintingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcPaintingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcPaintingClass.GetPayGold();
				break;
			case ScheduleLabel["시문학"]:
				this.AcPoetryClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcPoetryClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcPoetryClass.GetPayGold();
				break;
			case ScheduleLabel["예법"]:
				this.AcProtocolClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcProtocolClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcProtocolClass.GetPayGold();
				break;
			case ScheduleLabel["자연과학"]:
				this.AcScienceClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcScienceClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcScienceClass.GetPayGold();
				break;
			case ScheduleLabel["군사학"]:
				this.AcStrategyClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcStrategyClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcStrategyClass.GetPayGold();
				break;
			case ScheduleLabel["신학"]:
				this.AcTheologyClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcTheologyClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcTheologyClass.GetPayGold();
				break;
			default:
				break;
		}

		this.ParentLevel.GoToNextDay();
	}

	AnimationOff() {
		this.DayCount = 0;
		this.AcScheduleMessageBox.Off();
		this.AcScheduleAnimationPlayer.Off();
		this.AcDanceClass.Off();
		this.AcFencingClass.Off();
		this.AcFightingClass.Off();
		this.AcMagicClass.Off();
		this.AcPaintingClass.Off();
		this.AcPoetryClass.Off();
		this.AcProtocolClass.Off();
		this.AcScienceClass.Off();
		this.AcStrategyClass.Off();
		this.AcTheologyClass.Off();

		this.AcSchedulePlayerGuage.Off();
	}

	AnimationPlay() {
		this.AcDanceClass.PlayObj();
		this.AcFencingClass.PlayObj();
		this.AcFightingClass.PlayObj();
		this.AcMagicClass.PlayObj();
		this.AcPaintingClass.PlayObj();
		this.AcPoetryClass.PlayObj();
		this.AcProtocolClass.PlayObj();
		this.AcScienceClass.PlayObj();
		this.AcStrategyClass.PlayObj();
		this.AcTheologyClass.PlayObj();
	}

	AnimationStop() {
		this.AcDanceClass.StopObj();
		this.AcFencingClass.StopObj();
		this.AcFightingClass.StopObj();
		this.AcMagicClass.StopObj();
		this.AcPaintingClass.StopObj();
		this.AcPoetryClass.StopObj();
		this.AcProtocolClass.StopObj();
		this.AcScienceClass.StopObj();
		this.AcStrategyClass.StopObj();
		this.AcTheologyClass.StopObj();
	}

	PayDiet() {
		const Value = Olive.OlivePlayer.GetOliveDiet();
		switch (Value) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				// 원본: GetGold() -= 30; (int& 반환 — 참조 대상 Gold 에 대입)
				Olive.OlivePlayer.Gold -= 30;
				break;
			case Diet["어쨌든_튼튼하게"]:
				Olive.OlivePlayer.Gold -= 80;
				break;
			case Diet["얌전한_아이로"]:
				Olive.OlivePlayer.Gold -= 10;
				break;
			case Diet["다이어트_시킨다"]:
				Olive.OlivePlayer.Gold -= 5;
				break;
		default:
				break;
		}
		
	}
}
