// SetOliveName.h / SetOliveName.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { ButtonState } from "../GameEngineCore/Button.js";
import { GlobalButton } from "./GlobalButton.js";
import { CharButton } from "./CharButton.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { FirstSetLevel, ActorState } from "./FirstSetLevel.js";
import { OliveCalendar } from "./OliveCalendar.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PM2CollisionOrder, PM2ActorOrder } from "./ContentsEnums.js";

export class SetOliveName extends GameEngineActor {
	static FirstUpdate = false;

	static GetPrintLetter() {
		return SetOliveName.PrintLetter;
	}

	static PrintLetter = "\0";
	static ExplainRender1 = null;
	static ExplainRender2 = null;
	static ExplainRenderShadow = null;

	static ExplainText = "딸의 이름을 지어주세요(8자이내)";
	static ErrorText = "이름이 필요해요";
	static ExplainTextBoxScale = new float4(300, 18);
	static ErrorTextBoxScale = new float4(200, 18);

	constructor() {
		super();		this.ErrorText = ""; // 원본 SetOliveName.h: std::string ErrorText = 선언
		this.ExplainText = ""; // 원본 SetOliveName.h: std::string ExplainText = 선언
		this.FirstUpdate = false; // 원본 SetOliveName.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;

		this.PrintLetterRender1 = null;
		this.PrintLetterRender2 = null;
		this.PrintLetterRender3 = null;
		this.PrintLetterBoxScale = new float4(120, 18);

		// 원본: CharButton* UpperCaseButton[6][5] = {};
		this.UpperCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		// 원본: CharButton* LowerCaseButton[6][5] = {};
		this.LowerCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		this.CompleteButton = null;
		this.CompleteButton1Render = null;
		this.CompleteButton2Render = null;
		this.CompleteButtonEffect1Render = null;
		this.CompleteButtonEffect2Render = null;
		this.CompleteButtonEffect3Render = null;
		this.CompleteButtonShadowRender = null;

		this.LetterEraseButton = null;
		this.LetterEraseButton1Render = null;
		this.LetterEraseButton2Render = null;
		this.LetterEraseButtonEffect1Render = null;
		this.LetterEraseButtonEffect2Render = null;
		this.LetterEraseButtonEffect3Render = null;
		this.LetterEraseButtonShadowRender = null;

		this.ButtonScale = new float4(24, 24);
		this.ButtonScale2 = new float4(48, 24);
		this.ButtonInterval = new float4(16, 0);
		this.LetterRenderHeight = 18;
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(192, 120, 178);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
		this.TextType = "굴림";
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetOliveBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();

		this.SetExplainRender();

		this.SetPrintLetterRender();

		this.SetUpperCaseButton();
		this.SetUpperCaseRender();

		this.SetLowerCaseButton();
		this.SetLowerCaseRender();

		this.SetCompleteButton();
		this.SetCompleteButtonRender();

		this.SetLetterEraseButton();
		this.SetLetterEraseButtonRender();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!SetOliveName.FirstUpdate) {
			SetOliveName.FirstUpdate = true;
			SetOliveName.PrintLetter = "\0";
			SetOliveName.ExplainRender1.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
			SetOliveName.ExplainRender2.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
			SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetOliveName.ExplainTextBoxScale);
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.UpperCaseButton[y][x].GetState()) {
					this.UpperCaseLetterEffect1Render[y][x].Off();
					this.UpperCaseLetterEffect2Render[y][x].Off();
					this.UpperCaseLetterEffect3Render[y][x].Off();

					this.UpperCaseLetter1Render[y][x].On();
					this.UpperCaseLetter2Render[y][x].On();
					this.UpperCaseLetterShadowRender[y][x].On();
				}
				else {
					this.UpperCaseLetterEffect1Render[y][x].On();
					this.UpperCaseLetterEffect2Render[y][x].On();
					this.UpperCaseLetterEffect3Render[y][x].On();

					this.UpperCaseLetter1Render[y][x].Off();
					this.UpperCaseLetter2Render[y][x].Off();
					this.UpperCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.LowerCaseButton[y][x].GetState()) {
					this.LowerCaseLetterEffect1Render[y][x].Off();
					this.LowerCaseLetterEffect2Render[y][x].Off();
					this.LowerCaseLetterEffect3Render[y][x].Off();

					this.LowerCaseLetter1Render[y][x].On();
					this.LowerCaseLetter2Render[y][x].On();
					this.LowerCaseLetterShadowRender[y][x].On();
				}
				else {
					this.LowerCaseLetterEffect1Render[y][x].On();
					this.LowerCaseLetterEffect2Render[y][x].On();
					this.LowerCaseLetterEffect3Render[y][x].On();

					this.LowerCaseLetter1Render[y][x].Off();
					this.LowerCaseLetter2Render[y][x].Off();
					this.LowerCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		if (ButtonState.Release === this.CompleteButton.GetState()) {
			this.CompleteButtonEffect1Render.Off();
			this.CompleteButtonEffect2Render.Off();
			this.CompleteButtonEffect3Render.Off();

			this.CompleteButton1Render.On();
			this.CompleteButton2Render.On();
			this.CompleteButtonShadowRender.On();
		}
		else {
			this.CompleteButtonEffect1Render.On();
			this.CompleteButtonEffect2Render.On();
			this.CompleteButtonEffect3Render.On();

			this.CompleteButton1Render.Off();
			this.CompleteButton2Render.Off();
			this.CompleteButtonShadowRender.Off();
		}

		if (ButtonState.Release === this.LetterEraseButton.GetState()) {
			this.LetterEraseButtonEffect1Render.Off();
			this.LetterEraseButtonEffect2Render.Off();
			this.LetterEraseButtonEffect3Render.Off();

			this.LetterEraseButton1Render.On();
			this.LetterEraseButton2Render.On();
			this.LetterEraseButtonShadowRender.On();
		}
		else {
			this.LetterEraseButtonEffect1Render.On();
			this.LetterEraseButtonEffect2Render.On();
			this.LetterEraseButtonEffect3Render.On();

			this.LetterEraseButton1Render.Off();
			this.LetterEraseButton2Render.Off();
			this.LetterEraseButtonShadowRender.Off();
		}


		this.PrintLetterRender1.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect1Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect3Color, this.PrintLetterBoxScale);
	}

	Render(_DeltaTime) {
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}
				this.UpperCaseButton[y][x].On();
				this.LowerCaseButton[y][x].On();

			}
		}
		this.CompleteButton.On();
		this.LetterEraseButton.On();
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x].Off();
				this.LowerCaseButton[y][x].Off();
			}
		}
		this.CompleteButton.Off();
		this.LetterEraseButton.Off();
	}

	SetPrintLetterRender() {
		this.PrintLetterRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender1.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		const SetPrintLetterRenderPos = this.PrintLetterBoxScale.half().neg().sub(new float4(60, 60));
		this.PrintLetterRender1.SetPosition(SetPrintLetterRenderPos);

		this.PrintLetterRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender2.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetPosition(SetPrintLetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.PrintLetterRender3 = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.PrintLetterRender3.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetPosition(SetPrintLetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetExplainRender() {
		SetOliveName.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetOliveName.ExplainRender1.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
		const SetExplainRenderPos = SetOliveName.ExplainTextBoxScale.half().neg().sub(new float4(36, 36));
		SetOliveName.ExplainRender1.SetPosition(SetExplainRenderPos);

		SetOliveName.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetOliveName.ExplainRender2.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
		SetOliveName.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		SetOliveName.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetOliveName.ExplainTextBoxScale);
		SetOliveName.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetUpperCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(182, 312);

		let Start = 'A'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.UpperCaseButton[y][x].SetScale(this.ButtonScale);
				this.UpperCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.UpperCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].Chracter = Start++;
				this.UpperCaseButton[y][x].SetClickCallBack(SetOliveName.PushBack_Button);
			}
		}
	}

	SetUpperCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "A";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);

				this.UpperCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.UpperCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.UpperCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.UpperCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.UpperCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.UpperCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.UpperCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.UpperCaseLetterEffect1Render[y][x].Off();

				this.UpperCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.UpperCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect2Render[y][x].Off();

				this.UpperCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.UpperCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect3Render[y][x].Off();

				this.UpperCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.UpperCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.UpperCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

				if ("Z" === Start) {
					break;
				}
			}
		}
	}

	SetLowerCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(422, 312);

		let Start = 'a'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.LowerCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.LowerCaseButton[y][x].SetScale(this.ButtonScale);
				this.LowerCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.LowerCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].Chracter = Start++;
				this.LowerCaseButton[y][x].SetClickCallBack(SetOliveName.PushBack_Button);
			}
		}
	}


	SetLowerCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "a";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);
				this.LowerCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.LowerCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.LowerCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.LowerCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.LowerCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.LowerCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.LowerCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.LowerCaseLetterEffect1Render[y][x].Off();

				this.LowerCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.LowerCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect2Render[y][x].Off();

				this.LowerCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.LowerCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect3Render[y][x].Off();

				this.LowerCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.LowerCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.LowerCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				if ("z" === Start) {
					break;
				}
			}
		}
	}

	SetCompleteButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(194, 448);

		this.CompleteButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.CompleteButton.SetScale(this.ButtonScale2);
		this.CompleteButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.CompleteButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetPos(ButtonStartPosition);
		this.CompleteButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetHoverImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetPressImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetClickCallBack(SetOliveName.ClickCompleteButton);
	}

	SetCompleteButtonRender() {
		this.CompleteButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.CompleteButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.CompleteButton1Render.SetPosition(ButtonStartPosition);

		this.CompleteButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.CompleteButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.CompleteButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButtonEffect1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.CompleteButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.CompleteButtonEffect1Render.Off();

		this.CompleteButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.CompleteButtonEffect2Render.Off();

		this.CompleteButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect3Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.CompleteButtonEffect3Render.Off();

		this.CompleteButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.CompleteButtonShadowRender.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.CompleteButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}

	SetLetterEraseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(266, 448);

		this.LetterEraseButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.LetterEraseButton.SetScale(this.ButtonScale2);
		this.LetterEraseButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.LetterEraseButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetPos(ButtonStartPosition);
		this.LetterEraseButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetHoverImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetPressImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetClickCallBack(SetOliveName.PopBack_PrintLetter);
	}

	SetLetterEraseButtonRender() {
		this.LetterEraseButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.LetterEraseButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.LetterEraseButton1Render.SetPosition(ButtonStartPosition);

		this.LetterEraseButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.LetterEraseButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.LetterEraseButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButtonEffect1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.LetterEraseButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.LetterEraseButtonEffect1Render.Off();

		this.LetterEraseButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect2Render.Off();

		this.LetterEraseButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect3Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect3Render.Off();

		this.LetterEraseButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.LetterEraseButtonShadowRender.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.LetterEraseButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}


	static PushBack_Button(_Button) {
		if (8 <= SetOliveName.PrintLetter.length) {
			return;
		}
		const Ptr = _Button; // 원본: dynamic_cast<CharButton*>

		// 원본: PrintLetter.push_back(Ptr->Chracter); (char를 문자열에 추가)
		SetOliveName.PrintLetter += String.fromCharCode(Ptr.Chracter);
	}

	static PopBack_PrintLetter(_Button) {
		if (0 >= SetOliveName.PrintLetter.length) {
			FirstSetLevel.SetStateValue(ActorState.SetPlayerName);
			return;
		}

		// 원본: PrintLetter.pop_back();
		SetOliveName.PrintLetter = SetOliveName.PrintLetter.slice(0, -1);
	}

	static ClickCompleteButton(_Button) {
		if (0 === SetOliveName.PrintLetter.length) {
			SetOliveName.ExplainRender1.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetOliveName.ErrorTextBoxScale);
			SetOliveName.ExplainRender2.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetOliveName.ErrorTextBoxScale);
			SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(192, 120, 178), SetOliveName.ErrorTextBoxScale);
			return;
		}

		FirstSetLevel.SetStateValue(ActorState.OliveCalendar);
		Olive.OlivePlayer.SetOliveFirstName(SetOliveName.PrintLetter);
		SetOliveName.FirstUpdate = false;

		OliveCalendar.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetPrintLetter', 'PushBack_Button', 'PopBack_PrintLetter', 'ClickCompleteButton']) {
	Object.defineProperty(SetOliveName.prototype, __m, { value: function (...args) { return SetOliveName[__m](...args); }, writable: true, configurable: true });
}

