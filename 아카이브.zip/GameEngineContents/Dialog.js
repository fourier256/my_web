// Dialog.h / Dialog.cpp 의 전사
import { MenuFrame } from "./MenuFrame.js";
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { RGB } from "../WinAPI.js";

// enum class MugShotLR
export const MugShotLR = Object.freeze({
	Non: 0,
	Left: 1,
	Right: 2,
});

export class Dialog extends MenuFrame {
	constructor() {
		super();
		this.IsMugShot = false;
		this.MugShotLoc = -1;
		this.MugShotFrame = null;
		this.MugShot = null;

		this.DialogFrameScale = new float4(310, 150);

		this.UpdateText = "";
		this.RenderText = "";

		this.TextRender = null;

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(290, 130);

		this.Time = 0;
		this.RenderLen = 1;
		this.RenderEnd = false;
	}

	SetMugPic(_ImageFileName) {
		const Upper = GameEngineString.ToUpper(_ImageFileName);

		if (-1 !== Upper.indexOf("_GOD")) {

			if (null === this.MugShotFrame) {
				this.MugShotFrame = this.CreateRender("MugShotFrame_God.bmp", PM2RenderOrder.Dialog1_MugShotFrame);
			}
			else {
				this.MugShotFrame.SetImage("MugShotFrame_God.bmp");
			}
			this.MugShotFrame.SetScale(new float4(140, 195));

			if (null === this.MugShot) {
				this.MugShot = this.CreateRender(_ImageFileName, PM2RenderOrder.Dialog1_MugShot);
			}
			else {
				this.MugShot.SetImage(_ImageFileName);
			}
			this.MugShot.SetScale(new float4(120, 175));
		}
		else {
			if (null === this.MugShotFrame) {
				this.MugShotFrame = this.CreateRender("MugShotFrame_Nomal.bmp", PM2RenderOrder.Dialog1_MugShotFrame);
			}
			else {
				this.MugShotFrame.SetImage("MugShotFrame_Nomal.bmp");
			}
			this.MugShotFrame.SetScale(new float4(140, 150));

			if (null === this.MugShot) {
				this.MugShot = this.CreateRender(_ImageFileName, PM2RenderOrder.Dialog1_MugShot);
			}
			else {
				this.MugShot.SetImage(_ImageFileName);
			}
			this.MugShot.SetScale(new float4(120, 130));
		}

	}

	// 원본: SetMugLoc(int _MugLoc) 오버로드. SetMugLoc(MugShotLR)은 static_cast<int>로
	// 이 함수에 위임하므로(MugShotLR 값이 int인) JS에서는 하나의 메서드로 동일하게 동작한다.
	SetMugLoc(_MugLoc) {
		switch (_MugLoc) {
			case 0:
				this.MugShotFrame.Off();
				this.MugShot.Off();
				this.InitRenderPos();
				break;
			case 1:
				if (null === this.MugShot.GetImage()) {
					MsgAssert("먼저 머그샷 이미지를 세팅해야합니다");
				}
				this.MugShotFrame.On();
				this.MugShot.On();
				this.SetLeftMugDialog();
				break;
			case 2:
				if (null === this.MugShot.GetImage()) {
					MsgAssert("먼저 머그샷 이미지를 세팅해야합니다");
				}
				this.MugShotFrame.On();
				this.MugShot.On();
				this.SetRightMugDialog();
				break;
			default:
				break;
		}
	}

	SetUpdateText(_Text) {
		this.UpdateText = _Text;
		if (this.RenderText !== this.UpdateText) {
			this.RenderLen = 1;
			this.RenderEnd = false;
		}
		this.RenderText = this.UpdateText;

	}

	SetDialogScale(_Scale) {
		this.DialogFrameScale = _Scale;
		this.SetMenuFrameScale(this.DialogFrameScale);
		this.TextBoxScale = _Scale.sub(new float4(20, 20));
		this.SetTextRender();
	}

	IsRenderEnd() {
		return this.RenderEnd;
	}

	GetUpdateText() {
		return this.UpdateText;
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.RenderLen = 1;
		this.RenderEnd = false;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Dialog1);
		this.SetMenuFrameScale(this.DialogFrameScale);
		this.SetTextRender();
		this.Off();
	}

	Update(_DeltaTime) {
		this.Time += _DeltaTime;
		if (this.Time >= 0.03) {
			this.Time = 0;
			++this.RenderLen;
			if (this.UpdateText.length === this.RenderLen) {
				this.RenderLen = this.UpdateText.length;
				this.RenderEnd = true;
				return;
			}
		}

		this.TextRender.SetText(this.RenderText.substr(0, this.RenderLen), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}

	Render(_Time) {

	}

	SetTextRender() {
		if (null === this.TextRender) {
			this.TextRender = this.CreateRender(PM2RenderOrder.Dialog1_Display);
		}
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextBoxScale.half().neg());
	}

	SetTextRenderPos(_Pos) {
		this.TextRender.SetPosition(this.TextBoxScale.half().neg().add(_Pos));
	}

	SetRightMugDialog() {
		this.InitRenderPos();
		this.SetMoveMugShotRender(new float4(165, 0));
		this.SetPosFrameRender(new float4(-80, 0));
		this.SetTextRenderPos(new float4(-80, 0));
	}

	SetLeftMugDialog() {
		this.InitRenderPos();
		this.SetMoveMugShotRender(new float4(-165, 0));
		this.SetPosFrameRender(new float4(80, 0));
		this.SetTextRenderPos(new float4(80, 0));
	}

	SetMoveMugShotRender(_Move) {
		this.MugShotFrame.SetMove(_Move);
		this.MugShot.SetMove(_Move);
	}

	SetPosMugShotRender(_Pos) {
		this.MugShotFrame.SetPosition(_Pos);
		this.MugShot.SetPosition(_Pos);
	}

	InitRenderPos() {
		this.SetPosFrameRender(new float4(0, 0));
		this.SetPosMugShotRender(new float4(0, 0));
		this.SetTextRenderPos(new float4(0, 0));
	}
}
