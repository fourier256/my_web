// SelectionMenu.h / SelectionMenu.cpp 의 전사
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { ButtonState } from "../GameEngineCore/Button.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { GlobalButton } from "./GlobalButton.js"; // 아직 미전사 파일 — 원본 include 유지
import { MenuFrame } from "./MenuFrame.js";
import { PM2RenderOrder, PM2CollisionOrder } from "./ContentsEnums.js";

export class SelectionMenu extends MenuFrame {
	constructor() {
		super();
		this.SelectButtons = [];      // std::vector<GlobalButton*>
		this.CountButton = 0;

		this.StringRenders = [];      // std::vector<GameEngineRender*>
		this.StringShadowRenders = []; // std::vector<GameEngineRender*>
		this.StringHoverRenders = []; // std::vector<GameEngineRender*>
		this.ButtonStrings = [];      // std::vector<std::string>
	}

	// 원본: std::vector<GlobalButton*>& GetSelectButtons() { return SelectButtons; }
	GetSelectButtons() {
		return this.SelectButtons;
	}

	// 원본: SetSelectionMenu(int _ActorOrder, int _RenderOrder) 오버로드와
	// (PM2ActorOrder, PM2RenderOrder) 오버로드(static_cast<int> 위임) — JS에서 하나로 통합
	SetSelectionMenu(_Count, _Pos, _xScale, _ActorOrder, _RenderOrder) {
		this.CountButton = _Count;
		this.SetMenuFrameScale(new float4(_xScale, (_Count * 26.0) + 40.0));
		this.SetPos(_Pos);
		this.SelectButtons = new Array(this.CountButton).fill(null); // 원본: SelectButtons.resize(CountButton)
		const Level = this.GetLevel();
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i] = Level.CreateActor(GlobalButton, _ActorOrder);
			this.SelectButtons[i].SetReleaseImage("SelectButton_Release.bmp");
			this.SelectButtons[i].SetHoverImage("SelectButton_Hover.bmp");
			this.SelectButtons[i].SetPressImage("SelectButton_Hover.bmp");
			this.SelectButtons[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.SelectButtons[i].SetScale(new float4(_xScale - 20, 26.0));
			this.SelectButtons[i].SetPos(_Pos.add(float4.Up.scale(this.SelectButtons[i].GetScale().half()).scale(this.SelectButtons.length - 1)).add(float4.Down.scale(this.SelectButtons[i].GetScale().scale(i))));
			this.SelectButtons[i].SetRenderOrder(_RenderOrder);
		}
		this.StringRenders = new Array(this.CountButton).fill(null);       // 원본: StringRenders.resize(CountButton)
		this.StringShadowRenders = new Array(this.CountButton).fill(null); // 원본: StringShadowRenders.resize(CountButton)
		this.StringHoverRenders = new Array(this.CountButton).fill(null);  // 원본: StringHoverRenders.resize(CountButton)
	}

	SetButtonString(_RenderOrder, _ButtonIndex, _Text) {
		this.StringRenders[_ButtonIndex] = this.CreateRender(_RenderOrder);
		this.StringRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(255, 255, 255), this.SelectButtons[_ButtonIndex].GetScale());
		const SetStringPosition = float4.Left.scale(this.SelectButtons[_ButtonIndex].GetScale().half())
			.add(float4.Up.scale(this.SelectButtons[_ButtonIndex].GetScale().half()).scale(this.SelectButtons.length - 1))
			.add(float4.Down.scale(this.SelectButtons[_ButtonIndex].GetScale().scale(_ButtonIndex)))
			.add(float4.Up.half().scale(this.StringRenders[_ButtonIndex].GetTextHeight()));
		this.StringRenders[_ButtonIndex].SetPosition(SetStringPosition);

		let OrderDifference = PM2RenderOrder.Menu0_Display - PM2RenderOrder.Menu0_Display_Shadow;
		this.StringShadowRenders[_ButtonIndex] = this.CreateRender(_RenderOrder - OrderDifference);
		this.StringShadowRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(0, 0, 0), this.SelectButtons[_ButtonIndex].GetScale());
		this.StringShadowRenders[_ButtonIndex].SetPosition(SetStringPosition.add(new float4(0, 2)));

		OrderDifference = PM2RenderOrder.Menu0_Display - PM2RenderOrder.Menu0_Display_Effect;
		this.StringHoverRenders[_ButtonIndex] = this.CreateRender(_RenderOrder - OrderDifference);
		this.StringHoverRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(236, 152, 132), this.SelectButtons[_ButtonIndex].GetScale());
		this.StringHoverRenders[_ButtonIndex].SetPosition(SetStringPosition.add(new float4(0, 1)));

		this.StringHoverRenders[_ButtonIndex].Off();
	}

	On() {
		// 원본: GameEngineObject::On();
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i].On();
		}
	}

	Off() {
		// 원본: GameEngineObject::Off();
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i].Off();
		}
	}

	Start() {

	}

	Update(_Deltatime) {
		for (let i = 0; i < this.SelectButtons.length; i++) {
			if (ButtonState.Release === this.SelectButtons[i].GetState()) {
				this.StringHoverRenders[i].Off();
				this.StringShadowRenders[i].On();
			}
			else {
				this.StringHoverRenders[i].On();
				this.StringShadowRenders[i].Off();
			}
		}
	}

	Render(_Time) {

	}
}
