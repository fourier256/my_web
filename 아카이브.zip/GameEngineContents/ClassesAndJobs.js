// ClassesAndJobs.h / ClassesAndJobs.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineRandom } from "../GameEngineBase/GameEngineRandom.js";
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { FrameAnimationParameter } from "../GameEngineCore/GameEngineRender.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.OlivePlayer / Olive.Status 사용)

export class ClassesAndJobs extends GameEngineActor {
	constructor() {
		super();
		// RaisingSimLevel* ParentLevel = nullptr;
		this.ParentLevel = null;

		this.Pay = 0;

		// Olive::Status Beginner_StatusVarianceMin = {}; (모든 필드 0)
		this.Beginner_StatusVarianceMin = new Olive.Status();
		this.Beginner_StatusVarianceMax = new Olive.Status();
		this.Beginner_StatusVariance = new Olive.Status();
		this.ActorPos = new float4(240, 380);

		this.BackgroundLayer1 = null;
		this.BackgroundLayer2 = null;

		this.OliveObject = null;
		this.OliveObjectPos = float4.Zero;
		this.OliveSuccessFrameStart = -1;
		this.OliveSuccessFrameEnd = -1;
		this.OliveFailFrameStart = -1;
		this.OliveFailFrameEnd = -1;
		this.OliveDontFrameStart = -1;
		this.OliveDontFrameEnd = -1;
		this.SuccessState = "Success";
		this.FailState = "Fail";
		this.DontState = "Dont";
		this.StopState = "Stop";

		this.Object1 = null;
		this.Object1Pos = float4.Zero;
		this.Object1FrameStart = -1;
		this.Object1FrameEnd = -1;
		this.Object2 = null;
		this.Object2Pos = float4.Zero;
		this.Object2FrameStart = -1;
		this.Object2FrameEnd = -1;
		this.Object3 = null;
		this.Object3Pos = float4.Zero;
		this.Object3FrameStart = -1;
		this.Object3FrameEnd = -1;
		this.Object4 = null;
		this.Object4Pos = float4.Zero;
		this.Object4FrameStart = -1;
		this.Object4FrameEnd = -1;
		this.Object5 = null;
		this.Object5Pos = float4.Zero;
		this.Object5FrameStart = -1;
		this.Object5FrameEnd = -1;

		this.ObjScale = float4.Zero;

		this.BackgroundLayer1_Name = "";
		this.BackgroundLayer2_Name = "";
		this.Object_Name = "";

		this.Time = 0;
		this.Count = 0;
	}

	GetStatusVarianceMin() {
		return this.Beginner_StatusVarianceMin;
	}

	GetStatusVarianceMax() {
		return this.Beginner_StatusVarianceMax;
	}

	GetStatusVariance() {
		const Random = new GameEngineRandom();
		this.Beginner_StatusVariance.Constitution = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Constitution), Math.trunc(this.Beginner_StatusVarianceMax.Constitution));
		this.Beginner_StatusVariance.Strength = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Strength), Math.trunc(this.Beginner_StatusVarianceMax.Strength));
		this.Beginner_StatusVariance.Intelligence = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Intelligence), Math.trunc(this.Beginner_StatusVarianceMax.Intelligence));
		this.Beginner_StatusVariance.Refinement = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Refinement), Math.trunc(this.Beginner_StatusVarianceMax.Refinement));
		this.Beginner_StatusVariance.Charisma = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Charisma), Math.trunc(this.Beginner_StatusVarianceMax.Charisma));
		this.Beginner_StatusVariance.Morality = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Morality), Math.trunc(this.Beginner_StatusVarianceMax.Morality));
		this.Beginner_StatusVariance.Faith = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Faith), Math.trunc(this.Beginner_StatusVarianceMax.Faith));
		this.Beginner_StatusVariance.Sin = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Sin), Math.trunc(this.Beginner_StatusVarianceMax.Sin));
		this.Beginner_StatusVariance.Sensitivity = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Sensitivity), Math.trunc(this.Beginner_StatusVarianceMax.Sensitivity));
		this.Beginner_StatusVariance.Stress = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Stress), Math.trunc(this.Beginner_StatusVarianceMax.Stress));
		this.Beginner_StatusVariance.Fighter = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Fighter), Math.trunc(this.Beginner_StatusVarianceMax.Fighter));
		this.Beginner_StatusVariance.CombatSkill = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatSkill), Math.trunc(this.Beginner_StatusVarianceMax.CombatSkill));
		this.Beginner_StatusVariance.CombatAttack = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatAttack), Math.trunc(this.Beginner_StatusVarianceMax.CombatAttack));
		this.Beginner_StatusVariance.CombatDefense = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatDefense), Math.trunc(this.Beginner_StatusVarianceMax.CombatDefense));
		this.Beginner_StatusVariance.Magical = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Magical), Math.trunc(this.Beginner_StatusVarianceMax.Magical));
		this.Beginner_StatusVariance.MagicSkill = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicSkill), Math.trunc(this.Beginner_StatusVarianceMax.MagicSkill));
		this.Beginner_StatusVariance.MagicAttack = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicAttack), Math.trunc(this.Beginner_StatusVarianceMax.MagicAttack));
		this.Beginner_StatusVariance.MagicDefense = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicDefense), Math.trunc(this.Beginner_StatusVarianceMax.MagicDefense));
		this.Beginner_StatusVariance.Social = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Social), Math.trunc(this.Beginner_StatusVarianceMax.Social));
		this.Beginner_StatusVariance.Decorum = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Decorum), Math.trunc(this.Beginner_StatusVarianceMax.Decorum));
		this.Beginner_StatusVariance.Art = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Art), Math.trunc(this.Beginner_StatusVarianceMax.Art));
		this.Beginner_StatusVariance.Conversation = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Conversation), Math.trunc(this.Beginner_StatusVarianceMax.Conversation));
		this.Beginner_StatusVariance.HouseWork = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.HouseWork), Math.trunc(this.Beginner_StatusVarianceMax.HouseWork));
		this.Beginner_StatusVariance.Cooking = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Cooking), Math.trunc(this.Beginner_StatusVarianceMax.Cooking));
		this.Beginner_StatusVariance.Cleaning = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Cleaning), Math.trunc(this.Beginner_StatusVarianceMax.Cleaning));
		this.Beginner_StatusVariance.Temperament = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Temperament), Math.trunc(this.Beginner_StatusVarianceMax.Temperament));

		return this.Beginner_StatusVariance;
	}

	DoClassAndJob() {
		// 원본: Olive::OlivePlayer->OliveStatus += GetStatusVariance(); (Status::operator+= → float4 규칙과 같은 형태)
		Olive.OlivePlayer.OliveStatus = Olive.OlivePlayer.OliveStatus.add(this.GetStatusVariance());
		this.ParentLevel.GoToNextDay();
	}

	PlayObj() {
		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation(this.SuccessState);
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Obj1");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Obj2");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Obj3");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Obj4");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Obj5");
		}
	}

	StopObj() {
		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation("Stop");
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Stop");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Stop");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Stop");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Stop");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Stop");
		}
	}

	SetPayGold(_Pay) {
		this.Pay = _Pay;
	}

	GetPayGold() {
		return this.Pay;
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();

		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation(this.SuccessState);
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Obj1");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Obj2");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Obj3");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Obj4");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Obj5");
		}

		this.SetPos(this.ActorPos);
		this.Off();
	}

	SetImageName(_Obj, _Back1, _Back2 = "") {
		this.Object_Name = _Obj;
		this.BackgroundLayer1_Name = _Back1;
		this.BackgroundLayer2_Name = _Back2;
	}

	SetBackground() {
		this.BackgroundLayer1 = this.CreateRender(this.BackgroundLayer1_Name, PM2RenderOrder.Menu2_Background_1);
		this.BackgroundLayer1.SetScaleToImage();
		if (0 !== this.BackgroundLayer2_Name.length) {
			this.BackgroundLayer2 = this.CreateRender(this.BackgroundLayer2_Name, PM2RenderOrder.Menu2_Background_1);
			this.BackgroundLayer2.SetScaleToImage();
		}
	}

	SetObjScale(_Scale) {
		this.ObjScale = _Scale;
	}

	SetOliveObj(_SuccessStart, _SuccessEnd, _FailStart, _FailEnd, _DontStart, _DontEnd, _Pos) {
		this.OliveSuccessFrameStart = _SuccessStart;
		this.OliveSuccessFrameEnd = _SuccessEnd;
		this.OliveFailFrameStart = _FailStart;
		this.OliveFailFrameEnd = _FailEnd;
		this.OliveDontFrameStart = _DontStart;
		this.OliveDontFrameEnd = _DontEnd;
		this.OliveObjectPos = _Pos;

		this.OliveObject = this.CreateRender(PM2RenderOrder.Menu2_Obj_2);
		this.OliveObject.SetScale(this.ObjScale);
		this.OliveObject.SetPosition(this.OliveObjectPos);
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.SuccessState, this.Object_Name, this.OliveSuccessFrameStart, this.OliveSuccessFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.FailState, this.Object_Name, this.OliveFailFrameStart, this.OliveFailFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.DontState, this.Object_Name, this.OliveDontFrameStart, this.OliveDontFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.StopState, this.Object_Name, this.OliveSuccessFrameStart, this.OliveSuccessFrameStart, 0, 0.2));
	}

	SetObj1(_Order, _Start, _End, _Pos) {
		this.Object1FrameStart = _Start;
		this.Object1FrameEnd = _End;
		this.Object1Pos = _Pos;
		this.Object1 = this.CreateRender(_Order);
		this.Object1.SetScale(this.ObjScale);
		this.Object1.SetPosition(this.Object1Pos);
		this.Object1.CreateAnimation(new FrameAnimationParameter("Obj1", this.Object_Name, this.Object1FrameStart, this.Object1FrameEnd, 0, 0.2));
		this.Object1.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object1FrameStart, this.Object1FrameStart, 0, 0.2));
	}

	SetObj2(_Order, _Start, _End, _Pos) {
		this.Object2FrameStart = _Start;
		this.Object2FrameEnd = _End;
		this.Object2Pos = _Pos;
		this.Object2 = this.CreateRender(_Order);
		this.Object2.SetScale(this.ObjScale);
		this.Object2.SetPosition(this.Object2Pos);
		this.Object2.CreateAnimation(new FrameAnimationParameter("Obj2", this.Object_Name, this.Object2FrameStart, this.Object2FrameEnd, 0, 0.2));
		this.Object2.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object2FrameStart, this.Object2FrameStart, 0, 0.2));
	}

	SetObj3(_Order, _Start, _End, _Pos) {
		this.Object3FrameStart = _Start;
		this.Object3FrameEnd = _End;
		this.Object3Pos = _Pos;
		this.Object3 = this.CreateRender(_Order);
		this.Object3.SetScale(this.ObjScale);
		this.Object3.SetPosition(this.Object3Pos);
		this.Object3.CreateAnimation(new FrameAnimationParameter("Obj3", this.Object_Name, this.Object3FrameStart, this.Object3FrameEnd, 0, 0.2));
		this.Object3.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object3FrameStart, this.Object3FrameStart, 0, 0.2));
	}

	SetObj4(_Order, _Start, _End, _Pos) {
		this.Object4FrameStart = _Start;
		this.Object4FrameEnd = _End;
		this.Object4Pos = _Pos;
		this.Object4 = this.CreateRender(_Order);
		this.Object4.SetScale(this.ObjScale);
		this.Object4.SetPosition(this.Object4Pos);
		this.Object4.CreateAnimation(new FrameAnimationParameter("Obj4", this.Object_Name, this.Object4FrameStart, this.Object4FrameEnd, 0, 0.2));
		this.Object4.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object4FrameStart, this.Object4FrameStart, 0, 0.2));
	}

	SetObj5(_Order, _Start, _End, _Pos) {
		this.Object5FrameStart = _Start;
		this.Object5FrameEnd = _End;
		this.Object5Pos = _Pos;
		this.Object5 = this.CreateRender(_Order);
		this.Object5.SetScale(this.ObjScale);
		this.Object5.SetPosition(this.Object5Pos);
		this.Object5.CreateAnimation(new FrameAnimationParameter("Obj5", this.Object_Name, this.Object5FrameStart, this.Object5FrameEnd, 0, 0.2));
		this.Object5.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object5FrameStart, this.Object5FrameStart, 0, 0.2));
	}
}
