// Logo.h / Logo.cpp 의 전사 (원본 h의 전방 선언 "class GameEnigneRender;" — 오타 포함 원문)
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class Logo extends GameEngineActor {
	constructor() {
		super();
		this.PM2Logo = null;
	}

	Start() {
		this.PM2Logo = this.CreateRender("TitleLogo.BMP", PM2RenderOrder.TitleLogo);
		this.PM2Logo.SetScaleToImage();
		this.SetPos(new float4(400, 250));
		this.Off();
	}
}
