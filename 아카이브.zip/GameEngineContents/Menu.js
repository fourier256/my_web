// Menu.h / Menu.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";

export class Menu extends GameEngineActor {
	constructor() {
		super();
		this.LowMenu = [];
	}
}
