// DietSelectionMenu.h / DietSelectionMenu.cpp 의 전사
import { SelectionMenu } from "./SelectionMenu.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";
import { CubeDialog, CubeFace } from "./CubeDialog.js";
import { DietFinalConfirmSelectionMenu } from "./DietFinalConfirmSelectionMenu.js";
import { MainMenu } from "./MainMenu.js";
import { Diet, PM2ActorOrder, PM2RenderOrder } from "./ContentsEnums.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class DietSelectionMenu extends SelectionMenu {
	static AcDietSelectionMenu = null;
	static AcDietFinalConfirmSelectionMenu = null;
	static AcCubeDialog = null;

	constructor() {
		super();
		this.AcMainMenu = null;
		this.ActorPos = new float4(685, 346);
		this.Xscale = 170.0;

		DietSelectionMenu.AcDietSelectionMenu = this;
	}

	static GetAcDietSelectionMenu() {
		return DietSelectionMenu.AcDietSelectionMenu;
	}

	Start() {
		this.AcMainMenu = MainMenu.GetAcMainMenu();
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())->GetAcCubeDialog()
		DietSelectionMenu.AcCubeDialog = this.GetLevel().GetAcCubeDialog();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu = this.GetLevel().CreateActor(DietFinalConfirmSelectionMenu, PM2ActorOrder.Menu2);

		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(4, this.ActorPos, this.Xscale, PM2ActorOrder.Menu0_Button, PM2RenderOrder.Menu0_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "무리하지 않는다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "어쨌든 튼튼하게");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "얌전한 아이로");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 3, "다이어트 시킨다");

		this.SetButton();

		this.Off();
	}

	Update(_DeltaTime) {
		DietSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「주인님, 아가씨의 건강관리는\n어떤 방침으로 하시겠습니까?」");
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			DietSelectionMenu.AcCubeDialog.Off();
			this.AcMainMenu.On();
		}
	}

	SetButton() {
		this.GetSelectButtons()[0].SetClickCallBack(DietSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(DietSelectionMenu.Click1);
		this.GetSelectButtons()[2].SetClickCallBack(DietSelectionMenu.Click2);
		this.GetSelectButtons()[3].SetClickCallBack(DietSelectionMenu.Click3);
	}

	static Click0(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["무리하지_않는다"]);
	}

	static Click1(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["어쨌든_튼튼하게"]);
	}

	static Click2(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["얌전한_아이로"]);
	}

	static Click3(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["다이어트_시킨다"]);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcDietSelectionMenu', 'Click0', 'Click1', 'Click2', 'Click3']) {
	Object.defineProperty(DietSelectionMenu.prototype, __m, { value: function (...args) { return DietSelectionMenu[__m](...args); }, writable: true, configurable: true });
}

