// Date.h / Date.cpp 의 전사
// 주의: JS 내장 Date 와 이름이 같으므로 이 파일 안에서는 내장 Date 를 사용하지 않는다.
// 연산자 대응: operator== → Equals, operator!= → NotEquals, operator> → Greater,
// operator< → Less, operator>= → GreaterEquals, operator<= → LessEquals,
// 전위 operator++ → Increment(), operator+(int) → add(int)
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";

// enum class Week
export const Week = Object.freeze({
	Null: -1,
	SUN: 0,
	MON: 1,
	TUE: 2,
	WED: 3,
	THU: 4,
	FRI: 5,
	SAT: 6
});

export class Date {
	// 원본: static std::vector<Date> GetOneMonthCalendar(int _YYYY, int _MM);
	static GetOneMonthCalendar(_YYYY, _MM) {
		if (Date.IsOverMonth(_MM)) {
			MsgAssert("입력 가능한 Month의 범위를 벗어났습니다");
		}

		const Value = [];

		if (Date.IsBigMonth(_MM)) {
			// 원본: Value.resize(31);
			for (let i = 0; i < 31; i++) {
				Value.push(new Date());
			}
		}
		else if (2 === _MM) {
			if (Date.IsLeapYear(_YYYY)) {
				// 원본: Value.resize(29);
				for (let i = 0; i < 29; i++) {
					Value.push(new Date());
				}
			}
			else {
				// 원본: Value.resize(28);
				for (let i = 0; i < 28; i++) {
					Value.push(new Date());
				}
			}
		}
		else {
			// 원본: Value.resize(30);
			for (let i = 0; i < 30; i++) {
				Value.push(new Date());
			}
		}

		for (let Day = 1; Day <= Value.length; Day++) {
			Value[Day - 1].SetDate(_YYYY, _MM, Day);
		}

		return Value;
	}

	// 원본: static bool IsOverMonth(int _MM);
	static IsOverMonth(_MM) {
		if (0 < _MM && 13 > _MM) {
			return false;
		}
		return true;
	}

	// 원본: static bool IsOverDay(int _YYYY, int _MM, int _DD);
	static IsOverDay(_YYYY, _MM, _DD) {
		if (1 === _MM ||
			3 === _MM ||
			5 === _MM ||
			7 === _MM ||
			8 === _MM ||
			10 === _MM ||
			12 === _MM) {
			if (0 < _DD && 32 > _DD) {
				return false;
			}
			return true;
		}
		else if (4 === _MM ||
			6 === _MM ||
			9 === _MM ||
			11 === _MM) {
			if (0 < _DD && 31 > _DD) {
				return false;
			}
			return true;
		}
		else {
			if (Date.IsLeapYear(_YYYY)) {
				if (0 < _DD && 30 > _DD) {
					return false;
				}
				return true;
			}
			else {
				if (0 < _DD && 29 > _DD) {
					return false;
				}
				return true;
			}
		}

		return false;
	}

	// 원본: static bool IsLeapYear(int _YYYY);
	static IsLeapYear(_YYYY) {
		if ((0 === (_YYYY % 4) && 0 !== (_YYYY % 100)) || 0 === (_YYYY % 400)) {
			return true;
		}
		return false;
	}

	// 원본: static bool IsBigMonth(int _MM);
	static IsBigMonth(_MM) {
		if (1 === _MM ||
			3 === _MM ||
			5 === _MM ||
			7 === _MM ||
			8 === _MM ||
			10 === _MM ||
			12 === _MM) {
			return true;
		}
		return false;
	}

	// 원본: static int FindFirstWeekday(int _YYYY);
	static FindFirstWeekday(_YYYY) {
		const PrevYear = _YYYY - 1;
		return (PrevYear + ((PrevYear / 4) - (PrevYear / 100) + (PrevYear / 400)) + 1) % 7;
	}

	// 원본: static int GetMonthLenth(int _YYYY, int _MM);
	static GetMonthLenth(_YYYY, _MM) {
		if (Date.IsOverMonth(_MM)) {
			MsgAssert("입력 가능한 Month의 범위를 벗어났습니다");
		}

		if (Date.IsBigMonth(_MM)) {
			return 31;
		}
		else if (2 === _MM) {
			if (Date.IsLeapYear(_YYYY)) {
				return 29;
			}
			else {
				return 28;
			}
		}
		else {
			return 30;
		}
	}

	// 원본: static std::vector<int> GetMonthLenths(int _YYYY);
	static GetMonthLenths(_YYYY) {
		const Result = [];
		// 원본: Result.resize(12);
		for (let i = 0; i < 12; i++) {
			Result.push(0);
		}
		for (let i = 0; i < Result.length; i++) {
			Result[i] = Date.GetMonthLenth(_YYYY, i + 1);
		}
		return Result;
	}

	// 원본: static int FindMonthFirstWeekday(int _YYYY, int _MM);
	static FindMonthFirstWeekday(_YYYY, _MM) {
		if (true === Date.IsOverMonth(_MM)) {
			MsgAssert("입력가능한 Month의 범위를 벗어났습니다");
			return 0;
		}

		let Year = _YYYY;
		let Month = 1;
		// 원본: int MonthLen[12] = {};
		const MonthLen = new Array(12).fill(0);
		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			if (2 === Month) {
				if (Date.IsLeapYear(Year)) {
					MonthLen[i] = 29;
				}
				else {
					MonthLen[i] = 28;
				}
			}
			else if (4 === Month ||
				6 === Month ||
				9 === Month ||
				11 === Month) {
				MonthLen[i] = 30;
			}
			else {
				MonthLen[i] = 31;
			}
			Month++;
		}
		let WholeDay = 0;
		for (let i = 0; i < (_MM - 1); i++) {
			WholeDay += MonthLen[i];
		}
		return (Date.FindFirstWeekday(_YYYY) + WholeDay) % 7;
	}

	// 원본: static Week GetWeekDay(int _YYYY, int _MM, int _DD);
	static GetWeekDay(_YYYY, _MM, _DD) {
		const ThisMonthFirstWeekDay = Date.FindMonthFirstWeekday(_YYYY, _MM);
		return (ThisMonthFirstWeekDay + _DD - 1) % 7;
	}

	// 원본: static Date GetMonthLastDate(const Date& _Date);
	static GetMonthLastDate(_Date) {
		return new Date(_Date.Year, _Date.Month, Date.GetMonthLenth(_Date.Year, _Date.Month));
	}

	// 원본: Date(); / Date(int _YYYY, int _MM, int _DD); 두 생성자
	constructor(_YYYY, _MM, _DD) {
		this.Year = 0;
		this.Month = 0;
		this.Day = 0;
		this.WeekDay = Week.Null;
		if (undefined !== _YYYY) {
			this.SetDate(_YYYY, _MM, _DD);
		}
	}

	// 원본: bool IsOverMonth();
	IsOverMonth() {
		if (0 < this.Month && 13 > this.Month) {
			return false;
		}
		return true;
	}

	// 원본: bool IsOverDay();
	IsOverDay() {
		if (1 === this.Month ||
			3 === this.Month ||
			5 === this.Month ||
			7 === this.Month ||
			8 === this.Month ||
			10 === this.Month ||
			12 === this.Month) {
			if (0 < this.Day && 32 > this.Day) {
				return false;
			}
			return true;
		}
		else if (4 === this.Month ||
			6 === this.Month ||
			9 === this.Month ||
			11 === this.Month) {
			if (0 < this.Day && 31 > this.Day) {
				return false;
			}
			return true;
		}
		else {
			if (this.IsLeapYear()) {
				if (0 < this.Day && 30 > this.Day) {
					return false;
				}
				return true;
			}
			else {
				if (0 < this.Day && 29 > this.Day) {
					return false;
				}
				return true;
			}
		}

		return false;
	}

	// 원본: bool IsOverWeekDay();
	IsOverWeekDay() {
		if (0 <= this.Month && 7 > this.Month) {
			return false;
		}
		return true;
	}

	// 원본: bool IsLeapYear();
	IsLeapYear() {
		if ((0 === (this.Year % 4) && 0 !== (this.Year % 100)) || 0 === (this.Year % 400)) {
			return true;
		}
		return false;
	}

	IsNullDate() {
		if (this.Year === 0 ||
			this.Month === 0 ||
			this.Day === 0) {
			return true;
		}
		return false;
	}

	SetWeekDay() {
		const ThisMonthFirstWeekDay = Date.FindMonthFirstWeekday(this.Year, this.Month);
		this.WeekDay = (ThisMonthFirstWeekDay + this.Day - 1) % 7;
	}

	// 원본: void SetDate(const Date& _Date) / void SetDate(int _YYYY, int _MM, int _DD) 오버로드
	SetDate(_YYYY, _MM, _DD) {
		if (_YYYY instanceof Date) {
			const _Date = _YYYY;
			this.SetDate(_Date.Year, _Date.Month, _Date.Day);
			return;
		}

		if (Date.IsOverMonth(_MM) ||
			Date.IsOverDay(_YYYY, _MM, _DD)) {
			MsgAssert("입력가능한 날짜를 벗어났습니다");
		}
		this.Year = _YYYY;
		this.Month = _MM;
		this.Day = _DD;
		this.SetWeekDay();
	}

	SetNullDate() {
		this.Year = 0;
		this.Month = 0;
		this.Day = 0;
		this.WeekDay = Week.Null;
	}

	GetYear() {
		return this.Year;
	}

	GetMonth() {
		return this.Month;
	}

	GetDay() {
		return this.Day;
	}

	// 원본: Week GetWeekDay() const;
	GetWeekDay() {
		return this.WeekDay;
	}

	GetNextDate() {
		const CopyValue = this.copy();
		return CopyValue.Increment();
	}

	// 원본: int FindFirstWeekday(); (인스턴스 버전)
	FindFirstWeekday() {
		const PrevYear = this.Year - 1;
		return (PrevYear + ((PrevYear / 4) - (PrevYear / 100) + (PrevYear / 400)) + 1) % 7;
	}

	// 원본: bool operator== (const Date& _date)
	Equals(_date) {
		return this.Year === _date.Year && this.Month === _date.Month && this.Day === _date.Day;
	}

	// 원본: bool operator!= (const Date& _date)
	NotEquals(_date) {
		return this.Year !== _date.Year || this.Month !== _date.Month || this.Day !== _date.Day;
	}

	// 원본: bool operator> (const Date& _date)
	Greater(_date) {
		if (this.Year > _date.Year) {
			return true;
		}
		else if (this.Year < _date.Year) {
			return false;
		}
		else {
			if (this.Month > _date.Month) {
				return true;
			}
			else if (this.Month < _date.Month) {
				return false;
			}
			else {
				if (this.Day > _date.Day) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}

	// 원본: bool operator< (const Date& _date)
	Less(_date) {
		if (this.Year < _date.Year) {
			return true;
		}
		else if (this.Year > _date.Year) {
			return false;
		}
		else {
			if (this.Month < _date.Month) {
				return true;
			}
			else if (this.Month > _date.Month) {
				return false;
			}
			else {
				if (this.Day < _date.Day) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}

	// 원본: bool operator>= (const Date& _date) { return *this == _date || *this > _date; }
	GreaterEquals(_date) {
		return this.Equals(_date) || this.Greater(_date);
	}

	// 원본: bool operator<= (const Date& _date) { return *this == _date || *this < _date; }
	LessEquals(_date) {
		return this.Equals(_date) || this.Less(_date);
	}

	// 원본: Date& operator ++ ()
	Increment() {
		++this.Day;
		if (this.IsOverDay()) {
			++this.Month;
			this.Day = 1;
			if (this.IsOverMonth()) {
				++this.Year;
				this.Month = 1;
			}
		}
		this.SetWeekDay();

		if (this.IsOverDay() || this.IsOverMonth()) {
			MsgAssert("입력가능한 날짜를 벗어났습니다");
		}
		return this;
	}

	// 원본: Date operator + (int _Value)
	add(_Value) {
		const Result = this.copy();
		for (let i = 0; i < _Value; i++) {
			Result.Increment();
		}

		return Result;
	}

	// 원본: 복사 생성자(*this) 대응
	copy() {
		const CopyValue = new Date();
		CopyValue.Year = this.Year;
		CopyValue.Month = this.Month;
		CopyValue.Day = this.Day;
		CopyValue.WeekDay = this.WeekDay;
		return CopyValue;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetOneMonthCalendar', 'IsOverMonth', 'IsOverDay', 'IsLeapYear', 'IsBigMonth', 'FindFirstWeekday', 'GetMonthLenth', 'GetMonthLenths', 'FindMonthFirstWeekday', 'GetWeekDay', 'GetMonthLastDate']) {
	Object.defineProperty(Date.prototype, __m, { value: function (...args) { return Date[__m](...args); }, writable: true, configurable: true });
}

