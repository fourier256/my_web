// Background.h / Background.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export class Background extends GameEngineActor {
	constructor() {
		super();
		this.BackgroundRender = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("background.BMP", 0);
		this.BackgroundRender.SetScaleToImage();
	}

	Update(_Deltatime) {

	}

	Render(_Time) {
	}
}
