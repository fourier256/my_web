// FoodCostDialog.h / FoodCostDialog.cpp 의 전사
import { Dialog } from "./Dialog.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { Olive } from "./Olive.js";
import { Diet, PM2RenderOrder } from "./ContentsEnums.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";

export class FoodCostDialog extends Dialog {
	constructor() {
		super();
		this.OliveDiet = Diet["무리하지_않는다"];

		this.ActorPos = new float4(235, 475);
		this.ActorScale = new float4(390, 124);

		this.FoodCostRedner = null; // 오타 "Redner" 원본 유지
		this.FoodCostRednerPos = new float4(-95, -91);

		this.FoodCostNumRender = new NumberRenderObject();
		this.FoodCostNumRenderPos = new float4(-48, -92);

		this.TextRender = null;
		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(80, 21);
		this.TextRenderPos = new float4(-175, -103);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetDialogScale(this.ActorScale);
		this.SetPos(this.ActorPos);

		this.FoodCostRedner = this.CreateRender("FoodCost.bmp", PM2RenderOrder.Menu1);
		this.FoodCostRedner.SetScaleToImage();
		this.FoodCostRedner.SetPosition(this.FoodCostRednerPos);

		this.FoodCostNumRender.SetOwner(this);
		this.FoodCostNumRender.SetImage("Num.bmp", new float4(10, 19), PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.FoodCostNumRender.SetAlign(Align.Right);
		this.FoodCostNumRender.SetValue(30);
		this.FoodCostNumRender.SetRenderPos(this.FoodCostNumRenderPos);

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.TextRender.SetText("식비", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, new float4(80, 21));
		this.TextRender.SetPosition(this.TextRenderPos);

		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
		}

		this.OliveDiet = Olive.OlivePlayer.GetOliveDiet();
		this.SetRender();
		// 원본: Dialog::Update(_DeltaTime);
		super.Update(_DeltaTime);
	}

	SetRender() {
		switch (this.OliveDiet) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.SetUpdateText("식비가 30G 필요합니다");
				this.FoodCostNumRender.SetValue(30);
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.SetUpdateText("식비가 80G 필요합니다");
				this.FoodCostNumRender.SetValue(80);
				break;
			case Diet["얌전한_아이로"]:
				this.SetUpdateText("식비가 10G 필요합니다");
				this.FoodCostNumRender.SetValue(10);
				break;
			case Diet["다이어트_시킨다"]:
				this.SetUpdateText("식비가 5G 필요합니다");
				this.FoodCostNumRender.SetValue(5);
				break;
			default:
				break;
		}
	}
}
