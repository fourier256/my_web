// FighterAndMagicalStatusWindow.h / FighterAndMagicalStatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class FighterAndMagicalStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 455);

		this.CombatSkill = 0;
		this.CombatSkillRender = null;
		this.CombatAttack = 0;
		this.CombatAttackRender = null;
		this.CombatDefense = 0;
		this.CombatDefenseRender = null;

		this.MagicSkill = 0;
		this.MagicSkillRender = null;
		this.MagicAttack = 0;
		this.MagicAttackRender = null;
		this.MagicDefense = 0;
		this.MagicDefenseRender = null;

		this.Max = 100;

		this.Style = GaugeFrameStyle.Detail;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.CombatSkillRender = this.InsertStatus("전투기술", this.Max, this.Style);
		this.CombatAttackRender = this.InsertStatus("공격력", this.Max, this.Style);
		this.CombatDefenseRender = this.InsertStatus("방어력", this.Max, this.Style);

		this.MagicSkillRender = this.InsertStatus("마법기술", this.Max, this.Style);
		this.MagicAttackRender = this.InsertStatus("마력", this.Max, this.Style);
		this.MagicDefenseRender = this.InsertStatus("항마력", this.Max, this.Style);

		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.CombatSkill !== Olive.OlivePlayer.GetStatue().CombatSkill) {
			this.CombatSkill = Olive.OlivePlayer.GetStatue().CombatSkill;
			this.CombatSkillRender.UpdateValue(this.CombatSkill);
		}
		if (this.CombatAttack !== Olive.OlivePlayer.GetStatue().CombatAttack) {
			this.CombatAttack = Olive.OlivePlayer.GetStatue().CombatAttack;
			this.CombatAttackRender.UpdateValue(this.CombatAttack);
		}
		if (this.CombatDefense !== Olive.OlivePlayer.GetStatue().CombatDefense) {
			this.CombatDefense = Olive.OlivePlayer.GetStatue().CombatDefense;
			this.CombatDefenseRender.UpdateValue(this.CombatDefense);
		}
		if (this.MagicSkill !== Olive.OlivePlayer.GetStatue().MagicSkill) {
			this.MagicSkill = Olive.OlivePlayer.GetStatue().MagicSkill;
			this.MagicSkillRender.UpdateValue(this.MagicSkill);
		}
		if (this.MagicAttack !== Olive.OlivePlayer.GetStatue().MagicAttack) {
			this.MagicAttack = Olive.OlivePlayer.GetStatue().MagicAttack;
			this.MagicAttackRender.UpdateValue(this.MagicAttack);
		}
		if (this.MagicDefense !== Olive.OlivePlayer.GetStatue().MagicDefense) {
			this.MagicDefense = Olive.OlivePlayer.GetStatue().MagicDefense;
			this.MagicDefenseRender.UpdateValue(this.MagicDefense);
		}
	}
}
