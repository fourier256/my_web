// Olive.h / Olive.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineRandom } from "../GameEngineBase/GameEngineRandom.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { Date } from "./Date.js";
import { PM2RenderOrder, BloodType, Zodiac, PatronGod, Diet } from "./ContentsEnums.js";

export class Olive extends GameEngineActor {
	static OlivePlayer = null;

	constructor() {
		super();
		this.OliveStatus = new Olive.Status();

		this.OlivePhysical = new Olive.PhysicalCondition();

		this.ParentLevel = null;

		this.HeadImageName = "Head_";
		this.BodyImageName = "Body_";
		this.HeadRender = null;
		this.BodyRender = null;

		this.OliveFirstName = "DefaultFirst";
		this.OliveLastName = "DefaultLast";

		this.OliveAge = 10;

		this.OliveBirthDay = new Date(1200, 10, 10);

		this.OliveBloodType = BloodType.AB;

		this.OliveZodiac = Zodiac["황소자리"];

		this.OlivePatronGod = PatronGod["화성신_마르스"];
		this.PatronGodSex = false;

		this.OliveDiet = Diet["무리하지_않는다"];

		this.Gold = 10000;

		this.DiseaseState = false;
		this.DiseaseIndex = 0;
		this.DelinquentState = false;
		this.Delinquency = 0;
		this.FatState = false;


		this.Popularity = 0;

		this.FatherBirthDay = new Date();
		this.FatherAge = 10;

		this.MonthChange = false;

		this.IsBirthDay = false;
	}

	GetOliveBirthDay() {
		return this.OliveBirthDay;
	}

	GetFatherAge() {
		return this.FatherAge;
	}

	GetOliveFirstName() {
		return this.OliveFirstName;
	}

	GetOliveLastName() {
		return this.OliveLastName;
	}

	GetOliveAge() {
		return this.OliveAge;
	}

	GetOliveZodiac() {
		return this.OliveZodiac;
	}

	GetPatronGod() {
		return this.OlivePatronGod;
	}

	GetPatronGodSex() {
		return this.PatronGodSex;
	}

	GetGold() {
		return this.Gold;
	}

	GetBloodType() {
		return this.OliveBloodType;
	}

	SetOliveFirstName(_FirstName) {
		this.OliveFirstName = _FirstName;
	}

	SetOliveLastName(_LastName) {
		this.OliveLastName = _LastName;
	}

	SetOliveBirthDay(_BirthDay) {
		this.OliveBirthDay = _BirthDay;
	}

	SetFatherAge(_Age) {
		this.FatherAge = _Age;
	}

	SetFatherBirthDay(_BirthDay) {
		this.FatherBirthDay = _BirthDay;
	}

	SetBloodType(_BloodType) {
		this.OliveBloodType = _BloodType;
	}

	GetStatue() {
		return this.OliveStatus;
	}

	SetFirstStatus() {
		if (Zodiac["염소자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Capricorn = { 25, 20, 17, 15, 10, 38, 20, 0, 13, 0, 17, 15, 2, 0, 28, 15, 8, 5, 41, 20, 10, 11, 69, 19, 22, 28 };
			const Capricorn = new Olive.Status(25, 20, 17, 15, 10, 38, 20, 0, 13, 0, 17, 15, 2, 0, 28, 15, 8, 5, 41, 20, 10, 11, 69, 19, 22, 28);
			this.SetStatus(Capricorn);
		}
		else if (Zodiac["물병자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Aquarius = { 17,18,42,12,10,13,8,0,28,0,17,15,2,0,50,15,12,23,55,11,22,22,44,15,23,6 };
			const Aquarius = new Olive.Status(17, 18, 42, 12, 10, 13, 8, 0, 28, 0, 17, 15, 2, 0, 50, 15, 12, 23, 55, 11, 22, 22, 44, 15, 23, 6);
			this.SetStatus(Aquarius);
		}
		else if (Zodiac["물고기자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Pisces = { 16,15,15,32,31,27,30,0,45,0,12,10,2,0,56,18,20,18,59,24,20,15,48,16,14,18 };
			const Pisces = new Olive.Status(16, 15, 15, 32, 31, 27, 30, 0, 45, 0, 12, 10, 2, 0, 56, 18, 20, 18, 59, 24, 20, 15, 48, 16, 14, 18);
			this.SetStatus(Pisces);
		}
		else if (Zodiac["양자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Aries = { 45,45,13,10,7,14,21,0,6,0,43,38,5,0,32,8,14,10,35,10,15,10,40,18,18,4 };
			const Aries = new Olive.Status(45, 45, 13, 10, 7, 14, 21, 0, 6, 0, 43, 38, 5, 0, 32, 8, 14, 10, 35, 10, 15, 10, 40, 18, 18, 4);
			this.SetStatus(Aries);
		}
		else if (Zodiac["황소자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Taurus = { 33,28,23,25,24,32,20,0,19,0,13,10,3,0,60,17,18,25,49,21,20,8,58,19,16,23 };
			const Taurus = new Olive.Status(33, 28, 23, 25, 24, 32, 20, 0, 19, 0, 13, 10, 3, 0, 60, 17, 18, 25, 49, 21, 20, 8, 58, 19, 16, 23);
			this.SetStatus(Taurus);
		}
		else if (Zodiac["쌍둥이자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Gemini = { 19,18,36,14,14,7,10,0,35,0,16,14,2,0,52,18,19,15,65,10,25,30,29,8,10,11 };
			const Gemini = new Olive.Status(19, 18, 36, 14, 14, 7, 10, 0, 35, 0, 16, 14, 2, 0, 52, 18, 19, 15, 65, 10, 25, 30, 29, 8, 10, 11);
			this.SetStatus(Gemini);
		}
		else if (Zodiac["게자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Cancer = { 18,18,25,29,33,25,30,0,33,0,17,15,2,0,75,24,28,23,57,17,20,20,54,17,20,17 };
			const Cancer = new Olive.Status(18, 18, 25, 29, 33, 25, 30, 0, 33, 0, 17, 15, 2, 0, 75, 24, 28, 23, 57, 17, 20, 20, 54, 17, 20, 17);
			this.SetStatus(Cancer);
		}
		else if (Zodiac["사자자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Leo = { 50,50,7,42,18,23,10,0,9,0,37,32,5,0,16,2,6,8,38,15,8,15,18,7,9,2 };
			const Leo = new Olive.Status(50, 50, 7, 42, 18, 23, 10, 0, 9, 0, 37, 32, 5, 0, 16, 2, 6, 8, 38, 15, 8, 15, 18, 7, 9, 2);
			this.SetStatus(Leo);
		}
		else if (Zodiac["처녀자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Virgo = { 14,5,28,45,30,32,35,0,31,0,8,7,1,0,65,15,18,32,58,25,18,15,89,29,30,30 };
			const Virgo = new Olive.Status(14, 5, 28, 45, 30, 32, 35, 0, 31, 0, 8, 7, 1, 0, 65, 15, 18, 32, 58, 25, 18, 15, 89, 29, 30, 30);
			this.SetStatus(Virgo);
		}
		else if (Zodiac["천칭자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Libra = { 25,22,30,24,20,20,21,0,26,0,16,14,2,0,42,13,14,15,64,18,18,28,46,16,15,15 };
			const Libra = new Olive.Status(25, 22, 30, 24, 20, 20, 21, 0, 26, 0, 16, 14, 2, 0, 42, 13, 14, 15, 64, 18, 18, 28, 46, 16, 15, 15);
			this.SetStatus(Libra);
		}
		else if (Zodiac["전갈자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Scorpio = { 28,20,22,9,42,10,27,0,39,0,12,10,2,0,80,30,30,20,39,14,21,4,31,12,11,8 };
			const Scorpio = new Olive.Status(28, 20, 22, 9, 42, 10, 27, 0, 39, 0, 12, 10, 2, 0, 80, 30, 30, 20, 39, 14, 21, 4, 31, 12, 11, 8);
			this.SetStatus(Scorpio);
		}
		else if (Zodiac["사수자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Sagittarius = { 38,35,24,23,11,10,12,0,20,0,23,19,4,0,43,19,12,12,37,8,6,13,44,21,13,10 };
			const Sagittarius = new Olive.Status(38, 35, 24, 23, 11, 10, 12, 0, 20, 0, 23, 19, 4, 0, 43, 19, 12, 12, 37, 8, 6, 13, 44, 21, 13, 10);
			this.SetStatus(Sagittarius);
		}
		else
		{
			MsgAssert("별자리가 없습니다, 생일을 정해주지 않았습니다.");
		}
	}

	SetStatus(_Value) {
		this.OliveStatus.Constitution = _Value.Constitution;
		this.OliveStatus.Strength = _Value.Strength;
		this.OliveStatus.Intelligence = _Value.Intelligence;
		this.OliveStatus.Refinement = _Value.Refinement;
		this.OliveStatus.Charisma = _Value.Charisma;
		this.OliveStatus.Morality = _Value.Morality;
		this.OliveStatus.Faith = _Value.Faith;
		this.OliveStatus.Sin = _Value.Sin;
		this.OliveStatus.Sensitivity = _Value.Sensitivity;
		this.OliveStatus.Stress = _Value.Stress;

		this.OliveStatus.CombatSkill = _Value.CombatSkill;
		this.OliveStatus.CombatAttack = _Value.CombatAttack;
		this.OliveStatus.CombatDefense = _Value.CombatDefense;
		this.UpdateFighter();

		this.OliveStatus.MagicSkill = _Value.MagicSkill;
		this.OliveStatus.MagicAttack = _Value.MagicAttack;
		this.OliveStatus.MagicDefense = _Value.MagicDefense;
		this.UpdateMagical();

		this.OliveStatus.Decorum = _Value.Decorum;
		this.OliveStatus.Art = _Value.Art;
		this.OliveStatus.Conversation = _Value.Conversation;
		this.UpdateSocial();

		this.OliveStatus.Cooking = _Value.Cooking;
		this.OliveStatus.Cleaning = _Value.Cleaning;
		this.OliveStatus.Temperament = _Value.Temperament;
		this.UpdateHouseWork();
	}

	UpdateFighter() {
		this.OliveStatus.Fighter = this.OliveStatus.CombatSkill + this.OliveStatus.CombatAttack + this.OliveStatus.CombatDefense;
	}

	UpdateMagical() {
		this.OliveStatus.Magical = this.OliveStatus.MagicSkill + this.OliveStatus.MagicAttack + this.OliveStatus.MagicDefense;
	}

	UpdateSocial() {
		this.OliveStatus.Social = this.OliveStatus.Decorum + this.OliveStatus.Art + this.OliveStatus.Conversation;
	}

	UpdateHouseWork() {
		this.OliveStatus.HouseWork = this.OliveStatus.Cooking + this.OliveStatus.Cleaning + this.OliveStatus.Temperament;
	}

	UpdateZodiac() {

		if ((this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 12, 22)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 12, 31))) ||
			(this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 1, 1)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 1, 19))))
		{
			this.OliveZodiac = Zodiac["염소자리"];
			this.OlivePatronGod = PatronGod["토성신_새턴"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 1, 20)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 2, 18)))
		{
			this.OliveZodiac = Zodiac["물병자리"];
			this.OlivePatronGod = PatronGod["천왕성신_우라누스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 2, 19)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 3, 20)))
		{
			this.OliveZodiac = Zodiac["물고기자리"];
			this.OlivePatronGod = PatronGod["해왕성신_넵튠"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 3, 21)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 4, 19)))
		{
			this.OliveZodiac = Zodiac["양자리"];
			this.OlivePatronGod = PatronGod["화성신_마르스"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 4, 20)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 5, 20)))
		{
			this.OliveZodiac = Zodiac["황소자리"];
			this.OlivePatronGod = PatronGod["금성신_비너스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 5, 21)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 6, 21)))
		{
			this.OliveZodiac = Zodiac["쌍둥이자리"];
			this.OlivePatronGod = PatronGod["수성신_머큐리"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 6, 22)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 7, 22)))
		{
			this.OliveZodiac = Zodiac["게자리"];
			this.OlivePatronGod = PatronGod["달신_더문"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 7, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 8, 22)))
		{
			this.OliveZodiac = Zodiac["사자자리"];
			this.OlivePatronGod = PatronGod["태양신_솔"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 8, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 9, 22)))
		{
			this.OliveZodiac = Zodiac["처녀자리"];
			this.OlivePatronGod = PatronGod["수성신_머큐리"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 9, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 10, 23)))
		{
			this.OliveZodiac = Zodiac["천칭자리"];
			this.OlivePatronGod = PatronGod["금성신_비너스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 10, 24)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 11, 22)))
		{
			this.OliveZodiac = Zodiac["전갈자리"];
			this.OlivePatronGod = PatronGod["명왕성신_하데스"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 11, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 12, 21)))
		{
			this.OliveZodiac = Zodiac["사수자리"];
			this.OlivePatronGod = PatronGod["목성신_주피터"];
			this.PatronGodSex = false;
		}
		else
		{
			MsgAssert("생일을 정해주지 않았습니다.");
		}
	}


	SetFirstPhysicalCondition() {
		const Random = new GameEngineRandom();
		const RandomNum = Random.RandomInt(0, 16);
		const fHeight = 136.0 + 1.0 * RandomNum;
		const fWeight = 29.2 + 0.95 * RandomNum;
		const fBust = 68.0 + 0.5 * RandomNum;
		const fWaist = 47.5 + 0.625 * RandomNum;
		const fHip = 70.72 + 0.52 * RandomNum;

		this.SetHeight(fHeight);
		this.SetWeight(fWeight);
		this.SetBust(fBust);
		this.SetWaist(fWaist);
		this.SetHip(fHip);
	}

	SetHeight(_Value) {
		this.OlivePhysical.Height = _Value;
	}

	SetWeight(_Value) {
		this.OlivePhysical.Weight = _Value;
	}

	SetBust(_Value) {
		this.OlivePhysical.Bust = _Value;
	}

	SetWaist(_Value) {
		this.OlivePhysical.Waist = _Value;
	}

	SetHip(_Value) {
		this.OlivePhysical.Hip = _Value;
	}

	GetHeight() {
		return this.OlivePhysical.Height;
	}

	GetWeight() {
		return this.OlivePhysical.Weight;
	}

	GetBust() {
		return this.OlivePhysical.Bust;
	}

	GetWaist() {
		return this.OlivePhysical.Waist;
	}

	GetHip() {
		return this.OlivePhysical.Hip;
	}

	GetOliveDiet() {
		return this.OliveDiet;
	}

	SetOliveDiet(_Diet) {
		this.OliveDiet = _Diet;
	}

	GetDiseaseIndex() {
		this.DiseaseIndex = this.OliveStatus.Stress - this.OliveStatus.Constitution;
		if (this.DiseaseIndex < 0)
		{
			this.DiseaseIndex = 0;
		}
		return this.DiseaseIndex;
	}

	GetDelinquency() {
		let Higher = 0.0;
		this.OliveStatus.Morality > this.OliveStatus.Faith ? Higher = this.OliveStatus.Morality : Higher = this.OliveStatus.Faith;
		this.Delinquency = this.OliveStatus.Stress - Higher;
		if (this.Delinquency < 0)
		{
			this.Delinquency = 0;
		}
		return this.Delinquency;
	}

	GetPopularity() {
		return this.Popularity;
	}

	SetOliveAge(_Age) {
		this.OliveAge = _Age;
	}

	IsFat() {
		return this.FatState;
	}

	IsDisease() {
		return this.DiseaseState;
	}

	IsDelinquent() {
		return this.DelinquentState;
	}

	OliveStateUpdate() {
		this.UpdateFat();
		this.UpdateDisease();
		this.UpdateDelinquent();
	}

	OliveRenderUpdate() {
		let AgeCopy = this.OliveAge;

		if (this.OliveAge >= 18)
		{
			AgeCopy = 17;
		}

		this.HeadImageName += String(AgeCopy);
		if (this.DiseaseState)
		{
			this.HeadImageName += "_Sick";
		}
		else if (this.DelinquentState)
		{
			this.HeadImageName += "_Degrade";
		}
		else if (this.OliveStatus.Stress === 0)
		{
			this.HeadImageName += "_Happy";
		}
		else
		{
			this.HeadImageName += "_Nomal";
		}

		if (!this.FatState)
		{
			this.HeadImageName += "_Common";
		}
		else
		{
			this.HeadImageName += "_Fat";
		}

		this.HeadImageName += ".bmp";
		this.HeadRender.SetImage(this.HeadImageName);
		this.HeadRender.SetScaleToImage();
		this.HeadImageName = "Head_";

		this.BodyImageName += String(AgeCopy);
		if (!this.FatState)
		{
			this.BodyImageName += "_Common";
		}
		else
		{
			this.BodyImageName += "_Fat";
		}

		this.BodyImageName += ".bmp";
		this.BodyRender.SetImage(this.BodyImageName);
		this.BodyRender.SetScaleToImage();
		this.BodyImageName = "Body_";

		this.BodyRender.SetPosition(new float4(0, 300 - this.BodyRender.GetScale().hy()));
		this.HeadRender.SetPosition(new float4(0, 300 - this.HeadRender.GetScale().hy() - this.BodyRender.GetScale().y));
	}

	Start() {
		this.ParentLevel = this.GetLevel(); // 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())

		Olive.OlivePlayer = this;

		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BodyRender = this.CreateRender("Body_10_Common.BMP", PM2RenderOrder.Olive);
		this.BodyRender.SetScaleToImage();
		this.HeadRender = this.CreateRender("Head_10_Nomal_Common.BMP", PM2RenderOrder.Olive);
		this.HeadRender.SetScaleToImage();
		this.BodyRender.SetPosition(new float4(0, 300 - this.BodyRender.GetScale().hy()));
		this.HeadRender.SetPosition(new float4(0, 300 - this.HeadRender.GetScale().hy() - this.BodyRender.GetScale().y));

		this.Off();
	}

	Update(_DeltaTime) {
		this.OliveStatus.UpdateMoreThanMin();
		this.OliveStatus.UpdateLessThanMax();
		this.UpdateMonthChange();

		this.UpdateFighter();
		this.UpdateMagical();
		this.UpdateSocial();
		this.UpdateHouseWork();

		this.OliveBirthDayCheck();

	}

	Render(_Time) {

	}

	UpdateMonthChange() {
		if (this.ParentLevel.GetToday().IsEqual(Date.GetMonthLastDate(this.ParentLevel.GetToday())) && this.MonthChange === false)
		{
			this.MonthChange = true;
			this.BloodTypeMonthUpdate();
			this.DietMonthUpdate();
			this.OliveStateUpdate();
			this.OliveRenderUpdate();
		}

		if (this.ParentLevel.GetToday().GetDay() === 1 && this.MonthChange === true)
		{
			this.MonthChange = false;
		}
	}

	BloodTypeMonthUpdate() {
		switch (this.OliveBloodType)
		{
			case BloodType.Null:
				break;
			case BloodType.A:
				this.OliveStatus.Morality += 3;
				this.OliveStatus.Stress += 2;
				break;
			case BloodType.B:
				this.OliveStatus.Stress -= 2;
				break;
			case BloodType.O:
				break;
			case BloodType.AB:
				this.OliveStatus.Sensitivity += 2;
				break;
			default:
				break;
		}
	}

	DietMonthUpdate() {
		const Random = new GameEngineRandom();
		switch (this.OliveDiet)
		{
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.19, 0.22);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.05, 0.08);
				}
				break;
			case Diet["어쨌든_튼튼하게"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.28, 0.35);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.16, 0.20);
				}
				this.OliveStatus.Constitution += 10;
				break;
			case Diet["얌전한_아이로"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.10, 0.13);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.01, 0.04);
				}
				this.OliveStatus.Constitution += -5;
				break;
			case Diet["다이어트_시킨다"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(-0.6, -0.0);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(-1.00, -0.5);
				}
				this.OliveStatus.Constitution += -20;
				break;
			default:
				break;
		}
	}

	OliveBirthDayCheck() {

		if (this.IsBirthDay === false && this.ParentLevel.GetToday().GetYear() !== 1210 && this.ParentLevel.GetToday().GetMonth() === this.OliveBirthDay.GetMonth() && this.ParentLevel.GetToday().GetDay() === this.OliveBirthDay.GetDay())
		{
			this.OliveAge++;
			this.IsBirthDay = true;
			this.OliveRenderUpdate();
		}

		if (this.IsBirthDay === true && this.ParentLevel.GetToday().GetMonth() !== this.OliveBirthDay.GetMonth() || this.ParentLevel.GetToday().GetDay() !== this.OliveBirthDay.GetDay())
		{
			this.IsBirthDay = false;
		}
	}


	UpdateFat() {
		if (this.OlivePhysical.Weight > this.OlivePhysical.Height * 0.95 - 87 - this.OliveAge)
		{
			this.FatState = true;
			return this.FatState;
		}
		else
		{
			this.FatState = false;
			return this.FatState;
		}
	}

	UpdateDisease() {
		if (this.OliveStatus.Stress > this.OliveStatus.Constitution)
		{
			this.DiseaseState = true;
			return this.DiseaseState;
		}
		else
		{
			this.DiseaseState = false;
			return this.DiseaseState;
		}
	}

	UpdateDelinquent() {
		if (this.OliveStatus.Stress > this.OliveStatus.Morality || this.OliveStatus.Stress > this.OliveStatus.Faith)
		{
			this.DelinquentState = true;
			return this.DelinquentState;
		}
		else
		{
			this.DelinquentState = false;
			return this.DelinquentState;
		}
	}
}

// 원본: class Olive::Status — h에서 정의, cpp에서 연산자 구현
// operator +=(→AddAssign) / ==(→IsEqual) / !=(→IsNotEqual) / =(→Assign) 는 JS 메서드로 전사했다.
Olive.Status = class Status {
	// 원본: Status Capricorn = { 25, 20, ... } 같은 중괄호 aggregate 초기화 대응
	// (멤버 선언 순서대로 위치 인자로 받는다. 기본값 0 = 원본 Status()의 멤버 기본값)
	constructor(Constitution = 0, Strength = 0, Intelligence = 0, Refinement = 0, Charisma = 0, Morality = 0, Faith = 0, Sin = 0, Sensitivity = 0, Stress = 0, Fighter = 0, CombatSkill = 0, CombatAttack = 0, CombatDefense = 0, Magical = 0, MagicSkill = 0, MagicAttack = 0, MagicDefense = 0, Social = 0, Decorum = 0, Art = 0, Conversation = 0, HouseWork = 0, Cooking = 0, Cleaning = 0, Temperament = 0) {
		this.Constitution = Constitution;
		this.Strength = Strength;
		this.Intelligence = Intelligence;
		this.Refinement = Refinement;
		this.Charisma = Charisma;
		this.Morality = Morality;
		this.Faith = Faith;
		this.Sin = Sin;
		this.Sensitivity = Sensitivity;
		this.Stress = Stress;

		this.Fighter = Fighter;
		this.CombatSkill = CombatSkill;
		this.CombatAttack = CombatAttack;
		this.CombatDefense = CombatDefense;

		this.Magical = Magical;
		this.MagicSkill = MagicSkill;
		this.MagicAttack = MagicAttack;
		this.MagicDefense = MagicDefense;

		this.Social = Social;
		this.Decorum = Decorum;
		this.Art = Art;
		this.Conversation = Conversation;

		this.HouseWork = HouseWork;
		this.Cooking = Cooking;
		this.Cleaning = Cleaning;
		this.Temperament = Temperament;


		this.MaxConstitution = 999;
		this.MaxStrength = 999;
		this.MaxIntelligence = 999;
		this.MaxRefinement = 999;
		this.MaxCharisma = 999;
		this.MaxMorality = 999;
		this.MaxFaith = 999;
		this.MaxSin = 999;
		this.MaxSensitivity = 999;
		this.MaxStress = 999;

		this.MaxCombatSkill = 100;
		this.MaxCombatAttack = 100;
		this.MaxCombatDefense = 100;

		this.MaxMagicSkill = 100;
		this.MaxMagicAttack = 100;
		this.MaxMagicDefense = 100;

		this.MaxDecorum = 100;
		this.MaxArt = 100;
		this.MaxConversation = 100;

		this.MaxCooking = 100;
		this.MaxCleaning = 100;
		this.MaxTemperament = 100;
	}

	// 원본: Status& operator+=(const Status& _Value)
	AddAssign(_Value) {
		this.Constitution += _Value.Constitution;
		this.Strength += _Value.Strength;
		this.Intelligence += _Value.Intelligence;
		this.Refinement += _Value.Refinement;
		this.Charisma += _Value.Charisma;
		this.Morality += _Value.Morality;
		this.Faith += _Value.Faith;
		this.Sin += _Value.Sin;
		this.Sensitivity += _Value.Sensitivity;
		this.Stress += _Value.Stress;
		this.Fighter += _Value.Fighter;
		this.CombatSkill += _Value.CombatSkill;
		this.CombatAttack += _Value.CombatAttack;
		this.CombatDefense += _Value.CombatDefense;
		this.Magical += _Value.Magical;
		this.MagicSkill += _Value.MagicSkill;
		this.MagicAttack += _Value.MagicAttack;
		this.MagicDefense += _Value.MagicDefense;
		this.Social += _Value.Social;
		this.Decorum += _Value.Decorum;
		this.Art += _Value.Art;
		this.Conversation += _Value.Conversation;
		this.HouseWork += _Value.HouseWork;
		this.Cooking += _Value.Cooking;
		this.Cleaning += _Value.Cleaning;
		this.Temperament += _Value.Temperament;

		return this;
	}

	// 원본: bool operator==(const Status& _Value)
	IsEqual(_Value) {
		if (
			this.Constitution === _Value.Constitution &&
			this.Strength === _Value.Strength &&
			this.Intelligence === _Value.Intelligence &&
			this.Refinement === _Value.Refinement &&
			this.Charisma === _Value.Charisma &&
			this.Morality === _Value.Morality &&
			this.Faith === _Value.Faith &&
			this.Sin === _Value.Sin &&
			this.Sensitivity === _Value.Sensitivity &&
			this.Stress === _Value.Stress &&
			this.Fighter === _Value.Fighter &&
			this.CombatSkill === _Value.CombatSkill &&
			this.CombatAttack === _Value.CombatAttack &&
			this.CombatDefense === _Value.CombatDefense &&
			this.Magical === _Value.Magical &&
			this.MagicSkill === _Value.MagicSkill &&
			this.MagicAttack === _Value.MagicAttack &&
			this.MagicDefense === _Value.MagicDefense &&
			this.Social === _Value.Social &&
			this.Decorum === _Value.Decorum &&
			this.Art === _Value.Art &&
			this.Conversation === _Value.Conversation &&
			this.HouseWork === _Value.HouseWork &&
			this.Cooking === _Value.Cooking &&
			this.Cleaning === _Value.Cleaning &&
			this.Temperament === _Value.Temperament
			)
		{
			return true;
		}
		return false;
	}

	// 원본: bool operator!=(const Status& _Value)  → return !Status::operator==(_Value);
	IsNotEqual(_Value) {
		return !this.IsEqual(_Value);
	}

	// 원본: Status& operator=(const Status& _Value)
	Assign(_Value) {
		this.Constitution = _Value.Constitution;
		this.Strength = _Value.Strength;
		this.Intelligence = _Value.Intelligence;
		this.Refinement = _Value.Refinement;
		this.Charisma = _Value.Charisma;
		this.Morality = _Value.Morality;
		this.Faith = _Value.Faith;
		this.Sin = _Value.Sin;
		this.Sensitivity = _Value.Sensitivity;
		this.Stress = _Value.Stress;

		this.Fighter = _Value.Fighter;
		this.CombatSkill = _Value.CombatSkill;
		this.CombatAttack = _Value.CombatAttack;
		this.CombatDefense = _Value.CombatDefense;

		this.Magical = _Value.Magical;
		this.MagicSkill = _Value.MagicSkill;
		this.MagicAttack = _Value.MagicAttack;
		this.MagicDefense = _Value.MagicDefense;

		this.Social = _Value.Social;
		this.Decorum = _Value.Decorum;
		this.Art = _Value.Art;
		this.Conversation = _Value.Conversation;

		this.HouseWork = _Value.HouseWork;
		this.Cooking = _Value.Cooking;
		this.Cleaning = _Value.Cleaning;
		this.Temperament = _Value.Temperament;

		return this;
	}

	SetStatus(_Para) {
		this.Constitution = _Para.Constitution;
		this.Strength = _Para.Strength;
		this.Intelligence = _Para.Intelligence;
		this.Refinement = _Para.Refinement;
		this.Charisma = _Para.Charisma;
		this.Morality = _Para.Morality;
		this.Faith = _Para.Faith;
		this.Sin = _Para.Sin;
		this.Sensitivity = _Para.Sensitivity;
		this.Stress = _Para.Stress;
		this.Fighter = _Para.Fighter;
		this.CombatSkill = _Para.CombatSkill;
		this.CombatAttack = _Para.CombatAttack;
		this.CombatDefense = _Para.CombatDefense;
		this.Magical = _Para.Magical;
		this.MagicSkill = _Para.MagicSkill;
		this.MagicAttack = _Para.MagicAttack;
		this.MagicDefense = _Para.MagicDefense;
		this.Social = _Para.Social;
		this.Decorum = _Para.Decorum;
		this.Art = _Para.Art;
		this.Conversation = _Para.Conversation;
		this.HouseWork = _Para.HouseWork;
		this.Cooking = _Para.Cooking;
		this.Cleaning = _Para.Cleaning;
		this.Temperament = _Para.Temperament;
	}

	UpdateMoreThanMin() {
		if (this.Constitution < 0)
		{
			this.Constitution = 0;
		}

		if (this.Strength < 0)
		{
			this.Strength = 0;
		}

		if (this.Intelligence < 0)
		{
			this.Intelligence = 0;
		}

		if (this.Refinement < 0)
		{
			this.Refinement = 0;
		}

		if (this.Charisma < 0)
		{
			this.Charisma = 0;
		}

		if (this.Morality < 0)
		{
			this.Morality = 0;
		}

		if (this.Faith < 0)
		{
			this.Faith = 0;
		}

		if (this.Sin < 0)
		{
			this.Sin = 0;
		}

		if (this.Sensitivity < 0)
		{
			this.Sensitivity = 0;
		}

		if (this.Stress < 0)
		{
			this.Stress = 0;
		}

		if (this.CombatSkill < 0)
		{
			this.CombatSkill = 0;
		}

		if (this.CombatAttack < 0)
		{
			this.CombatAttack = 0;
		}

		if (this.CombatDefense < 0)
		{
			this.CombatDefense = 0;
		}

		if (this.MagicSkill < 0)
		{
			this.MagicSkill = 0;
		}

		if (this.MagicAttack < 0)
		{
			this.MagicAttack = 0;
		}

		if (this.MagicDefense < 0)
		{
			this.MagicDefense = 0;
		}

		if (this.Decorum < 0)
		{
			this.Decorum = 0;
		}

		if (this.Art < 0)
		{
			this.Art = 0;
		}

		if (this.Conversation < 0)
		{
			this.Conversation = 0;
		}

		if (this.Cooking < 0)
		{
			this.Cooking = 0;
		}

		if (this.Cleaning < 0)
		{
			this.Cleaning = 0;
		}

		if (this.Temperament < 0)
		{
			this.Temperament = 0;
		}
	}

	UpdateLessThanMax() {
		if (this.Constitution > 999)
		{
			this.Constitution = 999;
		}

		if (this.Strength > 999)
		{
			this.Strength = 999;
		}

		if (this.Intelligence > 999)
		{
			this.Intelligence = 999;
		}

		if (this.Refinement > 999)
		{
			this.Refinement = 999;
		}

		if (this.Charisma > 999)
		{
			this.Charisma = 999;
		}

		if (this.Morality > 999)
		{
			this.Morality = 999;
		}

		if (this.Faith > 999)
		{
			this.Faith = 999;
		}

		if (this.Sin > 999)
		{
			this.Sin = 999;
		}

		if (this.Sensitivity > 999)
		{
			this.Sensitivity = 999;
		}

		if (this.Stress > 999)
		{
			this.Stress = 999;
		}

		if (this.CombatSkill > 100)
		{
			this.CombatSkill = 100;
		}

		if (this.CombatAttack > 100)
		{
			this.CombatAttack = 100;
		}

		if (this.CombatDefense > 100)
		{
			this.CombatDefense = 100;
		}

		if (this.MagicSkill > 100)
		{
			this.MagicSkill = 100;
		}

		if (this.MagicAttack > 100)
		{
			this.MagicAttack = 100;
		}

		if (this.MagicDefense > 100)
		{
			this.MagicDefense = 100;
		}

		if (this.Decorum > 100)
		{
			this.Decorum = 100;
		}

		if (this.Art > 100)
		{
			this.Art = 100;
		}

		if (this.Conversation > 100)
		{
			this.Conversation = 100;
		}

		if (this.Cooking > 100)
		{
			this.Cooking = 100;
		}

		if (this.Cleaning > 100)
		{
			this.Cleaning = 100;
		}

		if (this.Temperament > 100)
		{
			this.Temperament = 100;
		}
	}
};

// 원본: class Olive::PhysicalCondition
Olive.PhysicalCondition = class PhysicalCondition {
	constructor() {
		this.Height = 0;
		this.Weight = 0;
		this.Bust = 0;
		this.Waist = 0;
		this.Hip = 0;
	}
};
