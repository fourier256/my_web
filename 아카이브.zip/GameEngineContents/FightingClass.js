// FightingClass.h / FightingClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class FightingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Fighting.bmp", "Animation_Background_Fighting.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 2, 3, 4, 5, 6, new float4(135, 14));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 9, new float4(-5, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 10, 12, new float4(65, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 13, 13, new float4(-135, 14));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 14, 18, new float4(-175, 14));

		// 원본: GetStatusVarianceMin().SetStatus({ .Stress = 0,.CombatSkill = 1, .CombatDefense = 0});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 1;
		StatusParaMin.CombatDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Stress = 1,.CombatSkill = 1, .CombatDefense = 0 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		StatusParaMax.CombatDefense = 0;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-30);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
