// UIManager.h / UIManager.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { MainMenu } from "./MainMenu.js";
import { PM2ActorOrder } from "./ContentsEnums.js";

export class UIManager extends GameEngineActor {
	static ParentLevel = null;
	static AcMainMenu = null;
	static AcCubeDialog = null;

	constructor() {
		super();
	}

	GetMainMenu() {
		return UIManager.AcMainMenu;
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		UIManager.ParentLevel = this.GetLevel();
		UIManager.AcMainMenu = UIManager.ParentLevel.CreateActor(MainMenu, PM2ActorOrder.Menu0);
		UIManager.AcCubeDialog = UIManager.ParentLevel.GetAcCubeDialog();

		UIManager.AcCubeDialog.SetUpdateText("「주인님, 안녕하십니까. 집사 \n큐브 입니다.」");
	}

	Update(_DeltaTime) {
		this.SetEngineRightClick();
	}

	SetEngineRightClick() {
		if (GameEngineInput.IsUp("EngineMouseRight"))
		{
			if (UIManager.AcCubeDialog.IsUpdate())
			{
				if (UIManager.AcCubeDialog.GetUpdateText() === "「주인님, 안녕하십니까. 집사 \n큐브 입니다.」")
				{
					UIManager.AcCubeDialog.SetUpdateText("「아가씨는 오늘도 건강하십니\n다. 그럼 속히 아가씨의 이번 \n달 스케줄을 결정해 주십시오」");
				}
				else if (UIManager.AcCubeDialog.GetUpdateText() === "「아가씨는 오늘도 건강하십니\n다. 그럼 속히 아가씨의 이번 \n달 스케줄을 결정해 주십시오」")
				{
					UIManager.AcCubeDialog.Off();
					UIManager.AcMainMenu.On();
				}
				else if (UIManager.AcCubeDialog.GetUpdateText() === "예, 알겠습니다. 다음달부터 그\n렇게 하겠습니다")
				{
					UIManager.AcCubeDialog.Off();
					UIManager.AcMainMenu.On();
				}
			}
		}
	}
}
