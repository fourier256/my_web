// Button_BloodType.h / Button_BloodType.cpp 의 전사
import { GlobalButton } from "./GlobalButton.js";
import { BloodType } from "./ContentsEnums.js";

export class Button_BloodType extends GlobalButton {
	constructor() {
		super();
		this.BloodTypeValue = BloodType.Null;
	}
}
