// SetOliveBloodType.h / SetOliveBloodType.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { ButtonState } from "../GameEngineCore/Button.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { Button_BloodType } from "./Button_BloodType.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PM2CollisionOrder, PM2ActorOrder } from "./ContentsEnums.js";

export class SetOliveBloodType extends GameEngineActor {
	static FirstUpdate = false;

	constructor() {
		super();		this.FirstUpdate = false; // 원본 SetOliveBloodType.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;
		// 원본: Button_BloodType* BloodTypeButton[4] = {};
		this.BloodTypeButton = new Array(4).fill(null);
		this.BloodTypeButtonRender1 = new Array(4).fill(null);
		this.BloodTypeButtonRender2 = new Array(4).fill(null);
		this.BloodTypeButtonEffect1Render = new Array(4).fill(null);
		this.BloodTypeButtonEffect2Render = new Array(4).fill(null);
		this.BloodTypeButtonEffect3Render = new Array(4).fill(null);
		this.BloodTypeButtonShadowRender = new Array(4).fill(null);

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.ButtonScale = new float4(24, 24);
		this.ButtonInterval = new float4(64, 0);
		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(192, 120, 178);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i].On();
		}
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i].Off();
		}
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetOliveBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();
		this.SetExplainRender();
		this.SetBloodTypeButton();
		this.SetBloodTypeButtonRender();

		this.Off();
	}

	Update(_DeltaTime) {
		for (let i = 0; i < 4; i++) {
			if (ButtonState.Release === this.BloodTypeButton[i].GetState()) {
				this.BloodTypeButtonEffect1Render[i].Off();
				this.BloodTypeButtonEffect2Render[i].Off();
				this.BloodTypeButtonEffect3Render[i].Off();

				this.BloodTypeButtonRender1[i].On();
				this.BloodTypeButtonRender2[i].On();
				this.BloodTypeButtonShadowRender[i].On();
			}
			else {
				this.BloodTypeButtonEffect1Render[i].On();
				this.BloodTypeButtonEffect2Render[i].On();
				this.BloodTypeButtonEffect3Render[i].On();

				this.BloodTypeButtonRender1[i].Off();
				this.BloodTypeButtonRender2[i].Off();
				this.BloodTypeButtonShadowRender[i].Off();
			}
		}
	}

	Render(_DeltaTime) {
	}

	SetBloodTypeButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(GameEngineWindow.GetScreenSize().x + float4.Left.x * 3 * (this.ButtonScale.hx() + this.ButtonInterval.hx()), 360);

		let Start = 0;

		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i] = Level.CreateActor(Button_BloodType, PM2ActorOrder.Menu0_Button);
			this.BloodTypeButton[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.BloodTypeButton[i].SetScale(this.ButtonScale);
			this.BloodTypeButton[i].SetRenderOrder(PM2RenderOrder.Menu0_Button);
			this.BloodTypeButton[i].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
			this.BloodTypeButton[i].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(i, 0))));
			this.BloodTypeButton[i].SetReleaseImage("SelectButton_Release.Bmp");
			this.BloodTypeButton[i].SetHoverImage("SelectButton_Release.Bmp");
			this.BloodTypeButton[i].SetPressImage("SelectButton_Release.Bmp");
			// 원본: BloodTypeValue = static_cast<BloodType>(Start++);
			this.BloodTypeButton[i].BloodTypeValue = Start++;
			this.BloodTypeButton[i].SetClickCallBack(SetOliveBloodType.ClickBloodType);
		}
	}

	SetBloodTypeButtonRender() {
		this.BloodTypeButtonRender1[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		let LetterRenderPos = this.BloodTypeButton[0].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[0].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[0].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[0].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[0].Off();

		this.BloodTypeButtonEffect2Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[0].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[0].Off();

		this.BloodTypeButtonEffect3Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[0].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[0].Off();

		this.BloodTypeButtonShadowRender[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[0].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[1].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[1].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[1].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[1].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[1].Off();

		this.BloodTypeButtonEffect2Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[1].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[1].Off();

		this.BloodTypeButtonEffect3Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[1].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[1].Off();

		this.BloodTypeButtonShadowRender[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[1].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[2].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[2].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[2].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[2].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[2].Off();

		this.BloodTypeButtonEffect2Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[2].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[2].Off();

		this.BloodTypeButtonEffect3Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[2].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[2].Off();

		this.BloodTypeButtonShadowRender[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[2].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[3].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[3].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[3].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[3].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[3].Off();

		this.BloodTypeButtonEffect2Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[3].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[3].Off();

		this.BloodTypeButtonEffect3Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[3].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[3].Off();

		this.BloodTypeButtonShadowRender[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[3].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = this.ExplainTextBoxScale.half().neg().sub(new float4(0, 36));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static ClickBloodType(_Button) {
		const Ptr = _Button; // 원본: dynamic_cast<Button_BloodType*>
		Olive.OlivePlayer.SetBloodType(Ptr.BloodTypeValue);
		Olive.OlivePlayer.UpdateZodiac();
		Olive.OlivePlayer.SetFirstStatus();
		Olive.OlivePlayer.SetFirstPhysicalCondition();
		GameEngineCore.GetInst().ChangeLevel("Opening");
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['ClickBloodType']) {
	Object.defineProperty(SetOliveBloodType.prototype, __m, { value: function (...args) { return SetOliveBloodType[__m](...args); }, writable: true, configurable: true });
}

