// ScheduleCalendar.h / ScheduleCalendar.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { RGB } from "../WinAPI.js";
import { Date } from "./Date.js";
import { OnedaySchedule } from "./OnedaySchedule.js";
import { SchedulePlayer, ScheduleSave } from "./SchedulePlayer.js";
import { PM2RenderOrder, PM2ActorOrder, ScheduleLabel } from "./ContentsEnums.js";

export class ScheduleCalendar extends GameEngineActor {
	static AcScheduleCalendar = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleCalendar.AcScheduleCalendar = this;
		this.FirstScheduleSet = false;
		this.SecondScheduleSet = false;
		this.ThirdScheduleSet = false;
		this.ScheduleSetEnd = false;
		this.ActorPos = new float4(160, 263);
		this.Today = new Date(1000, 10, 10);
		this.NextDate = new Date(1000, 10, 11);
		this.FirstScheduleEndDate = new Date();
		this.SecondScheduleEndDate = new Date();
		this.ThirdScheduleEndDate = new Date();
		this.ThisMonthSchedule = [];
		this.CalendarFrame = null;
		this.FirstScheduleActorPos = new float4(40, 183);
		this.ScheduleActorInterval = new float4(40, 40);
		this.YearNumRender = new NumberRenderObject();
		this.YearNumRenderScale = new float4(10, 20);
		this.YearNumRenderPos = new float4(-25, -130);
		this.MonthRender = null;
		this.MonthRenderScale = new float4(60, 20);
		this.MonthRenderPos = new float4(30, -130);
		// 원본: GameEngineRender* IconRender[6][7] = {};
		this.IconRender = Array.from({ length: 6 }, () => Array.from({ length: 7 }, () => null));
		this.IconScale = new float4(34, 34);
		this.FirstIconPos = new float4(-120, -80);
	}

	static GetAcScheduleCalendar() {
		return ScheduleCalendar.AcScheduleCalendar;
	}

	On() {
		super.On();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].On();
			}
		}

	}

	Off() {
		super.Off();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].Off();
			}
		}
	}

	ScheduleSetting(_Schedule) {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		const StartDate = this.NextDate;
		const LastDate = Date.GetMonthLastDate(this.NextDate);
		if (!this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.FirstScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate)) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(1);
						this.FirstScheduleEndDate = this.ThisMonthSchedule[y][x].DateValue;
						if (this.ThisMonthSchedule[y][x].DateValue.Equals(LastDate)) {
							this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
							this.ThisMonthSchedule[y][x].SetScheduleOrder(1);
							Save.push(new ScheduleSave(1, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
							this.FirstScheduleEndDate = LastDate;
							this.ScheduleSetEnd = true;
							return;
						}
						Save.push(new ScheduleSave(1, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
					}
				}
			}
		}
		else if (this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.SecondScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(10)) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(2);
						this.SecondScheduleEndDate = this.ThisMonthSchedule[y][x].DateValue;
						if (this.ThisMonthSchedule[y][x].DateValue.Equals(LastDate)) {
							this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
							this.ThisMonthSchedule[y][x].SetScheduleOrder(2);
							Save.push(new ScheduleSave(2, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
							this.SecondScheduleEndDate = LastDate;
							this.ScheduleSetEnd = true;
							return;
						}
						Save.push(new ScheduleSave(2, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.ThirdScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(20)) && this.ThisMonthSchedule[y][x].DateValue.LessEquals(LastDate)) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(3);
						Save.push(new ScheduleSave(3, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
						this.ThirdScheduleEndDate = LastDate;
					}
					this.ScheduleSetEnd = true;
				}
			}
		}
		else {
			MsgAssert("순서 제대로 셋팅 안해줬습니다");
		}

	}

	CancelSchedule() {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		const StartDate = this.NextDate;
		const LastDate = Date.GetMonthLastDate(this.NextDate);
		if (this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.FirstScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate)) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.SecondScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(10)) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && this.ThirdScheduleSet) {
			this.ThirdScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(20)) && this.ThisMonthSchedule[y][x].DateValue.LessEquals(LastDate)) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
	}

	Reset() {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
				this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
			}
		}
		this.FirstScheduleSet = false;
		this.SecondScheduleSet = false;
		this.ThirdScheduleSet = false;
		this.ScheduleSetEnd = false;

		Save.length = 0;
	}

	GetThisMonthSchedule() {
		return this.ThisMonthSchedule;
	}

	GetFirstScheduleEndDate() {
		return this.FirstScheduleEndDate;
	}

	GetSecondScheduleEndDate() {
		return this.SecondScheduleEndDate;
	}

	GetThirdScheduleEndDate() {
		return this.ThirdScheduleEndDate;
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.CalendarFrame = this.CreateRender("Calendar.bmp", PM2RenderOrder.Menu1);
		this.CalendarFrame.SetScaleToImage();
		this.SetThisMonthSchedule();
		this.SetYearNumRender();
		this.SetMonthRender();
		this.Off();
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.NextDate = this.Today.GetNextDate();
			this.UpdateMonthCalendar();
			this.UpdateYearNumRender();
			this.UpdateMonthRender();

		}
	}

	SetThisMonthSchedule() {
		// 원본: ThisMonthSchedule.resize(6);
		for (let y = 0; y < 6; y++) {
			this.ThisMonthSchedule.push([]);
		}
		// 원본: ThisMonthSchedule[y].resize(7); (nullptr 채움)
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < 7; x++) {
				this.ThisMonthSchedule[y].push(null);
			}
		}

		const Level = this.GetLevel();

		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x] = Level.CreateActor(OnedaySchedule, PM2ActorOrder.Menu1);
				this.ThisMonthSchedule[y][x].SetPos(this.FirstScheduleActorPos.add(this.ScheduleActorInterval.mul(new float4(x, y))));
			}
		}
	}

	UpdateMonthCalendar() {
		const OneMonthCalendar = Date.GetOneMonthCalendar(this.NextDate.GetYear(), this.NextDate.GetMonth());

		const MonthFirstWeekday = Date.FindMonthFirstWeekday(this.NextDate.GetYear(), this.NextDate.GetMonth());
		let DayIndex = 0;
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				if (x + (y * 7) < MonthFirstWeekday) {
					this.ThisMonthSchedule[y][x].DateValue.SetNullDate();
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
				else if (x + (y * 7) < MonthFirstWeekday + OneMonthCalendar.length) {
					this.ThisMonthSchedule[y][x].DateValue.SetDate(OneMonthCalendar[DayIndex++]);
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
				else {
					this.ThisMonthSchedule[y][x].DateValue.SetNullDate();
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
			}
		}
	}

	UpdateDayNumRender() {

	}

	SetYearNumRender() {
		this.YearNumRender.SetOwner(this);
		this.YearNumRender.SetImage("Num.bmp", this.YearNumRenderScale, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.YearNumRender.SetAlign(Align.Right);
		this.YearNumRender.SetRenderPos(this.YearNumRenderPos);
	}

	SetMonthRender() {
		this.MonthRender = this.CreateRender("Num_Month.bmp", PM2RenderOrder.Menu1_Display);
		this.MonthRender.SetScale(this.MonthRenderScale);
		this.MonthRender.SetPosition(this.MonthRenderPos);
	}

	UpdateYearNumRender() {
		this.YearNumRender.SetValue(this.NextDate.GetYear());
	}

	UpdateMonthRender() {
		this.MonthRender.SetFrame(this.NextDate.GetMonth() - 1);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcScheduleCalendar']) {
	Object.defineProperty(ScheduleCalendar.prototype, __m, { value: function (...args) { return ScheduleCalendar[__m](...args); }, writable: true, configurable: true });
}

