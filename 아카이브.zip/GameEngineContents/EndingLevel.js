// EndingLevel.h / EndingLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineResources, GameEngineSoundPlayer } from "../GameEngineCore/GameEngineResources.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { PM2ActorOrder } from "./ContentsEnums.js";

import { FirstScene } from "./FirstScene.js";
import { SecondScene } from "./SecondScene.js";
import { ThirdScene } from "./ThirdScene.js";
import { FourthScene } from "./FourthScene.js";
import { EndingPortrait } from "./EndingPortrait.js";
import { Olive } from "./Olive.js";

// enum class Ending (Null = -1, 이후 선언 순서대로 0부터)
export const Ending = Object.freeze({
	"Null": -1,
	"마왕": 0,
	"SM여왕": 1,
	"암흑가의보스": 2,
	"폭력배": 3,
	"고급창부": 4,
	"사기꾼": 5,
	"창부": 6,
	"광대": 7,
	"작가": 8,
	"화가": 9,
	"무용수": 10,
	"여왕": 11,
	"재상": 12,
	"박사": 13,
	"대신": 14,
	"대주교": 15,
	"학사": 16,
	"재판관": 17,
	"수녀": 18,
	"보모": 19,
	"여관직원": 20,
	"농부": 21,
	"교회직원": 22,
	"요리사": 23,
	"나무꾼": 24,
	"미용사": 25,
	"미장이": 26,
	"사냥꾼": 27,
	"묘지기": 28,
	"가정교사": 29,
	"주점직원": 30,
	"어둠의주점원": 31,
	"밤의무희": 32,
	"궁녀": 33,
	"용사": 34,
	"장군": 35,
	"근위대장": 36,
	"기사": 37,
	"무도사범": 38,
	"현상금사냥꾼": 39,
	"병사": 40,
	"용병": 41,
	"마법용사": 42,
	"왕궁마법사": 43,
	"마법사범": 44,
	"마도사": 45,
	"마법사": 46,
	"점술사": 47,
	"마술사": 48,
	"거리의광대": 49,
	"왕비": 50,
	"왕의후궁": 51,
	"백작부인": 52,
	"부호의처": 53,
	"상인의처": 54,
	"농부의처": 55,
	"지주의첩": 56,
	"이혼녀": 57,
	"신부수업": 58
});

export class EndingLevel extends GameEngineLevel {
	constructor() {
		super();
		this.Time = 0;
		this.AcOlive = null;

		this.OliveEnding = Ending.Null;

		this.AcFirstScene = null;
		this.AcSecondScene = null;
		this.AcThirdScene = null;
		this.AcFourthScene = null;

		this.AcEndingPortrait = null;
		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	Loading() {
		this.ImageLoad();
		this.SoundLoad();
		this.AcFirstScene = this.CreateActor(FirstScene, PM2ActorOrder.BackGround);
		this.AcSecondScene = this.CreateActor(SecondScene, PM2ActorOrder.BackGround);
		this.AcThirdScene = this.CreateActor(ThirdScene, PM2ActorOrder.BackGround);
		this.AcFourthScene = this.CreateActor(FourthScene, PM2ActorOrder.BackGround);
		this.AcEndingPortrait = this.CreateActor(EndingPortrait, PM2ActorOrder.BackGround);

	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("1"))
		{
			GameEngineCore.GetInst().DebugSwitch();
		}

		let LocalDeltaTime = _DeltaTime;

		if (GameEngineInput.IsPress("2"))
		{
			LocalDeltaTime *= 16;
			this.Time += LocalDeltaTime;
		}
		else
		{
			this.Time += LocalDeltaTime;
		}

		this.Time += _DeltaTime;
		if (this.Time >= 0 && this.Time < 10)
		{
			this.AcFirstScene.On();
		}
		else if (this.Time >= 10 && this.Time < 25)
		{
			this.AcFirstScene.Off();
			this.AcSecondScene.On();
		}
		else if (this.Time >= 25 && this.Time < 40)
		{
			this.AcSecondScene.Off();
			this.AcThirdScene.On();
		}
		else if (this.Time >= 40 && this.Time < 50)
		{
			this.AcThirdScene.Off();
			this.AcFourthScene.On();
		}
		else if (this.Time >= 50)
		{
			this.AcFourthScene.Off();
			this.AcEndingPortrait.On();
		}

		if (GameEngineInput.IsDown("LevelChange"))
		{
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}
	}

	LevelChangeEnd(_NextLevel) {
		this.Time = 0;
		this.AcFirstScene.Off();
		this.AcSecondScene.Off();
		this.AcThirdScene.Off();
		this.AcFourthScene.Off();
		this.AcEndingPortrait.Off();
		this.BGMPlayer.Stop();
		this.AcOlive.SetOliveAge(17);
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("30_Ending.mp3");
		this.AcOlive = Olive.OlivePlayer;
		if (this.AcOlive.OliveStatus.Fighter >= 300 && this.AcOlive.OliveStatus.Magical >= 200 && this.AcOlive.OliveStatus.Sin >= 500)
		{
			this.OliveEnding = Ending["마왕"];
		}
		else if ((this.AcOlive.OliveStatus.Morality === 0 && this.AcOlive.OliveStatus.Sin >= 100) || (this.AcOlive.OliveStatus.Morality < 30 && this.AcOlive.OliveStatus.Sin >= 250))
		{
			if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1 && this.AcOlive.OliveStatus.Refinement >= 200 && this.AcOlive.OliveStatus.Charisma >= 200)
			{
				this.OliveEnding = Ending["SM여왕"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1 && this.AcOlive.OliveStatus.Refinement >= 200 && this.AcOlive.OliveStatus.Charisma < 200)
			{
				this.OliveEnding = Ending["암흑가의보스"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1)
			{
				this.OliveEnding = Ending["폭력배"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0 && this.AcOlive.OliveStatus.Charisma >= 200 && this.AcOlive.OliveStatus.Conversation >= 70 && this.AcOlive.OliveStatus.Temperament >= 70)
			{
				this.OliveEnding = Ending["고급창부"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0 && this.AcOlive.OliveStatus.Charisma < 200 && this.AcOlive.OliveStatus.Conversation >= 70)
			{
				this.OliveEnding = Ending["사기꾼"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0)
			{
				this.OliveEnding = Ending["창부"];
			}
		}
		else if (this.EstimateMaxMinusMin() < 50 && this.EstimateGrade(this.EstimateMax()) >= 2)
		{
			if (this.EstimateGrade(this.EstimateMax()) === 4 && this.AcOlive.OliveStatus.Refinement >= 800)
			{
				this.OliveEnding = Ending["여왕"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 4 && this.AcOlive.OliveStatus.Refinement < 800)
			{
				this.OliveEnding = Ending["재상"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["박사"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Morality >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["대신"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Faith && this.AcOlive.OliveStatus.Morality < this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["대주교"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["학사"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Morality >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["재판관"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Faith && this.AcOlive.OliveStatus.Morality < this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["수녀"];
			}
		}
		else
		{
			this.OliveEnding = Ending["궁녀"];
		}

	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("EndingLevel");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FirstSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SecondSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("ThirdSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("EndingPortrait.BMP"));
		Dir.Move("EndingIllustration");
		const AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("30_Ending.mp3"));
	}

	EstimateGrade(_Estimate) {
		if (60 >= _Estimate)
		{
			return 0;
		}
		else if (60 < _Estimate && 160 >= _Estimate)
		{
			return 1;
		}
		else if (160 < _Estimate && 230 >= _Estimate)
		{
			return 2;
		}
		else if (230 < _Estimate && 270 >= _Estimate)
		{
			return 3;
		}
		else if (270 < _Estimate)
		{
			return 4;
		}
	}

	EstimateMaxMinusMin() {
		return this.EstimateMax() - this.EstimateMin();
	}

	EstimateMax() {
		const Estimate = [];
		// 원본: Estimate.reserve(4);
		Estimate.push(this.AcOlive.OliveStatus.Fighter);
		Estimate.push(this.AcOlive.OliveStatus.Magical);
		Estimate.push(this.AcOlive.OliveStatus.Social);
		Estimate.push(this.AcOlive.OliveStatus.HouseWork);

		let Max = Estimate[0];
		for (const i of Estimate)
		{
			Max = Max > i ? Max : i;
		}
		return Max;
	}

	EstimateMin() {
		const Estimate = [];
		// 원본: Estimate.reserve(4);
		Estimate.push(this.AcOlive.OliveStatus.Fighter);
		Estimate.push(this.AcOlive.OliveStatus.Magical);
		Estimate.push(this.AcOlive.OliveStatus.Social);
		Estimate.push(this.AcOlive.OliveStatus.HouseWork);

		let Min = Estimate[0];
		for (const i of Estimate)
		{
			Min = Min > i ? i : Min;
		}
		return Min;
	}

	GetOliveEnding() {
		return this.OliveEnding;
	}

	GetAcOlive() {
		return this.AcOlive;
	}
}
