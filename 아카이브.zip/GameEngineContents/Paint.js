import { float4 } from "../GameEngineBase/GameEngineMath.js";
// Paint.h / Paint.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class Paint extends GameEngineActor {
	constructor() {
		super();
		this.PaintRender = null;
	}

	Start() {
		this.PaintRender = this.CreateRender("paint_default.bmp", PM2RenderOrder.BackGroundObj);
		this.PaintRender.SetScaleToImage();
		this.SetPos(new float4(519, 157));
	}

	Update(_DeltaTime) {
	}

	Render(_Time) {
	}
}
