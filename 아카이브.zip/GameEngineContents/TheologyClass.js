// TheologyClass.h / TheologyClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class TheologyClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Theology.bmp", "Animation_Background_Theology.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 3, 4, 5, new float4(85, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 6, 7, new float4(175, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 8, 9, new float4(-95, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-175, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-25, 12));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Faith = 1, .Stress = 0,.MagicDefense = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Faith = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 1, .Faith = 2,.Stress = 1, .MagicDefense = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 1;
		StatusParaMax.Faith = 2;
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicDefense = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
