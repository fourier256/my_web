// Animation.h / Animation.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export class Animation extends GameEngineActor {
	constructor() {
		super();
		this.AccTime = 0.0;
		this.StartFrame = 0;
		this.MoveSpeed = 100.0;

		this.AnimationRender = null;
		this.Background = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
	}

	Update(_Deltatime) {
	}

	Render(_Time) {
	}
}
