// StatusWindowManager.h / StatusWindowManager.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { PM2ActorOrder } from "./ContentsEnums.js";
import { MainMenu } from "./MainMenu.js";
import { BasicStatusWindow } from "./BasicStatusWindow.js";
import { EstimateStatusWindow } from "./EstimateStatusWindow.js";
import { FighterAndMagicalStatusWindow } from "./FighterAndMagicalStatusWindow.js";
import { SocialAndHouseworkStatusWindow } from "./SocialAndHouseworkStatusWindow.js";

export class StatusWindowManager extends GameEngineActor {
	constructor() {
		super();
		this.AcMainMenu = null;

		this.AcBasicStatusWindow = null;
		this.AcEstimateStatusWindow = null;
		this.AcFighterAndMagicalStatusWindow = null;
		this.AcSocialAndHouseworkStatusWindow = null;
	}

	On() {
		super.On();
		this.AcBasicStatusWindow.On();
		this.AcEstimateStatusWindow.On();
		this.AcFighterAndMagicalStatusWindow.On();
		this.AcSocialAndHouseworkStatusWindow.On();
	}

	Off() {
		super.Off();
		this.AcBasicStatusWindow.Off();
		this.AcEstimateStatusWindow.Off();
		this.AcFighterAndMagicalStatusWindow.Off();
		this.AcSocialAndHouseworkStatusWindow.Off();
	}

	Start() {
		const Level = this.GetLevel();
		this.AcMainMenu = MainMenu.GetAcMainMenu();

		this.AcBasicStatusWindow = Level.CreateActor(BasicStatusWindow, PM2ActorOrder.Menu1);
		this.AcEstimateStatusWindow = Level.CreateActor(EstimateStatusWindow, PM2ActorOrder.Menu1);
		this.AcFighterAndMagicalStatusWindow = Level.CreateActor(FighterAndMagicalStatusWindow, PM2ActorOrder.Menu1);
		this.AcSocialAndHouseworkStatusWindow = Level.CreateActor(SocialAndHouseworkStatusWindow, PM2ActorOrder.Menu1);
		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			this.AcMainMenu.On();
		}
	}
}
