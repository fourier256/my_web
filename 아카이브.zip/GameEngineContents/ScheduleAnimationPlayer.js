// ScheduleAnimationPlayer.h / ScheduleAnimationPlayer.cpp 의 전사
import { MenuFrame, MenuFrameStyleEnum } from "./MenuFrame.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

// enum class AnimationState
export const AnimationState = Object.freeze({
	Null: -1,
	Dance: 0,
	Fencing: 1,
	Fighting: 2,
	Magic: 3,
	Painting: 4,
	Poetry: 5,
	Protocol: 6,
	Science: 7,
	Strategy: 8,
	Theology: 9,
});

export class ScheduleAnimationPlayer extends MenuFrame {
	constructor() {
		super();
		this.ActorPos = new float4(240, 380);
		this.BoxScale = new float4(420, 180);
		this.StateValue = AnimationState.Null;
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;
	}

	Start() {
		// 원본: RaisingSimLevel* Level = dynamic_cast<RaisingSimLevel*>(GetLevel());
		const Level = this.GetLevel();
		this.SetPos(this.ActorPos);
		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.BoxScale);

		this.AcDanceClass = Level.AcDanceClass;
		this.AcFencingClass = Level.AcFencingClass;
		this.AcFightingClass = Level.AcFightingClass;
		this.AcMagicClass = Level.AcMagicClass;
		this.AcPaintingClass = Level.AcPaintingClass;
		this.AcPoetryClass = Level.AcPoetryClass;
		this.AcProtocolClass = Level.AcProtocolClass;
		this.AcScienceClass = Level.AcScienceClass;
		this.AcStrategyClass = Level.AcStrategyClass;
		this.AcTheologyClass = Level.AcTheologyClass;

		this.Off();
	}

	Update(_DeltaTime) {

	}
}
