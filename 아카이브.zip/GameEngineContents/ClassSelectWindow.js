// ClassSelectWindow.h / ClassSelectWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { IconCode, ScheduleLabel, PM2ActorOrder } from "./ContentsEnums.js";
import { IconButton } from "./IconButton.js";
import { CubeFace } from "./CubeDialog.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { SchedulingConfirmSelectionMenu } from "./SchedulingConfirmSelectionMenu.js";
import { ScheduleSelectionMenu } from "./ScheduleSelectionMenu.js";

export class ClassSelectWindow extends GameEngineActor {
	static ParentLevel = null;
	static AcScheduleCalendar = null;
	static AcSchedulingConfirmSelectionMenu = null;
	static AcClassSelectWindow = null;

	static AcPaintingClass = null;
	static AcDanceClass = null;
	static AcMagicClass = null;
	static AcProtocolClass = null;
	static AcFencingClass = null;
	static AcFightingClass = null;
	static AcTheologyClass = null;
	static AcStrategyClass = null;
	static AcScienceClass = null;
	static AcPoetryClass = null;

	constructor() {
		super();
		this.AcCubeDialog = null;
		this.Painting = null;
		this.Button1Pos = new float4(540, 400);

		this.Dance = null;
		this.Button2Pos = new float4(710, 400);

		this.Magic = null;
		this.Button3Pos = new float4(540, 340);

		this.Protocol = null;
		this.Button4Pos = new float4(710, 340);

		this.Fencing = null;
		this.Button5Pos = new float4(540, 280);

		this.Fighting = null;
		this.Button6Pos = new float4(710, 280);

		this.Theology = null;
		this.Button7Pos = new float4(540, 220);

		this.Strategy = null;
		this.Button8Pos = new float4(710, 220);

		this.Science = null;
		this.Button9Pos = new float4(540, 160);

		this.Poetry = null;
		this.Button10Pos = new float4(710, 160);

		ClassSelectWindow.AcClassSelectWindow = this;
	}

	GetPaintingButton() {
		return this.Painting.GetButton();
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.Painting.On();
		this.Dance.On();
		this.Magic.On();
		this.Protocol.On();
		this.Fencing.On();
		this.Fighting.On();
		this.Theology.On();
		this.Strategy.On();
		this.Science.On();
		this.Poetry.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.Painting.Off();
		this.Dance.Off();
		this.Magic.Off();
		this.Protocol.Off();
		this.Fencing.Off();
		this.Fighting.Off();
		this.Theology.Off();
		this.Strategy.Off();
		this.Science.Off();
		this.Poetry.Off();
	}

	Start() {
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())
		ClassSelectWindow.ParentLevel = this.GetLevel();
		this.AcCubeDialog = ClassSelectWindow.ParentLevel.GetAcCubeDialog();
		ClassSelectWindow.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu = ClassSelectWindow.ParentLevel.CreateActor(SchedulingConfirmSelectionMenu, PM2ActorOrder.Menu2);

		this.Painting = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Dance = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Magic = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Protocol = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Fencing = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Fighting = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Theology = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Strategy = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Science = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Poetry = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);

		this.Painting.SetIconButton(IconCode["미술"], "미술", "초급", 40, this.Button1Pos);
		this.Dance.SetIconButton(IconCode["무용"], "무도", "초급", 50, this.Button2Pos);
		this.Magic.SetIconButton(IconCode["마법"], "마법", "초급", 60, this.Button3Pos);
		this.Protocol.SetIconButton(IconCode["예법"], "예법", "초급", 40, this.Button4Pos);
		this.Fencing.SetIconButton(IconCode["검술"], "검술", "초급", 40, this.Button5Pos);
		this.Fighting.SetIconButton(IconCode["격투술"], "격투술", "초급", 30, this.Button6Pos);
		this.Theology.SetIconButton(IconCode["신학"], "신학", "초급", 40, this.Button7Pos);
		this.Strategy.SetIconButton(IconCode["군사학"], "군사학\t", "초급", 50, this.Button8Pos);
		this.Science.SetIconButton(IconCode["자연과학"], "자연과학", "초급", 30, this.Button9Pos);
		this.Poetry.SetIconButton(IconCode["시문학"], "시문", "초급", 40, this.Button10Pos);

		ClassSelectWindow.AcDanceClass = ClassSelectWindow.ParentLevel.AcDanceClass;
		ClassSelectWindow.AcFencingClass = ClassSelectWindow.ParentLevel.AcFencingClass;
		ClassSelectWindow.AcFightingClass = ClassSelectWindow.ParentLevel.AcFightingClass;
		ClassSelectWindow.AcMagicClass = ClassSelectWindow.ParentLevel.AcMagicClass;
		ClassSelectWindow.AcPaintingClass = ClassSelectWindow.ParentLevel.AcPaintingClass;
		ClassSelectWindow.AcPoetryClass = ClassSelectWindow.ParentLevel.AcPoetryClass;
		ClassSelectWindow.AcProtocolClass = ClassSelectWindow.ParentLevel.AcProtocolClass;
		ClassSelectWindow.AcScienceClass = ClassSelectWindow.ParentLevel.AcScienceClass;
		ClassSelectWindow.AcStrategyClass = ClassSelectWindow.ParentLevel.AcStrategyClass;
		ClassSelectWindow.AcTheologyClass = ClassSelectWindow.ParentLevel.AcTheologyClass;

		this.SetButtonClick();

		this.Off();
	}

	Update(_DeltaTime) {
		this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "딸에게 무엇을 가르치시겠습니\n까?");

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			ScheduleSelectionMenu.GetAcScheduleSelectionMenu().On();
		}
	}

	SetButtonClick() {
		this.Painting.GetButton().SetClickCallBack(ClassSelectWindow.ClickPainting);
		this.Dance.GetButton().SetClickCallBack(ClassSelectWindow.ClickDance);
		this.Magic.GetButton().SetClickCallBack(ClassSelectWindow.ClickMagic);
		this.Protocol.GetButton().SetClickCallBack(ClassSelectWindow.ClickProtocol);
		this.Fencing.GetButton().SetClickCallBack(ClassSelectWindow.ClickFencing);
		this.Fighting.GetButton().SetClickCallBack(ClassSelectWindow.ClickFighting);
		this.Theology.GetButton().SetClickCallBack(ClassSelectWindow.ClickTheology);
		this.Strategy.GetButton().SetClickCallBack(ClassSelectWindow.ClickStrategy);
		this.Science.GetButton().SetClickCallBack(ClassSelectWindow.ClickScience);
		this.Poetry.GetButton().SetClickCallBack(ClassSelectWindow.ClickPoetry);
	}

	static ClickPainting(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["미술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickDance(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["무용"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickMagic(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["마법"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickProtocol(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["예법"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickFencing(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["검술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickFighting(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["격투술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickTheology(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["신학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickStrategy(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["군사학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickScience(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["자연과학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickPoetry(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["시문학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['ClickPainting', 'ClickDance', 'ClickMagic', 'ClickProtocol', 'ClickFencing', 'ClickFighting', 'ClickTheology', 'ClickStrategy', 'ClickScience', 'ClickPoetry']) {
	Object.defineProperty(ClassSelectWindow.prototype, __m, { value: function (...args) { return ClassSelectWindow[__m](...args); }, writable: true, configurable: true });
}

