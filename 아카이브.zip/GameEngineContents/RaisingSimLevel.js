// RaisingSimLevel.h / RaisingSimLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineResources, GameEngineSoundPlayer } from "../GameEngineCore/GameEngineResources.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { Date } from "./Date.js";
import { PM2ActorOrder, Season } from "./ContentsEnums.js";

import { Olive } from "./Olive.js";
import { Background } from "./Background.js";

import { UIManager } from "./UIManager.js";
import { MainMenu } from "./MainMenu.js";

import { Flower } from "./Flower.js";
import { Paint } from "./Paint.js";
import { DateViewer } from "./DateViewer.js";
import { BasicInfo } from "./BasicInfo.js";

import { CubeDialog, CubeFace } from "./CubeDialog.js";
import { ScheduleDialog } from "./ScheduleDialog.js";

import { MousePoint } from "./MousePoint.js";

import { DanceClass } from "./DanceClass.js";
import { FencingClass } from "./FencingClass.js";
import { FightingClass } from "./FightingClass.js";
import { MagicClass } from "./MagicClass.js";
import { PaintingClass } from "./PaintingClass.js";
import { PoetryClass } from "./PoetryClass.js";
import { ProtocolClass } from "./ProtocolClass.js";
import { ScienceClass } from "./ScienceClass.js";
import { StrategyClass } from "./StrategyClass.js";
import { TheologyClass } from "./TheologyClass.js";

export class RaisingSimLevel extends GameEngineLevel {
	static AcCubeDialog = null;
	static AcScheduleDialog = null;

	constructor() {
		super();
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;

		this.AcOlive = null;
		this.Today = new Date(1000, 10, 10);
		this.TodaySeason = Season.Null;

		this.AcBackground = null;
		this.AcFlower = null;
		this.AcPaint = null;
		this.AcUIManager = null;

		this.BGMPlayer = new GameEngineSoundPlayer();

		this.Time = 0;

		this.SeasonChange = false;
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		RaisingSimLevel.AcCubeDialog = this.CreateActor(CubeDialog, PM2ActorOrder.Dialog1);
		RaisingSimLevel.AcScheduleDialog = this.CreateActor(ScheduleDialog, PM2ActorOrder.Dialog2);
		this.AcBackground = this.CreateActor(Background, PM2ActorOrder.BackGround);
		this.CreateActor(DateViewer, PM2ActorOrder.Menu0);
		this.CreateActor(BasicInfo, PM2ActorOrder.Menu0);

		this.AcDanceClass = this.CreateActor(DanceClass, PM2ActorOrder.Menu2);
		this.AcFencingClass = this.CreateActor(FencingClass, PM2ActorOrder.Menu2);
		this.AcFightingClass = this.CreateActor(FightingClass, PM2ActorOrder.Menu2);
		this.AcMagicClass = this.CreateActor(MagicClass, PM2ActorOrder.Menu2);
		this.AcPaintingClass = this.CreateActor(PaintingClass, PM2ActorOrder.Menu2);
		this.AcPoetryClass = this.CreateActor(PoetryClass, PM2ActorOrder.Menu2);
		this.AcProtocolClass = this.CreateActor(ProtocolClass, PM2ActorOrder.Menu2);
		this.AcScienceClass = this.CreateActor(ScienceClass, PM2ActorOrder.Menu2);
		this.AcStrategyClass = this.CreateActor(StrategyClass, PM2ActorOrder.Menu2);
		this.AcTheologyClass = this.CreateActor(TheologyClass, PM2ActorOrder.Menu2);

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.CreateActor(Olive, PM2ActorOrder.Olive);
		this.CreateActor(Flower, PM2ActorOrder.BackGround);
		this.CreateActor(Paint, PM2ActorOrder.BackGround);


		this.AcUIManager = this.CreateActor(UIManager);
		GameEngineInput.CreateKey("3", '3'.charCodeAt(0));
		GameEngineInput.CreateKey("4", '4'.charCodeAt(0));
		GameEngineInput.CreateKey("5", '5'.charCodeAt(0));
		GameEngineInput.CreateKey("q", 'q'.charCodeAt(0));
		GameEngineInput.CreateKey("w", 'w'.charCodeAt(0));
		GameEngineInput.CreateKey("e", 'e'.charCodeAt(0));
		GameEngineInput.CreateKey("r", 'r'.charCodeAt(0));
		GameEngineInput.CreateKey("a", 'a'.charCodeAt(0));
		GameEngineInput.CreateKey("s", 's'.charCodeAt(0));
	}

	Update(_DeltaTime) {
		if (GameEngineInput.IsDown("LevelChange"))
		{
			GameEngineCore.GetInst().ChangeLevel("Ending");
		}

		if (GameEngineInput.IsDown("1"))
		{
			GameEngineCore.GetInst().DebugSwitch();
		}

		if (GameEngineInput.IsDown("2"))
		{
			// 원본: ++Today;
			this.Today = this.Today.GetNextDate();
		}

		if (GameEngineInput.IsDown("3"))
		{
			this.GoToBeforBirthDay();
		}

		if (GameEngineInput.IsDown("4"))
		{
			this.OliveAllStatMax();
		}

		if (GameEngineInput.IsDown("5"))
		{
			this.OliveAllStatMaxExeptSin();
		}

		if (this.Today.GetMonth() === this.AcOlive.GetOliveBirthDay().GetMonth() && this.Today.GetDay() === this.AcOlive.GetOliveBirthDay().GetDay() && this.AcOlive.GetOliveAge() === 18)
		{
			GameEngineCore.GetInst().ChangeLevel("Ending");
		}

		this.OliveStateChange();
		this.UpdateSeason();
		this.BGMUpdate();
	}

	LevelChangeEnd(_NextLevel) {
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.AcOlive = Olive.OlivePlayer;
		Olive.OlivePlayer.On();
		this.AcUIManager.GetMainMenu().Off();
		RaisingSimLevel.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「주인님, 안녕하십니까. 집사 \n큐브 입니다.」");
		this.UpdateSeason();
		switch (this.TodaySeason)
		{
			case Season.Spring:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
				break;
			case Season.Summer:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
				break;
			case Season.Fall:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
				break;
			case Season.Winter:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
				break;
			default:
				break;
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("04_Main_screen_(Spring).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("05_Main_screen_(Summer).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("06_Main_screen_(Autumn).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("07_Main_screen_(Winter).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("13_Training.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("RaisingLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("paint_default.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_spring.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_summer.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_fall.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_winter.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_disease.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("background.BMP"));

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("DateViewer.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_WeekDay.BMP")).Cut(7, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Month.BMP")).Cut(12, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Day.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num.BMP")).Cut(10, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BasicInfo.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Age.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu_Buttons.bmp")).Cut(4, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu_Schedule.bmp"));

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Detail.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Estemate.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Physical.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Detail.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Estemate.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Physical.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGauge.bmp")).Cut(2, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Status.bmp")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Status_etc.bmp")).Cut(3, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Icon.bmp")).Cut(15, 7);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BloodTypeRender.bmp")).Cut(4, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Calendar.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("IconButton_Hover.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FoodCost.bmp"));


		Dir.Move("Cube");

		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Cube");
		Dir.Move("Classes");

		AllFile.length = 0;
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.Move("Object");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Dance.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Fencing.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Fighting.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Magic.bmp")).Cut(13, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Painting.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Poetry.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Protocol.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Science.bmp")).Cut(13, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Strategy.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Theology.bmp")).Cut(13, 2);

		Dir.MoveParentToDirectory("Object");
		Dir.Move("Mug");
		AllFile.length = 0;
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}
	}

	GoToBeforBirthDay() {
		this.Today.SetDate(this.Today.GetYear() + 1, this.AcOlive.GetOliveBirthDay().GetMonth(), this.AcOlive.GetOliveBirthDay().GetDay() - 1);
	}

	OliveAllStatMax() {
		Olive.OlivePlayer.OliveStatus.Constitution = Olive.OlivePlayer.OliveStatus.MaxConstitution;
		Olive.OlivePlayer.OliveStatus.Strength = Olive.OlivePlayer.OliveStatus.MaxStrength;
		Olive.OlivePlayer.OliveStatus.Intelligence = Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		Olive.OlivePlayer.OliveStatus.Refinement = Olive.OlivePlayer.OliveStatus.MaxRefinement;
		Olive.OlivePlayer.OliveStatus.Charisma = Olive.OlivePlayer.OliveStatus.MaxCharisma;
		Olive.OlivePlayer.OliveStatus.Morality = Olive.OlivePlayer.OliveStatus.MaxMorality;
		Olive.OlivePlayer.OliveStatus.Faith = Olive.OlivePlayer.OliveStatus.MaxFaith;
		Olive.OlivePlayer.OliveStatus.Sin = Olive.OlivePlayer.OliveStatus.MaxSin;
		Olive.OlivePlayer.OliveStatus.Sensitivity = Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		Olive.OlivePlayer.OliveStatus.CombatSkill = Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		Olive.OlivePlayer.OliveStatus.CombatAttack = Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		Olive.OlivePlayer.OliveStatus.CombatDefense = Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		Olive.OlivePlayer.OliveStatus.MagicSkill = Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		Olive.OlivePlayer.OliveStatus.MagicAttack = Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		Olive.OlivePlayer.OliveStatus.MagicDefense = Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		Olive.OlivePlayer.OliveStatus.Decorum = Olive.OlivePlayer.OliveStatus.MaxDecorum;
		Olive.OlivePlayer.OliveStatus.Art = Olive.OlivePlayer.OliveStatus.MaxArt;
		Olive.OlivePlayer.OliveStatus.Conversation = Olive.OlivePlayer.OliveStatus.MaxConversation;
		Olive.OlivePlayer.OliveStatus.Cooking = Olive.OlivePlayer.OliveStatus.MaxCooking;
		Olive.OlivePlayer.OliveStatus.Cleaning = Olive.OlivePlayer.OliveStatus.MaxCleaning;
		Olive.OlivePlayer.OliveStatus.Temperament = Olive.OlivePlayer.OliveStatus.MaxTemperament;
	}

	OliveAllStatMaxExeptSin() {
		Olive.OlivePlayer.OliveStatus.Constitution = Olive.OlivePlayer.OliveStatus.MaxConstitution;
		Olive.OlivePlayer.OliveStatus.Strength = Olive.OlivePlayer.OliveStatus.MaxStrength;
		Olive.OlivePlayer.OliveStatus.Intelligence = Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		Olive.OlivePlayer.OliveStatus.Refinement = Olive.OlivePlayer.OliveStatus.MaxRefinement;
		Olive.OlivePlayer.OliveStatus.Charisma = Olive.OlivePlayer.OliveStatus.MaxCharisma;
		Olive.OlivePlayer.OliveStatus.Morality = Olive.OlivePlayer.OliveStatus.MaxMorality;
		Olive.OlivePlayer.OliveStatus.Faith = Olive.OlivePlayer.OliveStatus.MaxFaith;
		Olive.OlivePlayer.OliveStatus.Sin = 0;
		Olive.OlivePlayer.OliveStatus.Sensitivity = Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		Olive.OlivePlayer.OliveStatus.CombatSkill = Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		Olive.OlivePlayer.OliveStatus.CombatAttack = Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		Olive.OlivePlayer.OliveStatus.CombatDefense = Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		Olive.OlivePlayer.OliveStatus.MagicSkill = Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		Olive.OlivePlayer.OliveStatus.MagicAttack = Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		Olive.OlivePlayer.OliveStatus.MagicDefense = Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		Olive.OlivePlayer.OliveStatus.Decorum = Olive.OlivePlayer.OliveStatus.MaxDecorum;
		Olive.OlivePlayer.OliveStatus.Art = Olive.OlivePlayer.OliveStatus.MaxArt;
		Olive.OlivePlayer.OliveStatus.Conversation = Olive.OlivePlayer.OliveStatus.MaxConversation;
		Olive.OlivePlayer.OliveStatus.Cooking = Olive.OlivePlayer.OliveStatus.MaxCooking;
		Olive.OlivePlayer.OliveStatus.Cleaning = Olive.OlivePlayer.OliveStatus.MaxCleaning;
		Olive.OlivePlayer.OliveStatus.Temperament = Olive.OlivePlayer.OliveStatus.MaxTemperament;
	}

	OliveStateChange() {
		if (GameEngineInput.IsDown("q"))
		{
			Olive.OlivePlayer.OliveStatus.Constitution = 100;
			Olive.OlivePlayer.OliveStatus.Stress = 150;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("w"))
		{
			Olive.OlivePlayer.OliveStatus.Constitution = 100;
			Olive.OlivePlayer.OliveStatus.Stress = 50;
			Olive.OlivePlayer.OliveStatus.Morality = 0;
			Olive.OlivePlayer.OliveStatus.Faith = 0;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("e"))
		{
			Olive.OlivePlayer.OliveStatus.Stress = 0;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("r"))
		{
			Olive.OlivePlayer.OliveStatus.Stress = 1;
			Olive.OlivePlayer.OliveStatus.Morality = 100;
			Olive.OlivePlayer.OliveStatus.Faith = 100;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

	}

	UpdateSeason() {
		const Month = this.Today.GetMonth();
		if (Month >= 3 && Month < 6)
		{
			this.TodaySeason = Season.Spring;
		}
		else if (Month >= 6 && Month < 9)
		{
			this.TodaySeason = Season.Summer;
		}
		else if (Month >= 9 && Month < 12)
		{
			this.TodaySeason = Season.Fall;
		}
		else if (Month >= 1 && Month < 3 || Month === 12)
		{
			this.TodaySeason = Season.Winter;
		}
	}

	BGMUpdate() {
		if (this.IsFirstMonthOfSeason() && !this.SeasonChange && Date.GetMonthLastDate(this.Today).IsEqual(this.Today))
		{
			this.SeasonChange = true;
			switch (this.TodaySeason)
			{
				case Season.Spring:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
					break;
				case Season.Summer:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
					break;
				case Season.Fall:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
					break;
				case Season.Winter:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
					break;
				default:
					break;
			}
		}
		else if (!this.IsFirstMonthOfSeason())
		{
			this.SeasonChange = false;
		}
	}

	IsFirstMonthOfSeason() {
		if (this.Today.GetMonth() === 12 || this.Today.GetMonth() === 3 || this.Today.GetMonth() === 6 || this.Today.GetMonth() === 9)
		{
			return true;
		}
		return false;
	}

	SetToday(_Today) {
		this.Today.SetDate(_Today.GetYear(), _Today.GetMonth(), _Today.GetDay());
	}

	GetToday() {
		return this.Today;
	}

	GoToNextDay() {
		// 원본: ++Today;
		this.Today = this.Today.GetNextDate();
	}

	static GetAcCubeDialog() {
		return RaisingSimLevel.AcCubeDialog;
	}

	static GetAcScheduleDialog() {
		return RaisingSimLevel.AcScheduleDialog;
	}

	GetUIManager() {
		return this.AcUIManager;
	}

	GetTodaySeason() {
		return this.TodaySeason;
	}

	GetBGMPlayer() {
		return this.BGMPlayer;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcCubeDialog', 'GetAcScheduleDialog']) {
	Object.defineProperty(RaisingSimLevel.prototype, __m, { value: function (...args) { return RaisingSimLevel[__m](...args); }, writable: true, configurable: true });
}

