// Cutscene.h / Cutscene.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

// enum class BackgroundColor
export const BackgroundColor = Object.freeze({
	Black: 0,
	White: 1
});

export class Cutscene extends GameEngineActor {
	constructor() {
		super();
		this.CutScenes = [];  // std::vector<GameEngineRender*>
		this.Background = []; // std::vector<GameEngineRender*>
	}

	OnCutScene(_index) {
		for (let i = 0; i < this.CutScenes.length; i++) {
			if (i === _index) {
				this.CutScenes[i].On();
			}
			else {
				this.CutScenes[i].Off();
			}
		}
	}

	OffCutScene() {
		for (let i = 0; i < this.CutScenes.length; i++) {
			this.CutScenes[i].Off();
		}
	}

	SelectBackgroundColor(_Color) {
		if (_Color === BackgroundColor.Black) {
			this.Background[0].On();
			this.Background[1].Off();
		}
		else {
			this.Background[0].Off();
			this.Background[1].On();
		}
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		// 원본: CutScenes.resize(7);
		this.CutScenes = new Array(7).fill(null);
		this.CutScenes[0] = this.CreateRender("CutScene1.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[1] = this.CreateRender("CutScene2.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[2] = this.CreateRender("CutScene3.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[3] = this.CreateRender("CutScene4.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[4] = this.CreateRender("CutScene5.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[5] = this.CreateRender("CutScene6.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[6] = this.CreateRender("CutScene7.BMP", PM2RenderOrder.BackGroundObj);

		// 원본: Background.resize(2);
		this.Background = new Array(2).fill(null);
		this.Background[0] = this.CreateRender("BlackBackground.bmp", PM2RenderOrder.BackGround);
		this.Background[1] = this.CreateRender("WhiteBackground.bmp", PM2RenderOrder.BackGround);

		for (const i of this.CutScenes) {
			i.SetScaleToImage();
		}

		for (const i of this.Background) {
			i.SetScaleToImage();
		}

		this.Off();
	}

	Update(_DeltaTime) {
	}

	Render(_time) {
	}
}
