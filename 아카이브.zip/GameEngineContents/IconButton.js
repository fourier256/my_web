// IconButton.h / IconButton.cpp 의 전사
import { MenuFrame, MenuFrameStyleEnum } from "./MenuFrame.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GlobalButton } from "./GlobalButton.js";
import { PM2ActorOrder, PM2RenderOrder, PM2CollisionOrder, IconCode } from "./ContentsEnums.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";

export class IconButton extends MenuFrame {
	constructor() {
		super();
		this.ButtonScale = new float4(160, 52);
		this.Button = null;

		this.IconRender = null;
		this.ICode = IconCode.Null;
		this.IconScale = new float4(40, 40);
		this.IconPos = new float4(-50, 0);

		this.NameRender = null;
		this.Name = "";
		this.NameBoxScale = new float4(90, 20);
		this.NamePos = new float4(-20, -20);

		this.DifficultyRender = null;
		this.Difficulty = "";
		this.DifficultyBoxScale = new float4(90, 20);
		this.DifficultyPos = new float4(-20, 0);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);

		this.PriceRender = new NumberRenderObject();
		this.Price = 30;
		this.PriceRenderPos = new float4(38, 8);
		this.PriceRenderScale = new float4(10, 20);

		this.Alphabet_G = null;
		this.Alphabet_GPos = new float4(48, 8);
	}

	SetPos(_Pos) {
		// 원본: GameEngineActor::SetPos(_Pos);
		GameEngineActor.prototype.SetPos.call(this, _Pos);
		this.Button.SetPos(_Pos);
	}

	SetIconButton(_IconCode, _Name, _Difficulty, _Price, _Pos) {
		this.Button.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.Button.SetScale(this.ButtonScale);
		this.Button.SetRenderOrder(PM2RenderOrder.Menu2_Button);
		this.Button.SetCollisionOrder(PM2RenderOrder.Menu2_Button);
		this.Button.SetPos(this.GetPos());
		this.Button.SetReleaseImage("SelectButton_Release.bmp");
		this.Button.SetHoverImage("IconButton_Hover.bmp");
		this.Button.SetPressImage("IconButton_Hover.bmp");

		this.ICode = _IconCode;
		this.Name = _Name;
		this.Difficulty = _Difficulty;
		this.Price = _Price;

		this.SetPos(_Pos);

		this.IconRender.SetScale(this.IconScale);
		this.IconRender.SetFrame(this.ICode);
		this.IconRender.SetPosition(this.IconPos);

		this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.NameBoxScale);
		this.NameRender.SetPosition(this.NamePos);

		this.DifficultyRender.SetText(this.Difficulty, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.DifficultyBoxScale);
		this.DifficultyRender.SetPosition(this.DifficultyPos);

		this.PriceRender.SetImage("Num_Status.bmp", this.PriceRenderScale, PM2RenderOrder.Menu2_Display, RGB(0, 0, 0));
		this.PriceRender.SetAlign(Align.Right);
		this.PriceRender.SetValue(this.Price);
		this.PriceRender.SetRenderPos(this.PriceRenderPos);

		this.Alphabet_G.SetTransColor(RGB(0, 0, 0));
		this.Alphabet_G.SetScale(this.PriceRenderScale);
		this.Alphabet_G.SetFrame(2);
		this.Alphabet_G.SetPosition(this.Alphabet_GPos);
	}

	GetButton() {
		return this.Button;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.Button.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.Button.Off();
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu2_Button, MenuFrameStyleEnum.Silver);
		this.SetMenuFrameScale(this.ButtonScale);
		this.Button = this.GetLevel().CreateActor(GlobalButton, PM2ActorOrder.Menu2_Button);
		this.IconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu2_Display);
		this.NameRender = this.CreateRender(PM2RenderOrder.Menu2_Display);
		this.DifficultyRender = this.CreateRender(PM2RenderOrder.Menu2_Display);
		this.PriceRender.SetOwner(this);
		this.Alphabet_G = this.CreateRender("Num_Status_etc.bmp", PM2RenderOrder.Menu2_Display);
	}
}
