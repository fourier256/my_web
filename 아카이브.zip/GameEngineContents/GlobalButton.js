// GlobalButton.h / GlobalButton.cpp 의 전사
import { Button, ButtonState } from "../GameEngineCore/Button.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class GlobalButton extends Button {
	constructor() {
		super();
	}

	Render(_DeltaTime) {
		//디버그
		if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Release) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH)(채움 없음) + CreatePen(PS_SOLID, 0, RGB(255, 0, 0))
			DoubleDC.strokeStyle = "rgb(255, 0, 0)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
		else if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Hover) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH) + CreatePen(PS_SOLID, 0, RGB(0, 0, 255))
			DoubleDC.strokeStyle = "rgb(0, 0, 255)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
		else if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Press) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH) + CreatePen(PS_SOLID, 0, RGB(0, 255, 0))
			DoubleDC.strokeStyle = "rgb(0, 255, 0)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
	}
}
