// BottomDialog.h / BottomDialog.cpp 의 전사
import { Dialog } from "./Dialog.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class BottomDialog extends Dialog {
	constructor() {
		super();
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetPos(new float4(400, 460));
	}
}
