// PersonalInformationWindow.h / PersonalInformationWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { MenuFrame, MenuFrameStyleEnum } from "./MenuFrame.js";
import { Date } from "./Date.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, BloodType, Zodiac, PatronGod } from "./ContentsEnums.js";
import { RGB } from "../WinAPI.js";

export class PersonalInformationWindow extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(260, 184);
		this.ActorPos = new float4(154, 195);

		this.FirstName = "";
		this.LastName = "";
		this.BloodType = BloodType.Null;
		this.Age = 0;
		this.BirthDay = new Date();
		this.OliveZodiac = Zodiac.Null;
		this.OlivePatronGod = PatronGod.Null;

		this.interface_FirstName = null;
		this.interface_LastName = null;
		this.interface_BloodType = null;
		this.interface_Age = null;
		this.interface_BirthDay = null;
		this.interface_Zodiac = null;
		this.interface_PatronGod = null;
		this.interface_FirstNamePos = new float4(-118, -80);
		this.interface_LastNamePos = new float4(-118, -57);
		this.interface_BloodTypePos = new float4(-118, -34);
		this.interface_AgePos = new float4(-118, -11);
		this.interface_BirthDayPos = new float4(-118, 12);
		this.interface_ZodiacPos = new float4(-118, 35);
		this.interface_PatronGodPos = new float4(-118, 58);

		this.FirstNameRender = null;
		this.LastNameRender = null;
		this.BloodTypeRender = null;
		this.AgeRender = null;
		this.BirthDayRender = null;
		this.ZodiacRender = null;
		this.PatronGodRender = null;
		this.FirstNamePos = new float4(-38, -80);
		this.LastNamePos = new float4(-38, -57);
		this.BloodTypePos = new float4(-38, -34);
		this.AgePos = new float4(-38, -11);
		this.BirthDayPos = new float4(-38, 12);
		this.ZodiacPos = new float4(-38, 35);
		this.PatronGodPos = new float4(-38, 58);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale1 = new float4(80, 20);
		this.TextBoxScale2 = new float4(160, 20);
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.Scale);
		this.SetPos(this.ActorPos);

		this.interface_FirstName = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_FirstName.SetText("이름", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_FirstName.SetPosition(this.interface_FirstNamePos);

		this.interface_LastName = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_LastName.SetText("성", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_LastName.SetPosition(this.interface_LastNamePos);

		this.interface_BloodType = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_BloodType.SetText("혈액형", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_BloodType.SetPosition(this.interface_BloodTypePos);

		this.interface_Age = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Age.SetText("나이", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Age.SetPosition(this.interface_AgePos);

		this.interface_BirthDay = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_BirthDay.SetText("생일", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_BirthDay.SetPosition(this.interface_BirthDayPos);

		this.interface_Zodiac = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Zodiac.SetText("별자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Zodiac.SetPosition(this.interface_ZodiacPos);

		this.interface_PatronGod = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_PatronGod.SetText("수호성", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_PatronGod.SetPosition(this.interface_PatronGodPos);

		this.FirstNameRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.FirstNameRender.SetPosition(this.FirstNamePos);
		this.LastNameRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.LastNameRender.SetPosition(this.LastNamePos);
		this.BloodTypeRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.BloodTypeRender.SetPosition(this.BloodTypePos);
		this.AgeRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.AgeRender.SetPosition(this.AgePos);
		this.BirthDayRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.BirthDayRender.SetPosition(this.BirthDayPos);
		this.ZodiacRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.ZodiacRender.SetPosition(this.ZodiacPos);
		this.PatronGodRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.PatronGodRender.SetPosition(this.PatronGodPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdatePersonalInformationWindow();
	}

	UpdatePersonalInformationWindow() {
		if (this.FirstName !== Olive.OlivePlayer.GetOliveFirstName()) {
			this.FirstName = Olive.OlivePlayer.GetOliveFirstName();
			this.FirstNameRender.SetText(this.FirstName, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.LastName !== Olive.OlivePlayer.GetOliveLastName()) {
			this.LastName = Olive.OlivePlayer.GetOliveLastName();
			this.LastNameRender.SetText(this.LastName, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.BloodType !== Olive.OlivePlayer.GetBloodType()) {
			this.BloodType = Olive.OlivePlayer.GetBloodType();
			switch (this.BloodType) {
				case BloodType.Null:
					break;
				case BloodType.A:
					this.BloodTypeRender.SetText("A", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.B:
					this.BloodTypeRender.SetText("B", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.O:
					this.BloodTypeRender.SetText("O", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.AB:
					this.BloodTypeRender.SetText("AB", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}

		if (this.Age !== Olive.OlivePlayer.GetOliveAge()) {
			this.Age = Olive.OlivePlayer.GetOliveAge();
			this.AgeRender.SetText(String(this.Age), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.BirthDay !== Olive.OlivePlayer.GetOliveBirthDay()) {
			this.BirthDay = Olive.OlivePlayer.GetOliveBirthDay();
			this.BirthDayRender.SetText(String(this.BirthDay.GetYear()) + "/" + String(this.BirthDay.GetMonth()) + "/" + String(this.BirthDay.GetDay()), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.OliveZodiac !== Olive.OlivePlayer.GetOliveZodiac()) {
			this.OliveZodiac = Olive.OlivePlayer.GetOliveZodiac();
			switch (this.OliveZodiac) {
				case Zodiac.Null:
					break;
				case Zodiac["염소자리"]:
					this.ZodiacRender.SetText("염소자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["물병자리"]:
					this.ZodiacRender.SetText("물병자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["물고기자리"]:
					this.ZodiacRender.SetText("물고기자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["양자리"]:
					this.ZodiacRender.SetText("양자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["황소자리"]:
					this.ZodiacRender.SetText("황소자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["쌍둥이자리"]:
					this.ZodiacRender.SetText("쌍둥이자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["게자리"]:
					this.ZodiacRender.SetText("게자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["사자자리"]:
					this.ZodiacRender.SetText("사자자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["처녀자리"]:
					this.ZodiacRender.SetText("처녀자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["천칭자리"]:
					this.ZodiacRender.SetText("천칭자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["전갈자리"]:
					this.ZodiacRender.SetText("전갈자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["사수자리"]:
					this.ZodiacRender.SetText("사수자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}

		if (this.OlivePatronGod !== Olive.OlivePlayer.GetPatronGod()) {
			this.OlivePatronGod = Olive.OlivePlayer.GetPatronGod();
			switch (this.OlivePatronGod) {
				case PatronGod.Null:
					break;
				case PatronGod["태양신_솔"]:
					this.PatronGodRender.SetText("태양신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["달신_더문"]:
					this.PatronGodRender.SetText("달신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["화성신_마르스"]:
					this.PatronGodRender.SetText("화성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["수성신_머큐리"]:
					this.PatronGodRender.SetText("수성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["목성신_주피터"]:
					this.PatronGodRender.SetText("목성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["금성신_비너스"]:
					this.PatronGodRender.SetText("금성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["토성신_새턴"]:
					this.PatronGodRender.SetText("토성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["천왕성신_우라누스"]:
					this.PatronGodRender.SetText("천왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["해왕성신_넵튠"]:
					this.PatronGodRender.SetText("해왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["명왕성신_하데스"]:
					this.PatronGodRender.SetText("명왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}
	}
}
