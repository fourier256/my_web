// ScheduleFinalConfirm.h / ScheduleFinalConfirm.cpp 의 전사
import { SelectionMenu } from "./SelectionMenu.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { CubeFace } from "./CubeDialog.js";
import { RaisingSimLevel } from "./RaisingSimLevel.js";
import { ScheduleSelectionMenu } from "./ScheduleSelectionMenu.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { SchedulePlayer } from "./SchedulePlayer.js";
import { PM2RenderOrder, PM2ActorOrder } from "./ContentsEnums.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";

export class ScheduleFinalConfirm extends SelectionMenu {
	static AcScheduleFinalConfirm = null;

	// 원본: static CubeDialog* AcCubeDialog;
	static AcCubeDialog = null;
	static AcScheduleSelectionMenu = null;
	static AcScheduleCalendar = null;
	static AcSchedulePlayer = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleFinalConfirm.AcScheduleFinalConfirm = this;
		this.ActorPos = new float4(670, 321);
		this.Xscale = 140;
	}

	Start() {
		ScheduleFinalConfirm.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		ScheduleFinalConfirm.AcScheduleSelectionMenu = ScheduleSelectionMenu.GetAcScheduleSelectionMenu();
		ScheduleFinalConfirm.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		ScheduleFinalConfirm.AcSchedulePlayer = this.GetLevel().CreateActor(SchedulePlayer, PM2ActorOrder.Menu2);

		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "스케줄을 실행");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "취소");
		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		ScheduleFinalConfirm.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번달은 이 스케줄로\n좋습니까?");

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			ScheduleFinalConfirm.AcScheduleSelectionMenu.On();
			ScheduleFinalConfirm.AcScheduleCalendar.Reset();
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(ScheduleFinalConfirm.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(ScheduleFinalConfirm.Click1);
	}

	static Click0(_Button) {
		ScheduleFinalConfirm.AcSchedulePlayer.On();
		ScheduleFinalConfirm.AcScheduleFinalConfirm.Off();
		ScheduleFinalConfirm.AcScheduleCalendar.Off();
		ScheduleFinalConfirm.AcCubeDialog.Off();
	}

	static Click1(_Button) {
		ScheduleFinalConfirm.AcScheduleFinalConfirm.Off();
		ScheduleFinalConfirm.AcScheduleSelectionMenu.On();
		ScheduleFinalConfirm.AcScheduleCalendar.Reset();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(ScheduleFinalConfirm.prototype, __m, { value: function (...args) { return ScheduleFinalConfirm[__m](...args); }, writable: true, configurable: true });
}

