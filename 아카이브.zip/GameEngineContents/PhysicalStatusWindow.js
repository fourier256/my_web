// PhysicalStatusWindow.h / PhysicalStatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class PhysicalStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(664, 350);

		this.HeightRender = null;
		this.WeightRender = null;
		this.BustRender = null;
		this.WaistRender = null;
		this.HipRender = null;

		this.Height = 0.0;
		this.Weight = 0.0;
		this.Bust = 0.0;
		this.Waist = 0.0;
		this.Hip = 0.0;

		this.Max = 200.0;

		this.Style = GaugeFrameStyle.Physical;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.HeightRender = this.InsertStatus("키", this.Max, this.Style);
		this.WeightRender = this.InsertStatus("몸무게", this.Max, this.Style);
		this.BustRender = this.InsertStatus("가슴", this.Max, this.Style);
		this.WaistRender = this.InsertStatus("허리", this.Max, this.Style);
		this.HipRender = this.InsertStatus("엉덩이", this.Max, this.Style);
		this.SetPos(this.ActorPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdatePhysicalStatusWindow();
	}

	UpdatePhysicalStatusWindow() {
		if (this.Height !== Olive.OlivePlayer.GetHeight()) {
			this.Height = Olive.OlivePlayer.GetHeight();
			this.HeightRender.UpdateValue(this.Height);
		}

		if (this.Weight !== Olive.OlivePlayer.GetWeight()) {
			this.Weight = Olive.OlivePlayer.GetWeight();
			this.WeightRender.UpdateValue(this.Weight);
		}

		if (this.Bust !== Olive.OlivePlayer.GetBust()) {
			this.Bust = Olive.OlivePlayer.GetBust();
			this.BustRender.UpdateValue(this.Bust);
		}

		if (this.Waist !== Olive.OlivePlayer.GetWaist()) {
			this.Waist = Olive.OlivePlayer.GetWaist();
			this.WaistRender.UpdateValue(this.Waist);
		}

		if (this.Hip !== Olive.OlivePlayer.GetHip()) {
			this.Hip = Olive.OlivePlayer.GetHip();
			this.HipRender.UpdateValue(this.Hip);
		}
	}
}
