// MousePoint.h / MousePoint.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { PM2CollisionOrder, PM2RenderOrder } from "./ContentsEnums.js";

export class MousePoint extends GameEngineActor {
	static MainMouse = null;

	constructor() {
		super();
		this.MousePointCollision = null;
		this.MousePointRender = null;
	}

	GetMousePointCollision() {
		return this.MousePointCollision;
	}

	Start() {
		MousePoint.MainMouse = this;
		GameEngineInput.MouseCursorOff();
		this.MousePointCollision = this.CreateCollision(PM2CollisionOrder.MousePoint);
		this.MousePointCollision.SetScale(new float4(1, 1));
		this.MousePointRender = this.CreateRender(PM2RenderOrder.MousePoint);
		this.MousePointRender.SetImageToScaleToImage("Cursor.bmp");
		this.MousePointRender.SetPosition(this.MousePointRender.GetScale().half());
	}

	Update(_DeltaTime) {
		this.SetPos(this.GetLevel().GetMousePos());
	}

	Render(_Time) {
	}
}
