// ScheduleSelectionMenu.h / ScheduleSelectionMenu.cpp 의 전사
import { SelectionMenu } from "./SelectionMenu.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { ClassSelectWindow } from "./ClassSelectWindow.js";
import { CubeFace } from "./CubeDialog.js";
import { RaisingSimLevel } from "./RaisingSimLevel.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { MainMenu } from "./MainMenu.js";
import { PM2RenderOrder, PM2ActorOrder } from "./ContentsEnums.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";

export class ScheduleSelectionMenu extends SelectionMenu {
	static AcScheduleSelectionMenu = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleSelectionMenu.AcScheduleSelectionMenu = this;
		this.Xscale = 200;
		this.ActorPos = new float4(700, 347);
		this.AcCubeDialog = null;
		this.AcScheduleCalendar = null;
	}

	static GetAcScheduleSelectionMenu() {
		return ScheduleSelectionMenu.AcScheduleSelectionMenu;
	}

	// 원본: static ClassSelectWindow* AcClassSelectWindow;
	static AcClassSelectWindow = null;

	Start() {
		ScheduleSelectionMenu.AcClassSelectWindow = this.GetLevel().CreateActor(ClassSelectWindow, PM2ActorOrder.Menu2);
		this.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		this.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(4, this.ActorPos, this.Xscale, PM2ActorOrder.Menu1_Button, PM2RenderOrder.Menu1_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "딸을 단련시킨다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "딸에게 일을 시킨다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "무사수행을 보낸다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 3, "휴식을 준다");

		this.SetButtonClick();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 1 번째 )");
		}
		else if (this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 2 번째 )");
		}
		else if (this.AcScheduleCalendar.FirstScheduleSet && this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 3 번째 )");
		}


		if (GameEngineInput.IsUp("EngineMouseRight")) {
			if (!this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
				this.AcScheduleCalendar.Off();
				this.AcCubeDialog.Off();
				this.Off();
				MainMenu.GetAcMainMenu().On();
			}
			else {
				this.AcScheduleCalendar.CancelSchedule();
			}
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(ScheduleSelectionMenu.Click0);
	}

	static Click0(_Button) {
		ScheduleSelectionMenu.AcClassSelectWindow.On();
		ScheduleSelectionMenu.AcScheduleSelectionMenu.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcScheduleSelectionMenu', 'Click0']) {
	Object.defineProperty(ScheduleSelectionMenu.prototype, __m, { value: function (...args) { return ScheduleSelectionMenu[__m](...args); }, writable: true, configurable: true });
}

