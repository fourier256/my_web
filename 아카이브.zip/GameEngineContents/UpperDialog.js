// UpperDialog.h / UpperDialog.cpp 의 전사
import { Dialog } from "./Dialog.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export class UpperDialog extends Dialog {
	constructor() {
		super();
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetPos(GameEngineWindow.GetScreenSize().half());
	}
}
