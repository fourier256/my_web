// EndingDialog.h / EndingDialog.cpp 의 전사
import { Dialog } from "./Dialog.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class EndingDialog extends Dialog {
	constructor() {
		super();
		this.ActorPos = new float4(400, 400);
	}

	UpdateText(_Script) {
		this.SetUpdateText(_Script);
		this.On();
	}

	Start() {
		// 원본: Dialog::Start();
		Dialog.prototype.Start.call(this);
		this.SetDialogScale(new float4(390, 150));
		this.SetPos(this.ActorPos);
	}
}
