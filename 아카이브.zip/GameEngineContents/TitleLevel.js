// TitleLevel.h / TitleLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineResources, GameEngineSoundPlayer } from "../GameEngineCore/GameEngineResources.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { TitleMenu } from "./TitleMenu.js";
import { TitleBackground } from "./TitleBackground.js";
import { MousePoint } from "./MousePoint.js";
import { PM2ActorOrder } from "./ContentsEnums.js";

export class TitleLevel extends GameEngineLevel {
	constructor() {
		super();
		this.TitleSelectionMenu = null;
		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		if (false === GameEngineInput.IsKey("LevelChange")) {
			GameEngineInput.CreateKey("LevelChange", 'P'.charCodeAt(0));
		}

		if (false === GameEngineInput.IsKey("1")) {
			GameEngineInput.CreateKey("1", '1'.charCodeAt(0));
		}

		this.CreateActor(TitleBackground, PM2ActorOrder.BackGround);
		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.TitleSelectionMenu = this.CreateActor(TitleMenu, PM2ActorOrder.Menu0);

	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("FirstSet");
		}

		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}
	}

	// 원본 h에서 inline {}: void LevelChangeEnd(...) override {}; / void LevelChangeStart(...) override {};
	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();
		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SelectButton_Release.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SelectButton_Hover.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample1.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample2.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample3.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Cursor.bmp"));

		Dir.Move("TitleLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BlackBackground.BMP"));
	}
}
