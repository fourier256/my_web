// ConverstionSelectionMenu.h / ConverstionSelectionMenu.cpp 의 전사
// (파일명 오타 "Converstion"은 원본 그대로 유지)
import { SelectionMenu } from "./SelectionMenu.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";
import { MainMenu } from "./MainMenu.js";
import { PM2ActorOrder, PM2RenderOrder } from "./ContentsEnums.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class ConverstionSelectionMenu extends SelectionMenu {
	constructor() {
		super();
		this.AcMainMenu = null;
		this.ActorPos = new float4(685, 334);
		this.Xscale = 170.0;
	}

	Start() {
		this.AcMainMenu = MainMenu.GetAcMainMenu();

		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(3, this.ActorPos, this.Xscale, PM2ActorOrder.Menu1_Button, PM2RenderOrder.Menu0_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "부녀간의 이야기");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "용돈");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "설교");
		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			this.AcMainMenu.On();
		}
	}
}
