// DateViewer.h / DateViewer.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { Date } from "./Date.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class DateViewer extends GameEngineActor {
	constructor() {
		super();
		this.Today = new Date();
		this.DateViewerFrameRender = null;
		this.Year = new NumberRenderObject();
		this.Month = null; // 원본: GameEngineRender* Month = {};
		this.Day = new NumberRenderObject();
		this.WeekDay = null; // 원본: GameEngineRender* WeekDay = {};
	}

	Start() {
		this.Today.SetDate(1000, 1, 1);

		this.SetPos(new float4(90, 50));
		this.DateViewerFrameRender = this.CreateRender("DateViewer.bmp", PM2RenderOrder.Menu0);
		this.DateViewerFrameRender.SetScaleToImage();

		this.Year.SetOwner(this);
		this.Year.SetImage("Num.bmp", new float4(10, 20), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.Year.SetAlign(Align.Center);
		this.Year.SetRenderPos(new float4(0.0, -30.0));

		this.Month = this.CreateRender("Num_Month.bmp", PM2RenderOrder.Menu0_Display);
		this.Month.SetScale(new float4(60.0, 20.0));
		this.Month.SetPosition(new float4(-50.0, 0.0));

		this.WeekDay = this.CreateRender("Num_WeekDay.bmp", PM2RenderOrder.Menu0_Display);
		this.WeekDay.SetScale(new float4(60.0, 20.0));
		this.WeekDay.SetPosition(new float4(-50.0, 30.0));

		this.Day.SetOwner(this);
		this.Day.SetImage("Num_Day.bmp", new float4(40.0, 50.0), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.Day.SetAlign(Align.Center);
		this.Day.SetRenderPos(new float4(40.0, 15.0));
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.Year.SetValue(this.Today.GetYear());
			this.Month.SetFrame(this.Today.GetMonth() - 1);
			this.Day.SetValue(this.Today.GetDay());
			this.WeekDay.SetFrame(this.Today.GetWeekDay());
		}
	}
}
