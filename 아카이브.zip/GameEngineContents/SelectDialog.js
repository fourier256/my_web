// SelectDialog.h / SelectDialog.cpp 의 전사
import { Dialog } from "./Dialog.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class SelectDialog extends Dialog {
	constructor() {
		super();
		this.ActorScale = new float4(310, 76);
		this.ActorPos = new float4(170, 300);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetDialogScale(this.ActorScale);
		this.SetPos(this.ActorPos);
	}
}
