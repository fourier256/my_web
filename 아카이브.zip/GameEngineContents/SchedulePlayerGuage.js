// SchedulePlayerGuage.h / SchedulePlayerGuage.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PM2ActorOrder, ScheduleLabel } from "./ContentsEnums.js";

// 원본: const float* (OliveStatus 멤버 주소) 대응 — JS 에는 멤버 주소가 없으므로
// {상태 객체, 필드 키} 짝으로 동일한 의미를 유지한다. 역참조(*ptr) → Status[Key], 주소 비교 → Key 비교.
function StatusPtr(Status, Key) {
	return { Status: Status, Key: Key };
}

export class SchedulePlayerGuage extends GameEngineActor {
	constructor() {
		super();
		// construtor destructor
		this.CountStatus = 6;
		this.AcGauge11 = null;
		this.AcGauge12 = null;
		this.AcGauge13 = null;
		this.AcGauge21 = null;
		this.AcGauge22 = null;
		this.AcGauge23 = null;
		this.Render1 = null;
		this.Render11 = null;
		this.Render12 = null;
		this.Render3 = null;
		this.Render33 = null;
		this.Render34 = null;
		this.Render5 = null;
		this.Render55 = null;
		this.Render56 = null;
		this.Status1 = null;
		this.Status2 = null;
		this.Status3 = null;
		this.Status4 = null;
		this.Status5 = null;
		this.Status6 = null;
	}

	On() {
		super.On();
		switch (this.CountStatus) {
			case 0:
				this.Off();
				break;
			case 1:
				this.AcGauge11.On();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.Off();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 2:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 3:
				this.AcGauge11.Off();
				this.AcGauge12.On();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 4:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 5:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.On();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 6:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.On();
				break;
			default:
				break;
		}
	}

	Off() {
		super.Off();
		this.AcGauge11.Off();
		this.AcGauge12.Off();
		this.AcGauge13.Off();
		this.AcGauge21.Off();
		this.AcGauge22.Off();
		this.AcGauge23.Off();
	}

	Start() {
		this.SetAcGauge();
		this.Off();
	}

	Update(_DeltaTime) {
		if (null !== this.Status1) {
			this.Render1.UpdateValue(this.Status1.Status[this.Status1.Key]);
			this.Render11.UpdateValue(this.Status1.Status[this.Status1.Key]);
		}

		if (null !== this.Status2) {
			this.Render12.UpdateValue(this.Status2.Status[this.Status2.Key]);
		}

		if (null !== this.Status3) {
			this.Render3.UpdateValue(this.Status3.Status[this.Status3.Key]);
			this.Render33.UpdateValue(this.Status3.Status[this.Status3.Key]);
		}

		if (null !== this.Status4) {
			this.Render34.UpdateValue(this.Status4.Status[this.Status4.Key]);
		}

		if (null !== this.Status5) {
			this.Render5.UpdateValue(this.Status5.Status[this.Status5.Key]);
			this.Render55.UpdateValue(this.Status5.Status[this.Status5.Key]);
		}

		if (null !== this.Status6) {
			this.Render56.UpdateValue(this.Status6.Status[this.Status6.Key]);
		}

	}

	SetAcGauge() {
		this.AcGauge11 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge11.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render1 = this.AcGauge11.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge11.SetPos(new float4(160, 495));

		this.AcGauge12 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge12.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render3 = this.AcGauge12.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge12.SetPos(new float4(400, 495));

		this.AcGauge13 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge13.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render5 = this.AcGauge13.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge13.SetPos(new float4(640, 495));

		this.AcGauge21 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge21.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render11 = this.AcGauge21.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render12 = this.AcGauge21.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge21.SetPos(new float4(160, 505));

		this.AcGauge22 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge22.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render33 = this.AcGauge22.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render34 = this.AcGauge22.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge22.SetPos(new float4(400, 505));

		this.AcGauge23 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge23.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render55 = this.AcGauge23.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render56 = this.AcGauge23.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge23.SetPos(new float4(640, 505));
	}

	SetActorCount(_Count) {
		this.CountStatus = _Count;

		switch (this.CountStatus) {
			case 0:
				this.Off();
				break;
			case 1:
				this.AcGauge11.On();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.Off();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 2:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 3:
				this.AcGauge11.Off();
				this.AcGauge12.On();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 4:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 5:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.On();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 6:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.On();
				break;
			default:
				break;
		}
	}

	SetGaugeRender(_Count, _Name1 = " ", _OliveStatusPtr1 = null, _Name2 = " ", _OliveStatusPtr2 = null, _Name3 = " ", _OliveStatusPtr3 = null, _Name4 = " ", _OliveStatusPtr4 = null, _Name5 = " ", _OliveStatusPtr5 = null, _Name6 = " ", _OliveStatusPtr6 = null) {
		this.SetActorCount(_Count);
		if (1 === _Count) {
			if (null === _OliveStatusPtr1) {
				MsgAssert("그럴수없습니다");
			}
			this.Render1.SetNameRender(_Name1);
			this.Render1.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
		}
		else if (2 === _Count) {
			if (null === _OliveStatusPtr2) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr2;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
		}
		else if (3 === _Count) {
			if (null === _OliveStatusPtr3) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render3.SetNameRender(_Name3);
			this.Render3.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
		}
		else if (4 === _Count) {
			if (null === _OliveStatusPtr4) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
		}
		else if (5 === _Count) {
			if (null === _OliveStatusPtr5) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
			this.Render5.SetNameRender(_Name5);
			this.Render5.SetMax(this.FindMax(_OliveStatusPtr5));
			this.Status5 = _OliveStatusPtr5;
		}
		else if (6 === _Count) {
			if (null === _OliveStatusPtr6) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
			this.Render55.SetNameRender(_Name5);
			this.Render55.SetMax(this.FindMax(_OliveStatusPtr5));
			this.Status5 = _OliveStatusPtr5;
			this.Render56.SetNameRender(_Name6);
			this.Render56.SetMax(this.FindMax(_OliveStatusPtr6));
			this.Status6 = _OliveStatusPtr6;
		}
	}

	FindMax(_OliveStatusPtr) {
		// 원본: &(Olive::OlivePlayer->OliveStatus.Constitution) == _OliveStatusPtr — 멤버 주소 비교를 키 비교로 대응
		if (_OliveStatusPtr.Key === "Constitution") {
			return Olive.OlivePlayer.OliveStatus.MaxConstitution;
		}
		else if (_OliveStatusPtr.Key === "Strength") {
			return Olive.OlivePlayer.OliveStatus.MaxStrength;
		}
		else if (_OliveStatusPtr.Key === "Intelligence") {
			return Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		}
		else if (_OliveStatusPtr.Key === "Refinement") {
			return Olive.OlivePlayer.OliveStatus.MaxRefinement;
		}
		else if (_OliveStatusPtr.Key === "Charisma") {
			return Olive.OlivePlayer.OliveStatus.MaxCharisma;
		}
		else if (_OliveStatusPtr.Key === "Morality") {
			return Olive.OlivePlayer.OliveStatus.MaxMorality;
		}
		else if (_OliveStatusPtr.Key === "Faith") {
			return Olive.OlivePlayer.OliveStatus.MaxFaith;
		}
		else if (_OliveStatusPtr.Key === "Sin") {
			return Olive.OlivePlayer.OliveStatus.MaxSin;
		}
		else if (_OliveStatusPtr.Key === "Sensitivity") {
			return Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		}
		else if (_OliveStatusPtr.Key === "Stress") {
			return Olive.OlivePlayer.OliveStatus.MaxStress;
		}
		else if (_OliveStatusPtr.Key === "CombatSkill") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		}
		else if (_OliveStatusPtr.Key === "CombatAttack") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		}
		else if (_OliveStatusPtr.Key === "CombatDefense") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		}
		else if (_OliveStatusPtr.Key === "MagicSkill") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		}
		else if (_OliveStatusPtr.Key === "MagicAttack") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		}
		else if (_OliveStatusPtr.Key === "MagicDefense") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		}
		else if (_OliveStatusPtr.Key === "Decorum") {
			return Olive.OlivePlayer.OliveStatus.MaxDecorum;
		}
		else if (_OliveStatusPtr.Key === "Art") {
			return Olive.OlivePlayer.OliveStatus.MaxArt;
		}
		else if (_OliveStatusPtr.Key === "Conversation") {
			return Olive.OlivePlayer.OliveStatus.MaxConversation;
		}
		else if (_OliveStatusPtr.Key === "Cooking") {
			return Olive.OlivePlayer.OliveStatus.MaxCooking;
		}
		else if (_OliveStatusPtr.Key === "Cleaning") {
			return Olive.OlivePlayer.OliveStatus.MaxCleaning;
		}
		else if (_OliveStatusPtr.Key === "Temperament") {
			return Olive.OlivePlayer.OliveStatus.MaxTemperament;
		}

	}

	InitGauge() {
		this.Render1 = null;
		this.Render11 = null;
		this.Render12 = null;
		this.Render3 = null;
		this.Render33 = null;
		this.Render34 = null;
		this.Render5 = null;
		this.Render55 = null;
		this.Render56 = null;

		this.Status1 = null;
		this.Status2 = null;
		this.Status3 = null;
		this.Status4 = null;
		this.Status5 = null;
		this.Status6 = null;
	}

	SetSchedule(_Schedule) {
		switch (_Schedule) {
			case ScheduleLabel.Null:
				break;
			case ScheduleLabel["자연과학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "신앙심", StatusPtr(Olive.OlivePlayer.OliveStatus, "Faith"), "항마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["신학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "신앙심", StatusPtr(Olive.OlivePlayer.OliveStatus, "Faith"), "항마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["군사학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["검술"]:
				this.SetGaugeRender(3, "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "공격력", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatAttack"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["격투술"]:
				this.SetGaugeRender(3, "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "방어력", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["마법"]:
				this.SetGaugeRender(3, "마법기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicSkill"), "마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicAttack"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["시문학"]:
				this.SetGaugeRender(5, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "기품", StatusPtr(Olive.OlivePlayer.OliveStatus, "Refinement"), "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["예법"]:
				this.SetGaugeRender(3, "기품", StatusPtr(Olive.OlivePlayer.OliveStatus, "Refinement"), "예의범절", StatusPtr(Olive.OlivePlayer.OliveStatus, "Decorum"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["무용"]:
				this.SetGaugeRender(4, "체력", StatusPtr(Olive.OlivePlayer.OliveStatus, "Constitution"), "색기", StatusPtr(Olive.OlivePlayer.OliveStatus, "Charisma"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["미술"]:
				this.SetGaugeRender(3, "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			default:
				break;
		}
	}
}
