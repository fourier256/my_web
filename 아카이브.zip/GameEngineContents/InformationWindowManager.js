// InformationWindowManager.h / InformationWindowManager.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { HelthInformationWindow } from "./HelthInformationWindow.js";
import { PersonalInformationWindow } from "./PersonalInformationWindow.js";
import { PhysicalStatusWindow } from "./PhysicalStatusWindow.js";
import { MainMenu } from "./MainMenu.js";
import { PM2ActorOrder } from "./ContentsEnums.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";

export class InformationWindowManager extends GameEngineActor {
	constructor() {
		super();
		this.AcHelthInformationWindow = null;
		this.AcPersonalInformationWindow = null;
		this.AcPhysicalStatusWindow = null;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.AcHelthInformationWindow.On();
		this.AcPersonalInformationWindow.On();
		this.AcPhysicalStatusWindow.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.AcHelthInformationWindow.Off();
		this.AcPersonalInformationWindow.Off();
		this.AcPhysicalStatusWindow.Off();
	}

	Start() {
		this.AcHelthInformationWindow = this.GetLevel().CreateActor(HelthInformationWindow, PM2ActorOrder.Menu1);
		this.AcPersonalInformationWindow = this.GetLevel().CreateActor(PersonalInformationWindow, PM2ActorOrder.Menu1);
		this.AcPhysicalStatusWindow = this.GetLevel().CreateActor(PhysicalStatusWindow, PM2ActorOrder.Menu1);

		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			MainMenu.GetAcMainMenu().On();
		}
	}
}
