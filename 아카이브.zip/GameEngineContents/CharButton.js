// CharButton.h / CharButton.cpp 의 전사
import { GlobalButton } from "./GlobalButton.js";

export class CharButton extends GlobalButton {
	constructor() {
		super();
		this.Chracter = 0; // 오타 "Chracter" 원본 유지
	}
}
