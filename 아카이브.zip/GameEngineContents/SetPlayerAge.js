// SetPlayerAge.h / SetPlayerAge.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineObject } from "../GameEngineCore/GameEngineObject.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { ButtonState } from "../GameEngineCore/Button.js";
import { GlobalButton } from "./GlobalButton.js";
import { CharButton } from "./CharButton.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { FirstSetLevel, ActorState } from "./FirstSetLevel.js";
import { PlayerCalendar } from "./PlayerCalendar.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PM2CollisionOrder, PM2ActorOrder } from "./ContentsEnums.js";

export class SetPlayerAge extends GameEngineActor {
	static FirstUpdate = false;

	static PrintLetter = "";

	constructor() {
		super();		this.FirstUpdate = false; // 원본 SetPlayerAge.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;
		// 원본: CharButton* AgeNumButton[10] = {};
		this.AgeNumButton = new Array(10).fill(null);
		this.AgeNumButtonRender1 = new Array(10).fill(null);
		this.AgeNumButtonRender2 = new Array(10).fill(null);
		this.AgeNumButtonEffect1Render = new Array(10).fill(null);
		this.AgeNumButtonEffect2Render = new Array(10).fill(null);
		this.AgeNumButtonEffect3Render = new Array(10).fill(null);
		this.AgeNumButtonShadowRender = new Array(10).fill(null);

		this.PrintLetterRender1 = null;
		this.PrintLetterRender2 = null;
		this.PrintLetterRender3 = null;
		this.PrintLetterBoxScale = new float4(100, 18);

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.CompleteButton = null;
		this.CompleteButton1Render = null;
		this.CompleteButton2Render = null;
		this.CompleteButtonEffect1Render = null;
		this.CompleteButtonEffect2Render = null;
		this.CompleteButtonEffect3Render = null;
		this.CompleteButtonShadowRender = null;

		this.ButtonScale = new float4(24, 24);
		this.ButtonScale2 = new float4(48, 24);
		this.ButtonInterval = new float4(8, 0);
		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(106, 170, 126);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i].On();
		}
		this.CompleteButton.On();
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i].Off();
		}
		this.CompleteButton.Off();

	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetPlayerBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();
		this.SetAgeNumButton();
		this.SetAgeNumRender();

		this.SetPrintLetterRender();
		this.SetExplainRender();

		this.SetCompleteButton();
		this.SetCompleteButtonRender();


		this.Off();
	}

	Update(_DeltaTime) {
		if (!SetPlayerAge.FirstUpdate) {
			SetPlayerAge.FirstUpdate = true;
			SetPlayerAge.PrintLetter = "\0";
		}

		for (let i = 0; i < 10; i++) {
			if (ButtonState.Release === this.AgeNumButton[i].GetState()) {
				this.AgeNumButtonEffect1Render[i].Off();
				this.AgeNumButtonEffect2Render[i].Off();
				this.AgeNumButtonEffect3Render[i].Off();

				this.AgeNumButtonRender1[i].On();
				this.AgeNumButtonRender2[i].On();
				this.AgeNumButtonShadowRender[i].On();
			}
			else {
				this.AgeNumButtonEffect1Render[i].On();
				this.AgeNumButtonEffect2Render[i].On();
				this.AgeNumButtonEffect3Render[i].On();

				this.AgeNumButtonRender1[i].Off();
				this.AgeNumButtonRender2[i].Off();
				this.AgeNumButtonShadowRender[i].Off();
			}
		}

		if (ButtonState.Release === this.CompleteButton.GetState()) {
			this.CompleteButtonEffect1Render.Off();
			this.CompleteButtonEffect2Render.Off();
			this.CompleteButtonEffect3Render.Off();

			this.CompleteButton1Render.On();
			this.CompleteButton2Render.On();
			this.CompleteButtonShadowRender.On();
		}
		else {
			this.CompleteButtonEffect1Render.On();
			this.CompleteButtonEffect2Render.On();
			this.CompleteButtonEffect3Render.On();

			this.CompleteButton1Render.Off();
			this.CompleteButton2Render.Off();
			this.CompleteButtonShadowRender.Off();
		}

		this.PrintLetterRender1.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect1Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect3Color, this.PrintLetterBoxScale);

	}

	Render(_DeltaTime) {
	}

	SetAgeNumButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(GameEngineWindow.GetScreenSize().x + float4.Left.x * 9 * (this.ButtonScale.hx() + this.ButtonInterval.hx()), 360);

		let Start = '0'.charCodeAt(0);

		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
			this.AgeNumButton[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.AgeNumButton[i].SetScale(this.ButtonScale);
			this.AgeNumButton[i].SetRenderOrder(PM2RenderOrder.Menu0_Button);
			this.AgeNumButton[i].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
			this.AgeNumButton[i].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(i, 0))));
			this.AgeNumButton[i].SetReleaseImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].SetHoverImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].SetPressImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].Chracter = Start++;
			this.AgeNumButton[i].SetClickCallBack(SetPlayerAge.PushBack_Button);
		}
	}

	SetAgeNumRender() {
		let Count = 0;
		for (let i = 0; i < 10; i++) {
			let Start = "0";
			// 원본: Start[0] += Count++;
			Start = String.fromCharCode(Start.charCodeAt(0) + Count++);

			this.AgeNumButtonRender1[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonRender1[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
			const LetterRenderPos = this.AgeNumButton[i].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
			this.AgeNumButtonRender1[i].SetPosition(LetterRenderPos);

			this.AgeNumButtonRender2[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonRender2[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
			this.AgeNumButtonRender2[i].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

			this.AgeNumButtonEffect1Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonEffect1Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
			this.AgeNumButtonEffect1Render[i].SetPosition(LetterRenderPos);
			this.AgeNumButtonEffect1Render[i].Off();

			this.AgeNumButtonEffect2Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
			this.AgeNumButtonEffect2Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
			this.AgeNumButtonEffect2Render[i].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
			this.AgeNumButtonEffect2Render[i].Off();

			this.AgeNumButtonEffect3Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
			this.AgeNumButtonEffect3Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
			this.AgeNumButtonEffect3Render[i].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
			this.AgeNumButtonEffect3Render[i].Off();

			this.AgeNumButtonShadowRender[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
			this.AgeNumButtonShadowRender[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
			this.AgeNumButtonShadowRender[i].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		}
	}

	SetPrintLetterRender() {
		this.PrintLetterRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender1.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect1Color, this.PrintLetterBoxScale);
		const SetPrintLetterRenderPos = this.PrintLetterBoxScale.half().neg().sub(new float4(30, 60));
		this.PrintLetterRender1.SetPosition(SetPrintLetterRenderPos);

		this.PrintLetterRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.PrintLetterRender2.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetPosition(SetPrintLetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.PrintLetterRender3 = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.PrintLetterRender3.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect3Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetPosition(SetPrintLetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static PushBack_Button(_Button) {
		const Ptr = _Button; // 원본: dynamic_cast<CharButton*>

		if (2 <= SetPlayerAge.PrintLetter.length) {
			// 원본: PrintLetter[0] = PrintLetter[1]; PrintLetter[1] = Ptr->Chracter;
			SetPlayerAge.PrintLetter = SetPlayerAge.PrintLetter[1] + String.fromCharCode(Ptr.Chracter);
		}
		else {
			// 원본: PrintLetter.push_back(Ptr->Chracter);
			SetPlayerAge.PrintLetter += String.fromCharCode(Ptr.Chracter);
		}

		if ("00" === SetPlayerAge.PrintLetter) {
			SetPlayerAge.PrintLetter = "0";
		}
	}

	SetCompleteButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(194, 448);

		this.CompleteButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.CompleteButton.SetScale(this.ButtonScale2);
		this.CompleteButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.CompleteButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetPos(ButtonStartPosition);
		this.CompleteButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetHoverImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetPressImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetClickCallBack(SetPlayerAge.ClickCompleteButton);
	}

	SetCompleteButtonRender() {
		this.CompleteButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.CompleteButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.CompleteButton1Render.SetPosition(ButtonStartPosition);

		this.CompleteButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.CompleteButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.CompleteButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButtonEffect1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.CompleteButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.CompleteButtonEffect1Render.Off();

		this.CompleteButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.CompleteButtonEffect2Render.Off();

		this.CompleteButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect3Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.CompleteButtonEffect3Render.Off();

		this.CompleteButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.CompleteButtonShadowRender.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.CompleteButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = this.ExplainTextBoxScale.half().neg().sub(new float4(0, 36));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static ClickCompleteButton(_Button) {
		if (SetPlayerAge.PrintLetter.length === 0) {
			return;
		}
		// 원본: std::stoi(PrintLetter)
		const AgeValue = parseInt(SetPlayerAge.PrintLetter, 10);
		if (10 > AgeValue || 99 < AgeValue) {
			return;
		}
		FirstSetLevel.SetStateValue(ActorState.PlayerCalendar);
		Olive.OlivePlayer.SetFatherAge(AgeValue);
		SetPlayerAge.FirstUpdate = false;
		PlayerCalendar.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['PushBack_Button', 'ClickCompleteButton']) {
	Object.defineProperty(SetPlayerAge.prototype, __m, { value: function (...args) { return SetPlayerAge[__m](...args); }, writable: true, configurable: true });
}

