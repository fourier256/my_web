// PaintingClass.h / PaintingClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용 / 원본 PaintingClass.h의 #include "Olive.h")
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class PaintingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Painting.bmp", "Animation_Background_Painting.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 4, 5, 6, new float4(-165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 9, new float4(-85, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-15, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 12, 17, new float4(115, 12));

		// 원본: GetStatusVarianceMin().SetStatus({  .Sensitivity = 0,.Stress = 0, .Art = 1 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Sensitivity = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Sensitivity = 1,.Stress = 1, .Art = 1});
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Sensitivity = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
