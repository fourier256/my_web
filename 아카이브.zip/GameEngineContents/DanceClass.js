// DanceClass.h / DanceClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class DanceClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Dance.bmp", "Animation_Background_Dance.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 5, 6, 7, new float4(145, 14));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 8, 11, new float4(55, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-55, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 16, 17, new float4(-155, 14));

		// 원본: GetStatusVarianceMin().SetStatus({.Constitution = 1, .Charisma = 0, .Stress = 0, .Art = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Constitution = 1;
		StatusParaMin.Charisma = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Constitution = 1, .Charisma = 1, .Stress = 1, .Art = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Constitution = 1;
		StatusParaMax.Charisma = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-50);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
