// OpeningLevel.h / OpeningLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineResources, GameEngineSoundPlayer } from "../GameEngineCore/GameEngineResources.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MousePoint } from "./MousePoint.js";
import { Olive } from "./Olive.js";
import { Caption } from "./Caption.js";
import { UpperDialog } from "./UpperDialog.js";
import { BottomDialog } from "./BottomDialog.js";
import { Cutscene, BackgroundColor } from "./Cutscene.js";
import { OpeningCredit } from "./OpeningCredit.js";
import { OpeningDate } from "./OpeningDate.js";
import { Logo } from "./Logo.js";
import { MugShotLR } from "./Dialog.js";
import { Date } from "./Date.js";
import { PM2ActorOrder, PatronGod } from "./ContentsEnums.js";

export class OpeningLevel extends GameEngineLevel {
	constructor() {
		super();
		this.AcOlive = null;
		this.FatherName = "";

		this.GodPicImageString = "";
		this.GodName = "";
		this.PatronGodSex = 0;

		this.AcCaption = null;
		this.AcCutScene = null;
		this.AcUpperDialog = null;
		this.AcBottomDialog = null;
		this.AcOpeningCredit = null;
		this.AcOpeningDate = null;
		this.AcLogo = null;
		this.Time = 0.0;

		this.BGMPlayer = new GameEngineSoundPlayer();
		this.BGMChange = false;
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.AcCaption = this.CreateActor(Caption);
		this.AcUpperDialog = this.CreateActor(UpperDialog);
		this.AcBottomDialog = this.CreateActor(BottomDialog);
		this.AcCutScene = this.CreateActor(Cutscene);
		this.AcOpeningCredit = this.CreateActor(OpeningCredit);
		this.AcOpeningDate = this.CreateActor(OpeningDate);
		this.AcLogo = this.CreateActor(Logo);

		if (false === GameEngineInput.IsKey("2")) {
			GameEngineInput.CreateKey("2", '2'.charCodeAt(0));
		}
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}

		let LocalDeltaTime = _DeltaTime;

		if (GameEngineInput.IsPress("2")) {
			LocalDeltaTime *= 16;
			this.Time += LocalDeltaTime;
		}
		else {
			this.Time += LocalDeltaTime;
		}

		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}

		if (0 <= this.Time && 20 > this.Time) {
			this.AcCutScene.On();
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.Black);
			this.AcCutScene.OffCutScene();

			this.AcOpeningCredit.On();
			this.AcOpeningCredit.UpdateScroll(LocalDeltaTime);
		}
		else if (20 <= this.Time && 35 > this.Time) {
			this.AcOpeningCredit.Off();
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.White);
			this.AcCutScene.OnCutScene(0);
			if (22 <= this.Time && 26 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그것은 일방적인 싸움이었다…");
			}
			else if (26 <= this.Time && 27 > this.Time) {
				this.AcCaption.Off();
			}
			else if (27 <= this.Time && 31 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("평화에 길들여진 수도의 군대는\n막강한 마왕군 앞에 추풍낙엽처럼 쓰러져갔다.");
			}
			else if (31 <= this.Time && 32 > this.Time) {
				this.AcCaption.Off();
			}
			else if (32 <= this.Time && 35 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("성벽은 무너지고 거리는 불길에 휩싸였다.\n수도의 함락은 목전까지 닥친 상황이었다.");
			}
		}
		else if (35 <= this.Time && 75 > this.Time) {
			this.AcCaption.Off();
			this.AcCutScene.OnCutScene(1);

			if (37 <= this.Time && 41 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그때 그 참상을 목격한 방랑검사가 있었다. 그의 이름은 " + this.FatherName + "." + "\n그는 스스로 마왕과의 싸움에 몸을 던졌다");
			}
			else if (41 <= this.Time && 42 > this.Time) {
				this.AcCaption.Off();
			}
			else if (42 <= this.Time && 46 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("초승달이 뜬 밤, 마왕의 진영에 잠입한 " + this.FatherName + "." + "\n그는 1대1의 결투 끝에 마왕에게 승리했다.");
			}
			else if (46 <= this.Time && 47 > this.Time) {
				this.AcUpperDialog.On();
				this.AcUpperDialog.SetMugPic("Mug_Devil.bmp");
				this.AcUpperDialog.SetMugLoc(MugShotLR.Left);
				this.AcUpperDialog.SetUpdateText("「우우… 나의 패배다」");
			}
			else if (51 <= this.Time && 56 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「그러나 용자여. 너는 어째서\n싸우는가?」");
			}
			else if (56 <= this.Time && 64 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「타락한 도시를 벌함은 하늘의 뜻.\n 너와는 아무 상관 없는 어리석은\n 자들이 멸망할 뿐이다」");
			}
			else if (64 <= this.Time && 65 > this.Time) {
				this.AcUpperDialog.Off();
			}
			else if (65 <= this.Time && 69 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그 질문에 대한 " + this.FatherName + "의 대답은 전해지지 않는다.");
			}
			else if (69 <= this.Time && 70 > this.Time) {
				this.AcCaption.Off();
			}
			else if (70 <= this.Time && 74 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("얼마 후 마왕은 상처 입은 몸을 치료하기 위해\n군대를 이끌고 지저로 돌아갔다…");
			}
			else if (74 <= this.Time && 75 > this.Time) {
				this.AcCaption.Off();
			}
		}
		else if (75 <= this.Time && 115 > this.Time) {
			this.AcCutScene.OnCutScene(2);
			if (77 <= this.Time && 83 > this.Time) {
				this.AcUpperDialog.On();
				this.AcUpperDialog.SetMugPic("Mug_King.bmp");
				this.AcUpperDialog.SetMugLoc(MugShotLR.Right);
				this.AcUpperDialog.SetUpdateText("「오오, 용사여. 훌륭하게 이 도시를 \n구해주셨소」");
			}
			else if (83 <= this.Time && 92 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「이번 전쟁은 어리석은 짐에게 \n내려진신벌이오. 귀공이 없었다면 \n시민들과 함께 멸망했을 게요…」");
			}
			else if (92 <= this.Time && 102 > this.Time) {
				this.AcBottomDialog.On();
				this.AcBottomDialog.SetMugPic("Mug_Queen.bmp");
				this.AcBottomDialog.SetMugLoc(MugShotLR.Left);
				this.AcBottomDialog.SetUpdateText("「이 일은 우리들에게 내려진 \n신벌… 저도 왕도 이제부터 마음을 \n바꾸어 이곳이 좋은 도읍이 \n되도록 일하겠습니다」");
			}
			else if (102 <= this.Time && 114 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「보아하니 귀공도 부상을 당했\n구려. 이곳에 머물며 도읍의 재\n건을 도와줄 순 없겠는지. 짐이 \n간곡히 부탁하겠소」");
			}
			else if (114 <= this.Time && 115 > this.Time) {
				this.AcUpperDialog.Off();
				this.AcBottomDialog.Off();
			}
		}
		else if (115 <= this.Time && 119 > this.Time) {
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.Black);
			this.AcCutScene.OffCutScene();
			if (116 <= this.Time && 119 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("이리하여 도시에 정착해 왕의 녹봉을 받게 된 용사 " + this.FatherName + ".");
			}
		}
		else if (119 <= this.Time && 122 > this.Time) {
			this.AcCaption.Off();
			this.AcOpeningDate.On();
		}
		else if (122 <= this.Time && 144 > this.Time) {
			if (false === this.BGMChange) {
				this.BGMChange = true;
				this.BGMPlayer.Stop();
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("03_Opening_2.mp3");
			}
			this.AcCutScene.OnCutScene(3);
			this.AcOpeningDate.Off();
			if (125 <= this.Time && 130 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그러던 어느 아름다운 밤, " + this.FatherName + "의 이름을 부르는 듯한 느낌이 들었다…");
			}
			else if (130 <= this.Time && 134 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("「용사여……」");
			}
			else if (134 <= this.Time && 135 > this.Time) {
				this.AcCaption.Off();
			}
			else if (135 <= this.Time && 140 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("하늘에서 " + this.FatherName + "의 이름을 부르는 목소리가 들린다…");
			}
			else if (140 <= this.Time && 141 > this.Time) {
				this.AcCaption.Off();
			}
			else if (141 <= this.Time && 144 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("올려다보니, 한 줄기의 유성이 긴 꼬리를 끌며 천천히 눈앞의 언덕에 떨어졌다.");
			}
		}
		else if (144 <= this.Time && 149 > this.Time) {
			this.AcCaption.SetUpdateText("언덕으로 달려간 " + this.FatherName + ". 그곳에는 커다란 빛덩어리가 떠 있었다.");
			this.AcCutScene.OffCutScene();
		}
		else if (149 <= this.Time && 172 > this.Time) {
			this.AcCutScene.OnCutScene(4);
			if (149 <= this.Time && 150 > this.Time) {
				this.AcCaption.Off();
			}
			else if (150 <= this.Time && 155 > this.Time) {
				this.AcCaption.SetUpdateText("그리고, 빛속에는 어린 여자아이가…");
			}
			else if (155 <= this.Time && 156 > this.Time) {
				this.AcCaption.Off();
			}
			else if (156 <= this.Time && 161 > this.Time) {
				this.AcBottomDialog.On();
				this.AcBottomDialog.SetMugPic(this.GodPicImageString);
				this.AcBottomDialog.SetMugLoc(MugShotLR.Right);
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「용사여…나는 이 소녀의 수호\n자 " + this.GodName + "」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「용사여…나는 이 소녀의 수호\n자 " + this.GodName + "...」");
				}
			}
			else if (161 <= this.Time && 171 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이는 태어나서 오늘에 \n이르기까지 성스러운 빛의 안에\n서 자라 현세의 더러움을 일절 \n알지 못하는 순수한 영혼을 지\n닌 자다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이는 태어나서 오늘에 \n이르기까지 성스러운 빛의 안에\n서 자라 현세의 더러움을 일절 \n알지 못하는 순수한 영혼을 지\n닌 자…」");
				}
			}
			else if (171 <= this.Time && 172 > this.Time) {
				this.AcBottomDialog.Off();
			}
		}
		else if (172 <= this.Time && 200 > this.Time) {
			this.AcCutScene.OnCutScene(5);
			if (174 <= this.Time && 178 > this.Time) {
				this.AcBottomDialog.On();
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「바로 지금 그대에게 이 아이\n를 맡기겠다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「바로 지금 당신에게 이 아이\n를 맡기겠습니다」");
				}
			}
			else if (178 <= this.Time && 185 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이의 생과 사, 또한 어\n떠한 인생을 보내게 될 것인지\n도, 모두 그대에게 달렸다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이가 사는 것도 죽는 것\n도 또한 어떠한 인생을 보내게\n 되는 지도, 전부 당신 하기 나\n름」");
				}
			}
			else if (185 <= this.Time && 191 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「모든것이 그대에게 달려있는 \n것이다. 그래, 모든 것이 말이지\n…」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「모든 것이 당신에게 달려있는 \n겁니다. 그래요, 모든 것이…」");
				}
			}
			else if (191 <= this.Time && 198 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그럼 부탁하네. \n나는 항상 하늘에서 그대들 부\n녀를 지켜보고 있겠다……」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그럼 부탁드립니다. \n저는 항상 하늘에서 당신들 부\n녀를 지켜보겠습니다……」");
				}
			}
			else if (198 <= this.Time && 199 > this.Time) {
				this.AcBottomDialog.Off();
			}
		}
		else if (200 <= this.Time && 205 > this.Time) {
			this.AcCutScene.OffCutScene();
			if (200 <= this.Time && 205 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그리고 1년이 지났다……");
			}
		}
		else if (205 <= this.Time && 215 > this.Time) {
			this.AcCaption.Off();
			this.AcCutScene.OnCutScene(6);
			if (208 <= this.Time && 215 > this.Time) {
				this.AcLogo.On();
			}
		}
		else {
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}
	}

	LevelChangeEnd(_NextLevel) {
		// 원본: dynamic_cast<RaisingSimLevel*>(_NextLevel)->SetToday(...)
		_NextLevel.SetToday(new Date(1210, Olive.OlivePlayer.GetOliveBirthDay().GetMonth(), Olive.OlivePlayer.GetOliveBirthDay().GetDay()));
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("02_Opening_1.mp3");
		this.AcOlive = Olive.OlivePlayer;
		this.AcOpeningDate.UpdateOliveBirthDay();
		this.FatherName = this.AcOlive.GetOliveLastName();
		if (PatronGod["태양신_솔"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Sol_God.bmp";
			this.GodName = "태양신 솔";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["달신_더문"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_TheMoon_God.bmp";
			this.GodName = "달의신 더 문";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["화성신_마르스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Mars_God.bmp";
			this.GodName = "화성신 마르스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["수성신_머큐리"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Mercury_God.bmp";
			this.GodName = "수성신 머큐리";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["목성신_주피터"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Jupiter_God.bmp";
			this.GodName = "목성신 주피터";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["금성신_비너스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Venus_God.bmp";
			this.GodName = "금성신 비너스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["토성신_새턴"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Saturn_God.bmp";
			this.GodName = "토성신 새턴";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["천왕성신_우라누스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Uranus_God.bmp";
			this.GodName = "천왕성신 우라누스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["해왕성신_넵튠"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Neptune_God.bmp";
			this.GodName = "해왕성신 넵튠";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["명왕성신_하데스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Hades_God.bmp";
			this.GodName = "명왕성신 하데스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("02_Opening_1.mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("03_Opening_2.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MugShotFrame_God.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MugShotFrame_Nomal.BMP"));

		Dir.Move("OpeningLevel");

		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.Move("MugShot");
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Num");
		Dir.Move("Num");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OpeningDayNum.BMP")).Cut(10, 1);
	}
}
