// StrategyClass.h / StrategyClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class StrategyClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Strategy.bmp", "Animation_Background_Strategy.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(-35, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(45, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-125, -11));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Sensitivity = -1, .Stress = 0,.CombatSkill = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Sensitivity = -1;
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 2, .Sensitivity = 0, .Stress = 1,.CombatSkill = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 2;
		StatusParaMax.Sensitivity = 0;
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-50);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
