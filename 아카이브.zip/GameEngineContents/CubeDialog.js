// CubeDialog.h / CubeDialog.cpp 의 전사
import { Dialog, MugShotLR } from "./Dialog.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

// enum class CubeFace
export const CubeFace = Object.freeze({
	Nomal: 0,
	Happy: 1,
	Proud: 2,
	BigWorry: 3,
	Excited: 4,
	Embarrassment: 5,
	Anger: 6,
	Worry: 7,
	Surprise: 8,
	Hmm: 9,
	Serious: 10,
	SuperExcited: 11,
	OMG: 12,
	Love: 13,
});

export class CubeDialog extends Dialog {
	constructor() {
		super();
		this.CubeMugshot = new Map(); // std::map<CubeFace, std::string>
		this.ActorPos = new float4(250, 500);
	}

	UpdateCubeDialog(_Face, _Dialog) {
		this.On();
		this.SetMugPic(this.CubeMugshot.get(_Face));
		this.SetUpdateText(_Dialog);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetCubeMugShot();
		this.SetMugPic(this.CubeMugshot.get(CubeFace.Nomal));
		this.SetMugLoc(MugShotLR.Right);
		this.SetPos(this.ActorPos);
	}

	SetCubeMugShot() {
		this.CubeMugshot.set(CubeFace.Nomal, "Mug_Cube_Nomal.bmp");
		this.CubeMugshot.set(CubeFace.Anger, "Mug_Cube_Anger.bmp");
		this.CubeMugshot.set(CubeFace.BigWorry, "Mug_Cube_BigWorry.bmp");
		this.CubeMugshot.set(CubeFace.Embarrassment, "Mug_Cube_Embarrassment.bmp");
		this.CubeMugshot.set(CubeFace.Excited, "Mug_Cube_Excited.bmp");
		this.CubeMugshot.set(CubeFace.Happy, "Mug_Cube_Happy.bmp");
		this.CubeMugshot.set(CubeFace.Hmm, "Mug_Cube_Hmm.bmp");
		this.CubeMugshot.set(CubeFace.Love, "Mug_Cube_Love.bmp");
		this.CubeMugshot.set(CubeFace.OMG, "Mug_Cube_OMG.bmp");
		this.CubeMugshot.set(CubeFace.Proud, "Mug_Cube_Proud.bmp");
		this.CubeMugshot.set(CubeFace.Serious, "Mug_Cube_Serious.bmp");
		this.CubeMugshot.set(CubeFace.SuperExcited, "Mug_Cube_SuperExcited.bmp");
		this.CubeMugshot.set(CubeFace.Surprise, "Mug_Cube_Surprise.bmp");
		this.CubeMugshot.set(CubeFace.Worry, "Mug_Cube_Worry.bmp");
	}
}
