// ProtocolClass.h / ProtocolClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class ProtocolClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Protocol.bmp", "Animation_Background_Protocol.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(95, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(-165, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-85, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 13, 17, new float4(5, -3));

		// 원본: GetStatusVarianceMin().SetStatus({.Refinement = 1, .Stress = 0,.Decorum = 1 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Refinement = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.Decorum = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Refinement = 1,.Stress = 1, .Decorum = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Refinement = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Decorum = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
