// PlayerCalendar.h / PlayerCalendar.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { Button, ButtonState } from "../GameEngineCore/Button.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { GameEngineMath, float4 } from "../GameEngineBase/GameEngineMath.js";
import { Button_Date } from "./Button_Date.js";
import { Date } from "./Date.js";
import { Olive } from "./Olive.js";
import { FirstSetLevel, ActorState } from "./FirstSetLevel.js";
import { SetOliveBloodType } from "./SetOliveBloodType.js";
import { PM2ActorOrder, PM2RenderOrder, PM2CollisionOrder } from "./ContentsEnums.js";
import { RGB } from "../WinAPI.js";

export class PlayerCalendar extends GameEngineActor {
	static FirstUpdate = false;

	constructor() {
		super();		this.FirstUpdate = false; // 원본 PlayerCalendar.h: bool FirstUpdate = 선언

		this.OliveBirth = new Date();
		this.CalendarYear = 0;
		this.PlayerBirth = new Date();

		this.EcahMonthCalendarInterval = new float4(250, 105);

		// 원본 고정 크기 배열: Button_Date* DateButton[4][3][6][7] = {};
		this.DateButton = [];
		for (let w = 0; w < 4; w++) {
			this.DateButton.push([]);
			for (let z = 0; z < 3; z++) {
				this.DateButton[w].push([]);
				for (let y = 0; y < 6; y++) {
					this.DateButton[w][z].push([]);
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y].push(null);
					}
				}
			}
		}
		this.DateButtonScale = new float4(20, 14);
		this.FirstDaySetPos = new float4(-330, -177);
		this.EachDayNumInterval = new float4(30, 15);

		// 원본 고정 크기 배열: GameEngineRender* WeekRender[4][3] = {};
		this.WeekRender = [];
		for (let y = 0; y < 4; y++) {
			this.WeekRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.WeekRender[y].push(null);
			}
		}
		this.WeekRenderScale = new float4(210, 10);
		this.FirstWeekSetPos = new float4(-235, -192);

		// 원본 고정 크기 배열: GameEngineRender* YearRender[4][3][4] = {};
		this.YearRender = [];
		for (let z = 0; z < 4; z++) {
			this.YearRender.push([]);
			for (let y = 0; y < 3; y++) {
				this.YearRender[z].push([]);
				for (let x = 0; x < 4; x++) {
					this.YearRender[z][y].push(null);
				}
			}
		}
		this.YearRenderScale = new float4(8, 12);
		this.FirstYearSetPos = new float4(-370, -182);

		// 원본 고정 크기 배열: GameEngineRender* MonthRender[4][3] = {};
		this.MonthRender = [];
		for (let y = 0; y < 4; y++) {
			this.MonthRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.MonthRender[y].push(null);
			}
		}
		this.MonthRenderScale = new float4(20, 16);
		this.FirstMonthSetPos = new float4(-360, -165);


		this.BackgroundRender = null;

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(106, 170, 126);

		this.HoverButtonDateRender_Year = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Year = new float4(-335, -221);
		this.HoverButtonDateRender_Month = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Month = new float4(-305, -221);
		this.HoverButtonDateRender_Day = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Day = new float4(-275, -221);
	}

	SetOliveBirth(_YYYY, _MM, _DD) {
		this.OliveBirth.SetDate(_YYYY, _MM, _DD);
	}

	SetCalendarYear(_YYYY) {
		this.CalendarYear = _YYYY;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (0 !== this.DateButton[w][z][y][x].GetReleaseIndex()) {
							this.DateButton[w][z][y][x].On();
						}
					}
				}
			}
		}
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y][x].Off();
					}
				}
			}
		}
	}

	Start() {
		this.SetOliveBirth(1000, 1, 1);
		this.SetCalendarYear(1000);
		this.SetPos(GameEngineWindow.GetScreenSize().half());

		this.HoverButtonDateRender_Year.SetOwner(this);
		this.HoverButtonDateRender_Year.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Year.SetAlign(Align.Right);
		this.HoverButtonDateRender_Year.SetRenderPos(this.Pos_HoverButtonDateRender_Year);

		this.HoverButtonDateRender_Month.SetOwner(this);
		this.HoverButtonDateRender_Month.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Month.SetAlign(Align.Right);
		this.HoverButtonDateRender_Month.SetRenderPos(this.Pos_HoverButtonDateRender_Month);
		this.HoverButtonDateRender_Month.SetNumOfDigits(2);

		this.HoverButtonDateRender_Day.SetOwner(this);
		this.HoverButtonDateRender_Day.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Day.SetAlign(Align.Right);
		this.HoverButtonDateRender_Day.SetRenderPos(this.Pos_HoverButtonDateRender_Day);
		this.HoverButtonDateRender_Day.SetNumOfDigits(2);

		this.SetDateNumButton();
		this.SetMonthRender();
		this.SetYearRender();
		this.SetWeekdayRender();
		this.SetExplainRender();

		this.BackgroundRender = this.CreateRender("SetPlayerBirth.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!PlayerCalendar.FirstUpdate) {
			PlayerCalendar.FirstUpdate = true;
			this.OliveBirth = Olive.OlivePlayer.GetOliveBirthDay();
			this.CalendarYear = 1209 - Olive.OlivePlayer.GetFatherAge();

			this.UpdateDateNumButton();
			this.UpdateMonthRender();
			this.UpdateYearRender();
		}

		const Index = this.WichButtonNotRelease();
		if (
			0 > Index.x &&
			0 > Index.y &&
			0 > Index.z &&
			0 > Index.w
		) {
			this.HoverButtonDateRender_Year.Off();
			this.HoverButtonDateRender_Month.Off();
			this.HoverButtonDateRender_Day.Off();
		}
		else {
			this.HoverButtonDateRender_Year.On();
			this.HoverButtonDateRender_Month.On();
			this.HoverButtonDateRender_Day.On();

			this.HoverButtonDateRender_Year.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetYear());
			this.HoverButtonDateRender_Month.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetMonth());
			this.HoverButtonDateRender_Day.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetDay());
		}
	}

	Render(_DeltaTime) {

	}

	WichButtonNotRelease() {
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (ButtonState.Release !== this.DateButton[w][z][y][x].GetState()) {
							return new float4((x), (y), (z), (w));
						}
					}
				}
			}
		}
		return new float4(-1, -1, -1, -1);
	}

	SetDateNumButton() {
		let FirstMonth = this.OliveBirth.GetMonth();
		let Month = FirstMonth;
		let Year = this.CalendarYear;
		const MonthLen = new Array(12).fill(0);

		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			MonthLen[i] = Date.GetMonthLenth(Year, Month);
			Month++;
		}

		const FirstWeekday = Date.FindMonthFirstWeekday(this.CalendarYear, FirstMonth);
		let MonthFirstWeekday = FirstWeekday;
		Month = FirstMonth;
		Year = this.CalendarYear;
		const Level = this.GetLevel();

		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				if (Month === 13) {
					Month = 1;
					Year++;
				}
				let Day = 1;
				const FirstMonth = (z + 1) + (w * 3); // 원본: 외부 FirstMonth를 가리는 지역 변수
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						const fx = (x);
						const fy = (y);
						const fz = (z);
						const fw = (w);
						this.DateButton[w][z][y][x] = Level.CreateActor(Button_Date, PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
						this.DateButton[w][z][y][x].SetScale(this.DateButtonScale);
						this.DateButton[w][z][y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetPos(this.GetPos().add(this.FirstDaySetPos.add(this.EachDayNumInterval.mul(new float4(fx, fy))).add(this.EcahMonthCalendarInterval.mul(new float4(fz, fw)))));
						if (x + (y * 7) < MonthFirstWeekday) {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
						}
						else if (x + (y * 7) < MonthFirstWeekday + MonthLen[FirstMonth - 1]) {
							if (0 === x) {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 32 + Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
							}
							else {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
							}
						}
						else {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
						}
					}
				}
				Month++;
				MonthFirstWeekday = (MonthFirstWeekday + MonthLen[FirstMonth - 1]) % 7;
			}
		}
	}

	UpdateDateNumButton() {
		let FirstMonth = this.OliveBirth.GetMonth();
		let Month = FirstMonth;
		let Year = this.CalendarYear;
		const MonthLen = new Array(12).fill(0);

		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			MonthLen[i] = Date.GetMonthLenth(Year, Month);
			Month++;
		}

		const FirstWeekday = Date.FindMonthFirstWeekday(this.CalendarYear, FirstMonth);
		let MonthFirstWeekday = FirstWeekday;
		Month = FirstMonth;
		Year = this.CalendarYear;

		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				if (Month === 13) {
					Month = 1;
					Year++;
				}
				let Day = 1;
				const FirstMonth = (z + 1) + (w * 3); // 원본: 외부 FirstMonth를 가리는 지역 변수
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						const fx = (x);
						const fy = (y);
						const fz = (z);
						const fw = (w);
						if (x + (y * 7) < MonthFirstWeekday) {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].Off();
						}
						else if (x + (y * 7) < MonthFirstWeekday + MonthLen[FirstMonth - 1]) {
							if (0 === x) {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 32 + Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
								this.DateButton[w][z][y][x].On();
							}
							else {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
								this.DateButton[w][z][y][x].On();
							}
						}
						else {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].Off();
						}
					}
				}
				Month++;
				MonthFirstWeekday = (MonthFirstWeekday + MonthLen[FirstMonth - 1]) % 7;
			}
		}
	}

	SetYearRender() {
		let Month = this.OliveBirth.GetMonth();
		let Year = this.CalendarYear;
		let YearDigits = GameEngineMath.GetDigits(Year); // std::vector<unsigned int>

		for (let z = 0; z < 4; z++) {
			for (let y = 0; y < 3; y++) {

				if (Month === 13) {
					Month = 1;
					Year++;
					YearDigits = GameEngineMath.GetDigits(Year);
				}

				for (let x = 0; x < 4; x++) {
					const fx = (x);
					const fy = (y);
					const fz = (z);
					this.YearRender[z][y][x] = this.CreateRender("PlayerYearNum.BMP", PM2RenderOrder.Contents);
					this.YearRender[z][y][x].SetScale(this.YearRenderScale);
					this.YearRender[z][y][x].SetPosition(this.FirstYearSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fy, fz))).add(float4.Right.scale(fx).scale(this.YearRenderScale.x)));
				}

				this.YearRender[z][y][0].SetFrame(YearDigits[0]);
				this.YearRender[z][y][1].SetFrame(YearDigits[1]);
				this.YearRender[z][y][2].SetFrame(YearDigits[2]);
				this.YearRender[z][y][3].SetFrame(YearDigits[3]);

				Month++;
			}
		}
	}

	UpdateYearRender() {
		let Month = this.OliveBirth.GetMonth();
		let Year = this.CalendarYear;
		let YearDigits = GameEngineMath.GetDigits(Year); // std::vector<unsigned int>

		for (let z = 0; z < 4; z++) {
			for (let y = 0; y < 3; y++) {

				if (Month === 13) {
					Month = 1;
					Year++;
					YearDigits = GameEngineMath.GetDigits(Year);
				}

				this.YearRender[z][y][0].SetFrame(YearDigits[0]);
				this.YearRender[z][y][1].SetFrame(YearDigits[1]);
				this.YearRender[z][y][2].SetFrame(YearDigits[2]);
				this.YearRender[z][y][3].SetFrame(YearDigits[3]);

				Month++;
			}
		}
	}

	SetWeekdayRender() {
		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.WeekRender[y][x] = this.CreateRender("PlayerWeek.BMP", PM2RenderOrder.Contents);
				this.WeekRender[y][x].SetScale(this.WeekRenderScale);
				this.WeekRender[y][x].SetPosition(this.FirstWeekSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	SetMonthRender() {
		let Month = this.OliveBirth.GetMonth();

		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.MonthRender[y][x] = this.CreateRender("PlayerCalendarNum.BMP", PM2RenderOrder.Contents);
				if (13 === ((x + (y * 3)) + (Month))) {
					Month = -(12 - Month);
				}
				this.MonthRender[y][x].SetFrame((x + (y * 3)) + (Month));
				this.MonthRender[y][x].SetScale(new float4(20, 16));
				this.MonthRender[y][x].SetPosition(this.FirstMonthSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	UpdateMonthRender() {
		let Month = this.OliveBirth.GetMonth();

		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				if (13 === ((x + (y * 3)) + (Month))) {
					Month = -(12 - Month);
				}
				this.MonthRender[y][x].SetFrame((x + (y * 3)) + (Month));
			}
		}
	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = new float4(this.ExplainTextBoxScale.hx(), 0).neg().sub(new float4(0, 223));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static SetPlayerBirthDay(_Btn) {
		// 원본: dynamic_cast<Button_Date*>(_Btn)
		const Ptr = _Btn;
		Olive.OlivePlayer.SetFatherBirthDay(Ptr.Value);
		FirstSetLevel.SetStateValue(ActorState.SetOliveBloodType);
		PlayerCalendar.FirstUpdate = false;
		SetOliveBloodType.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['SetPlayerBirthDay']) {
	Object.defineProperty(PlayerCalendar.prototype, __m, { value: function (...args) { return PlayerCalendar[__m](...args); }, writable: true, configurable: true });
}

