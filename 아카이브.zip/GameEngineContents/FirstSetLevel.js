// FirstSetLevel.h / FirstSetLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { GameEngineResources, GameEngineSoundPlayer } from "../GameEngineCore/GameEngineResources.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { VK } from "../WinAPI.js";
import { MousePoint } from "./MousePoint.js";
import { Olive } from "./Olive.js";
import { SetPlayerName } from "./SetPlayerName.js";
import { SetOliveName } from "./SetOliveName.js";
import { OliveCalendar } from "./OliveCalendar.js";
import { PlayerCalendar } from "./PlayerCalendar.js";
import { SetPlayerAge } from "./SetPlayerAge.js";
import { SetOliveBloodType } from "./SetOliveBloodType.js";
import { PM2ActorOrder } from "./ContentsEnums.js";

// enum class ActorState
export const ActorState = Object.freeze({
	NULLSTATE: 0,
	SetPlayerName: 1,
	SetOliveName: 2,
	OliveCalendar: 3,
	SetPlayerAge: 4,
	PlayerCalendar: 5,
	SetOliveBloodType: 6
});

export class FirstSetLevel extends GameEngineLevel {
	static SetStateValue(_State) {
		FirstSetLevel.CurStateValue = _State;
	}

	constructor() {
		super();
		this.UpdateActor = null;

		this.AcOlive = null;
		this.AcSetPlayerName = null;
		this.AcSetOliveName = null;
		this.AcOliveCalendar = null;
		this.AcSetPlayerAge = null;
		this.AcPlayerCalendar = null;
		this.AcSetOliveBloodType = null;

		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	static CurStateValue = ActorState.NULLSTATE;
	static PrevStateValue = ActorState.NULLSTATE;

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);

		this.AcOlive = this.CreateActor(Olive, PM2ActorOrder.Olive);

		this.AcSetPlayerName = this.CreateActor(SetPlayerName, ActorState.SetPlayerName);
		this.AcSetOliveName = this.CreateActor(SetOliveName, ActorState.SetOliveName);
		this.AcOliveCalendar = this.CreateActor(OliveCalendar, ActorState.OliveCalendar);
		this.AcSetPlayerAge = this.CreateActor(SetPlayerAge, ActorState.SetPlayerAge);
		this.AcPlayerCalendar = this.CreateActor(PlayerCalendar, ActorState.PlayerCalendar);
		this.AcSetOliveBloodType = this.CreateActor(SetOliveBloodType, ActorState.SetOliveBloodType);

		FirstSetLevel.CurStateValue = ActorState.SetPlayerName;
		FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;

		if (true !== GameEngineInput.IsKey("ESC")) {
			GameEngineInput.CreateKey("ESC", VK.ESCAPE);
		}
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("Opening");
		}

		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}

		switch (FirstSetLevel.CurStateValue) {
			case ActorState.NULLSTATE:
				break;
			case ActorState.SetPlayerName:
				this.AcSetPlayerName.On();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;
				break;
			case ActorState.SetOliveName:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.On();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetPlayerName->FirstUpdate = false; (정적 멤버 접근)
					SetPlayerName.FirstUpdate = false;
				}
				break;
			case ActorState.OliveCalendar:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.On();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetOliveName;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetOliveName->FirstUpdate = false; (정적 멤버 접근)
					SetOliveName.FirstUpdate = false;
				}
				break;
			case ActorState.SetPlayerAge:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.On();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.OliveCalendar;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcOliveCalendar->FirstUpdate = false; (정적 멤버 접근)
					OliveCalendar.FirstUpdate = false;
				}
				break;
			case ActorState.PlayerCalendar:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.On();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerAge;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetPlayerAge->FirstUpdate = false; (정적 멤버 접근)
					SetPlayerAge.FirstUpdate = false;
				}
				break;
			case ActorState.SetOliveBloodType:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.On();
				FirstSetLevel.PrevStateValue = ActorState.PlayerCalendar;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcPlayerCalendar->FirstUpdate = false; (정적 멤버 접근)
					PlayerCalendar.FirstUpdate = false;
				}
				break;
			default:
				break;
		}
	}

	LevelChangeEnd(_NextLevel) {
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("01_Profile_determination.mp3");
		this.BGMPlayer.LoopCount(10000);
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("01_Profile_determination.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("ReleaseButton.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("HoverButton.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PressButton.BMP"));

		Dir.Move("Olive");
		Dir.Move("Head");
		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Body");
		Dir.Move("Body");

		// 원본: AllFile.clear();
		AllFile = [];
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("FirstSetLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BirthNum.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveCalendarNum.BMP")).Cut(32, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveYearNum.BMP")).Cut(10, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerYearNum.BMP")).Cut(10, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerCalendarNum.BMP")).Cut(32, 3);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveWeek.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerWeek.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetOliveBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetOliveBirth.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetPlayerBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetPlayerBirth.BMP"));
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['SetStateValue']) {
	Object.defineProperty(FirstSetLevel.prototype, __m, { value: function (...args) { return FirstSetLevel[__m](...args); }, writable: true, configurable: true });
}

