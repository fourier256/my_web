// MainMenu.h / MainMenu.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GlobalButton } from "./GlobalButton.js";
import { StatusWindowManager } from "./StatusWindowManager.js";
import { ConverstionSelectionMenu } from "./ConverstionSelectionMenu.js";
import { DietSelectionMenu } from "./DietSelectionMenu.js";
import { InformationWindowManager } from "./InformationWindowManager.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { ScheduleSelectionMenu } from "./ScheduleSelectionMenu.js";
import { PM2ActorOrder, PM2RenderOrder, PM2CollisionOrder } from "./ContentsEnums.js";

export class MainMenu extends GameEngineActor {
	static AcMainMenu = null;
	static AcStatusWindowManager = null;
	static AcConverstionSelectionMenu = null;
	static AcDietSelectionMenu = null;
	static AcInformationWindowManager = null;

	static AcScheduleCalendar = null;
	static AcScheduleSelectionMenu = null;

	constructor() {
		super();
		this.ActorPos = new float4(700, 278);
		this.MainMenuRender = null;
		this.MainMenuButtons = []; // std::vector<std::vector<GlobalButton*>>
		this.MainMenuButtonScale = new float4(50, 40);
		this.FirstButtonSetPos = new float4(-75, -40);

		this.ScheduleButton = null;
		this.ScheduleButtonScale = new float4(200, 40);
		this.ScheduleButtonPos = new float4(0, 40);

		MainMenu.AcMainMenu = this;
	}

	GetMainMenuButton() {
		return this.MainMenuButtons;
	}

	GetScheduleButton() {
		return this.ScheduleButton;
	}

	static GetAcMainMenu() {
		return MainMenu.AcMainMenu;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x].On();
			}
		}
		this.ScheduleButton.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x].Off();
			}
		}
		this.ScheduleButton.Off();
	}

	Start() {
		const Level = this.GetLevel();
		this.SetPos(this.ActorPos);
		this.MainMenuRender = this.CreateRender("MainMenu.bmp", PM2RenderOrder.Menu0);
		this.MainMenuRender.SetScaleToImage();
		this.SetMainMenuButtons();

		MainMenu.AcStatusWindowManager = Level.CreateActor(StatusWindowManager, PM2ActorOrder.Menu1);
		MainMenu.AcConverstionSelectionMenu = Level.CreateActor(ConverstionSelectionMenu, PM2ActorOrder.Menu1);
		MainMenu.AcDietSelectionMenu = Level.CreateActor(DietSelectionMenu, PM2ActorOrder.Menu1);
		MainMenu.AcInformationWindowManager = Level.CreateActor(InformationWindowManager, PM2ActorOrder.Menu1);

		MainMenu.AcScheduleCalendar = Level.CreateActor(ScheduleCalendar, PM2ActorOrder.Menu1);
		MainMenu.AcScheduleSelectionMenu = Level.CreateActor(ScheduleSelectionMenu, PM2ActorOrder.Menu1);
		this.SetClickButton();
	}

	Update(_DeltaTime) {

	}

	Render(_Time) {
	}

	SetMainMenuButtons() {
		const Level = this.GetLevel();
		// 원본: MainMenuButtons.resize(2) 후 각 행 resize(4)
		this.MainMenuButtons.length = 2;
		for (let x = 0; x < this.MainMenuButtons.length; x++) {
			this.MainMenuButtons[x] = new Array(4).fill(null);
		}


		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x] = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.MainMenuButtons[y][x].SetScale(this.MainMenuButtonScale);
				this.MainMenuButtons[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetReleaseImage("SelectButton_Release.bmp");
				this.MainMenuButtons[y][x].SetHoverImage("MainMenu_Buttons.bmp", x + 4 * y);
				this.MainMenuButtons[y][x].SetPressImage("MainMenu_Buttons.bmp", x + 4 * y);
				this.MainMenuButtons[y][x].SetPos(this.ActorPos.add(this.FirstButtonSetPos.add(this.MainMenuButtonScale.mul(new float4((x), (y))))));
			}
		}

		this.ScheduleButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.ScheduleButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.ScheduleButton.SetScale(this.ScheduleButtonScale);
		this.ScheduleButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.ScheduleButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.ScheduleButton.SetReleaseImage("SelectButton_Release.bmp");
		this.ScheduleButton.SetHoverImage("MainMenu_Schedule.bmp");
		this.ScheduleButton.SetPressImage("MainMenu_Schedule.bmp");
		this.ScheduleButton.SetPos(this.ActorPos.add(this.ScheduleButtonPos));
	}

	SetClickButton() {
		this.MainMenuButtons[0][0].SetClickCallBack(MainMenu.ClickMainMenu_00);
		this.MainMenuButtons[0][1].SetClickCallBack(MainMenu.ClickMainMenu_01);
		this.MainMenuButtons[0][2].SetClickCallBack(MainMenu.ClickMainMenu_02);
		this.MainMenuButtons[0][3].SetClickCallBack(MainMenu.ClickMainMenu_03);

		this.ScheduleButton.SetClickCallBack(MainMenu.ClickMainMenu_S);
	}

	static ClickMainMenu_00(_Btn) {
		MainMenu.AcStatusWindowManager.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_01(_Btn) {
		MainMenu.AcConverstionSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_02(_Btn) {
		MainMenu.AcDietSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_03(_Btn) {
		MainMenu.AcInformationWindowManager.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_S(_Btn) {
		MainMenu.AcScheduleCalendar.On();
		MainMenu.AcScheduleSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcMainMenu', 'ClickMainMenu_00', 'ClickMainMenu_01', 'ClickMainMenu_02', 'ClickMainMenu_03', 'ClickMainMenu_S']) {
	Object.defineProperty(MainMenu.prototype, __m, { value: function (...args) { return MainMenu[__m](...args); }, writable: true, configurable: true });
}

