// FirstScene.h / FirstScene.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class FirstScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);

		this.BackgroundRedner = null;
		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-400, -50);
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("FirstSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText((" "), this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText("8년 간이 꿈처럼 지나갔다…\n\n" + Olive.OlivePlayer.GetOliveLastName() + "의 딸 " + Olive.OlivePlayer.GetOliveFirstName() + "의 나이도 어느덧 18세, 성인이 된 것이었다.", this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
	}
}
