// OpeningCredit.h / OpeningCredit.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class OpeningCredit extends GameEngineActor {
	constructor() {
		super();
		this.MoveSpeed = 100.0;
		this.Time = 0.0;
		this.ScrollTime = 20.0;
		this.StartPos = float4.Zero;
		this.EndPos = float4.Zero;

		this.CreditRender = null;
	}

	UpdateScroll(_DeltaTime) {
		this.Time += _DeltaTime / this.ScrollTime;
		this.CreditRender.SetPosition(float4.LerpClamp(this.StartPos, this.EndPos, this.Time));
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.CreditRender = this.CreateRender("Credit.BMP", PM2RenderOrder.BackGroundObj);
		this.CreditRender.SetScaleToImage();
		this.StartPos = new float4(0, 700);
		this.EndPos = new float4(0, -700);
		const TopBox = this.CreateRender("BlackBox.BMP", PM2RenderOrder.CaptionBox);
		TopBox.SetScale(new float4(800, 100));
		TopBox.SetPosition(new float4(0, -250));
		const BotBox = this.CreateRender("BlackBox.BMP", PM2RenderOrder.CaptionBox);
		BotBox.SetScale(new float4(800, 100));
		BotBox.SetPosition(new float4(0, 250));
		this.Off();
	}

	Update(_DeltaTime) {
	}

	Render(_Time) {
	}
}
