// HelthInformationWindow.h / HelthInformationWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { MenuFrame, MenuFrameStyleEnum } from "./MenuFrame.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, Diet } from "./ContentsEnums.js";
import { RGB } from "../WinAPI.js";

export class HelthInformationWindow extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(260, 184);
		this.ActorPos = new float4(154, 380);

		this.DiseaseIndex = 0;
		this.Delinquency = 0;
		this.Popularity = 0;

		this.DiseaseState = false;
		this.DelinquentState = false;

		this.DietState = Diet["무리하지_않는다"];

		this.interface_Disease = null;
		this.interface_Delinquency = null;
		this.interface_Popularity = null;
		this.interface_DietState = null;
		this.interface_DiseasePos = new float4(-118, -80);
		this.interface_DelinquencyPos = new float4(-118, -57);
		this.interface_PopularityPos = new float4(-118, -34);
		this.interface_DietStatePos = new float4(-118, 58);

		this.DiseaseRender = null;
		this.DelinquencyRender = null;
		this.PopularityRender = null;
		this.DiseaseStateRender = null;
		this.DelinquentStateRender = null;
		this.DietStateRender = null;
		this.DiseaseRenderPos = new float4(2, -80);
		this.DelinquencyRenderPos = new float4(2, -57);
		this.PopularityRenderPos = new float4(2, -34);
		this.DiseaseStateRenderPos = new float4(-118, -11);
		this.DelinquentStateRenderPos = new float4(-118, 12);
		this.DietStateRenderPos = new float4(-78, 58);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale1 = new float4(160, 20);
		this.TextBoxScale2 = new float4(60, 20);
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.Scale);
		this.SetPos(this.ActorPos);

		this.interface_Disease = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Disease.SetText("질병 지수", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Disease.SetPosition(this.interface_DiseasePos);

		this.interface_Delinquency = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Delinquency.SetText("불량화 지수", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Delinquency.SetPosition(this.interface_DelinquencyPos);

		this.interface_Popularity = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Popularity.SetText("인맥", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Popularity.SetPosition(this.interface_PopularityPos);

		this.interface_DietState = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_DietState.SetText("건강", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_DietState.SetPosition(this.interface_DietStatePos);

		this.DiseaseRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DiseaseRender.SetText(String(Math.trunc(this.DiseaseIndex)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.DiseaseRender.SetPosition(this.DiseaseRenderPos);
		this.DelinquencyRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DelinquencyRender.SetText(String(Math.trunc(this.Delinquency)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.DelinquencyRender.SetPosition(this.DelinquencyRenderPos);
		this.PopularityRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.PopularityRender.SetText(String(Math.trunc(this.Popularity)), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.PopularityRender.SetPosition(this.PopularityRenderPos);
		this.DiseaseStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DiseaseState = Olive.OlivePlayer.IsDisease();
		switch (this.DiseaseState) {
			case false:
				this.DiseaseStateRender.SetText("건강합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case true:
				this.DiseaseStateRender.SetText("질병상태입니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
		}
		this.DiseaseStateRender.SetPosition(this.DiseaseStateRenderPos);
		this.DelinquentStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		switch (this.DelinquentState) {
			case false:
				this.DelinquentStateRender.SetText("솔직합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case true:
				this.DelinquentStateRender.SetText("불량합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
		}
		this.DelinquentStateRender.SetPosition(this.DelinquentStateRenderPos);

		this.DietStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		switch (this.DietState) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.DietStateRender.SetText("「무리하지 않는다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.DietStateRender.SetText("「어쨌든 튼튼하게」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["얌전한_아이로"]:
				this.DietStateRender.SetText("「얌전한 아이로」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["다이어트_시킨다"]:
				this.DietStateRender.SetText("「다이어트 시킨다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			default:
				break;
		}
		this.DietStateRender.SetPosition(this.DietStateRenderPos);

		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdateHelthInformationWindow();
	}

	UpdateHelthInformationWindow() {
		if (this.DiseaseIndex !== Olive.OlivePlayer.GetDiseaseIndex()) {
			this.DiseaseIndex = Olive.OlivePlayer.GetDiseaseIndex();
			this.DiseaseRender.SetText(String(Math.trunc(this.DiseaseIndex)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.Delinquency !== Olive.OlivePlayer.GetDelinquency()) {
			this.Delinquency = Olive.OlivePlayer.GetDelinquency();
			this.DelinquencyRender.SetText(String(Math.trunc(this.Delinquency)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.Popularity !== Olive.OlivePlayer.GetPopularity()) {
			this.Popularity = Olive.OlivePlayer.GetPopularity();
			this.PopularityRender.SetText(String(Math.trunc(this.Popularity)), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.DiseaseState !== Olive.OlivePlayer.IsDisease()) {
			this.DiseaseState = Olive.OlivePlayer.IsDisease();
			switch (this.DiseaseState) {
				case false:
					this.DiseaseStateRender.SetText("건강합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case true:
					this.DiseaseStateRender.SetText("질병상태입니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
			}
		}

		if (this.DelinquentState !== Olive.OlivePlayer.IsDelinquent()) {
			this.DelinquentState = Olive.OlivePlayer.IsDelinquent();
			switch (this.DelinquentState) {
				case false:
					this.DelinquentStateRender.SetText("솔직합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case true:
					this.DelinquentStateRender.SetText("불량합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
			}
		}

		if (this.DietState !== Olive.OlivePlayer.GetOliveDiet()) {
			this.DietState = Olive.OlivePlayer.GetOliveDiet();
			switch (this.DietState) {
				case Diet.Null:
					break;
				case Diet["무리하지_않는다"]:
					this.DietStateRender.SetText("「무리하지 않는다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["어쨌든_튼튼하게"]:
					this.DietStateRender.SetText("「어쨌든 튼튼하게」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["얌전한_아이로"]:
					this.DietStateRender.SetText("「얌전한 아이로」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["다이어트_시킨다"]:
					this.DietStateRender.SetText("「다이어트 시킨다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				default:
					break;
			}
		}

	}
}
