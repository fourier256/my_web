// ScheduleMessageBox.h / ScheduleMessageBox.cpp 의 전사
import { MenuFrame, MenuFrameStyleEnum } from "./MenuFrame.js";
import { Olive } from "./Olive.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { PM2RenderOrder, ScheduleLabel } from "./ContentsEnums.js";

export class ScheduleMessageBox extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(310, 180);
		this.ActorPos = new float4(619, 380);
		this.TextRender = null;
		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(290, 160);
		this.TextRenderPos = new float4(-145, -80);
		this.StartStatus = new Olive.Status();
		this.EndStatus = new Olive.Status();
		this.Schedule = " ";
		this.DayCount = 0;
	}

	SetScheduleString(_ScheduleLabel) {
		switch (_ScheduleLabel) {
			case ScheduleLabel.Null:
				break;
			case ScheduleLabel["자연과학"]:
				this.Schedule = "자연과학";
				break;
			case ScheduleLabel["신학"]:
				this.Schedule = "신학";
				break;
			case ScheduleLabel["군사학"]:
				this.Schedule = "군사학";
				break;
			case ScheduleLabel["검술"]:
				this.Schedule = "검술";
				break;
			case ScheduleLabel["격투술"]:
				this.Schedule = "격투술";
				break;
			case ScheduleLabel["마법"]:
				this.Schedule = "마법";
				break;
			case ScheduleLabel["시문학"]:
				this.Schedule = "시문학";
				break;
			case ScheduleLabel["예법"]:
				this.Schedule = "예법";
				break;
			case ScheduleLabel["무용"]:
				this.Schedule = "무용";
				break;
			case ScheduleLabel["미술"]:
				this.Schedule = "미술";
				break;
			case ScheduleLabel["집안일"]:
				this.Schedule = "집안일";
				break;
			case ScheduleLabel["보모"]:
				this.Schedule = "보모";
				break;
			case ScheduleLabel["여관"]:
				this.Schedule = "여관";
				break;
			case ScheduleLabel["농장"]:
				this.Schedule = "농장";
				break;
			case ScheduleLabel["교회"]:
				this.Schedule = "교회";
				break;
			case ScheduleLabel["요리점"]:
				this.Schedule = "요리점";
				break;
			case ScheduleLabel["나무꾼"]:
				this.Schedule = "나무꾼";
				break;
			case ScheduleLabel["미용실"]:
				this.Schedule = "미용실";
				break;
			case ScheduleLabel["미장이"]:
				this.Schedule = "미장이";
				break;
			case ScheduleLabel["사냥꾼"]:
				this.Schedule = "사냥꾼";
				break;
			case ScheduleLabel["묘지기"]:
				this.Schedule = "묘지기";
				break;
			case ScheduleLabel["가정교사"]:
				this.Schedule = "가정교사";
				break;
			case ScheduleLabel["주점"]:
				this.Schedule = "주점";
				break;
			case ScheduleLabel["어둠의주점"]:
				this.Schedule = "어둠의주점";
				break;
			case ScheduleLabel["어둠의전당"]:
				this.Schedule = "어둠의전당";
				break;
			default:
				break;
		}
	}

	SetDayCount(_DayCount) {
		this.DayCount = _DayCount;
	}

	SetStartStatus(_StartStatus) {
		this.StartStatus = _StartStatus;
	}

	SetEndStatus(_EndStatus) {
		this.EndStatus = _EndStatus;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		// 원본: SetMenuFrameScale({ Scale }); — float4 복사 생성
		this.SetMenuFrameScale(this.Scale.copy());
		this.SetPos(this.ActorPos);
		this.TextRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.TextRender.SetPosition(this.TextRenderPos);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);

		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdateTextRender();
	}

	UpdateTextRender() {
		this.TextRender.SetText(this.Schedule + " " + String(this.DayCount) + "일째\n 서서히 성과가 나오고 있습니다.", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}

	UpdateScheduleEndText() {
		this.TextRender.SetText("스케줄이 끝났다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}
}
