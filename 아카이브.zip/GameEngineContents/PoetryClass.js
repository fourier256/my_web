// PoetryClass.h / PoetryClass.cpp 의 전사
import { ClassesAndJobs } from "./ClassesAndJobs.js";
import { PM2RenderOrder } from "./ContentsEnums.js";
import { Olive } from "./Olive.js"; // (동료 파일 — 아직 미작성. Olive.Status 임시객체용)
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class PoetryClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Poetry.bmp", "Animation_Background_Poetry.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 7, 8, 9, new float4(135, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-5, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 13, new float4(65, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 14, 15, new float4(-115, -1));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 0, .Refinement = 0, .Sensitivity = 1, .Stress = 0,.Art = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 0;
		StatusParaMin.Refinement = 0;
		StatusParaMin.Sensitivity = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 1, .Refinement = 1, .Sensitivity = 1,.Stress = 1, .Art = 2 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 1;
		StatusParaMax.Refinement = 1;
		StatusParaMax.Sensitivity = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 2;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}
