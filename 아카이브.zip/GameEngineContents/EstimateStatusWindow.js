// EstimateStatusWindow.h / EstimateStatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class EstimateStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 455);

		this.Fighter = 0;
		this.FighterRender = null;
		this.Magical = 0;
		this.MagicalRender = null;
		this.Social = 0;
		this.SocialRender = null;
		this.HouseWork = 0;
		this.HouseWorkRender = null;

		this.Max = 300;

		this.Style = GaugeFrameStyle.Estemate;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);

		this.FighterRender = this.InsertStatus("전사평가", this.Max, this.Style);
		this.MagicalRender = this.InsertStatus("마법평가", this.Max, this.Style);
		this.SocialRender = this.InsertStatus("사교평가", this.Max, this.Style);
		this.HouseWorkRender = this.InsertStatus("가사평가", this.Max, this.Style);

		this.SetPos(new float4(GameEngineWindow.GetScreenSize().x, GameEngineWindow.GetScreenSize().hy()).add(float4.Left.mul(this.GetMenuFrameScale().half())).add(new float4(-10, 0)).add(new float4(0, 20)));
	}

	Update(_DeltaTime) {
		if (this.Fighter !== Olive.OlivePlayer.GetStatue().Fighter) {
			this.Fighter = Olive.OlivePlayer.GetStatue().Fighter;
			this.FighterRender.UpdateValue(this.Fighter);
		}
		if (this.Magical !== Olive.OlivePlayer.GetStatue().Magical) {
			this.Magical = Olive.OlivePlayer.GetStatue().Magical;
			this.MagicalRender.UpdateValue(this.Magical);
		}
		if (this.Social !== Olive.OlivePlayer.GetStatue().Social) {
			this.Social = Olive.OlivePlayer.GetStatue().Social;
			this.SocialRender.UpdateValue(this.Social);
		}
		if (this.HouseWork !== Olive.OlivePlayer.GetStatue().HouseWork) {
			this.HouseWork = Olive.OlivePlayer.GetStatue().HouseWork;
			this.HouseWorkRender.UpdateValue(this.HouseWork);
		}
	}
}
