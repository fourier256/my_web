// BasicInfo.h / BasicInfo.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { NumberRenderObject, Align } from "../GameEngineCore/NumberRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder, PatronGod, BloodType, Diet, IconCode } from "./ContentsEnums.js";
import { RGB } from "../WinAPI.js";

export class BasicInfo extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(700, 109);

		this.BasicInfoFrame = null;

		this.OliveFirstName = "Null";
		this.FirstNameRender = null;
		this.FirstNameRenderPos = new float4(-90, -98);
		this.OliveLastName = "Null";
		this.LastNameRender = null;
		this.LastNameRenderPos = new float4(-90, -75);
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(180, 20);

		this.OlivePatronGod = PatronGod.Null;
		this.PatronGodIconRender = null;
		this.PatronGodIconPos = new float4(-30, -22);
		this.IconScale = new float4(39, 39);

		this.OliveBloodType = BloodType.Null;
		this.BloodTypeRender = null;
		this.BloodTypeRenderPos = new float4(-30, -22);
		this.BloodTypeRenderScale = new float4(39, 39);

		this.Age = 0;
		this.AgeRender = new NumberRenderObject();
		this.AgeRenderPos = new float4(-70, -20);
		this.AgeRenderScale = new float4(20, 20);

		this.Gold = 0;
		this.GoldRender = new NumberRenderObject();
		this.GoldRenderPos = new float4(65, -12);
		this.GoldRenderScale = new float4(10, 19);

		this.OliveDiet = Diet["무리하지_않는다"];
		this.OliveDietRender = null;
		this.DietRenderText = "";

		this.OliveDietRenderPos = new float4(-90, 56);

		this.Height = 0.0;
		this.HeightRender = new NumberRenderObject();
		this.HeightRenderPos = new float4(-75, 89);
		this.HeightRenderScale = new float4(10, 20);

		this.Weight = 0.0;
		this.WeightRender = new NumberRenderObject();
		this.WeightRenderPos = new float4(-35, 89);
		this.WeightRenderScale = new float4(10, 20);

		this.Bust = 0.0;
		this.BustRender = new NumberRenderObject();
		this.BustRenderPos = new float4(-5, 89);
		this.BustRenderScale = new float4(10, 20);

		this.Waist = 0.0;
		this.WaistRender = new NumberRenderObject();
		this.WaistRenderPos = new float4(37, 89);
		this.WaistRenderScale = new float4(10, 20);

		this.Hip = 0.0;
		this.HipRender = new NumberRenderObject();
		this.HipRenderPos = new float4(79, 89);
		this.HipRenderScale = new float4(10, 20);

		this.DiseaseState = false;
		this.DiseaseIcon = null;
		this.DiseaseIconPos = new float4(0, 27);

		this.DelinquentState = false;
		this.DelinquentIcon = null;
		this.DelinquentIconPos = new float4(40, 27);
	}

	// 원본: h에서 inline으로 정의된 private 멤버 함수
	SetDietRenderText() {
		switch (this.OliveDiet) {
			case Diet["무리하지_않는다"]:
				this.DietRenderText = "무리하지 않는다";
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.DietRenderText = "어쨌든 튼튼하게";
				break;
			case Diet["얌전한_아이로"]:
				this.DietRenderText = "얌전한 아이로";
				break;
			case Diet["다이어트_시킨다"]:
				this.DietRenderText = "다이어트 시킨다";
				break;
			default:
				break;
		}
	}

	Start() {
		this.SetPos(this.ActorPos);

		this.BasicInfoFrame = this.CreateRender("BasicInfo.bmp", PM2RenderOrder.Menu0);
		this.BasicInfoFrame.SetScaleToImage();

		this.FirstNameRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.FirstNameRender.SetText(this.OliveFirstName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.FirstNameRender.SetPosition(this.FirstNameRenderPos);

		this.LastNameRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LastNameRender.SetText(this.OliveLastName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.LastNameRender.SetPosition(this.LastNameRenderPos);

		this.OliveDietRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.SetDietRenderText();
		this.OliveDietRender.SetText(this.DietRenderText, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.OliveDietRender.SetPosition(this.OliveDietRenderPos);

		this.AgeRender.SetOwner(this);
		this.AgeRender.SetImage("Num_Age.bmp", this.AgeRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.AgeRender.SetAlign(Align.Center);
		this.AgeRender.SetValue(this.Age);
		this.AgeRender.SetRenderPos(this.AgeRenderPos);

		this.GoldRender.SetOwner(this);
		this.GoldRender.SetImage("Num.bmp", this.GoldRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.GoldRender.SetAlign(Align.Right);
		this.GoldRender.SetValue(this.Gold);
		this.GoldRender.SetRenderPos(this.GoldRenderPos);

		this.HeightRender.SetOwner(this);
		this.HeightRender.SetImage("Num.bmp", this.HeightRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.HeightRender.SetAlign(Align.Center);
		this.HeightRender.SetValue(Math.trunc(this.Height));
		this.HeightRender.SetRenderPos(this.HeightRenderPos);

		this.WeightRender.SetOwner(this);
		this.WeightRender.SetImage("Num.bmp", this.WeightRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.WeightRender.SetAlign(Align.Center);
		this.WeightRender.SetValue(Math.trunc(this.Weight));
		this.WeightRender.SetRenderPos(this.WeightRenderPos);

		this.BustRender.SetOwner(this);
		this.BustRender.SetImage("Num.bmp", this.BustRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.BustRender.SetAlign(Align.Center);
		this.BustRender.SetValue(Math.trunc(this.Bust));
		this.BustRender.SetRenderPos(this.BustRenderPos);

		this.WaistRender.SetOwner(this);
		this.WaistRender.SetImage("Num.bmp", this.WaistRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.WaistRender.SetAlign(Align.Center);
		this.WaistRender.SetValue(Math.trunc(this.Waist));
		this.WaistRender.SetRenderPos(this.WaistRenderPos);

		this.HipRender.SetOwner(this);
		this.HipRender.SetImage("Num.bmp", this.HipRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.HipRender.SetAlign(Align.Center);
		this.HipRender.SetValue(Math.trunc(this.Hip));
		this.HipRender.SetRenderPos(this.HipRenderPos);

		this.PatronGodIconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.PatronGodIconRender.SetScale(this.IconScale);
		this.PatronGodIconRender.SetPosition(this.PatronGodIconPos);

		this.BloodTypeRender = this.CreateRender("BloodTypeRender.bmp", PM2RenderOrder.Menu0_Display);
		this.BloodTypeRender.SetScale(this.BloodTypeRenderScale);
		this.BloodTypeRender.SetPosition(this.BloodTypeRenderPos);

		this.DiseaseIcon = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.DiseaseIcon.SetScale(this.IconScale);
		this.DiseaseIcon.SetPosition(this.DiseaseIconPos);
		this.DiseaseIcon.SetFrame(Math.trunc(IconCode["질병상태"]));
		this.DiseaseIcon.Off();

		this.DelinquentIcon = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.DelinquentIcon.SetScale(this.IconScale);
		this.DelinquentIcon.SetPosition(this.DelinquentIconPos);
		this.DelinquentIcon.SetFrame(Math.trunc(IconCode["불량상태"]));
		this.DelinquentIcon.Off();
	}

	Update(_DeltaTime) {
		if (this.OliveFirstName !== Olive.OlivePlayer.GetOliveFirstName()) {
			this.OliveFirstName = Olive.OlivePlayer.GetOliveFirstName();
			this.FirstNameRender.SetText(this.OliveFirstName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.OliveLastName !== Olive.OlivePlayer.GetOliveLastName()) {
			this.OliveLastName = Olive.OlivePlayer.GetOliveLastName();
			this.LastNameRender.SetText(this.OliveLastName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.OliveDiet !== Olive.OlivePlayer.GetOliveDiet()) {
			this.OliveDiet = Olive.OlivePlayer.GetOliveDiet();
			this.SetDietRenderText();
			this.OliveDietRender.SetText(this.DietRenderText, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.Age !== Olive.OlivePlayer.GetOliveAge()) {
			this.Age = Olive.OlivePlayer.GetOliveAge();
			this.AgeRender.SetValue(this.Age);
		}

		if (this.OlivePatronGod !== Olive.OlivePlayer.GetPatronGod()) {
			this.OlivePatronGod = Olive.OlivePlayer.GetPatronGod();
			this.PatronGodIconRender.SetFrame(Math.trunc(this.OlivePatronGod));
		}

		if (this.OliveBloodType !== Olive.OlivePlayer.GetBloodType()) {
			this.OliveBloodType = Olive.OlivePlayer.GetBloodType();
			this.BloodTypeRender.SetFrame(Math.trunc(this.OliveBloodType));
		}

		if (this.Gold !== Olive.OlivePlayer.GetGold()) {
			this.Gold = Olive.OlivePlayer.GetGold();
			this.GoldRender.SetValue(this.Gold);
		}

		if (this.Height !== Olive.OlivePlayer.GetHeight()) {
			this.Height = Olive.OlivePlayer.GetHeight();
			this.HeightRender.SetValue(Math.trunc(this.Height));
		}

		if (this.Weight !== Olive.OlivePlayer.GetWeight()) {
			this.Weight = Olive.OlivePlayer.GetWeight();
			this.WeightRender.SetValue(Math.trunc(this.Weight));
		}

		if (this.Bust !== Olive.OlivePlayer.GetBust()) {
			this.Bust = Olive.OlivePlayer.GetBust();
			this.BustRender.SetValue(Math.trunc(this.Bust));
		}

		if (this.Waist !== Olive.OlivePlayer.GetWaist()) {
			this.Waist = Olive.OlivePlayer.GetWaist();
			this.WaistRender.SetValue(Math.trunc(this.Waist));
		}

		if (this.Hip !== Olive.OlivePlayer.GetHip()) {
			this.Hip = Olive.OlivePlayer.GetHip();
			this.HipRender.SetValue(Math.trunc(this.Hip));
		}

		if (this.DiseaseState !== Olive.OlivePlayer.IsDisease()) {
			this.DiseaseState = Olive.OlivePlayer.IsDisease();
			switch (this.DiseaseState) {
				case true:
					this.DiseaseIcon.On();
					break;
				case false:
					this.DiseaseIcon.Off();
					break;
			}
		}

		if (this.DelinquentState !== Olive.OlivePlayer.IsDelinquent()) {
			this.DelinquentState = Olive.OlivePlayer.IsDelinquent();
			switch (this.DelinquentState) {
				case true:
					this.DelinquentIcon.On();
					break;
				case false:
					this.DelinquentIcon.Off();
					break;
			}
		}
	}

	Render(_Time) {
	}
}
