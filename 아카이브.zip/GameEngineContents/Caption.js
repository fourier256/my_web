// Caption.h / Caption.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { GameEngineRender, TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class Caption extends GameEngineActor {
	constructor() {
		super();
		this.UpdateCaption = "";
		this.CaptionRender = null;
		this.CaptionOutline1Render = null;
		this.CaptionOutline2Render = null;
		this.CaptionOutline3Render = null;
		this.CaptionOutline4Render = null;

		this.CaptionPos = new float4(400, 500);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextOutlineColor = RGB(0, 0, 0);
		this.CaptionTextBoxScale = new float4(800, 100);
	}

	SetUpdateText(_Text) {
		this.UpdateCaption = _Text;
		this.CaptionRender.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.CaptionTextBoxScale);
		this.CaptionOutline1Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline2Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline3Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline4Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionRender.SetPosition(this.CaptionTextBoxScale.half().neg());
		this.CaptionOutline1Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Up.mul(new float4(1, 1))));
		this.CaptionOutline2Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Down.mul(new float4(1, 1))));
		this.CaptionOutline3Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Left.mul(new float4(1, 1))));
		this.CaptionOutline4Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Right.mul(new float4(1, 1))));
	}

	Start() {
		this.SetPos(this.CaptionPos);
		this.CaptionRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CaptionOutline1Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline4Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.Off();
	}

	Render(_DeltaTime) {
	}
}
