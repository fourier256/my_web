// DietFinalConfirmSelectionMenu.h / DietFinalConfirmSelectionMenu.cpp 의 전사
import { SelectionMenu } from "./SelectionMenu.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";
import { CubeDialog, CubeFace } from "./CubeDialog.js";
import { SelectDialog } from "./SelectDialog.js";
import { MainMenu } from "./MainMenu.js";
import { Olive } from "./Olive.js";
import { Diet, PM2ActorOrder, PM2RenderOrder } from "./ContentsEnums.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

export class DietFinalConfirmSelectionMenu extends SelectionMenu {
	static DietState = Diet.Null;
	static AcCubeDialog = null;
	static AcDietFinalConfirmSelectionMenu = null;

	constructor() {
		super();
		this.ActorPos = new float4(685, 320);
		this.Xscale = 140;

		this.AcSelectDialog = null;

		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu = this;
	}

	On() {
		// 원본: SelectionMenu::On();
		super.On();
		this.AcSelectDialog.On();
	}

	Off() {
		// 원본: SelectionMenu::Off();
		super.Off();
		this.AcSelectDialog.Off();
	}

	SetDietState(_State) {
		DietFinalConfirmSelectionMenu.DietState = _State;
	}

	Start() {
		this.AcSelectDialog = this.GetLevel().CreateActor(SelectDialog, PM2ActorOrder.Menu2);
		this.AcSelectDialog.SetUpdateText(" ");
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())->GetAcCubeDialog()
		DietFinalConfirmSelectionMenu.AcCubeDialog = this.GetLevel().GetAcCubeDialog();

		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "이 방침으로");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "지금까지대로");
		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		switch (DietFinalConfirmSelectionMenu.DietState) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.AcSelectDialog.SetUpdateText("무리하지 않는다");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n30G 들어갑니다. 무리 없는 식\n생활을 보낼 수 있습니다」");
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.AcSelectDialog.SetUpdateText("어쨌든 튼튼하게");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n80G 들어갑니다. 체력이 올라가\n겠죠」");
				break;
			case Diet["얌전한_아이로"]:
				this.AcSelectDialog.SetUpdateText("얌전한 아이로");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n10G 들어갑니다. 약간 건강에 부\n담이 갈지도 모릅니다」");
				break;
			case Diet["다이어트_시킨다"]:
				this.AcSelectDialog.SetUpdateText("다이어트 시킨다");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n5G 밖에 들지 않습니다. 아가씨의\n몸무게를 줄이고 싶다면, 이 방\n침으로 가시죠. 단, 체력을 상\n당히 소모하므로 주의하시기 바\n랍니다」");
				break;
			default:
				break;
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(DietFinalConfirmSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(DietFinalConfirmSelectionMenu.Click1);
	}

	static Click0(_Button) {
		Olive.OlivePlayer.SetOliveDiet(DietFinalConfirmSelectionMenu.DietState);
		DietFinalConfirmSelectionMenu.DietState = Diet.Null;
		DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Proud, "예, 알겠습니다. 다음달부터 그\n렇게 하겠습니다");
		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu.Off();
	}

	static Click1(_Button) {
		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu.Off();
		DietFinalConfirmSelectionMenu.AcCubeDialog.Off();
		MainMenu.GetAcMainMenu().On();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(DietFinalConfirmSelectionMenu.prototype, __m, { value: function (...args) { return DietFinalConfirmSelectionMenu[__m](...args); }, writable: true, configurable: true });
}

