// PM2Core.h / PM2Core.cpp 의 전사
import { GameEngineCore } from "../GameEngineCore/GameEngineCore.js";
import { TitleLevel } from "./TitleLevel.js";
import { FirstSetLevel } from "./FirstSetLevel.js";
import { OpeningLevel } from "./OpeningLevel.js";
import { RaisingSimLevel } from "./RaisingSimLevel.js";
import { RPGLevel } from "./RPGLevel.js";
import { EndingLevel } from "./EndingLevel.js";

export class PM2Core extends GameEngineCore {
	static Core = new PM2Core();

	static GetInst() {
		return this.Core;
	}

	constructor() {
		super();
	}

	Start() {
		this.CreateLevel("Title", TitleLevel);
		this.CreateLevel("FirstSet", FirstSetLevel);
		this.CreateLevel("Opening", OpeningLevel);
		this.CreateLevel("RaisingSim", RaisingSimLevel);
		this.CreateLevel("RPG", RPGLevel);
		this.CreateLevel("Ending", EndingLevel);

		this.ChangeLevel("Title");
	}

	Update() {
	}

	End() {
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetInst']) {
	Object.defineProperty(PM2Core.prototype, __m, { value: function (...args) { return PM2Core[__m](...args); }, writable: true, configurable: true });
}

