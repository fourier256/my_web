// BasicStatusWindow.h / BasicStatusWindow.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { StatusWindow } from "./StatusWindow.js";
import { GaugeFrameStyle } from "./GaugeRenderObject.js";
import { Olive } from "./Olive.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class BasicStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 260);

		this.Constitution = 0;
		this.ConstitutionRender = null;

		this.Strength = 0;
		this.StrengthRender = null;

		this.Intelligence = 0;
		this.IntelligenceRender = null;

		this.Refinement = 0;
		this.RefinementRender = null;

		this.Charisma = 0;
		this.CharismaRender = null;

		this.Morality = 0;
		this.MoralityRender = null;

		this.Faith = 0;
		this.FaithRender = null;

		this.Sin = 0;
		this.SinRender = null;

		this.Sensitivity = 0;
		this.SensitivityRender = null;

		this.Stress = 0;
		this.StressRender = null;

		this.Max = 999;

		this.Style = GaugeFrameStyle.Nomal;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.ConstitutionRender = this.InsertStatus("체력", this.Max, this.Style);
		this.StrengthRender = this.InsertStatus("근력", this.Max, this.Style);
		this.IntelligenceRender = this.InsertStatus("지능", this.Max, this.Style);
		this.RefinementRender = this.InsertStatus("기품", this.Max, this.Style);
		this.CharismaRender = this.InsertStatus("색기", this.Max, this.Style);
		this.MoralityRender = this.InsertStatus("도덕성", this.Max, this.Style);
		this.FaithRender = this.InsertStatus("신앙", this.Max, this.Style);
		this.SinRender = this.InsertStatus("업보", this.Max, this.Style);
		this.SensitivityRender = this.InsertStatus("감수성", this.Max, this.Style);
		this.StressRender = this.InsertStatus("스트레스", this.Max, this.Style);
		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.Constitution !== Olive.OlivePlayer.GetStatue().Constitution) {
			this.Constitution = Olive.OlivePlayer.GetStatue().Constitution;
			this.ConstitutionRender.UpdateValue(this.Constitution);
		}

		if (this.Strength !== Olive.OlivePlayer.GetStatue().Strength) {
			this.Strength = Olive.OlivePlayer.GetStatue().Strength;
			this.StrengthRender.UpdateValue(this.Strength);
		}

		if (this.Intelligence !== Olive.OlivePlayer.GetStatue().Intelligence) {
			this.Intelligence = Olive.OlivePlayer.GetStatue().Intelligence;
			this.IntelligenceRender.UpdateValue(this.Intelligence);
		}

		if (this.Refinement !== Olive.OlivePlayer.GetStatue().Refinement) {
			this.Refinement = Olive.OlivePlayer.GetStatue().Refinement;
			this.RefinementRender.UpdateValue(this.Refinement);
		}

		if (this.Charisma !== Olive.OlivePlayer.GetStatue().Charisma) {
			this.Charisma = Olive.OlivePlayer.GetStatue().Charisma;
			this.CharismaRender.UpdateValue(this.Charisma);
		}

		if (this.Morality !== Olive.OlivePlayer.GetStatue().Morality) {
			this.Morality = Olive.OlivePlayer.GetStatue().Morality;
			this.MoralityRender.UpdateValue(this.Morality);
		}

		if (this.Faith !== Olive.OlivePlayer.GetStatue().Faith) {
			this.Faith = Olive.OlivePlayer.GetStatue().Faith;
			this.FaithRender.UpdateValue(this.Faith);
		}

		if (this.Sin !== Olive.OlivePlayer.GetStatue().Sin) {
			this.Sin = Olive.OlivePlayer.GetStatue().Sin;
			this.SinRender.UpdateValue(this.Sin);
		}

		if (this.Sensitivity !== Olive.OlivePlayer.GetStatue().Sensitivity) {
			this.Sensitivity = Olive.OlivePlayer.GetStatue().Sensitivity;
			this.SensitivityRender.UpdateValue(this.Sensitivity);
		}

		if (this.Stress !== Olive.OlivePlayer.GetStatue().Stress) {
			this.Stress = Olive.OlivePlayer.GetStatue().Stress;
			this.StressRender.UpdateValue(this.Stress);
		}

	}
}
