// RPGLevel.h / RPGLevel.cpp 의 전사
import { GameEngineLevel } from "../GameEngineCore/GameEngineLevel.js";
import { GameEngineDirectory } from "../GameEngineBase/GameEngineDirectory.js";
import { GameEngineResources } from "../GameEngineCore/GameEngineResources.js";
import { MousePoint } from "./MousePoint.js";
import { RPGOlive } from "./RPGOlive.js";
import { PM2ActorOrder } from "./ContentsEnums.js";

export class RPGLevel extends GameEngineLevel {
	constructor() {
		super();
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();
	}

	Update(_DeltaTime) {
	}

	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	SoundLoad() {
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();
		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("RPGLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Olive.BMP")).Cut(8, 1);

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.CreateActor(RPGOlive);
	}
}
