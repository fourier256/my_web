import { float4 } from "../GameEngineBase/GameEngineMath.js";
// Flower.h / Flower.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { PM2RenderOrder, Season } from "./ContentsEnums.js"; // Season: ContentsEnums.h 라인 474의 enum class Season — ContentsEnums.js에 아직 미추가(동료 파일)

export class Flower extends GameEngineActor {
	constructor() {
		super();
		this.SpringFlower = null;
		this.SummerFlower = null;
		this.FallFlower = null;
		this.WinterFlower = null;
		this.DiseaseFlower = null;

		// Season TodaySeason = Season::Null;
		this.TodaySeason = Season.Null;
		// RaisingSimLevel* ParentLevel = nullptr;
		this.ParentLevel = null;
	}

	UpdateFlower() {

	}

	Start() {
		this.SetPos(new float4(85, 285));
		this.SpringFlower = this.CreateRender("flower_spring.bmp", PM2RenderOrder.BackGroundObj);
		this.SpringFlower.SetScaleToImage();
		this.SpringFlower.Off();
		this.SummerFlower = this.CreateRender("flower_summer.bmp", PM2RenderOrder.BackGroundObj);
		this.SummerFlower.SetScaleToImage();
		this.SummerFlower.Off();
		this.FallFlower = this.CreateRender("flower_fall.bmp", PM2RenderOrder.BackGroundObj);
		this.FallFlower.SetScaleToImage();
		this.FallFlower.Off();
		this.WinterFlower = this.CreateRender("flower_winter.bmp", PM2RenderOrder.BackGroundObj);
		this.WinterFlower.SetScaleToImage();
		this.WinterFlower.Off();
		this.DiseaseFlower = this.CreateRender("flower_disease.bmp", PM2RenderOrder.BackGroundObj);
		this.DiseaseFlower.SetScaleToImage();
		this.DiseaseFlower.Off();

		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();

	}

	Update(_DeltaTime) {
		if (this.TodaySeason !== this.ParentLevel.GetTodaySeason()) {
			this.TodaySeason = this.ParentLevel.GetTodaySeason();
			switch (this.TodaySeason) {
				case Season.Spring:
					this.SpringFlower.On();
					this.SummerFlower.Off();
					this.FallFlower.Off();
					this.WinterFlower.Off();
					break;
				case Season.Summer:
					this.SpringFlower.Off();
					this.SummerFlower.On();
					this.FallFlower.Off();
					this.WinterFlower.Off();
					break;
				case Season.Fall:
					this.SpringFlower.Off();
					this.SummerFlower.Off();
					this.FallFlower.On();
					this.WinterFlower.Off();
					break;
				case Season.Winter:
					this.SpringFlower.Off();
					this.SummerFlower.Off();
					this.FallFlower.Off();
					this.WinterFlower.On();
					break;
				default:
					break;
			}
		}
	}

	Render(_Time) {
	}
}
