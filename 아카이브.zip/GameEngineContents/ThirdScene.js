// ThirdScene.h / ThirdScene.cpp 의 전사
import { GameEngineActor } from "../GameEngineCore/GameEngineActor.js";
import { TextAlign } from "../GameEngineCore/GameEngineRender.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { RGB } from "../WinAPI.js";
import { PM2RenderOrder } from "./ContentsEnums.js";

export class ThirdScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.BackgroundRedner = null;

		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-300, -200);

		this.TextRenderShadow = null;
		this.TextShadowColor = RGB(0, 0, 0);
		this.TextShadowRenderPos = new float4(-300, -199);

		this.Script = "아무튼, 저도 어른이 되었어요.\n\n지금까지 무엇을 하든 아버지에게 기대기만 했지만,\n\n오늘부터는 저 자신의 힘으로 살아가겠어요.\n\n지금까지의 경험을 살려서 열심히 할 테니,\n\n따뜻하게 지켜봐 주세요.";
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("ThirdSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);

		this.TextRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.TextRenderShadow.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
		this.TextRenderShadow.SetPosition(this.TextShadowRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRenderShadow.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
	}
}
