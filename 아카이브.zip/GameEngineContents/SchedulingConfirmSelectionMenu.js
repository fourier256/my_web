// SchedulingConfirmSelectionMenu.h / SchedulingConfirmSelectionMenu.cpp 의 전사
import { SelectionMenu } from "./SelectionMenu.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { CubeFace } from "./CubeDialog.js";
import { RaisingSimLevel } from "./RaisingSimLevel.js";
import { ScheduleSelectionMenu } from "./ScheduleSelectionMenu.js";
import { ScheduleCalendar } from "./ScheduleCalendar.js";
import { ScheduleFinalConfirm } from "./ScheduleFinalConfirm.js";
import { PM2RenderOrder, PM2ActorOrder, ScheduleLabel } from "./ContentsEnums.js";
import { MenuFrameStyleEnum } from "./MenuFrame.js";

export class SchedulingConfirmSelectionMenu extends SelectionMenu {
	static AcCubeDialog = null;
	static ScheduleState = ScheduleLabel.Null;
	static AcScheduleSelectionMenu = null;
	static AcSchedulingConfirmSelectionMenu = null;
	static AcScheduleCalendars = null;
	static AcScheduleFinalConfirm = null;

	constructor() {
		super();
		// construtor destructor
		SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu = this;
		this.ActorPos = new float4(695, 371);
		this.Xscale = 190;
	}

	SetScheduleState(_State) {
		SchedulingConfirmSelectionMenu.ScheduleState = _State;
	}

	Start() {
		SchedulingConfirmSelectionMenu.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu = ScheduleSelectionMenu.GetAcScheduleSelectionMenu();
		SchedulingConfirmSelectionMenu.AcScheduleCalendars = ScheduleCalendar.GetAcScheduleCalendar();
		SchedulingConfirmSelectionMenu.AcScheduleFinalConfirm = this.GetLevel().CreateActor(ScheduleFinalConfirm, PM2ActorOrder.Menu2);
		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "스케줄에 편성한다");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "취소");

		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		switch (SchedulingConfirmSelectionMenu.ScheduleState) {
			case ScheduleLabel["자연과학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "자연과학.\n미신을 부정하고, 과학적, 합리\n적인 안목을 키운다");
				break;
			case ScheduleLabel["신학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "신학.\n신앙을 기초로 과학관의 수양.\n학문의 왕도");
				break;
			case ScheduleLabel["군사학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "군사학.\n전투의 기술을 학문으로서 배운\n다");
				break;
			case ScheduleLabel["검술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "검술.\n도장을 통해서 검술을 배운다");
				break;
			case ScheduleLabel["격투술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "격투술.\n무기를 의존하지 않고, 격투술\n을 중심으로 하는 전투법을 배\n운다");
				break;
			case ScheduleLabel["마법"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "마법.\n마법의 기초부터, 강력한 주문\n까지 습득");
				break;
			case ScheduleLabel["시문학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "시문학.\n시를 낭독하거나 창작. 시문을\n배우는 것은, 교양인의 지식의\n상징");
				break;
			case ScheduleLabel["예법"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "예법.\n숙녀의 교양부터, 오랜 세월에\n걸쳐 내려온 궁중 예법까지 전수");
				break;
			case ScheduleLabel["무용"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "무용.\n본격적인 궁중 무용을 전수");
				break;
			case ScheduleLabel["미술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "미술.\n그림을 그려 예술적인 센스를\n갈고 닦는다");
				break;
			default:
				break;
		}

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(SchedulingConfirmSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(SchedulingConfirmSelectionMenu.Click1);
	}

	static Click0(_Button) {
		SchedulingConfirmSelectionMenu.AcScheduleCalendars.ScheduleSetting(SchedulingConfirmSelectionMenu.ScheduleState);
		if (!SchedulingConfirmSelectionMenu.AcScheduleCalendars.ScheduleSetEnd) {
			SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
			SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
		}
		else {
			SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
			SchedulingConfirmSelectionMenu.AcScheduleFinalConfirm.On();
		}
	}

	static Click1(_Button) {
		SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
		SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(SchedulingConfirmSelectionMenu.prototype, __m, { value: function (...args) { return SchedulingConfirmSelectionMenu[__m](...args); }, writable: true, configurable: true });
}

