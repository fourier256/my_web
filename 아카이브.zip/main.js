// main.cpp 의 전사
// int APIENTRY wWinMain(...) { PM2Core::GetInst().CoreStart(hInstance); return 0; }
import { PM2Core } from "./GameEngineContents/PM2Core.js";

export function wWinMain() {
	PM2Core.GetInst().CoreStart(null);
	return 0;
}
