# WinAPI_HSM_PrincessMaker2 — JavaScript 전사판

원본: https://github.com/iqmin11/WinAPI_HSM (WinAPI/GDI + FMOD, C++로 작성된 PrincessMaker2 클론)

이 저장소는 원본 C++ 소스를 **문자 그대로** 순수 JavaScript(ES Module, 빌드 도구 없음)로 전사한 웹 버전이다.
Vite/React 등의 프레임워크를 사용하지 않는다.

## 실행 방법

```bash
cd web   # 이 폴더 (index.html이 있는 곳)
python3 -m http.server 8000
# 브라우저에서 http://localhost:8000 접속
```

별도의 설치/빌드 과정은 없다. 정적 서버만 있으면 된다.

## 구조 (원본 C++ 프로젝트와 1:1 대응)

| 원본 (C++) | 전사 (JS) |
|---|---|
| `GameEngineBase/` (Math, Debug, String, Time, Random, Path, Directory, File) | `GameEngineBase/*.js` |
| `GameEnginePlatform/` (Window, Image, Input, Sound) | `GameEnginePlatform/*.js` |
| `GameEngineCore/` (Object, Component, Actor, Render, Collision, Level, Core, Resources, Button, NumberRenderObject, TileMap) | `GameEngineCore/*.js` |
| `GameEngineContents/` (PM2Core + 레벨/액터 86개 클래스) | `GameEngineContents/*.js` |
| `WinAPI_HSM_PrincessMaker2/main.cpp` (wWinMain) | `main.js` (`wWinMain()`) |
| `ContentsResources/Image/*.bmp` | `ContentsResources/Image/*.png` (무손실 변환 — 브라우저가 BMP의 컬러키 투명 픽셀을 동일하게 처리하도록 픽셀 데이터는 동일) |
| `ContentsResources/Sound/*.mp3, *.wav` | 동일 (복사) |
| FMOD (`GameEngineSound`) | HTMLAudioElement 기반 `GameEngineSound.js` (재생/루프/볼륨/정지 의미 동일) |
| WinAPI 가상키(VK_*), RGB 매크로 | `WinAPI.js` |

## 전사 시 플랫폼 차이로 바뀐 점 (로직은 동일)

1. **BMP → PNG**: 파일 형식만 변환(무손실). 코드의 이미지 경로는 원본 그대로이며 엔진(`GameEngineImage.ResolveResourceUrl`)이 자동 매핑한다.
2. **동기 파일 I/O → 매니페스트 프리로드**: 브라우저는 디렉터리를 읽을 수 없으므로, 빌드 시 만든 `resources_manifest.js`로 존재 판정(`GameEnginePath.IsExists`)과 프리로드를 대신한다. 게임은 모든 리소스가 로드된 뒤 시작된다(원본은 exe 시작 즉시 시작).
3. **MessageBoxA(MsgAssert)**: 브라우저에서는 화면 상단 오버레이 + 콘솔 오류로 표시되며, 원본 Release 빌드처럼 확인 후 계속 진행된다(치명적이지 않음).
4. **FMOD → HTMLAudio**: `SoundLoad`는 `FMOD_LOOP_NORMAL`로 로드되므로 기본 반복 재생, `SoundPlay`가 채널에 `setLoopCount(0)`을 호출해 한 번만 재생되는 원본 의미를 그대로 유지. 브라우저 정책상 **첫 클릭 전에는 소리가 나지 않을 수 있다**(화면을 한 번 클릭하면 해제).
5. **키 입력**: `GetAsyncKeyState` 대신 DOM 이벤트로 물리 키 상태를 관리하며 `GameEngineKey::Update` 상태 머신(Down/Press/Up/Free)은 원본 그대로. 원본의 `IsAnyKeyOff()` 버그(`IsAnyKeyValue = true`)도 그대로 보존했다.
6. **렌더링**: GDI BitBlt/TransparentBlt/AlphaBlend/DrawText를 Canvas2D로 동일 의미 구현. 색상키 투명(기본 RGB(255,0,255))은 픽셀 매칭으로 처리. 내부 해상도 800x600, 화면 맞춤 확대(픽셀레이트).

## 게임 조작

- 마우스: 클릭으로 버튼 조작 (엔진 키 `EngineMouseLeft`)
- `P`: Title → FirstSet 레벨 이동 (원본 디버그용 키 그대로)
- `1`: 디버그 렌더 전환 (`DebugSwitch`)

## 라이선스 / 저작권

원본 코드와 리소스의 저작권은 원 저장소(https://github.com/iqmin11/WinAPI_HSM ) 작성자에게 있다.
이 전사본은 동일한 소스 코드를 다른 런타임(JS/브라우저)으로 옮긴 것임을 명시한다.
