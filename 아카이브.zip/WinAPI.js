// WinAPI.h 등 Windows 환경 상수의 전사 (브라우저용 호환 계층)
// 원본 C++가 WinAPI 상수(VK_* / RGB 매크로 / COLORREF)를 사용하는 곳의 대응 값.

export const VK = Object.freeze({
	LBUTTON: 0x01,
	RBUTTON: 0x02,
	CANCEL: 0x03,
	MBUTTON: 0x04,
	BACK: 0x08,
	TAB: 0x09,
	RETURN: 0x0D,
	SHIFT: 0x10,
	CONTROL: 0x11,
	MENU: 0x12,
	PAUSE: 0x13,
	CAPITAL: 0x14,
	ESCAPE: 0x1B,
	SPACE: 0x20,
	PRIOR: 0x21,
	NEXT: 0x22,
	END: 0x23,
	HOME: 0x24,
	LEFT: 0x25,
	UP: 0x26,
	RIGHT: 0x27,
	DOWN: 0x28,
	INSERT: 0x2D,
	DELETE: 0x2E,
	LWIN: 0x5B,
	RWIN: 0x5C,
	NUMPAD0: 0x60,
	NUMPAD1: 0x61,
	NUMPAD2: 0x62,
	NUMPAD3: 0x63,
	NUMPAD4: 0x64,
	NUMPAD5: 0x65,
	NUMPAD6: 0x66,
	NUMPAD7: 0x67,
	NUMPAD8: 0x68,
	NUMPAD9: 0x69,
	F1: 0x70,
	F2: 0x71,
	F3: 0x72,
	F4: 0x73,
	F5: 0x74,
	F6: 0x75,
	F7: 0x76,
	F8: 0x77,
	F9: 0x78,
	F10: 0x79,
	F11: 0x7A,
	F12: 0x7B,
});

// RGB 매크로: COLORREF = 0x00BBGGRR
export function RGB(r, g, b) {
	return (r & 0xff) | ((g & 0xff) << 8) | ((b & 0xff) << 16);
}

export function GetRValue(c) { return c & 0xff; }
export function GetGValue(c) { return (c >> 8) & 0xff; }
export function GetBValue(c) { return (c >> 16) & 0xff; }

// COLORREF → CSS 색 문자열
export function ColorRefToCss(c) {
	return `rgb(${c & 0xff}, ${(c >> 8) & 0xff}, ${(c >> 16) & 0xff})`;
}

// DOM 키보드 이벤트 → WinAPI 가상키 코드 대응
export function DomKeyToVK(e) {
	const k = e.key;
	if (k.length === 1) {
		return k.toUpperCase().charCodeAt(0);
	}
	const table = {
		"Escape": VK.ESCAPE, "Enter": VK.RETURN, "Spacebar": VK.SPACE, " ": VK.SPACE,
		"Tab": VK.TAB, "Backspace": VK.BACK, "Shift": VK.SHIFT, "Control": VK.CONTROL,
		"Alt": VK.MENU, "ArrowLeft": VK.LEFT, "ArrowUp": VK.UP, "ArrowRight": VK.RIGHT, "ArrowDown": VK.DOWN,
		"Insert": VK.INSERT, "Delete": VK.DELETE, "Home": VK.HOME, "End": VK.END,
		"PageUp": VK.PRIOR, "PageDown": VK.NEXT, "Pause": VK.PAUSE, "CapsLock": VK.CAPITAL,
		"F1": VK.F1, "F2": VK.F2, "F3": VK.F3, "F4": VK.F4, "F5": VK.F5, "F6": VK.F6,
		"F7": VK.F7, "F8": VK.F8, "F9": VK.F9, "F10": VK.F10, "F11": VK.F11, "F12": VK.F12,
	};
	return Object.prototype.hasOwnProperty.call(table, k) ? table[k] : null;
}
