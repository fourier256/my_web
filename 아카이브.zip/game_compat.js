// game_compat.js — 자동 생성된 단일 파일 클래식 번들 (ES 모듈 로딩 실패 시 폴백)
(function () {
"use strict";
var __PM2_EXPORTS__ = {};
var __PM2_LATE__ = [];
(function () {

// ===== GameEngineBase/GameEngineDebug.js =====
// GameEngineDebug.h / GameEngineDebug.cpp 의 전사
// MsgAssert 매크로: 원본은 MessageBoxA + assert. 브라우저에서는 치명적이지 않은
// 오버레이 + console.error 로 동일한 "보이는 실패"를 제공한다(원본 Release 동작:
// 박스 확인 후 계속 진행).

let _ErrorOverlay = null;
let _ErrorCount = 0;

function EnsureOverlay() {
	if (_ErrorOverlay) {
		return _ErrorOverlay;
	}
	_ErrorOverlay = document.createElement("div");
	_ErrorOverlay.style.cssText = "position:fixed;left:0;top:0;right:0;z-index:99999;background:rgba(120,0,0,0.85);color:#fff;font:12px/1.5 monospace;padding:4px 8px;max-height:40%;overflow:auto;display:none;white-space:pre-wrap;";
	document.body.appendChild(_ErrorOverlay);
	return _ErrorOverlay;
}

function MsgAssert(MsgText) {
	const ErrorText = String(MsgText);
	console.error("MsgAssert: " + ErrorText);
	if (_ErrorCount < 8) {
		const Overlay = EnsureOverlay();
		Overlay.style.display = "block";
		Overlay.textContent += "[MsgAssert] " + ErrorText + "\n";
	}
	_ErrorCount++;
	return;
}

class GameEngineDebug {
	static LeakCheck() {
		// 원본: _CrtSetDbgFlag — 브라우저에서는 해당 없음
	}

	static LeakPointBreak(_Point) {
		// 원본: _CrtSetBreakAlloc — 브라우저에서는 해당 없음
	}

	constructor() {
	}
	// delete Function
}

__PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"] = {"MsgAssert": MsgAssert, "GameEngineDebug": GameEngineDebug};
})();
(function () {

// ===== GameEngineBase/GameEnginePath.js =====
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
// GameEnginePath.h / GameEnginePath.cpp 의 전사
// 원본은 std::filesystem::path (Windows 구분자 '\'), 웹에서는 '/' 구분자를 사용한다.
// 콘텐츠 코드는 구분자를 직접 쓰지 않으므로(GameEngineDirectory 내부에서만 조립) 영향 없음.
// IsExists / IsExistsToPlusString 은 파일시스템 대신 로드 매니페스트(Boot.js에서 주입)를 본다.

class GameEnginePath {
	static Manifest = null; // Set<string> — 실제 존재하는 리소스 경로(소문자 정규화), 파일 또는 디렉터리 프리픽스

	static SetManifest(paths) {
		GameEnginePath.Manifest = new Set(paths.map((p) => GameEnginePath.Normalize(p)));
	}

	static Normalize(_Path) {
		return String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/").replace(/^\.\//, "").toLowerCase();
	}

	// 정규화된 키가 매니페스트에 있는지 (파일 또는 그 아래 파일이 있는 디렉터리)
	static ExistsInManifest(_Path) {
		if (null === GameEnginePath.Manifest) {
			return true; // 매니페스트 미주입 시 항상 존재한다고 본다(원본 파일시스템 동작)
		}
		const Key = GameEnginePath.Normalize(_Path);
		if ("" === Key) {
			return true;
		}
		if (GameEnginePath.Manifest.has(Key)) {
			return true;
		}
		for (const p of GameEnginePath.Manifest) {
			if (p.startsWith(Key) && p.charAt(Key.length) === "/") {
				return true;
			}
		}
		return false;
	}

	constructor(_Path) {
		if (undefined === _Path || null === _Path) {
			this.Path = "./"; // 원본: std::filesystem::current_path()
		} else if ("string" === typeof _Path) {
			this.Path = _Path;
		} else if (_Path instanceof GameEnginePath) {
			this.Path = _Path.GetPathToString(); // 원본 복사 생성자
		} else {
			this.Path = _Path;
		}
	}

	GetFileName() {
		const parts = this.Path.split("/");
		return parts[parts.length - 1];
	}

	GetPathToString() {
		return this.Path;
	}

	MoveParent() {
		const parts = this.Path.split("/").filter((s) => s.length > 0 && s !== ".");
		parts.pop();
		this.Path = parts.length === 0 ? "./" : "./" + parts.join("/");
	}

	MoveParentToChildPath(_String) {
		// 원본: 루트에 도달할 때까지 위로 올라가며 _String 자식이 있는 dir을 찾는다.
		// 웹 버전은 exe 대신 웹 루트("./")가 시작점이므로, 현재 위치의 존재 확인을
		// 루트 판정보다 먼저 수행해야 한다(원본 의미: 현재 dir부터 자식을 확인).
		while (true) {
			if (true === this.IsExistsToPlusString(_String)) {
				return;
			}
			if (true === this.IsRoot()) {
				break;
			}
			this.MoveParent();
		}
		MsgAssert("이런 경로의 자식이나 부모의 경로가 존재하지 않습니다.");
	}

	IsRoot() {
		// 상대 순회가 끝난(남은 경로 세그먼트가 없는) 상태만 루트로 본다
		return "" === this.Path.replace(/^\.\//, "").replace(/\//g, "");
	}

	IsExistsToPlusString(_String) {
		return GameEnginePath.ExistsInManifest(this.Path + _String);
	}

	IsExists() {
		return GameEnginePath.ExistsInManifest(this.Path);
	}

	Move(_Path) {
		// 원본: Path += _Path ("\" 조립) — 웹 버전은 "/" 조립 후 구분자를 정리한다
		this.Path = (this.Path + _Path).replace(/\/{2,}/g, "/");
		if (false === this.IsExists()) {
			MsgAssert(`이 존재하지 않는 경로로 이동하려고 했습니다.`);
			return false;
		}
		return true;
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEnginePath.js"] = {"GameEnginePath": GameEnginePath};
})();
(function () {

// ===== GameEngineBase/GameEngineFile.js =====
var GameEnginePath = __PM2_EXPORTS__["GameEngineBase/GameEnginePath.js"]["GameEnginePath"];
// GameEngineFile.h / GameEngineFile.cpp 의 전사

class GameEngineFile {
	constructor(_Path) {
		this.Path = new GameEnginePath(undefined === _Path ? null : _Path);
	}

	GetFullPath() {
		return this.Path.GetPathToString();
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineFile.js"] = {"GameEngineFile": GameEngineFile};
})();
(function () {

// ===== GameEngineBase/GameEngineDirectory.js =====
var GameEnginePath = __PM2_EXPORTS__["GameEngineBase/GameEnginePath.js"]["GameEnginePath"];
var GameEngineFile = __PM2_EXPORTS__["GameEngineBase/GameEngineFile.js"]["GameEngineFile"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
// GameEngineDirectory.h / GameEngineDirectory.cpp 의 전사
// 원본은 구분자로 "\"를 조립하지만, 웹 버전은 "/"를 사용한다(콘텐츠 코드에는 영향 없음).

class GameEngineDirectory {
	constructor() {
		this.Path = new GameEnginePath(null);
	}

	MoveParentToDirectory(_String) {
		// 원본: MovePath = "\" + _String; Path.MoveParentToChildPath(MovePath);
		this.Path.MoveParentToChildPath("/" + _String);
	}

	Move(_String) {
		return this.Path.Move("/" + _String);
	}

	GetPlusFileName(_String) {
		return new GameEnginePath(this.Path.GetPathToString() + "/" + _String);
	}

	MoveParent() {
		if (true === this.Path.IsRoot()) {
			MsgAssert("루트 디렉터리의 부모디렉터리로 이동할수 없습니다.");
			return false;
		}
		this.Path.MoveParent();
		return true;
	}

	GetAllFile(_Ext = "") {
		// 원본: std::filesystem::directory_iterator — 브라우저에서는 매니페스트로 대체
		const Files = [];
		if (null === GameEnginePath.Manifest) {
			return Files;
		}
		const Base = GameEnginePath.Normalize(this.Path.GetPathToString());
		for (const p of GameEnginePath.Manifest) {
			if (!p.startsWith(Base + "/")) {
				continue;
			}
			const rest = p.slice(Base.length + 1);
			if (rest.includes("/")) {
				continue; // 하위 디렉터리 파일 제외
			}
			if ("" === _Ext || p.endsWith(_Ext.toLowerCase())) {
				Files.push(new GameEngineFile(new GameEnginePath(p)));
			}
		}
		return Files;
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"] = {"GameEngineDirectory": GameEngineDirectory};
})();
(function () {

// ===== GameEngineBase/GameEngineString.js =====
// GameEngineString.h / GameEngineString.cpp 의 전사
// 브라우저는 UTF-8 문자열을 사용하므로 인코딩 변환 함수들은 항등 함수가 된다.

class GameEngineString {
	static ToUpper(_Str) {
		return String(_Str).toUpperCase();
	}

	static ToString(Value) {
		return String(Value);
	}

	static AnsiToUniCode(_Text) {
		return String(_Text);
	}

	static UniCodeToAnsi(_Text) {
		return String(_Text);
	}

	static UniCodeToUTF8(_Text) {
		return String(_Text);
	}

	static AnsiToUTF8(_Text) {
		return String(_Text);
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineString.js"] = {"GameEngineString": GameEngineString};
})();
(function () {

// ===== GameEngineBase/GameEngineMath.js =====
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
// GameEngineMath.h / GameEngineMath.cpp 의 전사
class GameEngineMath {
	static PIE = 3.141592653589793238462643383279502884197169399375105820974944;
	static PIE2 = GameEngineMath.PIE * 2.0;
	static DegToRad = GameEngineMath.PIE / 180;
	static RadToDeg = 180 / GameEngineMath.PIE;

	static GetDigits(_Value) {
		const ResultValue = [];
		const StringValue = GameEngineString.ToString(_Value);
		for (let i = 0; i < StringValue.length; i++) {
			ResultValue.push(StringValue.charCodeAt(i) - 48);
		}
		return ResultValue;
	}

	static GetLenth(_Value) {
		const StringValue = GameEngineString.ToString(_Value);
		let StartIndex = 0;
		if (0 !== StringValue.length && StringValue[0] === '-') {
			StartIndex = 1;
		}
		return StringValue.length - StartIndex;
	}
}


class float4 {
	static Left = new float4(-1.0, 0.0, 0.0, 1.0);
	static Right = new float4(1.0, 0.0, 0.0, 1.0);
	static Up = new float4(0.0, -1.0, 0.0, 1.0);
	static Down = new float4(0.0, 1.0, 0.0, 1.0);
	static Forward = new float4(0.0, 0.0, 1.0, 1.0);
	static Back = new float4(0.0, 0.0, -1.0, 1.0);
	static Zero = new float4(0.0, 0.0, 0.0, 1.0);
	static Null = new float4(0.0, 0.0, 0.0, 0.0);

	static AngleToDirection2DToDeg(_Deg) {
		return float4.AngleToDirection2DToRad(_Deg * GameEngineMath.DegToRad);
	}

	static AngleToDirection2DToRad(_Rad) {
		return new float4(Math.cos(_Rad), Math.sin(_Rad), 0.0, 1.0);
	}

	constructor(x = 0.0, y = 0.0, z = 0.0, w = 1.0) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}

	copy() {
		return new float4(this.x, this.y, this.z, this.w);
	}

	ix() { return Math.trunc(this.x); }
	iy() { return Math.trunc(this.y); }
	iz() { return Math.trunc(this.z); }
	iw() { return Math.trunc(this.w); }
	hix() { return Math.trunc(this.x * 0.5); }
	hiy() { return Math.trunc(this.y * 0.5); }
	hiz() { return Math.trunc(this.z * 0.5); }
	hiw() { return Math.trunc(this.w * 0.5); }
	hx() { return this.x * 0.5; }
	hy() { return this.y * 0.5; }
	hz() { return this.z * 0.5; }
	hw() { return this.w * 0.5; }

	GetAnagleDeg() {
		return this.GetAnagleRad() * GameEngineMath.RadToDeg;
	}

	GetAnagleRad() {
		const AngleCheck = this.copy();
		AngleCheck.Normalize();
		let Result = Math.acos(AngleCheck.x);
		if (AngleCheck.y > 0) {
			Result = GameEngineMath.PIE2 - Result;
		}
		return Result;
	}

	half() {
		return new float4(this.x * 0.5, this.y * 0.5, this.z * 0.5, this.w);
	}

	IsZero() {
		return this.x === 0.0 && this.y === 0.0 && this.z === 0.0;
	}

	Size() {
		return Math.sqrt(this.x * this.x + this.y * this.y);
	}

	Normalize() {
		const SizeValue = this.Size();
		this.x /= SizeValue;
		this.y /= SizeValue;
		this.z /= SizeValue;
	}

	static Lerp(Start, End, Ratio) {
		return Start.scale(1.0 - Ratio).add(End.scale(Ratio));
	}

	static LerpClamp(Start, End, Ratio) {
		if (0 >= Ratio) {
			Ratio = 0.0;
		}
		if (1.0 <= Ratio) {
			Ratio = 1.0;
		}
		return float4.Lerp(Start, End, Ratio);
	}

	scale(_Value) {
		return new float4(this.x * _Value, this.y * _Value, this.z * _Value, this.w);
	}

	add(_Value) {
		return new float4(this.x + _Value.x, this.y + _Value.y, this.z + _Value.z, this.w);
	}

	sub(_Value) {
		return new float4(this.x - _Value.x, this.y - _Value.y, this.z - _Value.z, this.w);
	}

	mul(_Value) {
		return new float4(this.x * _Value.x, this.y * _Value.y, this.z * _Value.z, this.w);
	}

	div(_Value) {
		return new float4(this.x / _Value.x, this.y / _Value.y, this.z / _Value.z, this.w);
	}

	neg() {
		return new float4(-this.x, -this.y, -this.z, 1.0);
	}

	ToString() {
		return `x: ${this.x}, y: ${this.y}, z: ${this.z}, w: ${this.w}`;
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"] = {"GameEngineMath": GameEngineMath, "float4": float4};
})();
(function () {

// ===== GameEngineBase/GameEngineRandom.js =====
// GameEngineRandom.h / GameEngineRandom.cpp 의 전사
// std::mt19937_64 + uniform_distribution 대신 Math.random 사용 (분포 의미 동일)

class GameEngineRandom {
	static MainRandom = new GameEngineRandom();

	constructor() {
		// 원본: 시드 = 현재 시각
		this.Seed = Date.now();
	}

	SetSeed(_Seed) {
		this.Seed = _Seed;
	}

	RandomInt(_Min, _Max) {
		// uniform_int_distribution: [Min, Max] 포함 균등 분포
		return Math.floor(Math.random() * (_Max - _Min + 1)) + _Min;
	}

	RandomFloat(_Min, _Max) {
		// uniform_real_distribution: [Min, Max) 균등 분포
		return Math.random() * (_Max - _Min) + _Min;
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineRandom.js"] = {"GameEngineRandom": GameEngineRandom};
})();
(function () {

// ===== GameEngineBase/GameEngineTime.js =====
// GameEngineTime.h / GameEngineTime.cpp 의 전사
// QueryPerformanceCounter 대신 performance.now() 사용 (초 단위 float 반환은 동일)

class GameEngineTime {
	static GlobalTime = new GameEngineTime();

	constructor() {
		this.Prev = performance.now();
		this.Second = 1000.0; // performance.now()의 "주파수" (ms → s 변환용)
	}

	Reset() {
		this.Prev = performance.now();
	}

	TimeCheck() {
		const Current = performance.now();
		const Tick = Current - this.Prev;
		const DoubleDeltaTime = (Current - this.Prev) / this.Second;
		this.Prev = Current;
		return DoubleDeltaTime;
	}
}

__PM2_EXPORTS__["GameEngineBase/GameEngineTime.js"] = {"GameEngineTime": GameEngineTime};
})();
(function () {

// ===== GameEngineCore/GameEngineObject.js =====
// GameEngineObject.h / GameEngineObject.cpp 의 전사
class GameEngineObject {
	constructor() {
		this.Order = -123123;
		this.Parent = null;
		this.ObjectDeath = false;
		this.ObjectUpdate = true;
		this.Name = "";
	}

	IsUpdate() {
		return null !== this.Parent ? ((this.ObjectUpdate && false === this.IsDeath()) && this.Parent.IsUpdate()) : (this.ObjectUpdate && false === this.IsDeath());
	}

	IsDeath() {
		return null !== this.Parent ? (true === this.ObjectDeath || this.Parent.IsDeath()) : (true === this.ObjectDeath);
	}

	Death() {
		this.ObjectDeath = true;
	}

	On() {
		this.ObjectUpdate = true;
	}

	Off() {
		this.ObjectUpdate = false;
	}

	OnOffSwtich() {
		this.ObjectUpdate = !this.ObjectUpdate;
	}

	SetOwner(_Parent) {
		this.Parent = _Parent;
	}

	GetOwner() {
		return this.Parent;
	}

	SetOrder(_Order) {
		this.Order = _Order;
	}

	GetOrder() {
		return this.Order;
	}

	SetName(_View) {
		this.Name = _View;
	}

	GetName() {
		return this.Name;
	}

	GetNameCopy() {
		return this.Name;
	}
}

__PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"] = {"GameEngineObject": GameEngineObject};
})();
(function () {

// ===== GameEngineCore/GameEngineComponent.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
// GameEngineComponent.h / GameEngineComponent.cpp 의 전사

class GameEngineComponent extends GameEngineObject {
	constructor() {
		super();
		this.Position = new float4(0, 0, 0, 1); // float4::Zero
		this.Scale = new float4(0, 0, 0, 1);     // float4::Zero
	}

	SetPosition(_Position) {
		this.Position = _Position;
	}

	SetMove(_Position) {
		this.Position = this.Position.add(_Position);
	}

	SetScale(_Scale) {
		this.Scale = _Scale;
	}

	GetPosition() {
		return this.Position;
	}

	GetScale() {
		return this.Scale;
	}

	GetActor() {
		return this.GetOwner();
	}

	GetActorPlusPos() {
		return this.GetActor().GetPos().add(this.Position);
	}
}

__PM2_EXPORTS__["GameEngineCore/GameEngineComponent.js"] = {"GameEngineComponent": GameEngineComponent};
})();
(function () {

// ===== GameEnginePlatform/GameEngineImage.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
// GameEngineImage.h / GameEngineImage.cpp 의 전사
// HBITMAP/HDC 대신 canvas + ImageData 캐시를 사용한다.
// TransCopy의 색상키 투명(기본 RGB(255,0,255))은 로드 시 픽셀 처리로 구현한다.

class ImageCutData {
	constructor() {
		this.StartX = 0.0;
		this.StartY = 0.0;
		this.SizeX = 0.0;
		this.SizeY = 0.0;
	}

	GetStartPos() {
		return new float4(this.StartX, this.StartY);
	}

	GetScale() {
		return new float4(this.SizeX, this.SizeY);
	}
}

class GameEngineImage {
	constructor() {
		this.canvas = null;   // HTMLCanvasElement (비트맵 본체)
		this.ctx = null;      // CanvasRenderingContext2D (원본 ImageDC)
		this.bmWidth = 0;     // 원본 BITMAP Info.bmWidth
		this.bmHeight = 0;    // 원본 BITMAP Info.bmHeight
		this.IsCut = false;
		this.ImageCutDatas = [];
		this._ImageDataCache = null;   // GetPixelColor 용
		this._KeyedCache = new Map();  // colorKey int → canvas
	}

	// 원본 ImageCreate(HDC): 이미 존재하는 표면을 감쌀 때 (백버퍼)
	// 원본 ImageCreate(float4): 빈 이미지 생성
	ImageCreate(_Scale) {
		if (_Scale instanceof GameEngineImage) {
			MsgAssert("잘못된 ImageCreate 호출");
			return false;
		}
		if (_Scale instanceof CanvasRenderingContext2D) {
			this.ctx = _Scale;
			this.canvas = _Scale.canvas;
			this.ImageScaleCheck();
			return true;
		}
		if (_Scale instanceof HTMLCanvasElement) {
			this.canvas = _Scale;
			this.ctx = _Scale.getContext("2d");
			this.ImageScaleCheck();
			return true;
		}
		if (true === _Scale.IsZero()) {
			MsgAssert("크기가 0인 이미지를 만들 수 는 없습니다");
			return false;
		}
		this.canvas = document.createElement("canvas");
		this.canvas.width = _Scale.ix();
		this.canvas.height = _Scale.iy();
		this.ctx = this.canvas.getContext("2d");
		this.ImageScaleCheck();
		this.ImageClear();
		return true;
	}

	ImageClear() {
		// 원본: Rectangle(ImageDC, 0, 0, w, h) — 기본 흰 브러시 채움
		this.ctx.fillStyle = "#ffffff";
		this.ctx.fillRect(0, 0, this.bmWidth, this.bmHeight);
	}

	ImageLoad(_Path) {
		const Url = GameEngineImage.ResolveResourceUrl(_Path);
		const Preloaded = (window.PM2_PRELOADED && window.PM2_PRELOADED.images) ? window.PM2_PRELOADED.images.get(Url.toLowerCase()) : null;
		if (null !== Preloaded && undefined !== Preloaded) {
			this.canvas = document.createElement("canvas");
			this.canvas.width = Preloaded.naturalWidth;
			this.canvas.height = Preloaded.naturalHeight;
			this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
			this.ctx.drawImage(Preloaded, 0, 0);
		} else {
			// 프리로드에 없으면 즉석 로드 (원본과 달리 비동기 — 매니페스트에 있으면 미리 로드됨)
			this.canvas = document.createElement("canvas");
			this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
			const img = new Image();
			img.src = Url;
			this.canvas.width = 0;
			this.canvas.height = 0;
			img.addEventListener("load", () => {
				this.canvas.width = img.naturalWidth;
				this.canvas.height = img.naturalHeight;
				this.ctx.drawImage(img, 0, 0);
				this.ImageScaleCheck();
			});
			img.addEventListener("error", () => {
				MsgAssert(_Path + " 이미지 로드에 실패했습니다.");
			});
		}
		this.ImageScaleCheck();
		return true;
	}

	ImageScaleCheck() {
		this.bmWidth = this.canvas ? this.canvas.width : 0;
		this.bmHeight = this.canvas ? this.canvas.height : 0;
	}

	GetImageDC() {
		return this.ctx;
	}

	GetImageScale() {
		return new float4(this.bmWidth, this.bmHeight, 0, 1);
	}

	IsImageCutting() {
		return this.IsCut;
	}

	GetImageCuttingCount() {
		return this.ImageCutDatas.length;
	}

	IsCutIndexValid(_Index) {
		if (0 > _Index) {
			return false;
		}
		if (this.ImageCutDatas.length <= _Index) {
			return false;
		}
		return true;
	}

	GetCutData(_Index) {
		if (false === this.IsCutIndexValid(_Index)) {
			MsgAssert("유효하지 않은 컷 인덱스 입니다.");
		}
		return this.ImageCutDatas[_Index];
	}

	// Cut(int _X, int _Y) / Cut(float4 _Start, float4 _End, int _X, int _Y)
	Cut(...args) {
		if (2 === args.length) {
			const _X = args[0];
			const _Y = args[1];
			const Data = new ImageCutData();
			Data.SizeX = this.GetImageScale().ix() / _X;
			Data.SizeY = this.GetImageScale().iy() / _Y;
			for (let j = 0; j < _Y; j++) {
				for (let i = 0; i < _X; i++) {
					this.ImageCutDatas.push(Data);
					Data.StartX += Data.SizeX;
				}
				Data.StartX = 0.0;
				Data.StartY += Data.SizeY;
			}
			this.IsCut = true;
			return;
		}

		const _Start = args[0];
		const _End = args[1];
		const _X = args[2];
		const _Y = args[3];
		const Data = new ImageCutData();
		Data.SizeX = (_End.x - _Start.x) / _X;
		Data.SizeY = (_End.y - _Start.y) / _Y;
		Data.StartX = _Start.x;
		Data.StartY = _Start.y;
		for (let j = 0; j < _Y; j++) {
			for (let i = 0; i < _X; i++) {
				this.ImageCutDatas.push(Data);
				Data.StartX += Data.SizeX;
			}
			Data.StartX = _Start.x;
			Data.StartY += Data.SizeY;
		}
		this.IsCut = true;
	}

	// BitBlt(SRCCOPY): 1:1 복사(스케일 없음) — 원본 동일
	BitCopy(_OtherImage, _CenterPos, _Scale) {
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		this.ctx.drawImage(
			_OtherImage.canvas,
			0, 0,
			Math.max(0, _Scale.ix()), Math.max(0, _Scale.iy()),
			_CenterPos.ix() - _Scale.hix(),
			_CenterPos.iy() - _Scale.hiy(),
			Math.max(0, _Scale.ix()), Math.max(0, _Scale.iy())
		);
	}

	// TransCopy(other, cutIndex, center, size[, color])
	// TransCopy(other, center, size, srcPos, srcSize[, color])
	TransCopy(...args) {
		let _OtherImage, _CopyCenterPos, _CopySize, _OtherImagePos, _OtherImageSize, _Color;
		if (4 === args.length || 5 === args.length) {
			_OtherImage = args[0];
			const _CutIndex = args[1];
			_CopyCenterPos = args[2];
			_CopySize = args[3];
			_Color = 5 === args.length ? args[4] : 0xff00ff; // RGB(255, 0, 255)
			if (false === _OtherImage.IsCut) {
				MsgAssert(" 잘못된 컷 이미지를 cut하려는 함수를 사용하려고 했습니다.");
				return;
			}
			const Data = _OtherImage.GetCutData(_CutIndex);
			_OtherImagePos = Data.GetStartPos();
			_OtherImageSize = Data.GetScale();
		} else {
			_OtherImage = args[0];
			_CopyCenterPos = args[1];
			_CopySize = args[2];
			_OtherImagePos = args[3];
			_OtherImageSize = args[4];
			_Color = 6 === args.length ? args[5] : 0xff00ff; // RGB(255, 0, 255)
		}
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		const Src = _OtherImage.GetKeyedCanvas(_Color);
		this.ctx.drawImage(
			Src,
			_OtherImagePos.ix(), _OtherImagePos.iy(),
			Math.max(0, _OtherImageSize.ix()), Math.max(0, _OtherImageSize.iy()),
			_CopyCenterPos.ix() - _CopySize.hix(),
			_CopyCenterPos.iy() - _CopySize.hiy(),
			Math.max(1, _CopySize.ix()), Math.max(1, _CopySize.iy())
		);
	}

	// AlphaCopy(other, cutIndex, center, size[, color])
	// AlphaCopy(other, center, size, srcPos, srcSize, alpha)
	AlphaCopy(...args) {
		let _OtherImage, _CopyCenterPos, _CopySize, _OtherImagePos, _OtherImageSize, _Alpha;
		if (4 === args.length || 5 === args.length) {
			_OtherImage = args[0];
			const _CutIndex = args[1];
			_CopyCenterPos = args[2];
			_CopySize = args[3];
			if (false === _OtherImage.IsCut) {
				MsgAssert(" 잘못된 컷 이미지를 cut하려는 함수를 사용하려고 했습니다.");
				return;
			}
			const Data = _OtherImage.GetCutData(_CutIndex);
			_OtherImagePos = Data.GetStartPos();
			_OtherImageSize = Data.GetScale();
			_Alpha = args[4];
		} else {
			_OtherImage = args[0];
			_CopyCenterPos = args[1];
			_CopySize = args[2];
			_OtherImagePos = args[3];
			_OtherImageSize = args[4];
			_Alpha = args[5];
		}
		if (null === this.ctx || null === _OtherImage || null === _OtherImage.canvas || 0 === _OtherImage.bmWidth) {
			return;
		}
		this.ctx.globalAlpha = _Alpha / 255.0;
		this.ctx.drawImage(
			_OtherImage.canvas,
			_OtherImagePos.ix(), _OtherImagePos.iy(),
			Math.max(0, _OtherImageSize.ix()), Math.max(0, _OtherImageSize.iy()),
			_CopyCenterPos.ix() - _CopySize.hix(),
			_CopyCenterPos.iy() - _CopySize.hiy(),
			Math.max(1, _CopySize.ix()), Math.max(1, _CopySize.iy())
		);
		this.ctx.globalAlpha = 1.0;
	}

	// 색상키가 적용된 소스 캔버스 (캐시)
	GetKeyedCanvas(_Color) {
		if (null === this.canvas || 0 === this.bmWidth) {
			return this.canvas;
		}
		const Key = null === _Color || undefined === _Color ? -1 : _Color;
		if (-1 === Key) {
			return this.canvas;
		}
		if (this._KeyedCache.has(Key)) {
			return this._KeyedCache.get(Key);
		}
		const Out = document.createElement("canvas");
		Out.width = this.bmWidth;
		Out.height = this.bmHeight;
		const octx = Out.getContext("2d");
		octx.drawImage(this.canvas, 0, 0);
		const Data = octx.getImageData(0, 0, Out.width, Out.height);
		const px = Data.data;
		for (let i = 0; i < px.length; i += 4) {
			const color = px[i] | (px[i + 1] << 8) | (px[i + 2] << 16);
			if (color === Key) {
				px[i + 3] = 0;
			}
		}
		octx.putImageData(Data, 0, 0);
		this._KeyedCache.set(Key, Out);
		return Out;
	}

	GetImageDataCache() {
		if (null === this._ImageDataCache && null !== this.ctx && this.bmWidth > 0) {
			this._ImageDataCache = this.ctx.getImageData(0, 0, this.bmWidth, this.bmHeight);
		}
		return this._ImageDataCache;
	}

	GetPixelColor(...args) {
		let _X, _Y;
		if (1 === args.length) {
			_X = args[0].ix();
			_Y = args[0].iy();
		} else {
			_X = args[0];
			_Y = args[1];
		}
		const _OutColor = args[args.length - 1];
		if (_X < 0) { return _OutColor; }
		if (_X >= this.GetImageScale().ix()) { return _OutColor; }
		if (_Y < 0) { return _OutColor; }
		if (_Y >= this.GetImageScale().iy()) { return _OutColor; }
		const Data = this.GetImageDataCache();
		if (null === Data) { return _OutColor; }
		const idx = (_Y * this.bmWidth + _X) * 4;
		// COLORREF = 0x00BBGGRR
		return Data.data[idx] | (Data.data[idx + 1] << 8) | (Data.data[idx + 2] << 16);
	}
}

// 리소스 경로 → 웹 URL 변환 (빌드 시 .bmp → .png 변환됨, 매니페스트로 대소문자 무시 매핑)
GameEngineImage.ResolveResourceUrl = function (_Path) {
	let p = String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/");
	if (p.startsWith("./")) {
		p = p.slice(2);
	}
	while (p.startsWith("/")) {
		p = p.slice(1); // 웹 루트 기준 상대 경로로 정규화 (서버/매니페스트 키 일치)
	}
	if (/\.bmp$/i.test(p)) {
		p = p.slice(0, -4) + ".png";
	}
	if (window.PM2_MANIFEST_PATHS) {
		const lower = p.toLowerCase();
		const Found = window.PM2_MANIFEST_PATHS.find((x) => x.toLowerCase() === lower);
		if (Found) {
			p = Found;
		}
	}
	return p;
};

__PM2_EXPORTS__["GameEnginePlatform/GameEngineImage.js"] = {"ImageCutData": ImageCutData, "GameEngineImage": GameEngineImage};
})();
(function () {

// ===== WinAPI.js =====
// WinAPI.h 등 Windows 환경 상수의 전사 (브라우저용 호환 계층)
// 원본 C++가 WinAPI 상수(VK_* / RGB 매크로 / COLORREF)를 사용하는 곳의 대응 값.

const VK = Object.freeze({
	LBUTTON: 0x01,
	RBUTTON: 0x02,
	CANCEL: 0x03,
	MBUTTON: 0x04,
	BACK: 0x08,
	TAB: 0x09,
	RETURN: 0x0D,
	SHIFT: 0x10,
	CONTROL: 0x11,
	MENU: 0x12,
	PAUSE: 0x13,
	CAPITAL: 0x14,
	ESCAPE: 0x1B,
	SPACE: 0x20,
	PRIOR: 0x21,
	NEXT: 0x22,
	END: 0x23,
	HOME: 0x24,
	LEFT: 0x25,
	UP: 0x26,
	RIGHT: 0x27,
	DOWN: 0x28,
	INSERT: 0x2D,
	DELETE: 0x2E,
	LWIN: 0x5B,
	RWIN: 0x5C,
	NUMPAD0: 0x60,
	NUMPAD1: 0x61,
	NUMPAD2: 0x62,
	NUMPAD3: 0x63,
	NUMPAD4: 0x64,
	NUMPAD5: 0x65,
	NUMPAD6: 0x66,
	NUMPAD7: 0x67,
	NUMPAD8: 0x68,
	NUMPAD9: 0x69,
	F1: 0x70,
	F2: 0x71,
	F3: 0x72,
	F4: 0x73,
	F5: 0x74,
	F6: 0x75,
	F7: 0x76,
	F8: 0x77,
	F9: 0x78,
	F10: 0x79,
	F11: 0x7A,
	F12: 0x7B,
});

// RGB 매크로: COLORREF = 0x00BBGGRR
function RGB(r, g, b) {
	return (r & 0xff) | ((g & 0xff) << 8) | ((b & 0xff) << 16);
}

function GetRValue(c) { return c & 0xff; }
function GetGValue(c) { return (c >> 8) & 0xff; }
function GetBValue(c) { return (c >> 16) & 0xff; }

// COLORREF → CSS 색 문자열
function ColorRefToCss(c) {
	return `rgb(${c & 0xff}, ${(c >> 8) & 0xff}, ${(c >> 16) & 0xff})`;
}

// DOM 키보드 이벤트 → WinAPI 가상키 코드 대응
function DomKeyToVK(e) {
	const k = e.key;
	if (k.length === 1) {
		return k.toUpperCase().charCodeAt(0);
	}
	const table = {
		"Escape": VK.ESCAPE, "Enter": VK.RETURN, "Spacebar": VK.SPACE, " ": VK.SPACE,
		"Tab": VK.TAB, "Backspace": VK.BACK, "Shift": VK.SHIFT, "Control": VK.CONTROL,
		"Alt": VK.MENU, "ArrowLeft": VK.LEFT, "ArrowUp": VK.UP, "ArrowRight": VK.RIGHT, "ArrowDown": VK.DOWN,
		"Insert": VK.INSERT, "Delete": VK.DELETE, "Home": VK.HOME, "End": VK.END,
		"PageUp": VK.PRIOR, "PageDown": VK.NEXT, "Pause": VK.PAUSE, "CapsLock": VK.CAPITAL,
		"F1": VK.F1, "F2": VK.F2, "F3": VK.F3, "F4": VK.F4, "F5": VK.F5, "F6": VK.F6,
		"F7": VK.F7, "F8": VK.F8, "F9": VK.F9, "F10": VK.F10, "F11": VK.F11, "F12": VK.F12,
	};
	return Object.prototype.hasOwnProperty.call(table, k) ? table[k] : null;
}

__PM2_EXPORTS__["WinAPI.js"] = {"VK": VK, "RGB": RGB, "GetRValue": GetRValue, "GetGValue": GetGValue, "GetBValue": GetBValue, "ColorRefToCss": ColorRefToCss, "DomKeyToVK": DomKeyToVK};
})();
(function () {

// ===== GameEnginePlatform/GameEngineInput.js =====
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var DomKeyToVK = __PM2_EXPORTS__["WinAPI.js"]["DomKeyToVK"];
// GameEngineInput.h / GameEngineInput.cpp 의 전사
// GetAsyncKeyState 대신 DOM 이벤트로 관리되는 "물리 키 눌림 집합"을 사용한다.
// 원본의 IsAnyKeyOff() 버그(IsAnyKeyValue = true)는 그대로 보존한다.

class GameEngineInput {
	static Keys = new Map();
	static IsAnyKeyValue = false;
	static PressedCodes = new Set(); // 물리적 눌림 상태 (KeyCheck 용)

	static IsAnyKeyOn() {
		this.IsAnyKeyValue = true;
	}

	static IsAnyKeyOff() {
		// 원본 그대로: IsAnyKeyValue = true (버그 보존)
		this.IsAnyKeyValue = true;
	}

	static IsAnyKey() {
		return this.IsAnyKeyValue;
	}

	static Update(_DeltaTime) {
		for (const [, i] of this.Keys) {
			i.Update(_DeltaTime);
		}
	}

	static CreateKey(_Name, _Key) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (this.Keys.has(UpperName)) {
			MsgAssert("이미 존재하는 이름의 키를 재 등록하려고 했습니다.");
		}
		this.Keys.set(UpperName, new GameEngineKey(_Key));
	}

	static IsKey(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		return this.Keys.has(UpperName);
	}

	static IsDown(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Down;
	}

	static IsUp(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Up;
	}

	static IsPress(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Press;
	}

	static IsFree(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).Free;
	}

	static GetPressTime(_Name) {
		const UpperName = GameEngineString.ToUpper(_Name);
		if (false === this.Keys.has(UpperName)) {
			MsgAssert("존재하지 않는 키를 사용하려고 했습니다." + UpperName);
		}
		return this.Keys.get(UpperName).PressTime;
	}

	static MouseCursorOff() {
		// 원본: ShowCursor(FALSE)
		const canvas = document.getElementById("GameEngineWindowDefault");
		if (canvas) {
			canvas.style.cursor = "none";
		}
	}

	// === 브라우저 물리 입력 바인딩 (GetAsyncKeyState 대체) ===
	static Install(canvas) {
		window.addEventListener("keydown", (e) => {
			const code = DomKeyToVK(e);
			if (null !== code) {
				GameEngineInput.PressedCodes.add(code);
				GameEngineInput.IsAnyKeyOn();
			}
		});
		window.addEventListener("keyup", (e) => {
			const code = DomKeyToVK(e);
			if (null !== code) {
				GameEngineInput.PressedCodes.delete(code);
			}
		});
		window.addEventListener("blur", () => {
			GameEngineInput.PressedCodes.clear();
		});
		canvas.addEventListener("mousedown", (e) => {
			if (0 === e.button) { GameEngineInput.PressedCodes.add(0x01); }  // VK_LBUTTON
			if (2 === e.button) { GameEngineInput.PressedCodes.add(0x02); }  // VK_RBUTTON
			if (1 === e.button) { GameEngineInput.PressedCodes.add(0x04); }  // VK_MBUTTON
			e.preventDefault();
		});
		window.addEventListener("mouseup", (e) => {
			if (0 === e.button) { GameEngineInput.PressedCodes.delete(0x01); }
			if (2 === e.button) { GameEngineInput.PressedCodes.delete(0x02); }
			if (1 === e.button) { GameEngineInput.PressedCodes.delete(0x04); }
		});
		canvas.addEventListener("contextmenu", (e) => e.preventDefault());
	}

	static IsPhysicalDown(_Key) {
		return this.PressedCodes.has(_Key);
	}
}

class GameEngineKey {
	constructor(_Key) {
		this.Down = false;
		this.Press = false;
		this.Up = false;
		this.Free = true;
		this.PressTime = 0;
		this.Key = _Key;
	}

	KeyCheck() {
		// 원본: 0 != GetAsyncKeyState(Key)
		return GameEngineInput.IsPhysicalDown(this.Key);
	}

	Update(_DeltaTime) {
		if (true === this.KeyCheck()) {
			this.PressTime += _DeltaTime;
			if (true === this.Free) {
				this.Down = true;
				this.Press = true;
				this.Up = false;
				this.Free = false;
			} else if (true === this.Press) {
				this.Down = false;
				this.Press = true;
				this.Up = false;
				this.Free = false;
			}
		} else {
			this.PressTime = 0.0;
			if (true === this.Press) {
				this.Down = false;
				this.Press = false;
				this.Up = true;
				this.Free = true;
			} else if (true === this.Up) {
				this.Down = false;
				this.Press = false;
				this.Up = false;
				this.Free = true;
			}
		}
	}
}

__PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"] = {"GameEngineInput": GameEngineInput};
})();
(function () {

// ===== GameEnginePlatform/GameEngineWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineImage = __PM2_EXPORTS__["GameEnginePlatform/GameEngineImage.js"]["GameEngineImage"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
// GameEngineWindow.h / GameEngineWindow.cpp 의 전사
// HWND/HDC/백버퍼 대신 canvas 2D 컨텍스트를 사용한다.
// - BackBufferImage  : 화면에 보이는 canvas를 감싼 이미지 (원본: 윈도우 DC)
// - DoubleBufferImage: 800x600 오프스크린 canvas (원본: 호환 비트맵 DC)

class GameEngineWindow {
	static HWnd = null;              // HTMLCanvasElement
	static WindowBackBufferHdc = null; // CanvasRenderingContext2D
	static WindowSize = new float4(800, 600);
	static ScreenSize = new float4(800, 600);
	static WindowPos = new float4(100, 100);
	static BackBufferImage = null;
	static DoubleBufferImage = null;
	static IsWindowUpdate = true;
	static MousePos = new float4(0, 0, 0, 0);

	static MessageFunction() {
		// 원본 WndProc: 브라우저 이벤트는 GameEngineInput.Install 에서 처리
	}

	static WindowCreate(_hInstance, _TitleName, _Size, _Pos) {
		const canvas = document.createElement("canvas");
		canvas.id = "GameEngineWindowDefault";
		canvas.width = _Size.ix();
		canvas.height = _Size.iy();
		canvas.style.position = "absolute";
		canvas.style.left = "50%";
		canvas.style.top = "50%";
		canvas.style.transform = "translate(-50%, -50%)";
		canvas.style.imageRendering = "pixelated";
		canvas.style.background = "#000";
		document.body.appendChild(canvas);

		// 창 크기에 맞게 비율 유지 스케일 (AdjustWindowRect 비해상당: 웹은 비클라이언트 영역 없음)
		const Fit = () => {
			const Scale = Math.min(window.innerWidth / _Size.ix(), window.innerHeight / _Size.iy());
			canvas.style.width = Math.floor(_Size.ix() * Scale) + "px";
			canvas.style.height = Math.floor(_Size.iy() * Scale) + "px";
		};
		window.addEventListener("resize", Fit);
		Fit();

		this.HWnd = canvas;
		this.WindowBackBufferHdc = canvas.getContext("2d");
		this.WindowBackBufferHdc.imageSmoothingEnabled = false;

		// 마우스 추적 (원본: GetCursorPos + ScreenToClient)
		const UpdateMouse = (e) => {
			const Rect = canvas.getBoundingClientRect();
			this.MousePos = new float4(
				(e.clientX - Rect.left) * (canvas.width / Rect.width),
				(e.clientY - Rect.top) * (canvas.height / Rect.height),
				0, 0
			);
		};
		window.addEventListener("mousemove", UpdateMouse);

		this.SettingWindowSize(_Size);
		this.SettingWindowPos(_Pos);

		this.BackBufferImage = new GameEngineImage();
		this.BackBufferImage.ImageCreate(this.WindowBackBufferHdc);

		GameEngineInput.Install(canvas);
	}

	static SettingWindowSize(_Size) {
		this.ScreenSize = _Size.copy();
		this.WindowSize = _Size.copy();

		if (null !== this.DoubleBufferImage) {
			// 원본: delete 후 재생성
		}

		this.DoubleBufferImage = new GameEngineImage();
		this.DoubleBufferImage.ImageCreate(this.ScreenSize);
	}

	static SettingWindowPos(_Pos) {
		this.WindowPos = _Pos.copy();
	}

	static GetScreenSize() {
		return this.ScreenSize;
	}

	static GetHWnd() {
		return this.HWnd;
	}

	static GetWindowBackBufferHdc() {
		return this.WindowBackBufferHdc;
	}

	static GetDoubleBufferImage() {
		return this.DoubleBufferImage;
	}

	static AppOff() {
		this.IsWindowUpdate = false;
	}

	static DoubleBufferClear() {
		this.DoubleBufferImage.ImageClear();
	}

	static DoubleBufferRender() {
		this.BackBufferImage.BitCopy(this.DoubleBufferImage, this.WindowSize.half(), this.WindowSize);
	}

	static GetMousePosition() {
		return this.MousePos.copy();
	}

	static WindowLoop(_Start, _Loop, _End) {
		if (null !== _Start && undefined !== _Start) {
			_Start();
		}

		const Frame = () => {
			if (false === this.IsWindowUpdate) {
				if (null !== _End && undefined !== _End) {
					_End();
				}
				return;
			}
			if (null !== _Loop && undefined !== _Loop) {
				_Loop();
			}
			GameEngineInput.IsAnyKeyOff();
			requestAnimationFrame(Frame);
		};
		requestAnimationFrame(Frame);
	}
}

__PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"] = {"GameEngineWindow": GameEngineWindow};
})();
(function () {

// ===== GameEngineCore/GameEngineCollision.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineComponent = __PM2_EXPORTS__["GameEngineCore/GameEngineComponent.js"]["GameEngineComponent"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// GameEngineCollision.h / GameEngineCollision.cpp 의 전사

const CollisionType = Object.freeze({
	CT_Point: 0,
	CT_CirCle: 1,
	CT_Rect: 2,
	CT_Max: 3
});

class CollisionCheckParameter {
	constructor() {
		this.TargetGroup = -342367842;
		this.TargetColType = CollisionType.CT_CirCle;
		this.ThisColType = CollisionType.CT_CirCle;
	}
}

class CollisionData {
	constructor() {
		this.Position = new float4(0, 0, 0, 1);
		this.Scale = new float4(0, 0, 0, 1);
	}

	Left() { return this.Position.x - this.Scale.hx(); }
	Right() { return this.Position.x + this.Scale.hx(); }
	Top() { return this.Position.y - this.Scale.hy(); }
	Bot() { return this.Position.y + this.Scale.hy(); }
}

// static bool(*ColFunctionPtr[CT_Max][CT_Max])(...) 대응 테이블
const ColFunctionPtr = [];

class CollisionFunctionInit {
	constructor() {
		ColFunctionPtr[CollisionType.CT_CirCle] = [];
		ColFunctionPtr[CollisionType.CT_CirCle][CollisionType.CT_CirCle] = GameEngineCollision.CollisionCirCleToCirCle;
		ColFunctionPtr[CollisionType.CT_CirCle][CollisionType.CT_Point] = GameEngineCollision.CollisionCirCleToPoint;
		ColFunctionPtr[CollisionType.CT_Rect] = [];
		ColFunctionPtr[CollisionType.CT_Rect][CollisionType.CT_Rect] = GameEngineCollision.CollisionRectToRect;
		ColFunctionPtr[CollisionType.CT_Rect][CollisionType.CT_Point] = GameEngineCollision.CollisionRectToPoint;
	}
}


class GameEngineCollision extends GameEngineComponent {
	constructor() {
		super();
		this.DebugRenderType = CollisionType.CT_CirCle;
	}

	static CollisionCirCleToPoint(_Left, _Right) {
		const Len = _Left.Position.sub(_Right.Position);
		const Size = Len.Size();
		const RadiusSum = _Left.Scale.hx();
		return RadiusSum > Size;
	}

	static CollisionCirCleToCirCle(_Left, _Right) {
		const Len = _Left.Position.sub(_Right.Position);
		const Size = Len.Size();
		const RadiusSum = _Left.Scale.hx() + _Right.Scale.hx();
		return RadiusSum > Size;
	}

	static CollisionRectToRect(_Left, _Right) {
		if (_Left.Bot() <= _Right.Top()) {
			return false;
		}
		if (_Left.Top() >= _Right.Bot()) {
			return false;
		}
		if (_Left.Left() >= _Right.Right()) {
			return false;
		}
		if (_Left.Right() <= _Right.Left()) {
			return false;
		}
		return true;
	}

	static CollisionRectToPoint(_Left, _Right) {
		if (_Left.Bot() <= _Right.Position.y) {
			return false;
		}
		if (_Left.Top() >= _Right.Position.y) {
			return false;
		}
		if (_Left.Left() >= _Right.Position.x) {
			return false;
		}
		if (_Left.Right() <= _Right.Position.x) {
			return false;
		}
		return true;
	}

	SetOrder(_Order) {
		this.GetActor().GetLevel().PushCollision(this, _Order);
	}

	// Collision(parameter) / Collision(parameter, outArray)
	Collision(...args) {
		const _Parameter = args[0];
		if (1 === args.length) {
			if (false === this.IsUpdate()) {
				return false;
			}

			const _TargetGroup = this.GetActor().GetLevel().GetCollisionGroup(_Parameter.TargetGroup);

			for (const OtherCollision of _TargetGroup) {
				if (OtherCollision === this) {
					continue;
				}
				if (false === OtherCollision.IsUpdate()) {
					continue;
				}
				const Type = _Parameter.ThisColType;
				const OtherType = _Parameter.TargetColType;
				if (null == ColFunctionPtr[Type] || null == ColFunctionPtr[Type][OtherType]) {
					MsgAssert("지원 하지않는 충돌 함수이거나 잘못 된 충돌 타입입니다");
				}
				if (ColFunctionPtr[Type] && ColFunctionPtr[Type][OtherType] && true === ColFunctionPtr[Type][OtherType](this.GetCollisionData(), OtherCollision.GetCollisionData())) {
					return true;
				}
			}
			return false;
		}

		const _Collision = args[1];
		if (false === this.IsUpdate()) {
			return false;
		}

		_Collision.length = 0;

		const _TargetGroup = this.GetActor().GetLevel().GetCollisionGroup(_Parameter.TargetGroup);

		this.SetDebugRenderType(_Parameter.ThisColType);

		for (const OtherCollision of _TargetGroup) {
			if (false === OtherCollision.IsUpdate()) {
				continue;
			}
			const Type = _Parameter.ThisColType;
			const OtherType = _Parameter.TargetColType;

			OtherCollision.SetDebugRenderType(OtherType);

			if (null == ColFunctionPtr[Type] || null == ColFunctionPtr[Type][OtherType]) {
				MsgAssert("지원 하지않는 충돌 함수이거나 잘못 된 충돌 타입입니다");
			}
			if (ColFunctionPtr[Type] && ColFunctionPtr[Type][OtherType] && true === ColFunctionPtr[Type][OtherType](this.GetCollisionData(), OtherCollision.GetCollisionData())) {
				_Collision.push(OtherCollision);
			}
		}

		return 0 !== _Collision.length;
	}

	GetCollisionData() {
		const Data = new CollisionData();
		Data.Position = this.GetActorPlusPos();
		Data.Scale = this.GetScale();
		return Data;
	}

	SetDebugRenderType(_DebugRenderType) {
		this.DebugRenderType = _DebugRenderType;
	}

	DebugRender() {
		const BackBufferDc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
		const DebugRenderPos = this.GetActorPlusPos().sub(this.GetActor().GetLevel().GetCameraPos());
		switch (this.DebugRenderType) {
			case CollisionType.CT_Point:
				break;
			case CollisionType.CT_CirCle:
				{
					const Radius = this.GetScale().hix();
					BackBufferDc.beginPath();
					BackBufferDc.ellipse(
						DebugRenderPos.ix(), DebugRenderPos.iy(),
						Radius, Radius, 0, 0, Math.PI * 2
					);
					BackBufferDc.stroke();
					break;
				}
			case CollisionType.CT_Rect:
				{
					BackBufferDc.strokeRect(
						DebugRenderPos.ix() - this.GetScale().hix(),
						DebugRenderPos.iy() - this.GetScale().hiy(),
						this.GetScale().ix(), this.GetScale().hiy()
					);
					break;
				}
			case CollisionType.CT_Max:
				break;
			default:
				break;
		}
	}
}

// 원본: 정적 충돌 함수 테이블 초기화 — C++의 정적 초기화 순서(클래스 정의 이후)와 동일하게 클래스 선언 뒤에서 실행
const Init = new CollisionFunctionInit();

__PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"] = {"CollisionType": CollisionType, "CollisionCheckParameter": CollisionCheckParameter, "CollisionData": CollisionData, "GameEngineCollision": GameEngineCollision};
})();
(function () {

// ===== GameEngineCore/GameEngineLevel.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// GameEngineLevel.h / GameEngineLevel.cpp 의 전사

class GameEngineLevel extends GameEngineObject {
	static IsDebugRender = false;
	static TextOutStart = new float4(0, 0, 0, 1);
	static DebugTexts = [];

	static DebugRenderSwitch() {
		GameEngineLevel.IsDebugRender = !GameEngineLevel.IsDebugRender;
	}

	static DebugTextPush(_DebugText) {
		GameEngineLevel.DebugTexts.push(_DebugText);
	}

	constructor() {
		super();
		this.CameraPos = new float4(0, 0, 0, 1); // float4::Zero
		this.Actors = new Map();      // int → Array<GameEngineActor>
		this.Renders = new Map();     // int → Array<GameEngineRender>
		this.Collisions = new Map();  // int → Array<GameEngineCollision>
		this.TimeScales = new Map();  // int → float
	}

	// std::map<K,V>::operator[] 대응 — 없으면 만들어 꺼낸다
	static GroupRef(MapRef, _Key) {
		if (false === MapRef.has(_Key)) {
			MapRef.set(_Key, []);
		}
		return MapRef.get(_Key);
	}

	GetMousePos() {
		return GameEngineWindow.GetMousePosition();
	}

	GetMousePosToCamera() {
		return GameEngineWindow.GetMousePosition().add(this.CameraPos);
	}

	SetCameraMove(_MoveValue) {
		this.CameraPos = this.CameraPos.add(_MoveValue);
	}

	SetCameraPos(_CameraPos) {
		this.CameraPos = _CameraPos;
	}

	GetCameraPos() {
		return this.CameraPos;
	}

	GetConvertActors(_GroupIndex) {
		return this.GetActors(_GroupIndex);
	}

	GetActors(_GroupIndex) {
		const Result = [];
		const Group = GameEngineLevel.GroupRef(this.Actors, _GroupIndex);
		for (const ActorPtr of Group) {
			Result.push(ActorPtr);
		}
		return Result;
	}

	SetTimeScale(_GroupIndex, _Time) {
		this.TimeScales.set(_GroupIndex, _Time);
	}

	Loading() {
	}

	Update(_DeltaTime) {
	}

	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	CreateActor(ActorType, _Order = 0) {
		const Actor = new ActorType();
		this.ActorStart(Actor, _Order);
		GameEngineLevel.GroupRef(this.Actors, _Order).push(Actor);
		return Actor;
	}

	ActorStart(_Actor, _Order) {
		if (null === _Actor) {
			MsgAssert("nullptr 액터를 Start하려고 했습니다.");
			return;
		}
		_Actor.SetOwner(this);
		_Actor.SetOrder(_Order);
		_Actor.Start();
	}

	ActorsUpdate(_DeltaTime) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				let CurTimeScale = 1.0;
				if (this.TimeScales.has(Order)) {
					CurTimeScale = this.TimeScales.get(Order);
				}
				for (const Actor of ActorList) {
					if (null === Actor || false === Actor.IsUpdate()) {
						continue;
					}
					Actor.TimeScale = CurTimeScale;
					Actor.LiveTime += _DeltaTime;
					Actor.Update(_DeltaTime * CurTimeScale);
				}
			}
		}
	}

	Release() {
		{
			const GroupKeys = [...this.Collisions.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const CollisionList = this.Collisions.get(Order);
				for (let i = CollisionList.length - 1; i >= 0; i--) {
					const ReleaseCollision = CollisionList[i];
					if (null !== ReleaseCollision && false === ReleaseCollision.IsDeath()) {
						continue;
					}
					CollisionList.splice(i, 1);
				}
			}
		}

		{
			const GroupKeys = [...this.Renders.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const RenderList = this.Renders.get(Order);
				for (let i = RenderList.length - 1; i >= 0; i--) {
					const ReleaseRender = RenderList[i];
					if (null !== ReleaseRender && false === ReleaseRender.IsDeath()) {
						continue;
					}
					RenderList.splice(i, 1);
				}
			}
		}

		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (let i = ActorList.length - 1; i >= 0; i--) {
					const ReleaseActor = ActorList[i];
					if (null !== ReleaseActor && false === ReleaseActor.IsDeath()) {
						ReleaseActor.Release();
						continue;
					}
					ActorList.splice(i, 1);
				}
			}
		}
	}

	ActorsRender(_DeltaTime) {
		{
			const GroupKeys = [...this.Renders.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const RenderList = this.Renders.get(Order);
				for (const Renderer of RenderList) {
					if (null === Renderer || false === Renderer.IsUpdate()) {
						continue;
					}
					Renderer.Render(_DeltaTime * Renderer.GetActor().TimeScale);
				}
			}
		}

		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					if (null === Actor || false === Actor.IsUpdate()) {
						continue;
					}
					// C++ 의 Actor->Render() 는 가상함수 호출이라 데이터 멤버에 가려지지 않는다
					// (예: TitleBackground 의 GameEngineRender* Render 멤버 — 원본 .h 23행).
					// JS 에서는 인스턴스 프로퍼티가 메서드를 가릴 수 있으므로, 원본 가상 호출
					// 의미대로 프로토타입 체인의 메서드를 직접 호출한다.
					const ActorRender = Object.getPrototypeOf(Actor).Render;
					ActorRender.call(Actor, _DeltaTime);
				}
			}
		}

		{
			if (true === GameEngineLevel.IsDebugRender) {
				const GroupKeys = [...this.Collisions.keys()].sort((a, b) => a - b);
				for (const Order of GroupKeys) {
					const CollisionList = this.Collisions.get(Order);
					for (const DebugCollision of CollisionList) {
						if (null === DebugCollision || false === DebugCollision.IsUpdate()) {
							continue;
						}
						DebugCollision.DebugRender();
					}
				}
			}
		}

		{
			GameEngineLevel.TextOutStart = new float4(0, 0, 0, 1);
			for (let i = 0; i < GameEngineLevel.DebugTexts.length; i++) {
				const ImageDc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
				ImageDc.font = "15px sans-serif";
				ImageDc.textBaseline = "top";
				ImageDc.textAlign = "left";
				ImageDc.fillStyle = "#ffffff";
				ImageDc.fillText(GameEngineLevel.DebugTexts[i], GameEngineLevel.TextOutStart.ix(), GameEngineLevel.TextOutStart.iy());
				GameEngineLevel.TextOutStart = GameEngineLevel.TextOutStart.add(new float4(0, 20.0, 0, 0));
			}
			GameEngineLevel.DebugTexts.length = 0;
		}
	}

	ActorLevelChangeEnd(_NextLevel) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					Actor.LevelChangeEnd(_NextLevel);
				}
			}
		}
	}

	ActorLevelChangeStart(_PrevLevel) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					Actor.LevelChangeStart(_PrevLevel);
				}
			}
		}
	}

	PushRender(_Render, _ChangeOrder) {
		const OldGroup = this.Renders.get(_Render.GetOrder());
		if (undefined !== OldGroup && null !== OldGroup) {
			const idx = OldGroup.indexOf(_Render);
			if (-1 !== idx) {
				OldGroup.splice(idx, 1);
			}
		}

		// 원본: _Render->GameEngineObject::SetOrder(_ChangeOrder);
		_Render.Order = _ChangeOrder;

		if (null === _Render) {
			MsgAssert("nullptr이 있는 렌더를 렌더 그룹에 넣지 말아 주세요.");
		}

		GameEngineLevel.GroupRef(this.Renders, _Render.GetOrder()).push(_Render);
	}

	PushCollision(_Collision, _ChangeOrder) {
		const OldGroup = this.Collisions.get(_Collision.GetOrder());
		if (undefined !== OldGroup && null !== OldGroup) {
			const idx = OldGroup.indexOf(_Collision);
			if (-1 !== idx) {
				OldGroup.splice(idx, 1);
			}
		}

		// 원본: _Collision->GameEngineObject::SetOrder(_ChangeOrder);
		_Collision.Order = _ChangeOrder;

		if (null === _Collision) {
			MsgAssert("nullptr인 충돌체를 충돌 그룹에 넣지 말아 주세요.");
		}

		GameEngineLevel.GroupRef(this.Collisions, _Collision.GetOrder()).push(_Collision);
	}

	GetCollisionGroup(_TargetGroup) {
		return GameEngineLevel.GroupRef(this.Collisions, _TargetGroup);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['DebugRenderSwitch', 'DebugTextPush', 'GroupRef']) {
	Object.defineProperty(GameEngineLevel.prototype, __m, { value: function (...args) { return GameEngineLevel[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"] = {"GameEngineLevel": GameEngineLevel};
})();
(function () {

// ===== GameEnginePlatform/GameEngineSound.js =====
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
// GameEngineSound.h / GameEngineSound.cpp 의 전사
// FMOD 대신 HTMLAudioElement를 사용한다. SoundLoad는 FMOD_LOOP_NORMAL로 로드하므로
// 기본 loop = true 이며, GameEngineResources.SoundPlay 가 채널에 setLoopCount(0)을
// 호출해 한 번만 재생된다(원본 의미 동일).

class GameEngineSound {
	constructor() {
		this.audio = null;   // 원본: FMOD::Sound*
	}

	static SoundUpdate() {
		// 원본: SoundSystem->update() — 브라우저에서는 불필요
	}

	SoundLoad(_Path) {
		const Url = GameEngineSound.ResolveSoundUrl(_Path);
		const Preloaded = (window.PM2_PRELOADED && window.PM2_PRELOADED.sounds) ? window.PM2_PRELOADED.sounds.get(Url.toLowerCase()) : null;
		if (null !== Preloaded && undefined !== Preloaded) {
			this.audio = Preloaded;
		} else {
			this.audio = new Audio(Url);
		}
		if (null === this.audio) {
			MsgAssert(`사운드 로드에 실패했습니다.\n 경로 : ` + _Path);
		}
	}

	Play() {
		if (null === this.audio) {
			MsgAssert(`FMODSound가 nullptr 입니다 `);
		}
		const Ch = new SoundChannel(this.audio);
		Ch.Play();
		return Ch;
	}
}

GameEngineSound.ResolveSoundUrl = function (_Path) {
	let p = String(_Path).replace(/\\/g, "/").replace(/\/{2,}/g, "/");
	if (p.startsWith("./")) {
		p = p.slice(2);
	}
	while (p.startsWith("/")) {
		p = p.slice(1); // 웹 루트 기준 상대 경로로 정규화
	}
	if (window.PM2_MANIFEST_PATHS) {
		const lower = p.toLowerCase();
		const Found = window.PM2_MANIFEST_PATHS.find((x) => x.toLowerCase() === lower);
		if (Found) {
			p = Found;
		}
	}
	return p;
};

// FMOD::Channel* 대응
class SoundChannel {
	constructor(_Audio) {
		this.audio = _Audio; // 사운드 원본(프리로드된 엘리먼트)
		this.node = null;    // 재생 중인 클론
		this.LoopMode = true; // FMOD_LOOP_NORMAL
	}

	Play() {
		this.node = this.audio.cloneNode(false);
		this.node.loop = this.LoopMode;
		this.node.volume = 1.0;
		const p = this.node.play();
		if (p !== undefined) {
			p.catch(() => {
				// 브라우저 자동재생 정책: 첫 사용자 입력 전에는 재생이 거부될 수 있다.
				this._Pending = true;
			});
		}
		return this.node;
	}

	setLoopCount(_Count) {
		if (null === this.node) { return; }
		if (_Count <= 0) {
			this.node.loop = false; // 원본: setLoopCount(0) → 현재 재생 후 정지
		} else {
			this.node.loop = true;
		}
	}

	setVolume(_Volume) {
		if (null === this.node) { return; }
		this.node.volume = Math.max(0, Math.min(1, _Volume));
	}

	stop() {
		if (null === this.node) { return; }
		this.node.pause();
		this.node.currentTime = 0;
	}
}

__PM2_EXPORTS__["GameEnginePlatform/GameEngineSound.js"] = {"GameEngineSound": GameEngineSound, "SoundChannel": SoundChannel};
})();
(function () {

// ===== GameEngineCore/GameEngineResources.js =====
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineImage = __PM2_EXPORTS__["GameEnginePlatform/GameEngineImage.js"]["GameEngineImage"];
var GameEngineSound = __PM2_EXPORTS__["GameEnginePlatform/GameEngineSound.js"]["GameEngineSound"];
var SoundChannel = __PM2_EXPORTS__["GameEnginePlatform/GameEngineSound.js"]["SoundChannel"];
// GameEngineResources.h / GameEngineResources.cpp 의 전사

class GameEngineSoundPlayer {
	constructor(_Channel = null) {
		this.ControlChannel = _Channel;
	}

	LoopCount(_Count) {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.setLoopCount(_Count - 1);
	}

	Volume(_Volume) {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.setVolume(_Volume);
	}

	Stop() {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.stop();
	}
}

class GameEngineResources {
	static Inst = new GameEngineResources();

	constructor() {
		this.AllImage = new Map();
		this.AllSound = new Map();
	}


	// 원본은 파일시스템의 .bmp 파일을 그대로 사용했으나, 웹 빌드는 무손실 .png로 변환한다.
	// 코드는 원본 그대로 .bmp로 참조하므로 저장/조회 키를 하나의 표기로 정규화한다(.PNG → .BMP).
	static KeyOf(_Name) {
		return GameEngineString.ToUpper(_Name).replace(/\.PNG$/, ".BMP");
	}

	static GetInst() {
		return this.Inst;
	}

	Relase() {
		for (const [, Pair] of this.AllImage) {
			if (null === Pair) {
				continue;
			}
		}
		this.AllImage.clear();

		for (const [, Pair] of this.AllSound) {
			if (null === Pair) {
				continue;
			}
		}
		this.AllSound.clear();
	}

	ImageLoad(_Path, _Name) {
		// 원본 오버로딩: ImageLoad(GameEnginePath) → (path, filename)
		if (undefined === _Name || null === _Name) {
			const PathStr = "string" === typeof _Path ? _Path : _Path.GetPathToString();
			const FileName = "string" === typeof _Path ? _Path.split("/").pop() : _Path.GetFileName();
			return this.ImageLoad(PathStr, FileName);
		}

		const UpperName = GameEngineResources.KeyOf(_Name);
		if (this.AllImage.has(UpperName)) {
			MsgAssert("이미 로딩된 이미지를 다시 로딩하려고 했습니다." + UpperName);
			return null;
		}

		const NewImage = new GameEngineImage();
		NewImage.ImageLoad("string" === typeof _Path ? _Path : _Path.GetPathToString());
		this.AllImage.set(UpperName, NewImage);
		return NewImage;
	}

	ImageFind(_Name) {
		const UpperName = GameEngineResources.KeyOf(_Name);
		if (false === this.AllImage.has(UpperName)) {
			MsgAssert("로딩되지 않은 이미지를 찾으려고 했습니다" + UpperName);
			return null;
		}
		return this.AllImage.get(UpperName);
	}

	SoundLoad(_Path, _Name) {
		if (undefined === _Name || null === _Name) {
			const PathStr = "string" === typeof _Path ? _Path : _Path.GetPathToString();
			const FileName = "string" === typeof _Path ? _Path.split("/").pop() : _Path.GetFileName();
			return this.SoundLoad(PathStr, FileName);
		}

		const UpperName = GameEngineResources.KeyOf(_Name);
		if (this.AllSound.has(UpperName)) {
			MsgAssert("이미 로딩된 이미지를 다시 로딩하려고 했습니다." + UpperName);
			return null;
		}

		const NewSound = new GameEngineSound();
		NewSound.SoundLoad("string" === typeof _Path ? _Path : _Path.GetPathToString());
		this.AllSound.set(UpperName, NewSound);
		return NewSound;
	}

	SoundFind(_Name) {
		const UpperName = GameEngineResources.KeyOf(_Name);
		if (false === this.AllSound.has(UpperName)) {
			MsgAssert("로딩되지 않은 이미지를 찾으려고 했습니다" + UpperName);
			return null;
		}
		return this.AllSound.get(UpperName);
	}

	SoundPlay(_Name) {
		const Sound = this.SoundFind(_Name);
		const Ch = Sound.Play();
		Ch.setLoopCount(0);
	}

	SoundPlayToControl(_Name) {
		const Sound = this.SoundFind(_Name);
		return new GameEngineSoundPlayer(Sound.Play());
	}
}

__PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"] = {"GameEngineSoundPlayer": GameEngineSoundPlayer, "GameEngineResources": GameEngineResources};
})();
(function () {

// ===== GameEngineCore/GameEngineCore.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineDebug = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["GameEngineDebug"];
var GameEngineTime = __PM2_EXPORTS__["GameEngineBase/GameEngineTime.js"]["GameEngineTime"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineSound = __PM2_EXPORTS__["GameEnginePlatform/GameEngineSound.js"]["GameEngineSound"];
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
// GameEngineCore.h / GameEngineCore.cpp 의 전사

let Core = null;

class GameEngineCore {
	constructor() {
		GameEngineDebug.LeakCheck();
		Core = this;
		this.Levels = new Map();
		this.MainLevel = null;
		this.NextLevel = null;
		this.IsDebugValue = false;
	}

	static GetInst() {
		return Core;
	}

	DebugSwitch() {
		this.IsDebugValue = !this.IsDebugValue;
	}

	SetDebugMode(_IsDebug) {
		this.IsDebugValue = _IsDebug;
	}

	IsDebug() {
		return this.IsDebugValue;
	}

	CreateLevel(_Name, LevelType) {
		if (this.Levels.has(_Name)) {
			MsgAssert(`${_Name}이미 존재하는 이름의 레벨을 생성하려고 했습니다`);
			return;
		}
		const Level = new LevelType();
		this.LevelLoading(Level, _Name);
		this.Levels.set(_Name, Level);
	}

	ChangeLevel(_Name) {
		if (false === this.Levels.has(_Name)) {
			MsgAssert(`${_Name}존재하지 않는 레벨을 변경키려고 했습니다`);
			return;
		}
		this.NextLevel = this.Levels.get(_Name);
	}

	LevelLoading(_Level, _Name) {
		if (null === _Level) {
			MsgAssert("nullptr 은 레벨을 로딩하려고 했습니다.");
			return;
		}
		_Level.SetName(_Name);
		_Level.Loading();
	}

	CoreStart(_instance) {
		if (false === GameEngineInput.IsKey("EngineMouseLeft")) {
			GameEngineInput.CreateKey("EngineMouseLeft", 0x01); // VK_LBUTTON
			GameEngineInput.CreateKey("EngineMouseRight", 0x02); // VK_RBUTTON
		}

		GameEngineWindow.WindowCreate(_instance, "PrincessMaker2", new float4(800, 600), new float4(0, 0));
		GameEngineWindow.WindowLoop(GameEngineCore.GlobalStart, GameEngineCore.GlobalUpdate, GameEngineCore.GlobalEnd);
	}

	static GlobalStart() {
		Core.Start();
		GameEngineTime.GlobalTime.Reset();
	}

	static GlobalUpdate() {
		if (null !== Core.NextLevel) {
			const PrevLevel = Core.MainLevel;
			const NextLevel = Core.NextLevel;

			if (null !== PrevLevel) {
				PrevLevel.LevelChangeEnd(NextLevel);
				PrevLevel.ActorLevelChangeEnd(NextLevel);
			}

			Core.MainLevel = NextLevel;
			Core.NextLevel = null;

			if (null !== NextLevel) {
				NextLevel.LevelChangeStart(PrevLevel);
				NextLevel.ActorLevelChangeStart(PrevLevel);
			}
		}

		GameEngineSound.SoundUpdate();
		const TimeDeltaTime = GameEngineTime.GlobalTime.TimeCheck();
		GameEngineInput.Update(TimeDeltaTime);

		Core.Update();
		if (null === Core.MainLevel) {
			MsgAssert("멤버 레벨이 없는 상태로 레벨매니저를 업데이트 했습니다");
			return;
		}

		Core.MainLevel.Update(TimeDeltaTime);
		Core.MainLevel.ActorsUpdate(TimeDeltaTime);
		GameEngineWindow.DoubleBufferClear();
		Core.MainLevel.ActorsRender(TimeDeltaTime);
		GameEngineWindow.DoubleBufferRender();
		Core.MainLevel.Release();
	}

	static GlobalEnd() {
		Core.End();
		GameEngineResources.GetInst().Relase();
	}

	Start() {
	}

	Update() {
	}

	End() {
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetInst', 'GlobalStart', 'GlobalUpdate', 'GlobalEnd']) {
	Object.defineProperty(GameEngineCore.prototype, __m, { value: function (...args) { return GameEngineCore[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"] = {"GameEngineCore": GameEngineCore};
})();
(function () {

// ===== GameEngineCore/GameEngineRender.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineComponent = __PM2_EXPORTS__["GameEngineCore/GameEngineComponent.js"]["GameEngineComponent"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var ColorRefToCss = __PM2_EXPORTS__["WinAPI.js"]["ColorRefToCss"];
// GameEngineRender.h / GameEngineRender.cpp 의 전사

// enum class TextAlign { Left = DT_LEFT, Right = DT_RIGHT, Center = DT_CENTER }
const TextAlign = Object.freeze({
	Left: 0,  // DT_LEFT
	Right: 2, // DT_RIGHT
	Center: 1 // DT_CENTER
});

class FrameAnimationParameter {
	constructor(AnimationName = "", ImageName = "", Start = 0, End = 0, CurrentIndex = 0, InterTime = 0.1, Loop = true, FrameIndex = [], FrameTime = []) {
		this.AnimationName = AnimationName;
		this.ImageName = ImageName;
		this.Start = Start;
		this.End = End;
		this.CurrentIndex = CurrentIndex;
		this.InterTime = InterTime;
		this.Loop = Loop;
		this.FrameIndex = FrameIndex;
		this.FrameTime = FrameTime;
	}
}

class GameEngineRender extends GameEngineComponent {
	constructor() {
		super();
		this.Image = null;
		this.IsEffectCamera = true;
		this.TransColor = 0xff00ff; // RGB(255, 0, 255)
		this.Frame = 0;
		this.Alpha = 255;
		this.Animation = new Map();
		this.CurrentAnimation = null;
		this.RenderText = "";
		this.TextHeight = 0;
		this.TextType = "";
		this.Align = TextAlign.Left;
		this.TextColor = RGB(0, 0, 0);
		this.TextBoxScale = new float4(0, 0, 0, 1);
	}

	GetImage() {
		return this.Image;
	}

	GetFrame() {
		return this.Frame;
	}

	GetTextBoxScale() {
		return this.TextBoxScale;
	}

	SetTransColor(_Color) {
		this.TransColor = _Color;
	}

	SetEffectCamera(_Effect) {
		this.IsEffectCamera = _Effect;
	}

	EffectCameraOff() {
		this.SetEffectCamera(false);
	}

	EffectCameraOn() {
		this.SetEffectCamera(true);
	}

	GetTextHeight() {
		return this.TextHeight;
	}

	SetAlpha(_Alpha) {
		this.Alpha = _Alpha;
	}

	SetTextBoxScale(_TextBoxScale) {
		this.TextBoxScale = _TextBoxScale;
	}

	SetImage(_ImageName) {
		this.Image = GameEngineResources.GetInst().ImageFind(_ImageName);
	}

	SetImageToScaleToImage(_ImageName) {
		this.Image = GameEngineResources.GetInst().ImageFind(_ImageName);
		this.SetScaleToImage();
	}

	SetScaleToImage() {
		if (null === this.Image) {
			MsgAssert("이미지가 할당되지 않았는데 이미지의 크기를 변경하려고 했습니다.");
		}
		this.SetScale(this.Image.GetImageScale());
	}

	SetOrder(_Order) {
		// 원본: GetActor()->GetLevel()->PushRender(this, _Order);
		const Level = this.GetActor().GetLevel();
		if (null !== Level && undefined !== Level) {
			Level.PushRender(this, _Order);
		} else {
			this.Order = _Order;
		}
	}

	SetFrame(_Frame) {
		if (null === this.Image) {
			MsgAssert("이미지가 설정되지 않는 렌더러가 프레임을 변경하려고 했습니다.");
		}
		if (false === this.Image.IsImageCutting()) {
			MsgAssert("잘라놓은 이미지가 아니면 프레임을 지정할 수  없습니다.");
		}
		if (false === this.Image.IsCutIndexValid(_Frame)) {
			MsgAssert("범위를 벗어난 이미지인덱스 입니다.");
		}
		this.Frame = _Frame;
	}

	IsAnimationEnd() {
		return this.CurrentAnimation.IsEnd();
	}

	CreateAnimation(_Paramter) {
		const Image = GameEngineResources.GetInst().ImageFind(_Paramter.ImageName);
		if (null === Image) {
			MsgAssert("존재하지 않는 이미지로 애니메이션을 만들려고 했습니다.");
		}
		if (false === Image.IsImageCutting()) {
			MsgAssert("잘라놓은 이미지가 아니면 애니메이션을 만들 수 없습니다.");
		}
		const UpperName = GameEngineString.ToUpper(_Paramter.AnimationName);
		if (this.Animation.has(UpperName)) {
			MsgAssert("이미 존재하는 이름의 애니메이션 입니다." + UpperName);
		}

		const NewAnimation = new GameEngineRender.FrameAnimation();
		this.Animation.set(UpperName, NewAnimation);

		NewAnimation.Image = Image;

		if (0 !== _Paramter.FrameIndex.length) {
			NewAnimation.FrameIndex = _Paramter.FrameIndex.slice();
		} else {
			for (let i = _Paramter.Start; i <= _Paramter.End; ++i) {
				NewAnimation.FrameIndex.push(i);
			}
		}

		if (0 !== _Paramter.FrameTime.length) {
			NewAnimation.FrameTime = _Paramter.FrameTime.slice();
		} else {
			for (let i = 0; i < NewAnimation.FrameIndex.length; ++i) {
				NewAnimation.FrameTime.push(_Paramter.InterTime);
			}
		}

		NewAnimation.Loop = _Paramter.Loop;
		NewAnimation.Parent = this;
	}

	ChangeAnimation(_AnimationName, _ForceChange = false) {
		const UpperName = GameEngineString.ToUpper(_AnimationName);
		if (false === this.Animation.has(UpperName)) {
			MsgAssert("존재하지 않는 애니메이션으로 바꾸려고 했습니다." + UpperName);
		}
		if (false === _ForceChange && this.CurrentAnimation === this.Animation.get(UpperName)) {
			return;
		}
		this.CurrentAnimation = this.Animation.get(UpperName);
		this.CurrentAnimation.CurrentIndex = 0;
		this.CurrentAnimation.CurrentTime = this.CurrentAnimation.FrameTime[this.CurrentAnimation.CurrentIndex];
	}

	SetText(_Text, _TextHeight = 20, _TextType = "바탕", _TextAlign = TextAlign.Center, _TextColor = RGB(0, 0, 0), _TextBoxScale = new float4(0, 0, 0, 1)) {
		this.RenderText = _Text;
		this.TextHeight = _TextHeight;
		this.TextType = _TextType;
		this.Align = _TextAlign;
		this.TextColor = _TextColor;
		this.TextBoxScale = _TextBoxScale;
	}

	Render(_DeltaTime) {
		if (this.RenderText !== "") {
			this.TextRender(_DeltaTime);
		} else {
			this.ImageRender(_DeltaTime);
		}
	}

	TextRender(_DeltaTime) {
		let CameraPos = new float4(0, 0, 0, 1);
		if (true === this.IsEffectCamera) {
			CameraPos = this.GetActor().GetLevel().GetCameraPos();
		}
		const RenderPos = this.GetActorPlusPos().sub(CameraPos);

		const hdc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();

		// 원본: LOGFONTA(HANGEUL_CHARSET) + DrawTextA(Rect, Align)
		hdc.font = `${this.TextHeight}px "${this.TextType}", "바탕", sans-serif`;
		hdc.textBaseline = "top";
		hdc.fillStyle = ColorRefToCss(this.TextColor);

		const Left = RenderPos.ix();
		const Top = RenderPos.iy();
		const Right = RenderPos.ix() + this.TextBoxScale.ix();
		const Bottom = RenderPos.iy() + this.TextBoxScale.iy();

		if (GameEngineCore.GetInst().IsDebug()) {
			// 원본: 점선 사각형 테두리
			hdc.strokeStyle = "rgb(255, 0, 255)";
			hdc.setLineDash([4, 3]);
			hdc.strokeRect(Left, Top, Right - Left, Bottom - Top);
			hdc.setLineDash([]);
		}

		switch (this.Align) {
			case TextAlign.Left:
				hdc.textAlign = "left";
				hdc.fillText(this.RenderText, Left, Top);
				break;
			case TextAlign.Center:
				hdc.textAlign = "center";
				hdc.fillText(this.RenderText, Left + (Right - Left) / 2, Top);
				break;
			case TextAlign.Right:
				hdc.textAlign = "right";
				hdc.fillText(this.RenderText, Right, Top);
				break;
		}
	}

	ImageRender(_DeltaTime) {
		if (null !== this.CurrentAnimation) {
			this.CurrentAnimation.Render(_DeltaTime);
			this.Frame = this.CurrentAnimation.FrameIndex[this.CurrentAnimation.CurrentIndex];
			this.Image = this.CurrentAnimation.Image;
		}

		if (null === this.Image) {
			MsgAssert("이미지가 설정되지 않았습니다.");
		}

		let CameraPos = new float4(0, 0, 0, 1);
		if (true === this.IsEffectCamera) {
			CameraPos = this.GetActor().GetLevel().GetCameraPos();
		}

		const RenderPos = this.GetActorPlusPos().sub(CameraPos);

		const DoubleImage = GameEngineWindow.GetDoubleBufferImage();

		if (true === this.Image.IsImageCutting()) {
			if (255 === this.Alpha) {
				DoubleImage.TransCopy(this.Image, this.Frame, RenderPos, this.GetScale(), this.TransColor);
			} else if (255 > this.Alpha) {
				DoubleImage.AlphaCopy(this.Image, this.Frame, RenderPos, this.GetScale(), this.Alpha);
			}
		} else {
			if (255 === this.Alpha) {
				DoubleImage.TransCopy(this.Image, RenderPos, this.GetScale(), new float4(0, 0), this.Image.GetImageScale(), this.TransColor);
			} else if (255 > this.Alpha) {
				DoubleImage.AlphaCopy(this.Image, RenderPos, this.GetScale(), new float4(0, 0), this.Image.GetImageScale(), this.Alpha);
			}
		}
	}
}

// 원본 GameEngineRender::FrameAnimation 내부 클래스
GameEngineRender.FrameAnimation = class FrameAnimation {
	constructor() {
		this.Parent = null;
		this.Image = null;
		this.FrameIndex = [];
		this.FrameTime = [];
		this.CurrentIndex = 0;
		this.CurrentTime = 0.0;
		this.Loop = true;
	}

	IsEnd() {
		const Value = (this.FrameIndex.length - 1);
		return this.CurrentIndex === Value;
	}

	Render(_DeltaTime) {
		this.CurrentTime -= _DeltaTime;
		if (this.CurrentTime <= 0.0) {
			++this.CurrentIndex;
			if (this.FrameIndex.length <= this.CurrentIndex) {
				if (true === this.Loop) {
					this.CurrentIndex = 0;
				} else {
					this.CurrentIndex = this.FrameIndex.length - 1;
				}
			}
			this.CurrentTime += this.FrameTime[this.CurrentIndex];
		}
	}

	Reset() {
		this.CurrentIndex = 0;
		this.CurrentTime = 0.0;
	}
};

__PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"] = {"TextAlign": TextAlign, "FrameAnimationParameter": FrameAnimationParameter, "GameEngineRender": GameEngineRender};
})();
(function () {

// ===== GameEngineCore/GameEngineActor.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var GameEngineCollision = __PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"]["GameEngineCollision"];
// GameEngineActor.h / GameEngineActor.cpp 의 전사

class GameEngineActor extends GameEngineObject {
	constructor() {
		super();
		this.TimeScale = 0.0;
		this.LiveTime = 0.0;
		this.Pos = new float4(0.0, 0.0, 0.0, 1.0);
		this.RenderList = [];
		this.CollisionList = [];
	}

	GetPos() {
		return this.Pos;
	}

	SetPos(_MovePos) {
		this.Pos = _MovePos;
	}

	SetMove(_MovePos) {
		this.Pos = this.Pos.add(_MovePos);
	}

	GetLevel() {
		return this.GetOwner();
	}

	CreateRender(_ImageOrOrder, _Order) {
		// 원본 오버로딩: CreateRender(string, int) / CreateRender(int)
		if (null !== _Order && undefined !== _Order) {
			const Render = this.CreateRender(_Order);
			Render.SetImage(_ImageOrOrder);
			return Render;
		}
		const Render = new GameEngineRender();
		Render.SetOwner(this);
		Render.SetOrder(_ImageOrOrder);
		this.RenderList.push(Render);
		return Render;
	}

	CreateCollision(_GroupIndex = 0) {
		const Collision = new GameEngineCollision();
		Collision.SetOwner(this);
		Collision.SetOrder(_GroupIndex);
		this.CollisionList.push(Collision);
		return Collision;
	}

	GetLiveTime() {
		return this.LiveTime;
	}

	LevelChangeEnd(_PrevLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	Release() {
		{
			for (let i = this.RenderList.length - 1; i >= 0; i--) {
				const ReleaseRender = this.RenderList[i];
				if (null === ReleaseRender) {
					MsgAssert("nullptr 는 렌더 리스트에 있어서는 안됩니다.");
				}
				if (false === ReleaseRender.IsDeath()) {
					continue;
				}
				this.RenderList.splice(i, 1);
			}
		}
		{
			for (let i = this.CollisionList.length - 1; i >= 0; i--) {
				const ReleaseCollision = this.CollisionList[i];
				if (null === ReleaseCollision) {
					MsgAssert("nullptr 는 렌더 리스트에 있어서는 안됩니다.");
				}
				if (false === ReleaseCollision.IsDeath()) {
					continue;
				}
				this.CollisionList.splice(i, 1);
			}
		}
	}

	Start() {
	}

	Update(_DeltaTime) {
	}

	LateUpdate(_DeltaTime) {
	}

	Render(_DeltaTime) {
	}
}

__PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"] = {"GameEngineActor": GameEngineActor};
})();
(function () {

// ===== GameEngineContents/Animation.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// Animation.h / Animation.cpp 의 전사

class Animation extends GameEngineActor {
	constructor() {
		super();
		this.AccTime = 0.0;
		this.StartFrame = 0;
		this.MoveSpeed = 100.0;

		this.AnimationRender = null;
		this.Background = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
	}

	Update(_Deltatime) {
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Animation.js"] = {"Animation": Animation};
})();
(function () {

// ===== GameEngineContents/Background.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// Background.h / Background.cpp 의 전사

class Background extends GameEngineActor {
	constructor() {
		super();
		this.BackgroundRender = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("background.BMP", 0);
		this.BackgroundRender.SetScaleToImage();
	}

	Update(_Deltatime) {

	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Background.js"] = {"Background": Background};
})();
(function () {

// ===== GameEngineContents/ContentsEnums.js =====
// ContentsEnums.h 의 전사
// enum class X { ... } → Object.freeze({ "멤버": 값, ... })
// 값: 선언 순서대로 0부터, 명시 초기화가 있으면 그 값(이후 멤버는 +1씩)

const PM2RenderOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

const PM2ActorOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

const PM2CollisionOrder = Object.freeze({
	BackGround: 0,
	BackGroundObj: 1,
	TitleLogo: 2,
	CaptionBox: 3,
	Map: 4,
	Contents: 5,
	Olive: 6,
	Menu0: 7,
	Menu0_Background_1: 8,
	Menu0_Obj_1: 9,
	Menu0_Obj_2: 10,
	Menu0_Background_2: 11,
	Menu0_Button: 12,
	Menu0_StatusGauge: 13,
	Menu0_StatusGauge_1: 14,
	Menu0_StatusGauge_2: 15,
	Menu0_StatusGauge_3: 16,
	Menu0_Display_Effect: 17,
	Menu0_Display_Shadow: 18,
	Menu0_Display: 19,
	Menu1: 20,
	Menu1_Background_1: 21,
	Menu1_Obj_1: 22,
	Menu1_Obj_2: 23,
	Menu1_Background_2: 24,
	Menu1_Button: 25,
	Menu1_StatusGauge: 26,
	Menu1_StatusGauge_1: 27,
	Menu1_StatusGauge_2: 28,
	Menu1_StatusGauge_3: 29,
	Menu1_Display_Effect: 30,
	Menu1_Display_Shadow: 31,
	Menu1_Display: 32,
	Dialog1: 33,
	Dialog1_Display: 34,
	Dialog1_Display_Button: 35,
	Dialog1_MugShotFrame: 36,
	Dialog1_MugShot: 37,
	Menu2: 38,
	Menu2_Background_1: 39,
	Menu2_Obj_1: 40,
	Menu2_Obj_2: 41,
	Menu2_Background_2: 42,
	Menu2_Button: 43,
	Menu2_StatusGauge: 44,
	Menu2_StatusGauge_1: 45,
	Menu2_StatusGauge_2: 46,
	Menu2_StatusGauge_3: 47,
	Menu2_Display_Effect: 48,
	Menu2_Display_Shadow: 49,
	Menu2_Display: 50,
	Dialog2: 51,
	Dialog2_Display: 52,
	Dialog2_Display_Button: 53,
	Dialog2_MugShotFrame: 54,
	Dialog2_MugShot: 55,
	MousePoint: 56
});

// ── 이하 추가 전사: ContentsEnums.h의 나머지 enum들 ──

// enum class IconCode
const IconCode = Object.freeze({
	"Null": -1,

	//무기
	"곤봉": 0,
	"구리검": 1,
	"철제단검": 2,
	"철제장검": 3,
	"양손철검": 4,
	"미스릴검": 5,
	"동방도": 6,
	"은사의검": 7,
	"무신의검": 8,
	"발키리의검": 9,

	//방어구
	"가죽갑옷": 10,
	"쇠사슬갑옷": 11,
	"철갑옷": 12,
	"미스릴갑옷": 13,
	"실크갑옷": 14,

	//아이템
	"쾌유환": 15,
	"폭탄": 16,
	"인형": 17,
	"찻잔": 18,
	"책": 19,
	"시집": 20,
	"정령의반지": 21,
	"유니콘뿔피리": 22,
	"악마의펜던트": 23,
	"비너스목걸이": 24,
	"칠흑의비늘": 25,
	"고양이의눈": 26,
	"드래곤의이빨": 27,
	"인어의눈물": 28,
	"은색모피": 29,
	"유혹의향수": 30,
	"축복의빵가루": 31,
	"귀부인의반지": 32,
	"극락조의알": 33,
	"명장의붓": 34,
	"얼음의조각": 35,
	"무적의반지": 36,
	"왕가의비파": 37,
	"케이크": 38,
	"생선조개": 39, //??
	"고기요리": 40, //??
	"요정의꿀": 41,

	//의류
	"평상복": 42,
	"하복": 43,
	"동복": 44,
	"목면드레스": 45,
	"실크드레스": 46,
	"가죽드레스": 47,
	"가시드레스": 48,
	"경국의로브": 49,
	"빈칸": 50,
	"악마의드레스": 51,
	"용의레오타드": 52,

	//교육
	"자연과학": 53,
	"시문학": 54,
	"신학": 55,
	"군사학": 56,
	"검술": 57,
	"격투술": 58,
	"마법": 59,
	"예법": 60,
	"미술": 61,
	"무용": 62,

	//아르바이트
	"집안일": 63,
	"아이보기": 64,
	"여관": 65,
	"농장": 66,
	"레스토랑": 67,
	"나무꾼": 68,
	"미용실": 69,
	"미장이": 70,
	"사냥꾼": 71,
	"묘지기": 72,
	"가정교사": 73,
	"주점": 74,
	"어둠의주점": 75,
	"어둠의전당": 76,

	//휴식
	"무사수행_동부산림지대": 77,
	"자유행동": 78,
	"바캉스": 79,
	"간호": 80,
	"요양": 81,
	"감시": 82,

	//상점가
	"무기점": 83,
	"의류점": 84,
	"잡화점": 85,
	"병원": 86,

	//수호신
	"태양신_솔": 87,
	"달신_더문": 88,
	"화성신_마르스": 89,
	"수성신_머큐리": 90,
	"목성신_주피터": 91,
	"금성신_비너스": 92,
	"토성신_새턴": 93,
	"천왕성신_우라누스": 94,
	"해왕성신_넵튠": 95,
	"명왕성신_하데스": 96,

	//무사수행
	"서부사막지대": 97,
	"남부폭포지대": 98,
	"북부빙산지대": 99,

	//상태
	"불량상태": 100,
	"질병상태": 101,
	"연애상태": 102,

	//떠돌이행상인
	"고대의우유": 103,
	"풍유환": 104

});

// enum class StatusName
const StatusName = Object.freeze({
	"Null": -1,

	"체력": 0,
	"근력": 1,
	"지능": 2,
	"기품": 3,
	"색기": 4,
	"도덕성": 5,
	"신앙": 6,
	"업보": 7,
	"감수성": 8,
	"스트레스": 9,

	"전사평가": 10,
	"전투기술": 11,
	"공격력": 12,
	"방어력": 13,

	"마법평가": 14,
	"마법기술": 15,
	"마력": 16,
	"항마력": 17,

	"사교평가": 18,
	"예의범절": 19,
	"예술": 20,
	"화술": 21,

	"가사평가": 22,
	"요리": 23,
	"청소세탁": 24,
	"성품": 25,

	"신장": 26,
	"체중": 27,
	"가슴": 28,
	"허리": 29,
	"엉덩이": 30,

	"인맥": 31,

	"모성": 32,
	"왕자관계": 33,
	"아버지관계": 34,
	"집사관계": 35,
	"몬스터살육수": 36,
	"교육및알바횟수": 37,
	"마왕이벤트횟수": 38
});

// enum class BloodType
const BloodType = Object.freeze({
	"Null": -1,
	A: 0,
	B: 1,
	O: 2,
	AB: 3
});

// enum class Zodiac
const Zodiac = Object.freeze({
	"Null": -1,
	"염소자리": 0,
	"물병자리": 1,
	"물고기자리": 2,
	"양자리": 3,
	"황소자리": 4,
	"쌍둥이자리": 5,
	"게자리": 6,
	"사자자리": 7,
	"처녀자리": 8,
	"천칭자리": 9,
	"전갈자리": 10,
	"사수자리": 11
});

// enum class PatronGod
const PatronGod = Object.freeze({
	"Null": -1,
	"태양신_솔": 87,
	"달신_더문": 88,
	"화성신_마르스": 89,
	"수성신_머큐리": 90,
	"목성신_주피터": 91,
	"금성신_비너스": 92,
	"토성신_새턴": 93,
	"천왕성신_우라누스": 94,
	"해왕성신_넵튠": 95,
	"명왕성신_하데스": 96
});

// enum class Diet
const Diet = Object.freeze({
	"Null": -1,
	"무리하지_않는다": 0,
	"어쨌든_튼튼하게": 1,
	"얌전한_아이로": 2,
	"다이어트_시킨다": 3
});

// enum class ScheduleLabel
const ScheduleLabel = Object.freeze({
	"Null": -1,

	//교육
	"자연과학": 0,
	"신학": 1,
	"군사학": 2,
	"검술": 3,
	"격투술": 4,
	"마법": 5,
	"시문학": 6,
	"예법": 7,
	"무용": 8,
	"미술": 9,

	//아르바이트
	"집안일": 10,
	"보모": 11,
	"여관": 12,
	"농장": 13,
	"교회": 14,
	"요리점": 15,
	"나무꾼": 16,
	"미용실": 17,
	"미장이": 18,
	"사냥꾼": 19,
	"묘지기": 20,
	"가정교사": 21,
	"주점": 22,
	"어둠의주점": 23,
	"어둠의전당": 24,

	//무사수행
	"동부수풀지대": 25,
	"남부폭포지대": 26,
	"북부빙산지대": 27,
	"서부사막지대": 28,

	//휴식
	"자유행동": 29,
	"바캉스": 30,
	"간호": 31,
	"요양": 32,
	"감시": 33,

	End: 34

});

// enum class Season
const Season = Object.freeze({
	"Null": -1,
	Spring: 0,
	Summer: 1,
	Fall: 2,
	Winter: 3
});

// ─── 이하: ContentsEnums.h의 나머지 enum들 (기존 파일에 누락되어 h 원문 그대로 전사) ───

// enum class IconCode

__PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"] = {"PM2RenderOrder": PM2RenderOrder, "PM2ActorOrder": PM2ActorOrder, "PM2CollisionOrder": PM2CollisionOrder, "IconCode": IconCode, "StatusName": StatusName, "BloodType": BloodType, "Zodiac": Zodiac, "PatronGod": PatronGod, "Diet": Diet, "ScheduleLabel": ScheduleLabel, "Season": Season};
})();
(function () {

// ===== GameEngineContents/Date.js =====
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
// Date.h / Date.cpp 의 전사
// 주의: JS 내장 Date 와 이름이 같으므로 이 파일 안에서는 내장 Date 를 사용하지 않는다.
// 연산자 대응: operator== → Equals, operator!= → NotEquals, operator> → Greater,
// operator< → Less, operator>= → GreaterEquals, operator<= → LessEquals,
// 전위 operator++ → Increment(), operator+(int) → add(int)

// enum class Week
const Week = Object.freeze({
	Null: -1,
	SUN: 0,
	MON: 1,
	TUE: 2,
	WED: 3,
	THU: 4,
	FRI: 5,
	SAT: 6
});

class Date {
	// 원본: static std::vector<Date> GetOneMonthCalendar(int _YYYY, int _MM);
	static GetOneMonthCalendar(_YYYY, _MM) {
		if (Date.IsOverMonth(_MM)) {
			MsgAssert("입력 가능한 Month의 범위를 벗어났습니다");
		}

		const Value = [];

		if (Date.IsBigMonth(_MM)) {
			// 원본: Value.resize(31);
			for (let i = 0; i < 31; i++) {
				Value.push(new Date());
			}
		}
		else if (2 === _MM) {
			if (Date.IsLeapYear(_YYYY)) {
				// 원본: Value.resize(29);
				for (let i = 0; i < 29; i++) {
					Value.push(new Date());
				}
			}
			else {
				// 원본: Value.resize(28);
				for (let i = 0; i < 28; i++) {
					Value.push(new Date());
				}
			}
		}
		else {
			// 원본: Value.resize(30);
			for (let i = 0; i < 30; i++) {
				Value.push(new Date());
			}
		}

		for (let Day = 1; Day <= Value.length; Day++) {
			Value[Day - 1].SetDate(_YYYY, _MM, Day);
		}

		return Value;
	}

	// 원본: static bool IsOverMonth(int _MM);
	static IsOverMonth(_MM) {
		if (0 < _MM && 13 > _MM) {
			return false;
		}
		return true;
	}

	// 원본: static bool IsOverDay(int _YYYY, int _MM, int _DD);
	static IsOverDay(_YYYY, _MM, _DD) {
		if (1 === _MM ||
			3 === _MM ||
			5 === _MM ||
			7 === _MM ||
			8 === _MM ||
			10 === _MM ||
			12 === _MM) {
			if (0 < _DD && 32 > _DD) {
				return false;
			}
			return true;
		}
		else if (4 === _MM ||
			6 === _MM ||
			9 === _MM ||
			11 === _MM) {
			if (0 < _DD && 31 > _DD) {
				return false;
			}
			return true;
		}
		else {
			if (Date.IsLeapYear(_YYYY)) {
				if (0 < _DD && 30 > _DD) {
					return false;
				}
				return true;
			}
			else {
				if (0 < _DD && 29 > _DD) {
					return false;
				}
				return true;
			}
		}

		return false;
	}

	// 원본: static bool IsLeapYear(int _YYYY);
	static IsLeapYear(_YYYY) {
		if ((0 === (_YYYY % 4) && 0 !== (_YYYY % 100)) || 0 === (_YYYY % 400)) {
			return true;
		}
		return false;
	}

	// 원본: static bool IsBigMonth(int _MM);
	static IsBigMonth(_MM) {
		if (1 === _MM ||
			3 === _MM ||
			5 === _MM ||
			7 === _MM ||
			8 === _MM ||
			10 === _MM ||
			12 === _MM) {
			return true;
		}
		return false;
	}

	// 원본: static int FindFirstWeekday(int _YYYY);
	static FindFirstWeekday(_YYYY) {
		const PrevYear = _YYYY - 1;
		return (PrevYear + ((PrevYear / 4) - (PrevYear / 100) + (PrevYear / 400)) + 1) % 7;
	}

	// 원본: static int GetMonthLenth(int _YYYY, int _MM);
	static GetMonthLenth(_YYYY, _MM) {
		if (Date.IsOverMonth(_MM)) {
			MsgAssert("입력 가능한 Month의 범위를 벗어났습니다");
		}

		if (Date.IsBigMonth(_MM)) {
			return 31;
		}
		else if (2 === _MM) {
			if (Date.IsLeapYear(_YYYY)) {
				return 29;
			}
			else {
				return 28;
			}
		}
		else {
			return 30;
		}
	}

	// 원본: static std::vector<int> GetMonthLenths(int _YYYY);
	static GetMonthLenths(_YYYY) {
		const Result = [];
		// 원본: Result.resize(12);
		for (let i = 0; i < 12; i++) {
			Result.push(0);
		}
		for (let i = 0; i < Result.length; i++) {
			Result[i] = Date.GetMonthLenth(_YYYY, i + 1);
		}
		return Result;
	}

	// 원본: static int FindMonthFirstWeekday(int _YYYY, int _MM);
	static FindMonthFirstWeekday(_YYYY, _MM) {
		if (true === Date.IsOverMonth(_MM)) {
			MsgAssert("입력가능한 Month의 범위를 벗어났습니다");
			return 0;
		}

		let Year = _YYYY;
		let Month = 1;
		// 원본: int MonthLen[12] = {};
		const MonthLen = new Array(12).fill(0);
		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			if (2 === Month) {
				if (Date.IsLeapYear(Year)) {
					MonthLen[i] = 29;
				}
				else {
					MonthLen[i] = 28;
				}
			}
			else if (4 === Month ||
				6 === Month ||
				9 === Month ||
				11 === Month) {
				MonthLen[i] = 30;
			}
			else {
				MonthLen[i] = 31;
			}
			Month++;
		}
		let WholeDay = 0;
		for (let i = 0; i < (_MM - 1); i++) {
			WholeDay += MonthLen[i];
		}
		return (Date.FindFirstWeekday(_YYYY) + WholeDay) % 7;
	}

	// 원본: static Week GetWeekDay(int _YYYY, int _MM, int _DD);
	static GetWeekDay(_YYYY, _MM, _DD) {
		const ThisMonthFirstWeekDay = Date.FindMonthFirstWeekday(_YYYY, _MM);
		return (ThisMonthFirstWeekDay + _DD - 1) % 7;
	}

	// 원본: static Date GetMonthLastDate(const Date& _Date);
	static GetMonthLastDate(_Date) {
		return new Date(_Date.Year, _Date.Month, Date.GetMonthLenth(_Date.Year, _Date.Month));
	}

	// 원본: Date(); / Date(int _YYYY, int _MM, int _DD); 두 생성자
	constructor(_YYYY, _MM, _DD) {
		this.Year = 0;
		this.Month = 0;
		this.Day = 0;
		this.WeekDay = Week.Null;
		if (undefined !== _YYYY) {
			this.SetDate(_YYYY, _MM, _DD);
		}
	}

	// 원본: bool IsOverMonth();
	IsOverMonth() {
		if (0 < this.Month && 13 > this.Month) {
			return false;
		}
		return true;
	}

	// 원본: bool IsOverDay();
	IsOverDay() {
		if (1 === this.Month ||
			3 === this.Month ||
			5 === this.Month ||
			7 === this.Month ||
			8 === this.Month ||
			10 === this.Month ||
			12 === this.Month) {
			if (0 < this.Day && 32 > this.Day) {
				return false;
			}
			return true;
		}
		else if (4 === this.Month ||
			6 === this.Month ||
			9 === this.Month ||
			11 === this.Month) {
			if (0 < this.Day && 31 > this.Day) {
				return false;
			}
			return true;
		}
		else {
			if (this.IsLeapYear()) {
				if (0 < this.Day && 30 > this.Day) {
					return false;
				}
				return true;
			}
			else {
				if (0 < this.Day && 29 > this.Day) {
					return false;
				}
				return true;
			}
		}

		return false;
	}

	// 원본: bool IsOverWeekDay();
	IsOverWeekDay() {
		if (0 <= this.Month && 7 > this.Month) {
			return false;
		}
		return true;
	}

	// 원본: bool IsLeapYear();
	IsLeapYear() {
		if ((0 === (this.Year % 4) && 0 !== (this.Year % 100)) || 0 === (this.Year % 400)) {
			return true;
		}
		return false;
	}

	IsNullDate() {
		if (this.Year === 0 ||
			this.Month === 0 ||
			this.Day === 0) {
			return true;
		}
		return false;
	}

	SetWeekDay() {
		const ThisMonthFirstWeekDay = Date.FindMonthFirstWeekday(this.Year, this.Month);
		this.WeekDay = (ThisMonthFirstWeekDay + this.Day - 1) % 7;
	}

	// 원본: void SetDate(const Date& _Date) / void SetDate(int _YYYY, int _MM, int _DD) 오버로드
	SetDate(_YYYY, _MM, _DD) {
		if (_YYYY instanceof Date) {
			const _Date = _YYYY;
			this.SetDate(_Date.Year, _Date.Month, _Date.Day);
			return;
		}

		if (Date.IsOverMonth(_MM) ||
			Date.IsOverDay(_YYYY, _MM, _DD)) {
			MsgAssert("입력가능한 날짜를 벗어났습니다");
		}
		this.Year = _YYYY;
		this.Month = _MM;
		this.Day = _DD;
		this.SetWeekDay();
	}

	SetNullDate() {
		this.Year = 0;
		this.Month = 0;
		this.Day = 0;
		this.WeekDay = Week.Null;
	}

	GetYear() {
		return this.Year;
	}

	GetMonth() {
		return this.Month;
	}

	GetDay() {
		return this.Day;
	}

	// 원본: Week GetWeekDay() const;
	GetWeekDay() {
		return this.WeekDay;
	}

	GetNextDate() {
		const CopyValue = this.copy();
		return CopyValue.Increment();
	}

	// 원본: int FindFirstWeekday(); (인스턴스 버전)
	FindFirstWeekday() {
		const PrevYear = this.Year - 1;
		return (PrevYear + ((PrevYear / 4) - (PrevYear / 100) + (PrevYear / 400)) + 1) % 7;
	}

	// 원본: bool operator== (const Date& _date)
	Equals(_date) {
		return this.Year === _date.Year && this.Month === _date.Month && this.Day === _date.Day;
	}

	// 원본: bool operator!= (const Date& _date)
	NotEquals(_date) {
		return this.Year !== _date.Year || this.Month !== _date.Month || this.Day !== _date.Day;
	}

	// 원본: bool operator> (const Date& _date)
	Greater(_date) {
		if (this.Year > _date.Year) {
			return true;
		}
		else if (this.Year < _date.Year) {
			return false;
		}
		else {
			if (this.Month > _date.Month) {
				return true;
			}
			else if (this.Month < _date.Month) {
				return false;
			}
			else {
				if (this.Day > _date.Day) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}

	// 원본: bool operator< (const Date& _date)
	Less(_date) {
		if (this.Year < _date.Year) {
			return true;
		}
		else if (this.Year > _date.Year) {
			return false;
		}
		else {
			if (this.Month < _date.Month) {
				return true;
			}
			else if (this.Month > _date.Month) {
				return false;
			}
			else {
				if (this.Day < _date.Day) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}

	// 원본: bool operator>= (const Date& _date) { return *this == _date || *this > _date; }
	GreaterEquals(_date) {
		return this.Equals(_date) || this.Greater(_date);
	}

	// 원본: bool operator<= (const Date& _date) { return *this == _date || *this < _date; }
	LessEquals(_date) {
		return this.Equals(_date) || this.Less(_date);
	}

	// 원본: Date& operator ++ ()
	Increment() {
		++this.Day;
		if (this.IsOverDay()) {
			++this.Month;
			this.Day = 1;
			if (this.IsOverMonth()) {
				++this.Year;
				this.Month = 1;
			}
		}
		this.SetWeekDay();

		if (this.IsOverDay() || this.IsOverMonth()) {
			MsgAssert("입력가능한 날짜를 벗어났습니다");
		}
		return this;
	}

	// 원본: Date operator + (int _Value)
	add(_Value) {
		const Result = this.copy();
		for (let i = 0; i < _Value; i++) {
			Result.Increment();
		}

		return Result;
	}

	// 원본: 복사 생성자(*this) 대응
	copy() {
		const CopyValue = new Date();
		CopyValue.Year = this.Year;
		CopyValue.Month = this.Month;
		CopyValue.Day = this.Day;
		CopyValue.WeekDay = this.WeekDay;
		return CopyValue;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetOneMonthCalendar', 'IsOverMonth', 'IsOverDay', 'IsLeapYear', 'IsBigMonth', 'FindFirstWeekday', 'GetMonthLenth', 'GetMonthLenths', 'FindMonthFirstWeekday', 'GetWeekDay', 'GetMonthLastDate']) {
	Object.defineProperty(Date.prototype, __m, { value: function (...args) { return Date[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/Date.js"] = {"Week": Week, "Date": Date};
})();
(function () {

// ===== GameEngineContents/Olive.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineRandom = __PM2_EXPORTS__["GameEngineBase/GameEngineRandom.js"]["GameEngineRandom"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var BloodType = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["BloodType"];
var Zodiac = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Zodiac"];
var PatronGod = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PatronGod"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
// Olive.h / Olive.cpp 의 전사

class Olive extends GameEngineActor {
	static OlivePlayer = null;

	constructor() {
		super();
		this.OliveStatus = new Olive.Status();

		this.OlivePhysical = new Olive.PhysicalCondition();

		this.ParentLevel = null;

		this.HeadImageName = "Head_";
		this.BodyImageName = "Body_";
		this.HeadRender = null;
		this.BodyRender = null;

		this.OliveFirstName = "DefaultFirst";
		this.OliveLastName = "DefaultLast";

		this.OliveAge = 10;

		this.OliveBirthDay = new Date(1200, 10, 10);

		this.OliveBloodType = BloodType.AB;

		this.OliveZodiac = Zodiac["황소자리"];

		this.OlivePatronGod = PatronGod["화성신_마르스"];
		this.PatronGodSex = false;

		this.OliveDiet = Diet["무리하지_않는다"];

		this.Gold = 10000;

		this.DiseaseState = false;
		this.DiseaseIndex = 0;
		this.DelinquentState = false;
		this.Delinquency = 0;
		this.FatState = false;


		this.Popularity = 0;

		this.FatherBirthDay = new Date();
		this.FatherAge = 10;

		this.MonthChange = false;

		this.IsBirthDay = false;
	}

	GetOliveBirthDay() {
		return this.OliveBirthDay;
	}

	GetFatherAge() {
		return this.FatherAge;
	}

	GetOliveFirstName() {
		return this.OliveFirstName;
	}

	GetOliveLastName() {
		return this.OliveLastName;
	}

	GetOliveAge() {
		return this.OliveAge;
	}

	GetOliveZodiac() {
		return this.OliveZodiac;
	}

	GetPatronGod() {
		return this.OlivePatronGod;
	}

	GetPatronGodSex() {
		return this.PatronGodSex;
	}

	GetGold() {
		return this.Gold;
	}

	GetBloodType() {
		return this.OliveBloodType;
	}

	SetOliveFirstName(_FirstName) {
		this.OliveFirstName = _FirstName;
	}

	SetOliveLastName(_LastName) {
		this.OliveLastName = _LastName;
	}

	SetOliveBirthDay(_BirthDay) {
		this.OliveBirthDay = _BirthDay;
	}

	SetFatherAge(_Age) {
		this.FatherAge = _Age;
	}

	SetFatherBirthDay(_BirthDay) {
		this.FatherBirthDay = _BirthDay;
	}

	SetBloodType(_BloodType) {
		this.OliveBloodType = _BloodType;
	}

	GetStatue() {
		return this.OliveStatus;
	}

	SetFirstStatus() {
		if (Zodiac["염소자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Capricorn = { 25, 20, 17, 15, 10, 38, 20, 0, 13, 0, 17, 15, 2, 0, 28, 15, 8, 5, 41, 20, 10, 11, 69, 19, 22, 28 };
			const Capricorn = new Olive.Status(25, 20, 17, 15, 10, 38, 20, 0, 13, 0, 17, 15, 2, 0, 28, 15, 8, 5, 41, 20, 10, 11, 69, 19, 22, 28);
			this.SetStatus(Capricorn);
		}
		else if (Zodiac["물병자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Aquarius = { 17,18,42,12,10,13,8,0,28,0,17,15,2,0,50,15,12,23,55,11,22,22,44,15,23,6 };
			const Aquarius = new Olive.Status(17, 18, 42, 12, 10, 13, 8, 0, 28, 0, 17, 15, 2, 0, 50, 15, 12, 23, 55, 11, 22, 22, 44, 15, 23, 6);
			this.SetStatus(Aquarius);
		}
		else if (Zodiac["물고기자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Pisces = { 16,15,15,32,31,27,30,0,45,0,12,10,2,0,56,18,20,18,59,24,20,15,48,16,14,18 };
			const Pisces = new Olive.Status(16, 15, 15, 32, 31, 27, 30, 0, 45, 0, 12, 10, 2, 0, 56, 18, 20, 18, 59, 24, 20, 15, 48, 16, 14, 18);
			this.SetStatus(Pisces);
		}
		else if (Zodiac["양자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Aries = { 45,45,13,10,7,14,21,0,6,0,43,38,5,0,32,8,14,10,35,10,15,10,40,18,18,4 };
			const Aries = new Olive.Status(45, 45, 13, 10, 7, 14, 21, 0, 6, 0, 43, 38, 5, 0, 32, 8, 14, 10, 35, 10, 15, 10, 40, 18, 18, 4);
			this.SetStatus(Aries);
		}
		else if (Zodiac["황소자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Taurus = { 33,28,23,25,24,32,20,0,19,0,13,10,3,0,60,17,18,25,49,21,20,8,58,19,16,23 };
			const Taurus = new Olive.Status(33, 28, 23, 25, 24, 32, 20, 0, 19, 0, 13, 10, 3, 0, 60, 17, 18, 25, 49, 21, 20, 8, 58, 19, 16, 23);
			this.SetStatus(Taurus);
		}
		else if (Zodiac["쌍둥이자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Gemini = { 19,18,36,14,14,7,10,0,35,0,16,14,2,0,52,18,19,15,65,10,25,30,29,8,10,11 };
			const Gemini = new Olive.Status(19, 18, 36, 14, 14, 7, 10, 0, 35, 0, 16, 14, 2, 0, 52, 18, 19, 15, 65, 10, 25, 30, 29, 8, 10, 11);
			this.SetStatus(Gemini);
		}
		else if (Zodiac["게자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Cancer = { 18,18,25,29,33,25,30,0,33,0,17,15,2,0,75,24,28,23,57,17,20,20,54,17,20,17 };
			const Cancer = new Olive.Status(18, 18, 25, 29, 33, 25, 30, 0, 33, 0, 17, 15, 2, 0, 75, 24, 28, 23, 57, 17, 20, 20, 54, 17, 20, 17);
			this.SetStatus(Cancer);
		}
		else if (Zodiac["사자자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Leo = { 50,50,7,42,18,23,10,0,9,0,37,32,5,0,16,2,6,8,38,15,8,15,18,7,9,2 };
			const Leo = new Olive.Status(50, 50, 7, 42, 18, 23, 10, 0, 9, 0, 37, 32, 5, 0, 16, 2, 6, 8, 38, 15, 8, 15, 18, 7, 9, 2);
			this.SetStatus(Leo);
		}
		else if (Zodiac["처녀자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Virgo = { 14,5,28,45,30,32,35,0,31,0,8,7,1,0,65,15,18,32,58,25,18,15,89,29,30,30 };
			const Virgo = new Olive.Status(14, 5, 28, 45, 30, 32, 35, 0, 31, 0, 8, 7, 1, 0, 65, 15, 18, 32, 58, 25, 18, 15, 89, 29, 30, 30);
			this.SetStatus(Virgo);
		}
		else if (Zodiac["천칭자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Libra = { 25,22,30,24,20,20,21,0,26,0,16,14,2,0,42,13,14,15,64,18,18,28,46,16,15,15 };
			const Libra = new Olive.Status(25, 22, 30, 24, 20, 20, 21, 0, 26, 0, 16, 14, 2, 0, 42, 13, 14, 15, 64, 18, 18, 28, 46, 16, 15, 15);
			this.SetStatus(Libra);
		}
		else if (Zodiac["전갈자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Scorpio = { 28,20,22,9,42,10,27,0,39,0,12,10,2,0,80,30,30,20,39,14,21,4,31,12,11,8 };
			const Scorpio = new Olive.Status(28, 20, 22, 9, 42, 10, 27, 0, 39, 0, 12, 10, 2, 0, 80, 30, 30, 20, 39, 14, 21, 4, 31, 12, 11, 8);
			this.SetStatus(Scorpio);
		}
		else if (Zodiac["사수자리"] === this.OliveZodiac)
		{
			// 원본: Olive::Status Sagittarius = { 38,35,24,23,11,10,12,0,20,0,23,19,4,0,43,19,12,12,37,8,6,13,44,21,13,10 };
			const Sagittarius = new Olive.Status(38, 35, 24, 23, 11, 10, 12, 0, 20, 0, 23, 19, 4, 0, 43, 19, 12, 12, 37, 8, 6, 13, 44, 21, 13, 10);
			this.SetStatus(Sagittarius);
		}
		else
		{
			MsgAssert("별자리가 없습니다, 생일을 정해주지 않았습니다.");
		}
	}

	SetStatus(_Value) {
		this.OliveStatus.Constitution = _Value.Constitution;
		this.OliveStatus.Strength = _Value.Strength;
		this.OliveStatus.Intelligence = _Value.Intelligence;
		this.OliveStatus.Refinement = _Value.Refinement;
		this.OliveStatus.Charisma = _Value.Charisma;
		this.OliveStatus.Morality = _Value.Morality;
		this.OliveStatus.Faith = _Value.Faith;
		this.OliveStatus.Sin = _Value.Sin;
		this.OliveStatus.Sensitivity = _Value.Sensitivity;
		this.OliveStatus.Stress = _Value.Stress;

		this.OliveStatus.CombatSkill = _Value.CombatSkill;
		this.OliveStatus.CombatAttack = _Value.CombatAttack;
		this.OliveStatus.CombatDefense = _Value.CombatDefense;
		this.UpdateFighter();

		this.OliveStatus.MagicSkill = _Value.MagicSkill;
		this.OliveStatus.MagicAttack = _Value.MagicAttack;
		this.OliveStatus.MagicDefense = _Value.MagicDefense;
		this.UpdateMagical();

		this.OliveStatus.Decorum = _Value.Decorum;
		this.OliveStatus.Art = _Value.Art;
		this.OliveStatus.Conversation = _Value.Conversation;
		this.UpdateSocial();

		this.OliveStatus.Cooking = _Value.Cooking;
		this.OliveStatus.Cleaning = _Value.Cleaning;
		this.OliveStatus.Temperament = _Value.Temperament;
		this.UpdateHouseWork();
	}

	UpdateFighter() {
		this.OliveStatus.Fighter = this.OliveStatus.CombatSkill + this.OliveStatus.CombatAttack + this.OliveStatus.CombatDefense;
	}

	UpdateMagical() {
		this.OliveStatus.Magical = this.OliveStatus.MagicSkill + this.OliveStatus.MagicAttack + this.OliveStatus.MagicDefense;
	}

	UpdateSocial() {
		this.OliveStatus.Social = this.OliveStatus.Decorum + this.OliveStatus.Art + this.OliveStatus.Conversation;
	}

	UpdateHouseWork() {
		this.OliveStatus.HouseWork = this.OliveStatus.Cooking + this.OliveStatus.Cleaning + this.OliveStatus.Temperament;
	}

	UpdateZodiac() {

		if ((this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 12, 22)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 12, 31))) ||
			(this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 1, 1)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 1, 19))))
		{
			this.OliveZodiac = Zodiac["염소자리"];
			this.OlivePatronGod = PatronGod["토성신_새턴"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 1, 20)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 2, 18)))
		{
			this.OliveZodiac = Zodiac["물병자리"];
			this.OlivePatronGod = PatronGod["천왕성신_우라누스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 2, 19)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 3, 20)))
		{
			this.OliveZodiac = Zodiac["물고기자리"];
			this.OlivePatronGod = PatronGod["해왕성신_넵튠"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 3, 21)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 4, 19)))
		{
			this.OliveZodiac = Zodiac["양자리"];
			this.OlivePatronGod = PatronGod["화성신_마르스"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 4, 20)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 5, 20)))
		{
			this.OliveZodiac = Zodiac["황소자리"];
			this.OlivePatronGod = PatronGod["금성신_비너스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 5, 21)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 6, 21)))
		{
			this.OliveZodiac = Zodiac["쌍둥이자리"];
			this.OlivePatronGod = PatronGod["수성신_머큐리"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 6, 22)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 7, 22)))
		{
			this.OliveZodiac = Zodiac["게자리"];
			this.OlivePatronGod = PatronGod["달신_더문"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 7, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 8, 22)))
		{
			this.OliveZodiac = Zodiac["사자자리"];
			this.OlivePatronGod = PatronGod["태양신_솔"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 8, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 9, 22)))
		{
			this.OliveZodiac = Zodiac["처녀자리"];
			this.OlivePatronGod = PatronGod["수성신_머큐리"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 9, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 10, 23)))
		{
			this.OliveZodiac = Zodiac["천칭자리"];
			this.OlivePatronGod = PatronGod["금성신_비너스"];
			this.PatronGodSex = true;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 10, 24)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 11, 22)))
		{
			this.OliveZodiac = Zodiac["전갈자리"];
			this.OlivePatronGod = PatronGod["명왕성신_하데스"];
			this.PatronGodSex = false;
		}
		else if (this.OliveBirthDay.IsGreaterOrEqual(new Date(1200, 11, 23)) &&
			this.OliveBirthDay.IsLessOrEqual(new Date(1200, 12, 21)))
		{
			this.OliveZodiac = Zodiac["사수자리"];
			this.OlivePatronGod = PatronGod["목성신_주피터"];
			this.PatronGodSex = false;
		}
		else
		{
			MsgAssert("생일을 정해주지 않았습니다.");
		}
	}


	SetFirstPhysicalCondition() {
		const Random = new GameEngineRandom();
		const RandomNum = Random.RandomInt(0, 16);
		const fHeight = 136.0 + 1.0 * RandomNum;
		const fWeight = 29.2 + 0.95 * RandomNum;
		const fBust = 68.0 + 0.5 * RandomNum;
		const fWaist = 47.5 + 0.625 * RandomNum;
		const fHip = 70.72 + 0.52 * RandomNum;

		this.SetHeight(fHeight);
		this.SetWeight(fWeight);
		this.SetBust(fBust);
		this.SetWaist(fWaist);
		this.SetHip(fHip);
	}

	SetHeight(_Value) {
		this.OlivePhysical.Height = _Value;
	}

	SetWeight(_Value) {
		this.OlivePhysical.Weight = _Value;
	}

	SetBust(_Value) {
		this.OlivePhysical.Bust = _Value;
	}

	SetWaist(_Value) {
		this.OlivePhysical.Waist = _Value;
	}

	SetHip(_Value) {
		this.OlivePhysical.Hip = _Value;
	}

	GetHeight() {
		return this.OlivePhysical.Height;
	}

	GetWeight() {
		return this.OlivePhysical.Weight;
	}

	GetBust() {
		return this.OlivePhysical.Bust;
	}

	GetWaist() {
		return this.OlivePhysical.Waist;
	}

	GetHip() {
		return this.OlivePhysical.Hip;
	}

	GetOliveDiet() {
		return this.OliveDiet;
	}

	SetOliveDiet(_Diet) {
		this.OliveDiet = _Diet;
	}

	GetDiseaseIndex() {
		this.DiseaseIndex = this.OliveStatus.Stress - this.OliveStatus.Constitution;
		if (this.DiseaseIndex < 0)
		{
			this.DiseaseIndex = 0;
		}
		return this.DiseaseIndex;
	}

	GetDelinquency() {
		let Higher = 0.0;
		this.OliveStatus.Morality > this.OliveStatus.Faith ? Higher = this.OliveStatus.Morality : Higher = this.OliveStatus.Faith;
		this.Delinquency = this.OliveStatus.Stress - Higher;
		if (this.Delinquency < 0)
		{
			this.Delinquency = 0;
		}
		return this.Delinquency;
	}

	GetPopularity() {
		return this.Popularity;
	}

	SetOliveAge(_Age) {
		this.OliveAge = _Age;
	}

	IsFat() {
		return this.FatState;
	}

	IsDisease() {
		return this.DiseaseState;
	}

	IsDelinquent() {
		return this.DelinquentState;
	}

	OliveStateUpdate() {
		this.UpdateFat();
		this.UpdateDisease();
		this.UpdateDelinquent();
	}

	OliveRenderUpdate() {
		let AgeCopy = this.OliveAge;

		if (this.OliveAge >= 18)
		{
			AgeCopy = 17;
		}

		this.HeadImageName += String(AgeCopy);
		if (this.DiseaseState)
		{
			this.HeadImageName += "_Sick";
		}
		else if (this.DelinquentState)
		{
			this.HeadImageName += "_Degrade";
		}
		else if (this.OliveStatus.Stress === 0)
		{
			this.HeadImageName += "_Happy";
		}
		else
		{
			this.HeadImageName += "_Nomal";
		}

		if (!this.FatState)
		{
			this.HeadImageName += "_Common";
		}
		else
		{
			this.HeadImageName += "_Fat";
		}

		this.HeadImageName += ".bmp";
		this.HeadRender.SetImage(this.HeadImageName);
		this.HeadRender.SetScaleToImage();
		this.HeadImageName = "Head_";

		this.BodyImageName += String(AgeCopy);
		if (!this.FatState)
		{
			this.BodyImageName += "_Common";
		}
		else
		{
			this.BodyImageName += "_Fat";
		}

		this.BodyImageName += ".bmp";
		this.BodyRender.SetImage(this.BodyImageName);
		this.BodyRender.SetScaleToImage();
		this.BodyImageName = "Body_";

		this.BodyRender.SetPosition(new float4(0, 300 - this.BodyRender.GetScale().hy()));
		this.HeadRender.SetPosition(new float4(0, 300 - this.HeadRender.GetScale().hy() - this.BodyRender.GetScale().y));
	}

	Start() {
		this.ParentLevel = this.GetLevel(); // 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())

		Olive.OlivePlayer = this;

		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BodyRender = this.CreateRender("Body_10_Common.BMP", PM2RenderOrder.Olive);
		this.BodyRender.SetScaleToImage();
		this.HeadRender = this.CreateRender("Head_10_Nomal_Common.BMP", PM2RenderOrder.Olive);
		this.HeadRender.SetScaleToImage();
		this.BodyRender.SetPosition(new float4(0, 300 - this.BodyRender.GetScale().hy()));
		this.HeadRender.SetPosition(new float4(0, 300 - this.HeadRender.GetScale().hy() - this.BodyRender.GetScale().y));

		this.Off();
	}

	Update(_DeltaTime) {
		this.OliveStatus.UpdateMoreThanMin();
		this.OliveStatus.UpdateLessThanMax();
		this.UpdateMonthChange();

		this.UpdateFighter();
		this.UpdateMagical();
		this.UpdateSocial();
		this.UpdateHouseWork();

		this.OliveBirthDayCheck();

	}

	Render(_Time) {

	}

	UpdateMonthChange() {
		if (this.ParentLevel.GetToday().IsEqual(Date.GetMonthLastDate(this.ParentLevel.GetToday())) && this.MonthChange === false)
		{
			this.MonthChange = true;
			this.BloodTypeMonthUpdate();
			this.DietMonthUpdate();
			this.OliveStateUpdate();
			this.OliveRenderUpdate();
		}

		if (this.ParentLevel.GetToday().GetDay() === 1 && this.MonthChange === true)
		{
			this.MonthChange = false;
		}
	}

	BloodTypeMonthUpdate() {
		switch (this.OliveBloodType)
		{
			case BloodType.Null:
				break;
			case BloodType.A:
				this.OliveStatus.Morality += 3;
				this.OliveStatus.Stress += 2;
				break;
			case BloodType.B:
				this.OliveStatus.Stress -= 2;
				break;
			case BloodType.O:
				break;
			case BloodType.AB:
				this.OliveStatus.Sensitivity += 2;
				break;
			default:
				break;
		}
	}

	DietMonthUpdate() {
		const Random = new GameEngineRandom();
		switch (this.OliveDiet)
		{
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.19, 0.22);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.05, 0.08);
				}
				break;
			case Diet["어쨌든_튼튼하게"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.28, 0.35);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.16, 0.20);
				}
				this.OliveStatus.Constitution += 10;
				break;
			case Diet["얌전한_아이로"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.10, 0.13);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(0.01, 0.04);
				}
				this.OliveStatus.Constitution += -5;
				break;
			case Diet["다이어트_시킨다"]:
				if (this.OliveAge <= 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(-0.6, -0.0);
				}
				else if (this.OliveAge > 15)
				{
					this.OlivePhysical.Weight += Random.RandomFloat(-1.00, -0.5);
				}
				this.OliveStatus.Constitution += -20;
				break;
			default:
				break;
		}
	}

	OliveBirthDayCheck() {

		if (this.IsBirthDay === false && this.ParentLevel.GetToday().GetYear() !== 1210 && this.ParentLevel.GetToday().GetMonth() === this.OliveBirthDay.GetMonth() && this.ParentLevel.GetToday().GetDay() === this.OliveBirthDay.GetDay())
		{
			this.OliveAge++;
			this.IsBirthDay = true;
			this.OliveRenderUpdate();
		}

		if (this.IsBirthDay === true && this.ParentLevel.GetToday().GetMonth() !== this.OliveBirthDay.GetMonth() || this.ParentLevel.GetToday().GetDay() !== this.OliveBirthDay.GetDay())
		{
			this.IsBirthDay = false;
		}
	}


	UpdateFat() {
		if (this.OlivePhysical.Weight > this.OlivePhysical.Height * 0.95 - 87 - this.OliveAge)
		{
			this.FatState = true;
			return this.FatState;
		}
		else
		{
			this.FatState = false;
			return this.FatState;
		}
	}

	UpdateDisease() {
		if (this.OliveStatus.Stress > this.OliveStatus.Constitution)
		{
			this.DiseaseState = true;
			return this.DiseaseState;
		}
		else
		{
			this.DiseaseState = false;
			return this.DiseaseState;
		}
	}

	UpdateDelinquent() {
		if (this.OliveStatus.Stress > this.OliveStatus.Morality || this.OliveStatus.Stress > this.OliveStatus.Faith)
		{
			this.DelinquentState = true;
			return this.DelinquentState;
		}
		else
		{
			this.DelinquentState = false;
			return this.DelinquentState;
		}
	}
}

// 원본: class Olive::Status — h에서 정의, cpp에서 연산자 구현
// operator +=(→AddAssign) / ==(→IsEqual) / !=(→IsNotEqual) / =(→Assign) 는 JS 메서드로 전사했다.
Olive.Status = class Status {
	// 원본: Status Capricorn = { 25, 20, ... } 같은 중괄호 aggregate 초기화 대응
	// (멤버 선언 순서대로 위치 인자로 받는다. 기본값 0 = 원본 Status()의 멤버 기본값)
	constructor(Constitution = 0, Strength = 0, Intelligence = 0, Refinement = 0, Charisma = 0, Morality = 0, Faith = 0, Sin = 0, Sensitivity = 0, Stress = 0, Fighter = 0, CombatSkill = 0, CombatAttack = 0, CombatDefense = 0, Magical = 0, MagicSkill = 0, MagicAttack = 0, MagicDefense = 0, Social = 0, Decorum = 0, Art = 0, Conversation = 0, HouseWork = 0, Cooking = 0, Cleaning = 0, Temperament = 0) {
		this.Constitution = Constitution;
		this.Strength = Strength;
		this.Intelligence = Intelligence;
		this.Refinement = Refinement;
		this.Charisma = Charisma;
		this.Morality = Morality;
		this.Faith = Faith;
		this.Sin = Sin;
		this.Sensitivity = Sensitivity;
		this.Stress = Stress;

		this.Fighter = Fighter;
		this.CombatSkill = CombatSkill;
		this.CombatAttack = CombatAttack;
		this.CombatDefense = CombatDefense;

		this.Magical = Magical;
		this.MagicSkill = MagicSkill;
		this.MagicAttack = MagicAttack;
		this.MagicDefense = MagicDefense;

		this.Social = Social;
		this.Decorum = Decorum;
		this.Art = Art;
		this.Conversation = Conversation;

		this.HouseWork = HouseWork;
		this.Cooking = Cooking;
		this.Cleaning = Cleaning;
		this.Temperament = Temperament;


		this.MaxConstitution = 999;
		this.MaxStrength = 999;
		this.MaxIntelligence = 999;
		this.MaxRefinement = 999;
		this.MaxCharisma = 999;
		this.MaxMorality = 999;
		this.MaxFaith = 999;
		this.MaxSin = 999;
		this.MaxSensitivity = 999;
		this.MaxStress = 999;

		this.MaxCombatSkill = 100;
		this.MaxCombatAttack = 100;
		this.MaxCombatDefense = 100;

		this.MaxMagicSkill = 100;
		this.MaxMagicAttack = 100;
		this.MaxMagicDefense = 100;

		this.MaxDecorum = 100;
		this.MaxArt = 100;
		this.MaxConversation = 100;

		this.MaxCooking = 100;
		this.MaxCleaning = 100;
		this.MaxTemperament = 100;
	}

	// 원본: Status& operator+=(const Status& _Value)
	AddAssign(_Value) {
		this.Constitution += _Value.Constitution;
		this.Strength += _Value.Strength;
		this.Intelligence += _Value.Intelligence;
		this.Refinement += _Value.Refinement;
		this.Charisma += _Value.Charisma;
		this.Morality += _Value.Morality;
		this.Faith += _Value.Faith;
		this.Sin += _Value.Sin;
		this.Sensitivity += _Value.Sensitivity;
		this.Stress += _Value.Stress;
		this.Fighter += _Value.Fighter;
		this.CombatSkill += _Value.CombatSkill;
		this.CombatAttack += _Value.CombatAttack;
		this.CombatDefense += _Value.CombatDefense;
		this.Magical += _Value.Magical;
		this.MagicSkill += _Value.MagicSkill;
		this.MagicAttack += _Value.MagicAttack;
		this.MagicDefense += _Value.MagicDefense;
		this.Social += _Value.Social;
		this.Decorum += _Value.Decorum;
		this.Art += _Value.Art;
		this.Conversation += _Value.Conversation;
		this.HouseWork += _Value.HouseWork;
		this.Cooking += _Value.Cooking;
		this.Cleaning += _Value.Cleaning;
		this.Temperament += _Value.Temperament;

		return this;
	}

	// 원본: bool operator==(const Status& _Value)
	IsEqual(_Value) {
		if (
			this.Constitution === _Value.Constitution &&
			this.Strength === _Value.Strength &&
			this.Intelligence === _Value.Intelligence &&
			this.Refinement === _Value.Refinement &&
			this.Charisma === _Value.Charisma &&
			this.Morality === _Value.Morality &&
			this.Faith === _Value.Faith &&
			this.Sin === _Value.Sin &&
			this.Sensitivity === _Value.Sensitivity &&
			this.Stress === _Value.Stress &&
			this.Fighter === _Value.Fighter &&
			this.CombatSkill === _Value.CombatSkill &&
			this.CombatAttack === _Value.CombatAttack &&
			this.CombatDefense === _Value.CombatDefense &&
			this.Magical === _Value.Magical &&
			this.MagicSkill === _Value.MagicSkill &&
			this.MagicAttack === _Value.MagicAttack &&
			this.MagicDefense === _Value.MagicDefense &&
			this.Social === _Value.Social &&
			this.Decorum === _Value.Decorum &&
			this.Art === _Value.Art &&
			this.Conversation === _Value.Conversation &&
			this.HouseWork === _Value.HouseWork &&
			this.Cooking === _Value.Cooking &&
			this.Cleaning === _Value.Cleaning &&
			this.Temperament === _Value.Temperament
			)
		{
			return true;
		}
		return false;
	}

	// 원본: bool operator!=(const Status& _Value)  → return !Status::operator==(_Value);
	IsNotEqual(_Value) {
		return !this.IsEqual(_Value);
	}

	// 원본: Status& operator=(const Status& _Value)
	Assign(_Value) {
		this.Constitution = _Value.Constitution;
		this.Strength = _Value.Strength;
		this.Intelligence = _Value.Intelligence;
		this.Refinement = _Value.Refinement;
		this.Charisma = _Value.Charisma;
		this.Morality = _Value.Morality;
		this.Faith = _Value.Faith;
		this.Sin = _Value.Sin;
		this.Sensitivity = _Value.Sensitivity;
		this.Stress = _Value.Stress;

		this.Fighter = _Value.Fighter;
		this.CombatSkill = _Value.CombatSkill;
		this.CombatAttack = _Value.CombatAttack;
		this.CombatDefense = _Value.CombatDefense;

		this.Magical = _Value.Magical;
		this.MagicSkill = _Value.MagicSkill;
		this.MagicAttack = _Value.MagicAttack;
		this.MagicDefense = _Value.MagicDefense;

		this.Social = _Value.Social;
		this.Decorum = _Value.Decorum;
		this.Art = _Value.Art;
		this.Conversation = _Value.Conversation;

		this.HouseWork = _Value.HouseWork;
		this.Cooking = _Value.Cooking;
		this.Cleaning = _Value.Cleaning;
		this.Temperament = _Value.Temperament;

		return this;
	}

	SetStatus(_Para) {
		this.Constitution = _Para.Constitution;
		this.Strength = _Para.Strength;
		this.Intelligence = _Para.Intelligence;
		this.Refinement = _Para.Refinement;
		this.Charisma = _Para.Charisma;
		this.Morality = _Para.Morality;
		this.Faith = _Para.Faith;
		this.Sin = _Para.Sin;
		this.Sensitivity = _Para.Sensitivity;
		this.Stress = _Para.Stress;
		this.Fighter = _Para.Fighter;
		this.CombatSkill = _Para.CombatSkill;
		this.CombatAttack = _Para.CombatAttack;
		this.CombatDefense = _Para.CombatDefense;
		this.Magical = _Para.Magical;
		this.MagicSkill = _Para.MagicSkill;
		this.MagicAttack = _Para.MagicAttack;
		this.MagicDefense = _Para.MagicDefense;
		this.Social = _Para.Social;
		this.Decorum = _Para.Decorum;
		this.Art = _Para.Art;
		this.Conversation = _Para.Conversation;
		this.HouseWork = _Para.HouseWork;
		this.Cooking = _Para.Cooking;
		this.Cleaning = _Para.Cleaning;
		this.Temperament = _Para.Temperament;
	}

	UpdateMoreThanMin() {
		if (this.Constitution < 0)
		{
			this.Constitution = 0;
		}

		if (this.Strength < 0)
		{
			this.Strength = 0;
		}

		if (this.Intelligence < 0)
		{
			this.Intelligence = 0;
		}

		if (this.Refinement < 0)
		{
			this.Refinement = 0;
		}

		if (this.Charisma < 0)
		{
			this.Charisma = 0;
		}

		if (this.Morality < 0)
		{
			this.Morality = 0;
		}

		if (this.Faith < 0)
		{
			this.Faith = 0;
		}

		if (this.Sin < 0)
		{
			this.Sin = 0;
		}

		if (this.Sensitivity < 0)
		{
			this.Sensitivity = 0;
		}

		if (this.Stress < 0)
		{
			this.Stress = 0;
		}

		if (this.CombatSkill < 0)
		{
			this.CombatSkill = 0;
		}

		if (this.CombatAttack < 0)
		{
			this.CombatAttack = 0;
		}

		if (this.CombatDefense < 0)
		{
			this.CombatDefense = 0;
		}

		if (this.MagicSkill < 0)
		{
			this.MagicSkill = 0;
		}

		if (this.MagicAttack < 0)
		{
			this.MagicAttack = 0;
		}

		if (this.MagicDefense < 0)
		{
			this.MagicDefense = 0;
		}

		if (this.Decorum < 0)
		{
			this.Decorum = 0;
		}

		if (this.Art < 0)
		{
			this.Art = 0;
		}

		if (this.Conversation < 0)
		{
			this.Conversation = 0;
		}

		if (this.Cooking < 0)
		{
			this.Cooking = 0;
		}

		if (this.Cleaning < 0)
		{
			this.Cleaning = 0;
		}

		if (this.Temperament < 0)
		{
			this.Temperament = 0;
		}
	}

	UpdateLessThanMax() {
		if (this.Constitution > 999)
		{
			this.Constitution = 999;
		}

		if (this.Strength > 999)
		{
			this.Strength = 999;
		}

		if (this.Intelligence > 999)
		{
			this.Intelligence = 999;
		}

		if (this.Refinement > 999)
		{
			this.Refinement = 999;
		}

		if (this.Charisma > 999)
		{
			this.Charisma = 999;
		}

		if (this.Morality > 999)
		{
			this.Morality = 999;
		}

		if (this.Faith > 999)
		{
			this.Faith = 999;
		}

		if (this.Sin > 999)
		{
			this.Sin = 999;
		}

		if (this.Sensitivity > 999)
		{
			this.Sensitivity = 999;
		}

		if (this.Stress > 999)
		{
			this.Stress = 999;
		}

		if (this.CombatSkill > 100)
		{
			this.CombatSkill = 100;
		}

		if (this.CombatAttack > 100)
		{
			this.CombatAttack = 100;
		}

		if (this.CombatDefense > 100)
		{
			this.CombatDefense = 100;
		}

		if (this.MagicSkill > 100)
		{
			this.MagicSkill = 100;
		}

		if (this.MagicAttack > 100)
		{
			this.MagicAttack = 100;
		}

		if (this.MagicDefense > 100)
		{
			this.MagicDefense = 100;
		}

		if (this.Decorum > 100)
		{
			this.Decorum = 100;
		}

		if (this.Art > 100)
		{
			this.Art = 100;
		}

		if (this.Conversation > 100)
		{
			this.Conversation = 100;
		}

		if (this.Cooking > 100)
		{
			this.Cooking = 100;
		}

		if (this.Cleaning > 100)
		{
			this.Cleaning = 100;
		}

		if (this.Temperament > 100)
		{
			this.Temperament = 100;
		}
	}
};

// 원본: class Olive::PhysicalCondition
Olive.PhysicalCondition = class PhysicalCondition {
	constructor() {
		this.Height = 0;
		this.Weight = 0;
		this.Bust = 0;
		this.Waist = 0;
		this.Hip = 0;
	}
};

__PM2_EXPORTS__["GameEngineContents/Olive.js"] = {"Olive": Olive};
})();
(function () {

// ===== GameEngineCore/NumberRenderObject.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineMath = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["GameEngineMath"];
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
// NumberRenderObject.h / NumberRenderObject.cpp 의 전사

// enum class Align
const Align = Object.freeze({
	Left: 0,
	Right: 1,
	Center: 2
});

class NumberRenderObject extends GameEngineObject {
	constructor() {
		super();
		this.Order = 0;
		this.NumberScale = new float4(0, 0, 0, 1);
		this.Pos = new float4(0, 0, 0, 1);
		this.Value = 0;
		this.TransColor = 0xff00ff; // RGB(255, 0, 255)
		this.AlignState = Align.Left;
		this.Negative = false;
		this.NumOfDigits = -1;
		this.CameraEffect = false;
		this.ImageName = "";
		this.NegativeName = "";
		this.NumberRenders = [];
		this.NegativeRender = null;
	}

	SetImage(_ImageName, _Scale, _Order, _TransColor, _NegativeName = "") {
		const FindNumberImage = GameEngineResources.GetInst().ImageFind(_ImageName);

		if (FindNumberImage.GetImageCuttingCount() !== 10) {
			MsgAssert("숫자 이미지는 반드시 10개로 짤라줘야 됩니다.");
		}

		if (0 >= _Scale.x || 0 >= _Scale.y) {
			MsgAssert("크기가 0보다 작으면 숫자를 만들 수 없습니다.");
		}

		this.ImageName = _ImageName;
		this.NumberScale = _Scale;
		this.Order = _Order;
		this.TransColor = _TransColor;
		this.NegativeName = _NegativeName;
	}

	SetNumberRenders(_Index, _TransColor, _Pos, _ImageName, _Scale, _CameraEffect, _Frame = -1) {
		const Render = this.NumberRenders[_Index];
		if (null === Render || undefined === Render) {
			MsgAssert("렌더러레스가 nullptr 입니다");
		}
		Render.SetTransColor(_TransColor);
		Render.SetPosition(_Pos);
		Render.SetImage(_ImageName);
		Render.SetScale(_Scale);
		Render.SetEffectCamera(_CameraEffect);
		if (-1 !== _Frame) {
			Render.SetFrame(_Frame);
		}
	}

	On() {
		super.On();
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].On();
		}
	}

	Off() {
		super.Off();
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].Off();
		}
	}

	SetValue(_Value) {
		const Actor = this.GetOwner();
		this.Value = _Value;

		const Numbers = GameEngineMath.GetDigits(this.Value);

		if (null === Actor) {
			MsgAssert("액터만이 NumberRenderObject의 부모 될 수 있습니다.");
		}

		if (-1 !== this.NumOfDigits && Numbers.length > this.NumOfDigits) {
			MsgAssert("Digits 보다 큰 value가 들어왔습니다.");
		}

		if (-1 !== this.NumOfDigits && _Value < 0) {
			this.ResetDigits();
			MsgAssert("Value가 음수인 경우에는 Digits의값이 설정되었습니다.");
		}

		this.Negative = _Value >= 0 ? false : true;

		const Digits = (this.NumOfDigits === -1 ? Numbers.length : this.NumOfDigits) + (this.Negative ? 1 : 0);

		if (this.NumberRenders.length < Digits) {
			const CurRenderSize = this.NumberRenders.length;
			for (let i = 0; i < (Digits - CurRenderSize); ++i) {
				this.NumberRenders.push(Actor.CreateRender(this.Order));
			}
		} else {
			const CurRenderSize = this.NumberRenders.length;
			for (let i = 0; i < (CurRenderSize - Digits); ++i) {
				const LastRender = this.NumberRenders[this.NumberRenders.length - 1];
				this.NumberRenders.pop();
				LastRender.Death();
			}
		}

		let RenderPos = this.Pos.copy();
		let NumRenderIndex = 0;

		switch (this.AlignState) {
			case Align.Left:
				break;
			case Align.Right:
				RenderPos = RenderPos.sub(new float4((Digits - 1) * this.NumberScale.x, 0, 0, 0));
				break;
			case Align.Center:
				RenderPos = RenderPos.sub(new float4(((Digits - 1) * this.NumberScale.x) / 2, 0, 0, 0));
				break;
			default:
				break;
		}

		if (true === this.Negative && null === this.NegativeRender) {
			this.SetNumberRenders(NumRenderIndex++, this.TransColor, RenderPos, this.NegativeName, this.NumberScale, this.CameraEffect);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
		for (; NumRenderIndex < Digits - Numbers.length; ++NumRenderIndex) {
			this.SetNumberRenders(NumRenderIndex, this.TransColor, RenderPos, this.ImageName, this.NumberScale, this.CameraEffect, 0);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
		for (let i = 0; NumRenderIndex < this.NumberRenders.length; ++NumRenderIndex) {
			this.SetNumberRenders(NumRenderIndex, this.TransColor, RenderPos, this.ImageName, this.NumberScale, this.CameraEffect, Numbers[i++]);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
	}

	SetMove(_RenderPos) {
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].SetMove(_RenderPos);
		}
	}

	SetAlign(_Align) {
		this.AlignState = _Align;
	}

	SetRenderPos(_Pos) {
		this.Pos = _Pos;
		this.SetValue(this.Value);
	}

	GetValue() {
		return this.Value;
	}

	SetNumOfDigits(_Num) {
		this.NumOfDigits = _Num;
	}

	ResetDigits() {
		this.SetNumOfDigits(-1);
	}

	SetCameraEffect(_EffectSetting) {
		this.CameraEffect = _EffectSetting;
	}
}

__PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"] = {"Align": Align, "NumberRenderObject": NumberRenderObject};
})();
(function () {

// ===== GameEngineContents/BasicInfo.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PatronGod = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PatronGod"];
var BloodType = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["BloodType"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var IconCode = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["IconCode"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// BasicInfo.h / BasicInfo.cpp 의 전사

class BasicInfo extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(700, 109);

		this.BasicInfoFrame = null;

		this.OliveFirstName = "Null";
		this.FirstNameRender = null;
		this.FirstNameRenderPos = new float4(-90, -98);
		this.OliveLastName = "Null";
		this.LastNameRender = null;
		this.LastNameRenderPos = new float4(-90, -75);
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(180, 20);

		this.OlivePatronGod = PatronGod.Null;
		this.PatronGodIconRender = null;
		this.PatronGodIconPos = new float4(-30, -22);
		this.IconScale = new float4(39, 39);

		this.OliveBloodType = BloodType.Null;
		this.BloodTypeRender = null;
		this.BloodTypeRenderPos = new float4(-30, -22);
		this.BloodTypeRenderScale = new float4(39, 39);

		this.Age = 0;
		this.AgeRender = new NumberRenderObject();
		this.AgeRenderPos = new float4(-70, -20);
		this.AgeRenderScale = new float4(20, 20);

		this.Gold = 0;
		this.GoldRender = new NumberRenderObject();
		this.GoldRenderPos = new float4(65, -12);
		this.GoldRenderScale = new float4(10, 19);

		this.OliveDiet = Diet["무리하지_않는다"];
		this.OliveDietRender = null;
		this.DietRenderText = "";

		this.OliveDietRenderPos = new float4(-90, 56);

		this.Height = 0.0;
		this.HeightRender = new NumberRenderObject();
		this.HeightRenderPos = new float4(-75, 89);
		this.HeightRenderScale = new float4(10, 20);

		this.Weight = 0.0;
		this.WeightRender = new NumberRenderObject();
		this.WeightRenderPos = new float4(-35, 89);
		this.WeightRenderScale = new float4(10, 20);

		this.Bust = 0.0;
		this.BustRender = new NumberRenderObject();
		this.BustRenderPos = new float4(-5, 89);
		this.BustRenderScale = new float4(10, 20);

		this.Waist = 0.0;
		this.WaistRender = new NumberRenderObject();
		this.WaistRenderPos = new float4(37, 89);
		this.WaistRenderScale = new float4(10, 20);

		this.Hip = 0.0;
		this.HipRender = new NumberRenderObject();
		this.HipRenderPos = new float4(79, 89);
		this.HipRenderScale = new float4(10, 20);

		this.DiseaseState = false;
		this.DiseaseIcon = null;
		this.DiseaseIconPos = new float4(0, 27);

		this.DelinquentState = false;
		this.DelinquentIcon = null;
		this.DelinquentIconPos = new float4(40, 27);
	}

	// 원본: h에서 inline으로 정의된 private 멤버 함수
	SetDietRenderText() {
		switch (this.OliveDiet) {
			case Diet["무리하지_않는다"]:
				this.DietRenderText = "무리하지 않는다";
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.DietRenderText = "어쨌든 튼튼하게";
				break;
			case Diet["얌전한_아이로"]:
				this.DietRenderText = "얌전한 아이로";
				break;
			case Diet["다이어트_시킨다"]:
				this.DietRenderText = "다이어트 시킨다";
				break;
			default:
				break;
		}
	}

	Start() {
		this.SetPos(this.ActorPos);

		this.BasicInfoFrame = this.CreateRender("BasicInfo.bmp", PM2RenderOrder.Menu0);
		this.BasicInfoFrame.SetScaleToImage();

		this.FirstNameRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.FirstNameRender.SetText(this.OliveFirstName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.FirstNameRender.SetPosition(this.FirstNameRenderPos);

		this.LastNameRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LastNameRender.SetText(this.OliveLastName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.LastNameRender.SetPosition(this.LastNameRenderPos);

		this.OliveDietRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.SetDietRenderText();
		this.OliveDietRender.SetText(this.DietRenderText, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.OliveDietRender.SetPosition(this.OliveDietRenderPos);

		this.AgeRender.SetOwner(this);
		this.AgeRender.SetImage("Num_Age.bmp", this.AgeRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.AgeRender.SetAlign(Align.Center);
		this.AgeRender.SetValue(this.Age);
		this.AgeRender.SetRenderPos(this.AgeRenderPos);

		this.GoldRender.SetOwner(this);
		this.GoldRender.SetImage("Num.bmp", this.GoldRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.GoldRender.SetAlign(Align.Right);
		this.GoldRender.SetValue(this.Gold);
		this.GoldRender.SetRenderPos(this.GoldRenderPos);

		this.HeightRender.SetOwner(this);
		this.HeightRender.SetImage("Num.bmp", this.HeightRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.HeightRender.SetAlign(Align.Center);
		this.HeightRender.SetValue(Math.trunc(this.Height));
		this.HeightRender.SetRenderPos(this.HeightRenderPos);

		this.WeightRender.SetOwner(this);
		this.WeightRender.SetImage("Num.bmp", this.WeightRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.WeightRender.SetAlign(Align.Center);
		this.WeightRender.SetValue(Math.trunc(this.Weight));
		this.WeightRender.SetRenderPos(this.WeightRenderPos);

		this.BustRender.SetOwner(this);
		this.BustRender.SetImage("Num.bmp", this.BustRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.BustRender.SetAlign(Align.Center);
		this.BustRender.SetValue(Math.trunc(this.Bust));
		this.BustRender.SetRenderPos(this.BustRenderPos);

		this.WaistRender.SetOwner(this);
		this.WaistRender.SetImage("Num.bmp", this.WaistRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.WaistRender.SetAlign(Align.Center);
		this.WaistRender.SetValue(Math.trunc(this.Waist));
		this.WaistRender.SetRenderPos(this.WaistRenderPos);

		this.HipRender.SetOwner(this);
		this.HipRender.SetImage("Num.bmp", this.HipRenderScale, Math.trunc(PM2RenderOrder.Menu0_Display), RGB(255, 0, 255));
		this.HipRender.SetAlign(Align.Center);
		this.HipRender.SetValue(Math.trunc(this.Hip));
		this.HipRender.SetRenderPos(this.HipRenderPos);

		this.PatronGodIconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.PatronGodIconRender.SetScale(this.IconScale);
		this.PatronGodIconRender.SetPosition(this.PatronGodIconPos);

		this.BloodTypeRender = this.CreateRender("BloodTypeRender.bmp", PM2RenderOrder.Menu0_Display);
		this.BloodTypeRender.SetScale(this.BloodTypeRenderScale);
		this.BloodTypeRender.SetPosition(this.BloodTypeRenderPos);

		this.DiseaseIcon = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.DiseaseIcon.SetScale(this.IconScale);
		this.DiseaseIcon.SetPosition(this.DiseaseIconPos);
		this.DiseaseIcon.SetFrame(Math.trunc(IconCode["질병상태"]));
		this.DiseaseIcon.Off();

		this.DelinquentIcon = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu0_Display);
		this.DelinquentIcon.SetScale(this.IconScale);
		this.DelinquentIcon.SetPosition(this.DelinquentIconPos);
		this.DelinquentIcon.SetFrame(Math.trunc(IconCode["불량상태"]));
		this.DelinquentIcon.Off();
	}

	Update(_DeltaTime) {
		if (this.OliveFirstName !== Olive.OlivePlayer.GetOliveFirstName()) {
			this.OliveFirstName = Olive.OlivePlayer.GetOliveFirstName();
			this.FirstNameRender.SetText(this.OliveFirstName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.OliveLastName !== Olive.OlivePlayer.GetOliveLastName()) {
			this.OliveLastName = Olive.OlivePlayer.GetOliveLastName();
			this.LastNameRender.SetText(this.OliveLastName, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.OliveDiet !== Olive.OlivePlayer.GetOliveDiet()) {
			this.OliveDiet = Olive.OlivePlayer.GetOliveDiet();
			this.SetDietRenderText();
			this.OliveDietRender.SetText(this.DietRenderText, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		}

		if (this.Age !== Olive.OlivePlayer.GetOliveAge()) {
			this.Age = Olive.OlivePlayer.GetOliveAge();
			this.AgeRender.SetValue(this.Age);
		}

		if (this.OlivePatronGod !== Olive.OlivePlayer.GetPatronGod()) {
			this.OlivePatronGod = Olive.OlivePlayer.GetPatronGod();
			this.PatronGodIconRender.SetFrame(Math.trunc(this.OlivePatronGod));
		}

		if (this.OliveBloodType !== Olive.OlivePlayer.GetBloodType()) {
			this.OliveBloodType = Olive.OlivePlayer.GetBloodType();
			this.BloodTypeRender.SetFrame(Math.trunc(this.OliveBloodType));
		}

		if (this.Gold !== Olive.OlivePlayer.GetGold()) {
			this.Gold = Olive.OlivePlayer.GetGold();
			this.GoldRender.SetValue(this.Gold);
		}

		if (this.Height !== Olive.OlivePlayer.GetHeight()) {
			this.Height = Olive.OlivePlayer.GetHeight();
			this.HeightRender.SetValue(Math.trunc(this.Height));
		}

		if (this.Weight !== Olive.OlivePlayer.GetWeight()) {
			this.Weight = Olive.OlivePlayer.GetWeight();
			this.WeightRender.SetValue(Math.trunc(this.Weight));
		}

		if (this.Bust !== Olive.OlivePlayer.GetBust()) {
			this.Bust = Olive.OlivePlayer.GetBust();
			this.BustRender.SetValue(Math.trunc(this.Bust));
		}

		if (this.Waist !== Olive.OlivePlayer.GetWaist()) {
			this.Waist = Olive.OlivePlayer.GetWaist();
			this.WaistRender.SetValue(Math.trunc(this.Waist));
		}

		if (this.Hip !== Olive.OlivePlayer.GetHip()) {
			this.Hip = Olive.OlivePlayer.GetHip();
			this.HipRender.SetValue(Math.trunc(this.Hip));
		}

		if (this.DiseaseState !== Olive.OlivePlayer.IsDisease()) {
			this.DiseaseState = Olive.OlivePlayer.IsDisease();
			switch (this.DiseaseState) {
				case true:
					this.DiseaseIcon.On();
					break;
				case false:
					this.DiseaseIcon.Off();
					break;
			}
		}

		if (this.DelinquentState !== Olive.OlivePlayer.IsDelinquent()) {
			this.DelinquentState = Olive.OlivePlayer.IsDelinquent();
			switch (this.DelinquentState) {
				case true:
					this.DelinquentIcon.On();
					break;
				case false:
					this.DelinquentIcon.Off();
					break;
			}
		}
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/BasicInfo.js"] = {"BasicInfo": BasicInfo};
})();
(function () {

// ===== GameEngineContents/GaugeRenderObject.js =====
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// GaugeRenderObject.h / GaugeRenderObject.cpp 의 전사

// enum class GaugeFrameStyle
const GaugeFrameStyle = Object.freeze({
	"Null": -1,
	Nomal: 0,
	Estemate: 1,
	Detail: 2,
	Physical: 3
});

class GaugeRenderObject extends GameEngineObject {
	constructor() {
		super();
		this.Min = 0;
		this.Max = 0;
		this.StatusValue = 0;

		this.StartPos = float4.Zero;
		this.EndPos = float4.Zero;

		this.Style = GaugeFrameStyle.Null;

		this.Name = "";
		this.NameRender = null;
		this.TextHeight = 19;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(80, 20);
		this.TextRenderPos = new float4(-70, 0);

		this.StatusGaugeFrameRender_Layer1 = null;
		this.StatusGaugeEmptyRender = null;
		this.StatusGaugeRender = null;
		this.StatusGaugeFrameRender_Layer2 = null;
		this.StatusValueRender = new NumberRenderObject();
		this.DemicalPoint = null;
		this.StatusValueDemicalRender = new NumberRenderObject();
	}

	SetGaugeRender(_Order, _Name, _MaxValue, _Style) {
		this.Name = _Name;
		this.Style = _Style;
		this.Max = _MaxValue;

		// 원본: GameEngineActor* Actor = GetOwner<GameEngineActor>();
		const Actor = this.GetOwner();
		switch (this.Style) {
			case GaugeFrameStyle.Nomal:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Detail:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Detail.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Detail.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Estemate:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Estemate.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Estemate.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));
				this.StatusValueRender.SetMove(new float4(0, 0));

				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition();
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			case GaugeFrameStyle.Physical:
				this.StatusGaugeFrameRender_Layer1 = Actor.CreateRender("StatusGaugeFrame_Layer1_Physical.bmp", _Order);
				this.StatusGaugeFrameRender_Layer1.SetScaleToImage();
				this.StatusGaugeFrameRender_Layer2 = Actor.CreateRender("StatusGaugeFrame_Layer2_Physical.bmp", _Order + 3);
				this.StatusGaugeFrameRender_Layer2.SetScaleToImage();
				this.StatusGaugeEmptyRender = Actor.CreateRender("StatusGauge.bmp", _Order + 1);
				this.StatusGaugeEmptyRender.SetFrame(1);
				this.StatusGaugeEmptyRender.SetScale(new float4(110, 14));
				this.StatusGaugeEmptyRender.SetPosition(new float4(55.0, -1.0));
				this.StatusGaugeRender = Actor.CreateRender("StatusGauge.bmp", _Order + 2);
				this.StatusGaugeRender.SetFrame(0);
				this.StatusGaugeRender.SetScale(new float4(110, 14));
				this.StatusGaugeRender.SetPosition(new float4(-55.0, -1.0));

				this.StatusValueRender.SetOwner(Actor);
				this.StatusValueRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueRender.SetAlign(Align.Right);
				this.StatusValueRender.SetRenderPos(new float4(-5, 0));
				this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));

				this.DemicalPoint = Actor.CreateRender("Num_Status_etc.bmp", _Order + 4);
				this.DemicalPoint.SetScale(new float4(10, 20));
				this.DemicalPoint.SetFrame(0);
				this.DemicalPoint.SetPosition(new float4(5, 0));

				this.StatusValueDemicalRender.SetOwner(Actor);
				this.StatusValueDemicalRender.SetImage("Num_Status.bmp", new float4(10, 20), _Order + 4, RGB(0, 0, 0));
				this.StatusValueDemicalRender.SetAlign(Align.Left);
				this.StatusValueDemicalRender.SetRenderPos(new float4(15, 0));
				this.StatusValueDemicalRender.SetNumOfDigits(2);
				{
					const DemicalValue = Math.trunc(this.StatusValue * 100) % 100;
					this.StatusValueDemicalRender.SetValue(DemicalValue);
				}
				this.NameRender = Actor.CreateRender(_Order + 4);
				this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
				this.NameRender.SetPosition(this.TextRenderPos.sub(this.TextBoxScale.half()));

				this.StartPos = this.StatusGaugeRender.GetPosition().add(new float4(30, 0));
				this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
				break;
			default:
				break;
		}

		this.UpdateValue(this.StatusValue);
	}

	UpdateValue(_Value) {
		if (this.Min > _Value || this.Max < _Value) {
			MsgAssert("범위를 초과하는 값을 입력하였습니다.")
		}

		if (0 >= _Value) {
			this.StatusGaugeEmptyRender.Off();
			this.StatusGaugeRender.Off();
		}
		else {
			this.StatusGaugeEmptyRender.On();
			this.StatusGaugeRender.On();
		}

		this.StatusValue = _Value;
		this.StatusValueRender.SetValue(Math.trunc(this.StatusValue));

		if (this.Style === GaugeFrameStyle.Physical) {
			const DemicalValue = Math.trunc(this.StatusValue * 100) % 100;
			this.StatusValueDemicalRender.SetValue(DemicalValue);
		}
		this.StatusGaugeRender.SetPosition(float4.LerpClamp(this.StartPos, this.EndPos, _Value / (this.Max - this.Min)));
	}

	SetMove(_Move) {
		this.StatusGaugeFrameRender_Layer1.SetMove(_Move);
		this.StatusGaugeEmptyRender.SetMove(_Move);
		this.StatusGaugeRender.SetMove(_Move);
		this.StatusGaugeFrameRender_Layer2.SetMove(_Move);
		this.StatusValueRender.SetMove(_Move);
	}

	SetPosition(_Position) {
		this.StatusGaugeFrameRender_Layer1.SetPosition(_Position);
		this.StatusGaugeEmptyRender.SetPosition(_Position.add(float4.Right.scale(55.0)));
		this.StatusGaugeRender.SetPosition(_Position.add(float4.Left.scale(55.0)));
		this.StatusGaugeFrameRender_Layer2.SetPosition(_Position);
		this.StatusValueRender.SetRenderPos(_Position.add(float4.Left.scale(5.0)));
		this.NameRender.SetPosition(_Position.add(this.TextRenderPos).sub(this.TextBoxScale.half()));
		if (this.Style === GaugeFrameStyle.Physical) {
			this.StartPos = this.StatusGaugeRender.GetPosition().add(new float4(30, 0));
			this.DemicalPoint.SetPosition(_Position.add(float4.Right.scale(5.0)));
			this.StatusValueDemicalRender.SetRenderPos(_Position.add(float4.Right.scale(15.0)));
		}
		else {
			this.StartPos = this.StatusGaugeRender.GetPosition();
		}
		this.EndPos = this.StatusGaugeEmptyRender.GetPosition();
		this.UpdateValue(this.StatusValue);
	}

	SetMin(_Min) {
		this.Min = _Min;
	}

	SetMax(_Max) {
		this.Max = _Max;
	}

	SetNameRender(_Name) {
		this.Name = _Name;
		this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"] = {"GaugeFrameStyle": GaugeFrameStyle, "GaugeRenderObject": GaugeRenderObject};
})();
(function () {

// ===== GameEngineContents/MenuFrame.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// MenuFrame.h / MenuFrame.cpp 의 전사

// enum class MenuFrameStyleEnum
const MenuFrameStyleEnum = Object.freeze({
	"Null": -1,
	Gold: 0,
	Silver: 1,
	Nomal: 2
});

class MenuFrame extends GameEngineActor {
	constructor() {
		super();
		this.MenuFrameScale = new float4(0, 0, 0, 1); // float4 MenuFrameScale = {};
		this.MenuFrameStyle = MenuFrameStyleEnum.Null;
		this.FrameRender = [null, null, null, null, null, null, null, null, null]; // GameEngineRender* FrameRender[9] = {};
		this.FrameRenderOrder = 0;
	}

	// 원본: InitMenuFrameRender(int) 오버로드와 InitMenuFrameRender(PM2RenderOrder) 오버로드
	// (후자는 static_cast<int> 위임) — JS에서 하나로 통합. 기본 인자 _style = Nomal 은 h의 디폴트 값.
	InitMenuFrameRender(_Order, _style = MenuFrameStyleEnum.Nomal) {
		this.FrameRenderOrder = _Order;

		for (const i of this.FrameRender) {
			if (null !== i) {
				MsgAssert("이미 사용하고 있는 MenuFrameRender를 초기화하려고 했습니다")
			}
		}

		this.MenuFrameStyle = _style;

		switch (this.MenuFrameStyle) {
			case MenuFrameStyleEnum.Gold:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample1.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			case MenuFrameStyleEnum.Silver:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample2.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			case MenuFrameStyleEnum.Nomal:
				for (let i = 0; i < 9; i++) {
					this.FrameRender[i] = this.CreateRender("FrameSample3.bmp", _Order);
					this.FrameRender[i].SetFrame(i);
				}
				break;

			default:
				break;
		}
	}

	SetMenuFrameScale(_Scale) {
		if (_Scale.x < 34 || _Scale.y < 34) {
			MsgAssert("메뉴프레임의 최소 크기는 34*34입니다")
		}

		this.MenuFrameScale = _Scale;

		for (let i = 0; i < 9; i++) {
			if (i == 0 || i == 2 || i == 6 || i == 8) {
				this.FrameRender[i].SetScale(new float4(16, 16));
			}
			else if (i == 1 || i == 7) {
				this.FrameRender[i].SetScale(new float4(this.MenuFrameScale.x - 32, 16));
			}
			else if (i == 3 || i == 5) {
				this.FrameRender[i].SetScale(new float4(16, this.MenuFrameScale.y - 32));
			}
			else if (i == 4) {
				this.FrameRender[i].SetScale(this.MenuFrameScale.sub(new float4(32, 32)));
			}

			switch (i) {
				case 0:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, -this.MenuFrameScale.hy() + 8));
					break;
				case 1:
					this.FrameRender[i].SetPosition(new float4(0, -this.MenuFrameScale.hy() + 8));
					break;
				case 2:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, -this.MenuFrameScale.hy() + 8));
					break;
				case 3:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, 0));
					break;
				case 4:
					this.FrameRender[i].SetPosition(new float4(0, 0));
					break;
				case 5:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, 0));
					break;
				case 6:
					this.FrameRender[i].SetPosition(new float4(-this.MenuFrameScale.hx() + 8, this.MenuFrameScale.hy() - 8));
					break;
				case 7:
					this.FrameRender[i].SetPosition(new float4(0, this.MenuFrameScale.hy() - 8));
					break;
				case 8:
					this.FrameRender[i].SetPosition(new float4(this.MenuFrameScale.hx() - 8, this.MenuFrameScale.hy() - 8));
					break;
				default:
					break;
			}
		}
	}

	GetFrameRender() {
		return this.FrameRender;
	}

	GetMenuFrameScale() {
		return this.MenuFrameScale;
	}

	GetFrameRenderOrder() {
		return this.FrameRenderOrder;
	}

	FrameRenderOn() {
		for (const i of this.FrameRender) {
			i.On();
		}
	}

	FrameRenderOff() {
		for (const i of this.FrameRender) {
			i.Off();
		}
	}

	SetMoveFrameRender(_Pos) {
		for (const i of this.FrameRender) {
			i.SetMove(_Pos);
		}
	}

	SetPosFrameRender(_Pos) {
		for (let i = 0; i < 9; i++) {
			switch (i) {
				case 0:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, -this.MenuFrameScale.hy() + 8)));
					break;
				case 1:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, -this.MenuFrameScale.hy() + 8)));
					break;
				case 2:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, -this.MenuFrameScale.hy() + 8)));
					break;
				case 3:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, 0)));
					break;
				case 4:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, 0)));
					break;
				case 5:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, 0)));
					break;
				case 6:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(-this.MenuFrameScale.hx() + 8, this.MenuFrameScale.hy() - 8)));
					break;
				case 7:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(0, this.MenuFrameScale.hy() - 8)));
					break;
				case 8:
					this.FrameRender[i].SetPosition(_Pos.add(new float4(this.MenuFrameScale.hx() - 8, this.MenuFrameScale.hy() - 8)));
					break;
				default:
					break;
			}
		}

	}

	Start() {

	}

	Update(_Deltatime) {

	}

	Render(_Time) {

	}
}

__PM2_EXPORTS__["GameEngineContents/MenuFrame.js"] = {"MenuFrameStyleEnum": MenuFrameStyleEnum, "MenuFrame": MenuFrame};
})();
(function () {

// ===== GameEngineContents/StatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var GaugeRenderObject = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeRenderObject"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
// StatusWindow.h / StatusWindow.cpp 의 전사

class StatusWindow extends MenuFrame {
	constructor() {
		super();
		this.StatusCount = 0;
		this.Gauges = [];
	}

	InsertStatus(_StatusName, _Max, _Style) {
		++this.StatusCount;
		this.SetMenuFrameScale(new float4(220.0 + 20.0, (this.StatusCount * 20.0) + 20.0));
		const InsertGaugePtr = new GaugeRenderObject();
		InsertGaugePtr.SetOwner(this);
		InsertGaugePtr.SetGaugeRender(this.GetFrameRenderOrder() + 1, _StatusName, _Max, _Style);
		this.Gauges.push(InsertGaugePtr);
		for (let i = 0; i < this.Gauges.length; ++i) {
			this.Gauges[i].SetPosition(float4.Up.scale(10).scale(this.Gauges.length - 1).add(float4.Down.scale(20).scale(i)));
		}
		return InsertGaugePtr;
	}

	Start() {

	}

	Update(_DeltaTime) {

	}
}

__PM2_EXPORTS__["GameEngineContents/StatusWindow.js"] = {"StatusWindow": StatusWindow};
})();
(function () {

// ===== GameEngineContents/BasicStatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// BasicStatusWindow.h / BasicStatusWindow.cpp 의 전사

class BasicStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 260);

		this.Constitution = 0;
		this.ConstitutionRender = null;

		this.Strength = 0;
		this.StrengthRender = null;

		this.Intelligence = 0;
		this.IntelligenceRender = null;

		this.Refinement = 0;
		this.RefinementRender = null;

		this.Charisma = 0;
		this.CharismaRender = null;

		this.Morality = 0;
		this.MoralityRender = null;

		this.Faith = 0;
		this.FaithRender = null;

		this.Sin = 0;
		this.SinRender = null;

		this.Sensitivity = 0;
		this.SensitivityRender = null;

		this.Stress = 0;
		this.StressRender = null;

		this.Max = 999;

		this.Style = GaugeFrameStyle.Nomal;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.ConstitutionRender = this.InsertStatus("체력", this.Max, this.Style);
		this.StrengthRender = this.InsertStatus("근력", this.Max, this.Style);
		this.IntelligenceRender = this.InsertStatus("지능", this.Max, this.Style);
		this.RefinementRender = this.InsertStatus("기품", this.Max, this.Style);
		this.CharismaRender = this.InsertStatus("색기", this.Max, this.Style);
		this.MoralityRender = this.InsertStatus("도덕성", this.Max, this.Style);
		this.FaithRender = this.InsertStatus("신앙", this.Max, this.Style);
		this.SinRender = this.InsertStatus("업보", this.Max, this.Style);
		this.SensitivityRender = this.InsertStatus("감수성", this.Max, this.Style);
		this.StressRender = this.InsertStatus("스트레스", this.Max, this.Style);
		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.Constitution !== Olive.OlivePlayer.GetStatue().Constitution) {
			this.Constitution = Olive.OlivePlayer.GetStatue().Constitution;
			this.ConstitutionRender.UpdateValue(this.Constitution);
		}

		if (this.Strength !== Olive.OlivePlayer.GetStatue().Strength) {
			this.Strength = Olive.OlivePlayer.GetStatue().Strength;
			this.StrengthRender.UpdateValue(this.Strength);
		}

		if (this.Intelligence !== Olive.OlivePlayer.GetStatue().Intelligence) {
			this.Intelligence = Olive.OlivePlayer.GetStatue().Intelligence;
			this.IntelligenceRender.UpdateValue(this.Intelligence);
		}

		if (this.Refinement !== Olive.OlivePlayer.GetStatue().Refinement) {
			this.Refinement = Olive.OlivePlayer.GetStatue().Refinement;
			this.RefinementRender.UpdateValue(this.Refinement);
		}

		if (this.Charisma !== Olive.OlivePlayer.GetStatue().Charisma) {
			this.Charisma = Olive.OlivePlayer.GetStatue().Charisma;
			this.CharismaRender.UpdateValue(this.Charisma);
		}

		if (this.Morality !== Olive.OlivePlayer.GetStatue().Morality) {
			this.Morality = Olive.OlivePlayer.GetStatue().Morality;
			this.MoralityRender.UpdateValue(this.Morality);
		}

		if (this.Faith !== Olive.OlivePlayer.GetStatue().Faith) {
			this.Faith = Olive.OlivePlayer.GetStatue().Faith;
			this.FaithRender.UpdateValue(this.Faith);
		}

		if (this.Sin !== Olive.OlivePlayer.GetStatue().Sin) {
			this.Sin = Olive.OlivePlayer.GetStatue().Sin;
			this.SinRender.UpdateValue(this.Sin);
		}

		if (this.Sensitivity !== Olive.OlivePlayer.GetStatue().Sensitivity) {
			this.Sensitivity = Olive.OlivePlayer.GetStatue().Sensitivity;
			this.SensitivityRender.UpdateValue(this.Sensitivity);
		}

		if (this.Stress !== Olive.OlivePlayer.GetStatue().Stress) {
			this.Stress = Olive.OlivePlayer.GetStatue().Stress;
			this.StressRender.UpdateValue(this.Stress);
		}

	}
}

__PM2_EXPORTS__["GameEngineContents/BasicStatusWindow.js"] = {"BasicStatusWindow": BasicStatusWindow};
})();
(function () {

// ===== GameEngineContents/Dialog.js =====
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var GameEngineString = __PM2_EXPORTS__["GameEngineBase/GameEngineString.js"]["GameEngineString"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// Dialog.h / Dialog.cpp 의 전사

// enum class MugShotLR
const MugShotLR = Object.freeze({
	Non: 0,
	Left: 1,
	Right: 2,
});

class Dialog extends MenuFrame {
	constructor() {
		super();
		this.IsMugShot = false;
		this.MugShotLoc = -1;
		this.MugShotFrame = null;
		this.MugShot = null;

		this.DialogFrameScale = new float4(310, 150);

		this.UpdateText = "";
		this.RenderText = "";

		this.TextRender = null;

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(290, 130);

		this.Time = 0;
		this.RenderLen = 1;
		this.RenderEnd = false;
	}

	SetMugPic(_ImageFileName) {
		const Upper = GameEngineString.ToUpper(_ImageFileName);

		if (-1 !== Upper.indexOf("_GOD")) {

			if (null === this.MugShotFrame) {
				this.MugShotFrame = this.CreateRender("MugShotFrame_God.bmp", PM2RenderOrder.Dialog1_MugShotFrame);
			}
			else {
				this.MugShotFrame.SetImage("MugShotFrame_God.bmp");
			}
			this.MugShotFrame.SetScale(new float4(140, 195));

			if (null === this.MugShot) {
				this.MugShot = this.CreateRender(_ImageFileName, PM2RenderOrder.Dialog1_MugShot);
			}
			else {
				this.MugShot.SetImage(_ImageFileName);
			}
			this.MugShot.SetScale(new float4(120, 175));
		}
		else {
			if (null === this.MugShotFrame) {
				this.MugShotFrame = this.CreateRender("MugShotFrame_Nomal.bmp", PM2RenderOrder.Dialog1_MugShotFrame);
			}
			else {
				this.MugShotFrame.SetImage("MugShotFrame_Nomal.bmp");
			}
			this.MugShotFrame.SetScale(new float4(140, 150));

			if (null === this.MugShot) {
				this.MugShot = this.CreateRender(_ImageFileName, PM2RenderOrder.Dialog1_MugShot);
			}
			else {
				this.MugShot.SetImage(_ImageFileName);
			}
			this.MugShot.SetScale(new float4(120, 130));
		}

	}

	// 원본: SetMugLoc(int _MugLoc) 오버로드. SetMugLoc(MugShotLR)은 static_cast<int>로
	// 이 함수에 위임하므로(MugShotLR 값이 int인) JS에서는 하나의 메서드로 동일하게 동작한다.
	SetMugLoc(_MugLoc) {
		switch (_MugLoc) {
			case 0:
				this.MugShotFrame.Off();
				this.MugShot.Off();
				this.InitRenderPos();
				break;
			case 1:
				if (null === this.MugShot.GetImage()) {
					MsgAssert("먼저 머그샷 이미지를 세팅해야합니다");
				}
				this.MugShotFrame.On();
				this.MugShot.On();
				this.SetLeftMugDialog();
				break;
			case 2:
				if (null === this.MugShot.GetImage()) {
					MsgAssert("먼저 머그샷 이미지를 세팅해야합니다");
				}
				this.MugShotFrame.On();
				this.MugShot.On();
				this.SetRightMugDialog();
				break;
			default:
				break;
		}
	}

	SetUpdateText(_Text) {
		this.UpdateText = _Text;
		if (this.RenderText !== this.UpdateText) {
			this.RenderLen = 1;
			this.RenderEnd = false;
		}
		this.RenderText = this.UpdateText;

	}

	SetDialogScale(_Scale) {
		this.DialogFrameScale = _Scale;
		this.SetMenuFrameScale(this.DialogFrameScale);
		this.TextBoxScale = _Scale.sub(new float4(20, 20));
		this.SetTextRender();
	}

	IsRenderEnd() {
		return this.RenderEnd;
	}

	GetUpdateText() {
		return this.UpdateText;
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.RenderLen = 1;
		this.RenderEnd = false;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Dialog1);
		this.SetMenuFrameScale(this.DialogFrameScale);
		this.SetTextRender();
		this.Off();
	}

	Update(_DeltaTime) {
		this.Time += _DeltaTime;
		if (this.Time >= 0.03) {
			this.Time = 0;
			++this.RenderLen;
			if (this.UpdateText.length === this.RenderLen) {
				this.RenderLen = this.UpdateText.length;
				this.RenderEnd = true;
				return;
			}
		}

		this.TextRender.SetText(this.RenderText.substr(0, this.RenderLen), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}

	Render(_Time) {

	}

	SetTextRender() {
		if (null === this.TextRender) {
			this.TextRender = this.CreateRender(PM2RenderOrder.Dialog1_Display);
		}
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextBoxScale.half().neg());
	}

	SetTextRenderPos(_Pos) {
		this.TextRender.SetPosition(this.TextBoxScale.half().neg().add(_Pos));
	}

	SetRightMugDialog() {
		this.InitRenderPos();
		this.SetMoveMugShotRender(new float4(165, 0));
		this.SetPosFrameRender(new float4(-80, 0));
		this.SetTextRenderPos(new float4(-80, 0));
	}

	SetLeftMugDialog() {
		this.InitRenderPos();
		this.SetMoveMugShotRender(new float4(-165, 0));
		this.SetPosFrameRender(new float4(80, 0));
		this.SetTextRenderPos(new float4(80, 0));
	}

	SetMoveMugShotRender(_Move) {
		this.MugShotFrame.SetMove(_Move);
		this.MugShot.SetMove(_Move);
	}

	SetPosMugShotRender(_Pos) {
		this.MugShotFrame.SetPosition(_Pos);
		this.MugShot.SetPosition(_Pos);
	}

	InitRenderPos() {
		this.SetPosFrameRender(new float4(0, 0));
		this.SetPosMugShotRender(new float4(0, 0));
		this.SetTextRenderPos(new float4(0, 0));
	}
}

__PM2_EXPORTS__["GameEngineContents/Dialog.js"] = {"MugShotLR": MugShotLR, "Dialog": Dialog};
})();
(function () {

// ===== GameEngineContents/BottomDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// BottomDialog.h / BottomDialog.cpp 의 전사

class BottomDialog extends Dialog {
	constructor() {
		super();
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetPos(new float4(400, 460));
	}
}

__PM2_EXPORTS__["GameEngineContents/BottomDialog.js"] = {"BottomDialog": BottomDialog};
})();
(function () {

// ===== GameEngineCore/Button.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineCollision = __PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"]["GameEngineCollision"];
var CollisionType = __PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"]["CollisionType"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var CollisionCheckParameter = __PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"]["CollisionCheckParameter"];
// Button.h / Button.cpp 의 전사

// enum class ButtonState
const ButtonState = Object.freeze({
	Release: 0,
	Press: 1,
	Hover: 2,
});

// 원본 파일 전역: GameEngineCollision* CurCollision;
let CurCollision = null;

class Button extends GameEngineActor {
	constructor() {
		super();
		this.ButtonRender = null;
		this.ButtonCollision = null;
		this.PointTargetGroup = 0;
		this.ButtonCollisionType = CollisionType.CT_Rect;
		this.ClickPtr = null;
		this.Scale = new float4(0, 0, 0, 1);
		this.State = ButtonState.Release;
		this.CurImageName = "";
		this.HoverImageName = "";
		this.HoverIndex = -1;
		this.ReleaseImageName = "";
		this.ReleaseIndex = -1;
		this.PressImageName = "";
		this.PressIndex = -1;

		this.State = ButtonState.Release;
	}

	SetClickCallBack(_ClickPtr) {
		this.ClickPtr = _ClickPtr;
	}

	SetTargetCollisionGroup(_PointTargetGroup) {
		this.PointTargetGroup = _PointTargetGroup;
		if (null === this.ButtonCollision) {
			this.ButtonCollision = this.CreateCollision(this.PointTargetGroup);
		}
	}

	SetButtonCollisionType(_ButtonCollisionType) {
		this.ButtonCollisionType = _ButtonCollisionType;
	}

	// 원본: SetHoverImage / SetReleaseImage / SetPressImage — 동일한 switch 본문
	SetImageByState() {
		switch (this.State) {
			case ButtonState.Release:
				this.CurImageName = this.ReleaseImageName;
				this.ButtonRender.SetImage(this.ReleaseImageName);
				if (-1 !== this.ReleaseIndex) {
					this.ButtonRender.SetFrame(this.ReleaseIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			case ButtonState.Press:
				this.CurImageName = this.PressImageName;
				this.ButtonRender.SetImage(this.PressImageName);
				if (-1 !== this.PressIndex) {
					this.ButtonRender.SetFrame(this.PressIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			case ButtonState.Hover:
				this.CurImageName = this.HoverImageName;
				this.ButtonRender.SetImage(this.HoverImageName);
				if (-1 !== this.HoverIndex) {
					this.ButtonRender.SetFrame(this.HoverIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			default:
				break;
		}
	}

	SetHoverImage(_Name, _HoverIndex = -1) {
		this.HoverImageName = _Name;
		this.HoverIndex = _HoverIndex;
		this.SetImageByState();
	}

	SetReleaseImage(_Name, _ReleaseIndex = -1) {
		this.ReleaseImageName = _Name;
		this.ReleaseIndex = _ReleaseIndex;
		this.SetImageByState();
	}

	SetPressImage(_Name, _PressIndex = -1) {
		this.PressImageName = _Name;
		this.PressIndex = _PressIndex;
		this.SetImageByState();
	}

	GetButtonRender() {
		return this.ButtonRender;
	}

	GetButtonCollision() {
		return this.ButtonCollision;
	}

	GetState() {
		return this.State;
	}

	GetHoverIndex() {
		return this.HoverIndex;
	}

	GetReleaseIndex() {
		return this.ReleaseIndex;
	}

	GetPressIndex() {
		return this.PressIndex;
	}

	SetRenderOrder(_Value) {
		this.ButtonRender.SetOrder(_Value);
	}

	SetScale(_Scale) {
		this.Scale = _Scale;
		this.ButtonCollision.SetScale(this.Scale);
	}

	SetCollisionOrder(_Order) {
		this.ButtonCollision.SetOrder(_Order);
	}

	GetScale() {
		return this.Scale;
	}

	Off() {
		// 원본: GameEngineActor::Off();
		GameEngineActor.prototype.Off.call(this);

		if (CurCollision === this.ButtonCollision) {
			CurCollision = null;
		}
	}

	Start() {
		this.ButtonRender = this.CreateRender(0);
		this.ButtonCollision = this.CreateCollision(0);
	}

	Update(_DeltaTime) {
		this.State = ButtonState.Release;

		const CheckParam = new CollisionCheckParameterLike();
		CheckParam.TargetGroup = this.PointTargetGroup;
		CheckParam.TargetColType = CollisionType.CT_Point;
		CheckParam.ThisColType = this.ButtonCollisionType;

		if (true === this.ButtonCollision.Collision(CheckParam)) {
			if (true === GameEngineInput.IsPress("EngineMouseLeft") && null !== CurCollision) {
				this.State = ButtonState.Press;
			} else if (true === GameEngineInput.IsUp("EngineMouseLeft") && null !== this.ClickPtr && this.ButtonCollision === CurCollision) {
				CurCollision = null;
				this.ClickPtr(this);
			} else if ((true === GameEngineInput.IsFree("EngineMouseLeft") && null === CurCollision) || this.ButtonCollision === CurCollision) {
				CurCollision = this.ButtonCollision;
				this.State = ButtonState.Hover;
			}
		} else {
			if (CurCollision === this.ButtonCollision) {
				CurCollision = null;
			}
		}

		this.SetImageByState();
	}

	LevelChangeEnd(_Level) {
	}
}

// 원본: Button.cpp의 Collision({ .TargetGroup = ..., .TargetColType = ..., .ThisColType = ... })
// 지정 초기화자 대응용 헬퍼 (GameEngineCollision.CollisionCheckParameter와 동일 구조)
function CollisionCheckParameterLike() {
	return new CollisionCheckParameter();
}

__PM2_EXPORTS__["GameEngineCore/Button.js"] = {"ButtonState": ButtonState, "Button": Button};
})();
(function () {

// ===== GameEngineContents/GlobalButton.js =====
var Button = __PM2_EXPORTS__["GameEngineCore/Button.js"]["Button"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// GlobalButton.h / GlobalButton.cpp 의 전사

class GlobalButton extends Button {
	constructor() {
		super();
	}

	Render(_DeltaTime) {
		//디버그
		if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Release) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH)(채움 없음) + CreatePen(PS_SOLID, 0, RGB(255, 0, 0))
			DoubleDC.strokeStyle = "rgb(255, 0, 0)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
		else if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Hover) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH) + CreatePen(PS_SOLID, 0, RGB(0, 0, 255))
			DoubleDC.strokeStyle = "rgb(0, 0, 255)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
		else if (true === GameEngineCore.GetInst().IsDebug() && this.GetState() === ButtonState.Press) {
			const DoubleDC = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
			const ActorPos = this.GetPos().sub(this.GetLevel().GetCameraPos());
			// 원본: GetStockObject(NULL_BRUSH) + CreatePen(PS_SOLID, 0, RGB(0, 255, 0))
			DoubleDC.strokeStyle = "rgb(0, 255, 0)";
			DoubleDC.lineWidth = 1;

			DoubleDC.strokeRect(
				ActorPos.ix() - Math.trunc(this.GetScale().hx()),
				ActorPos.iy() - Math.trunc(this.GetScale().hy()),
				Math.trunc(this.GetScale().hx()) * 2,
				Math.trunc(this.GetScale().hy()) * 2
			);
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/GlobalButton.js"] = {"GlobalButton": GlobalButton};
})();
(function () {

// ===== GameEngineContents/Button_BloodType.js =====
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var BloodType = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["BloodType"];
// Button_BloodType.h / Button_BloodType.cpp 의 전사

class Button_BloodType extends GlobalButton {
	constructor() {
		super();
		this.BloodTypeValue = BloodType.Null;
	}
}

__PM2_EXPORTS__["GameEngineContents/Button_BloodType.js"] = {"Button_BloodType": Button_BloodType};
})();
(function () {

// ===== GameEngineContents/Button_Date.js =====
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
// Button_Date.h / Button_Date.cpp 의 전사

class Button_Date extends GlobalButton {
	constructor() {
		super();
		this.Value = new Date();
	}
}

__PM2_EXPORTS__["GameEngineContents/Button_Date.js"] = {"Button_Date": Button_Date};
})();
(function () {

// ===== GameEngineContents/Caption.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// Caption.h / Caption.cpp 의 전사

class Caption extends GameEngineActor {
	constructor() {
		super();
		this.UpdateCaption = "";
		this.CaptionRender = null;
		this.CaptionOutline1Render = null;
		this.CaptionOutline2Render = null;
		this.CaptionOutline3Render = null;
		this.CaptionOutline4Render = null;

		this.CaptionPos = new float4(400, 500);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextOutlineColor = RGB(0, 0, 0);
		this.CaptionTextBoxScale = new float4(800, 100);
	}

	SetUpdateText(_Text) {
		this.UpdateCaption = _Text;
		this.CaptionRender.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.CaptionTextBoxScale);
		this.CaptionOutline1Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline2Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline3Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionOutline4Render.SetText(this.UpdateCaption, this.TextHeight, this.TextType, TextAlign.Center, this.TextOutlineColor, this.CaptionTextBoxScale);
		this.CaptionRender.SetPosition(this.CaptionTextBoxScale.half().neg());
		this.CaptionOutline1Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Up.mul(new float4(1, 1))));
		this.CaptionOutline2Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Down.mul(new float4(1, 1))));
		this.CaptionOutline3Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Left.mul(new float4(1, 1))));
		this.CaptionOutline4Render.SetPosition(this.CaptionTextBoxScale.half().neg().add(float4.Right.mul(new float4(1, 1))));
	}

	Start() {
		this.SetPos(this.CaptionPos);
		this.CaptionRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CaptionOutline1Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CaptionOutline4Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.Off();
	}

	Render(_DeltaTime) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Caption.js"] = {"Caption": Caption};
})();
(function () {

// ===== GameEngineContents/CharButton.js =====
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
// CharButton.h / CharButton.cpp 의 전사

class CharButton extends GlobalButton {
	constructor() {
		super();
		this.Chracter = 0; // 오타 "Chracter" 원본 유지
	}
}

__PM2_EXPORTS__["GameEngineContents/CharButton.js"] = {"CharButton": CharButton};
})();
(function () {

// ===== GameEngineContents/CubeDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var MugShotLR = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["MugShotLR"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// CubeDialog.h / CubeDialog.cpp 의 전사

// enum class CubeFace
const CubeFace = Object.freeze({
	Nomal: 0,
	Happy: 1,
	Proud: 2,
	BigWorry: 3,
	Excited: 4,
	Embarrassment: 5,
	Anger: 6,
	Worry: 7,
	Surprise: 8,
	Hmm: 9,
	Serious: 10,
	SuperExcited: 11,
	OMG: 12,
	Love: 13,
});

class CubeDialog extends Dialog {
	constructor() {
		super();
		this.CubeMugshot = new Map(); // std::map<CubeFace, std::string>
		this.ActorPos = new float4(250, 500);
	}

	UpdateCubeDialog(_Face, _Dialog) {
		this.On();
		this.SetMugPic(this.CubeMugshot.get(_Face));
		this.SetUpdateText(_Dialog);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetCubeMugShot();
		this.SetMugPic(this.CubeMugshot.get(CubeFace.Nomal));
		this.SetMugLoc(MugShotLR.Right);
		this.SetPos(this.ActorPos);
	}

	SetCubeMugShot() {
		this.CubeMugshot.set(CubeFace.Nomal, "Mug_Cube_Nomal.bmp");
		this.CubeMugshot.set(CubeFace.Anger, "Mug_Cube_Anger.bmp");
		this.CubeMugshot.set(CubeFace.BigWorry, "Mug_Cube_BigWorry.bmp");
		this.CubeMugshot.set(CubeFace.Embarrassment, "Mug_Cube_Embarrassment.bmp");
		this.CubeMugshot.set(CubeFace.Excited, "Mug_Cube_Excited.bmp");
		this.CubeMugshot.set(CubeFace.Happy, "Mug_Cube_Happy.bmp");
		this.CubeMugshot.set(CubeFace.Hmm, "Mug_Cube_Hmm.bmp");
		this.CubeMugshot.set(CubeFace.Love, "Mug_Cube_Love.bmp");
		this.CubeMugshot.set(CubeFace.OMG, "Mug_Cube_OMG.bmp");
		this.CubeMugshot.set(CubeFace.Proud, "Mug_Cube_Proud.bmp");
		this.CubeMugshot.set(CubeFace.Serious, "Mug_Cube_Serious.bmp");
		this.CubeMugshot.set(CubeFace.SuperExcited, "Mug_Cube_SuperExcited.bmp");
		this.CubeMugshot.set(CubeFace.Surprise, "Mug_Cube_Surprise.bmp");
		this.CubeMugshot.set(CubeFace.Worry, "Mug_Cube_Worry.bmp");
	}
}

__PM2_EXPORTS__["GameEngineContents/CubeDialog.js"] = {"CubeFace": CubeFace, "CubeDialog": CubeDialog};
})();
(function () {

// ===== GameEngineContents/IconButton.js =====
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var IconCode = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["IconCode"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// IconButton.h / IconButton.cpp 의 전사

class IconButton extends MenuFrame {
	constructor() {
		super();
		this.ButtonScale = new float4(160, 52);
		this.Button = null;

		this.IconRender = null;
		this.ICode = IconCode.Null;
		this.IconScale = new float4(40, 40);
		this.IconPos = new float4(-50, 0);

		this.NameRender = null;
		this.Name = "";
		this.NameBoxScale = new float4(90, 20);
		this.NamePos = new float4(-20, -20);

		this.DifficultyRender = null;
		this.Difficulty = "";
		this.DifficultyBoxScale = new float4(90, 20);
		this.DifficultyPos = new float4(-20, 0);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);

		this.PriceRender = new NumberRenderObject();
		this.Price = 30;
		this.PriceRenderPos = new float4(38, 8);
		this.PriceRenderScale = new float4(10, 20);

		this.Alphabet_G = null;
		this.Alphabet_GPos = new float4(48, 8);
	}

	SetPos(_Pos) {
		// 원본: GameEngineActor::SetPos(_Pos);
		GameEngineActor.prototype.SetPos.call(this, _Pos);
		this.Button.SetPos(_Pos);
	}

	SetIconButton(_IconCode, _Name, _Difficulty, _Price, _Pos) {
		this.Button.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.Button.SetScale(this.ButtonScale);
		this.Button.SetRenderOrder(PM2RenderOrder.Menu2_Button);
		this.Button.SetCollisionOrder(PM2RenderOrder.Menu2_Button);
		this.Button.SetPos(this.GetPos());
		this.Button.SetReleaseImage("SelectButton_Release.bmp");
		this.Button.SetHoverImage("IconButton_Hover.bmp");
		this.Button.SetPressImage("IconButton_Hover.bmp");

		this.ICode = _IconCode;
		this.Name = _Name;
		this.Difficulty = _Difficulty;
		this.Price = _Price;

		this.SetPos(_Pos);

		this.IconRender.SetScale(this.IconScale);
		this.IconRender.SetFrame(this.ICode);
		this.IconRender.SetPosition(this.IconPos);

		this.NameRender.SetText(this.Name, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.NameBoxScale);
		this.NameRender.SetPosition(this.NamePos);

		this.DifficultyRender.SetText(this.Difficulty, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.DifficultyBoxScale);
		this.DifficultyRender.SetPosition(this.DifficultyPos);

		this.PriceRender.SetImage("Num_Status.bmp", this.PriceRenderScale, PM2RenderOrder.Menu2_Display, RGB(0, 0, 0));
		this.PriceRender.SetAlign(Align.Right);
		this.PriceRender.SetValue(this.Price);
		this.PriceRender.SetRenderPos(this.PriceRenderPos);

		this.Alphabet_G.SetTransColor(RGB(0, 0, 0));
		this.Alphabet_G.SetScale(this.PriceRenderScale);
		this.Alphabet_G.SetFrame(2);
		this.Alphabet_G.SetPosition(this.Alphabet_GPos);
	}

	GetButton() {
		return this.Button;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.Button.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.Button.Off();
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu2_Button, MenuFrameStyleEnum.Silver);
		this.SetMenuFrameScale(this.ButtonScale);
		this.Button = this.GetLevel().CreateActor(GlobalButton, PM2ActorOrder.Menu2_Button);
		this.IconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu2_Display);
		this.NameRender = this.CreateRender(PM2RenderOrder.Menu2_Display);
		this.DifficultyRender = this.CreateRender(PM2RenderOrder.Menu2_Display);
		this.PriceRender.SetOwner(this);
		this.Alphabet_G = this.CreateRender("Num_Status_etc.bmp", PM2RenderOrder.Menu2_Display);
	}
}

__PM2_EXPORTS__["GameEngineContents/IconButton.js"] = {"IconButton": IconButton};
})();
(function () {

// ===== GameEngineContents/OnedaySchedule.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var GameEngineMath = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["GameEngineMath"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
var IconCode = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["IconCode"];
// OnedaySchedule.h / OnedaySchedule.cpp 의 전사

class OnedaySchedule extends GameEngineActor {
	constructor() {
		super();
		this.DateValue = new Date();
		this.ScheduleValue = ScheduleLabel.Null;
		this.Today = new Date();
		this.NextDate = new Date();
		this.ScheduleOrder = 0;
		this.DayNumRender = new NumberRenderObject();
		this.DayNumRenderScale_1 = new float4(20, 20);
		this.DayNumRenderScale_2 = new float4(10, 20);
		this.DayNumRenderPos_1 = new float4(10, 10);
		this.DayNumRenderPos_2 = new float4(15, 10);
		this.IconRender = null;
		this.IconRenderScale = new float4(40, 40);
	}

	UpdateDayNumRender() {
		if (this.DateValue.IsNullDate() || this.NextDate.Greater(this.DateValue)) {
			this.DayNumRender.Off();
		}
		else {
			this.DayNumRender.On();

			if (1 === GameEngineMath.GetLenth(this.DateValue.GetDay())) {
				this.DayNumRender.SetImage("Num_Age.bmp", this.DayNumRenderScale_1, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
				this.DayNumRender.SetValue(this.DateValue.GetDay());
				this.DayNumRender.SetRenderPos(this.DayNumRenderPos_1);
			}
			else if (2 === GameEngineMath.GetLenth(this.DateValue.GetDay())) {
				this.DayNumRender.SetImage("Num.bmp", this.DayNumRenderScale_2, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
				this.DayNumRender.SetValue(this.DateValue.GetDay());
				this.DayNumRender.SetRenderPos(this.DayNumRenderPos_2);
			}
		}
	}

	GetScheduleOrder() {
		return this.ScheduleOrder;
	}

	SetScheduleOrder(_Order) {
		this.ScheduleOrder = _Order;
	}

	Start() {
		this.SetDayNumRender();
		this.IconRender = this.CreateRender("Icon.bmp", PM2RenderOrder.Menu1_Display_Shadow);
		this.IconRender.SetScale(this.IconRenderScale);
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.NextDate = this.Today.GetNextDate();
		}

		switch (this.ScheduleValue) {
			case ScheduleLabel.Null:
				this.IconRender.SetFrame(IconCode["빈칸"]);
				break;
			case ScheduleLabel["자연과학"]:
				this.IconRender.SetFrame(IconCode["자연과학"]);
				break;
			case ScheduleLabel["신학"]:
				this.IconRender.SetFrame(IconCode["신학"]);
				break;
			case ScheduleLabel["군사학"]:
				this.IconRender.SetFrame(IconCode["군사학"]);
				break;
			case ScheduleLabel["검술"]:
				this.IconRender.SetFrame(IconCode["검술"]);
				break;
			case ScheduleLabel["격투술"]:
				this.IconRender.SetFrame(IconCode["격투술"]);
				break;
			case ScheduleLabel["마법"]:
				this.IconRender.SetFrame(IconCode["마법"]);
				break;
			case ScheduleLabel["시문학"]:
				this.IconRender.SetFrame(IconCode["시문학"]);
				break;
			case ScheduleLabel["예법"]:
				this.IconRender.SetFrame(IconCode["예법"]);
				break;
			case ScheduleLabel["무용"]:
				this.IconRender.SetFrame(IconCode["무용"]);
				break;
			case ScheduleLabel["미술"]:
				this.IconRender.SetFrame(IconCode["미술"]);
				break;
			case ScheduleLabel["집안일"]:
				this.IconRender.SetFrame(IconCode["집안일"]);
				break;
			case ScheduleLabel["보모"]:
				this.IconRender.SetFrame(IconCode["아이보기"]);
				break;
			case ScheduleLabel["여관"]:
				this.IconRender.SetFrame(IconCode["여관"]);
				break;
			case ScheduleLabel["농장"]:
				this.IconRender.SetFrame(IconCode["농장"]);
				break;
			case ScheduleLabel["교회"]:
				this.IconRender.SetFrame(IconCode["신학"]);
				break;
			case ScheduleLabel["요리점"]:
				this.IconRender.SetFrame(IconCode["레스토랑"]);
				break;
			case ScheduleLabel["나무꾼"]:
				this.IconRender.SetFrame(IconCode["나무꾼"]);
				break;
			case ScheduleLabel["미용실"]:
				this.IconRender.SetFrame(IconCode["미용실"]);
				break;
			case ScheduleLabel["미장이"]:
				this.IconRender.SetFrame(IconCode["미장이"]);
				break;
			case ScheduleLabel["사냥꾼"]:
				this.IconRender.SetFrame(IconCode["사냥꾼"]);
				break;
			case ScheduleLabel["묘지기"]:
				this.IconRender.SetFrame(IconCode["묘지기"]);
				break;
			case ScheduleLabel["가정교사"]:
				this.IconRender.SetFrame(IconCode["가정교사"]);
				break;
			case ScheduleLabel["주점"]:
				this.IconRender.SetFrame(IconCode["주점"]);
				break;
			case ScheduleLabel["어둠의주점"]:
				this.IconRender.SetFrame(IconCode["어둠의주점"]);
				break;
			case ScheduleLabel["어둠의전당"]:
				this.IconRender.SetFrame(IconCode["어둠의전당"]);
				break;
			case ScheduleLabel["동부수풀지대"]:
				this.IconRender.SetFrame(IconCode["무사수행_동부산림지대"]);
				break;
			case ScheduleLabel["남부폭포지대"]:
				this.IconRender.SetFrame(IconCode["남부폭포지대"]);
				break;
			case ScheduleLabel["북부빙산지대"]:
				this.IconRender.SetFrame(IconCode["북부빙산지대"]);
				break;
			case ScheduleLabel["서부사막지대"]:
				this.IconRender.SetFrame(IconCode["서부사막지대"]);
				break;
			case ScheduleLabel["자유행동"]:
				this.IconRender.SetFrame(IconCode["자유행동"]);
				break;
			case ScheduleLabel["바캉스"]:
				this.IconRender.SetFrame(IconCode["바캉스"]);
				break;
			case ScheduleLabel["간호"]:
				this.IconRender.SetFrame(IconCode["간호"]);
				break;
			case ScheduleLabel["요양"]:
				this.IconRender.SetFrame(IconCode["요양"]);
				break;
			case ScheduleLabel["감시"]:
				this.IconRender.SetFrame(IconCode["감시"]);
				break;
			default:
				break;
		}

	}

	SetDayNumRender() {
		this.DayNumRender.SetOwner(this);
		this.DayNumRender.SetImage("Num.bmp", this.DayNumRenderScale_2, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.DayNumRender.SetAlign(Align.Right);
		this.DayNumRender.SetValue(10);
	}
}

__PM2_EXPORTS__["GameEngineContents/OnedaySchedule.js"] = {"OnedaySchedule": OnedaySchedule};
})();
(function () {

// ===== GameEngineContents/FoodCostDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// FoodCostDialog.h / FoodCostDialog.cpp 의 전사

class FoodCostDialog extends Dialog {
	constructor() {
		super();
		this.OliveDiet = Diet["무리하지_않는다"];

		this.ActorPos = new float4(235, 475);
		this.ActorScale = new float4(390, 124);

		this.FoodCostRedner = null; // 오타 "Redner" 원본 유지
		this.FoodCostRednerPos = new float4(-95, -91);

		this.FoodCostNumRender = new NumberRenderObject();
		this.FoodCostNumRenderPos = new float4(-48, -92);

		this.TextRender = null;
		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(80, 21);
		this.TextRenderPos = new float4(-175, -103);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetDialogScale(this.ActorScale);
		this.SetPos(this.ActorPos);

		this.FoodCostRedner = this.CreateRender("FoodCost.bmp", PM2RenderOrder.Menu1);
		this.FoodCostRedner.SetScaleToImage();
		this.FoodCostRedner.SetPosition(this.FoodCostRednerPos);

		this.FoodCostNumRender.SetOwner(this);
		this.FoodCostNumRender.SetImage("Num.bmp", new float4(10, 19), PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.FoodCostNumRender.SetAlign(Align.Right);
		this.FoodCostNumRender.SetValue(30);
		this.FoodCostNumRender.SetRenderPos(this.FoodCostNumRenderPos);

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.TextRender.SetText("식비", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, new float4(80, 21));
		this.TextRender.SetPosition(this.TextRenderPos);

		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
		}

		this.OliveDiet = Olive.OlivePlayer.GetOliveDiet();
		this.SetRender();
		// 원본: Dialog::Update(_DeltaTime);
		super.Update(_DeltaTime);
	}

	SetRender() {
		switch (this.OliveDiet) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.SetUpdateText("식비가 30G 필요합니다");
				this.FoodCostNumRender.SetValue(30);
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.SetUpdateText("식비가 80G 필요합니다");
				this.FoodCostNumRender.SetValue(80);
				break;
			case Diet["얌전한_아이로"]:
				this.SetUpdateText("식비가 10G 필요합니다");
				this.FoodCostNumRender.SetValue(10);
				break;
			case Diet["다이어트_시킨다"]:
				this.SetUpdateText("식비가 5G 필요합니다");
				this.FoodCostNumRender.SetValue(5);
				break;
			default:
				break;
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/FoodCostDialog.js"] = {"FoodCostDialog": FoodCostDialog};
})();
(function () {

// ===== GameEngineContents/SelectionMenu.js =====
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
// SelectionMenu.h / SelectionMenu.cpp 의 전사

class SelectionMenu extends MenuFrame {
	constructor() {
		super();
		this.SelectButtons = [];      // std::vector<GlobalButton*>
		this.CountButton = 0;

		this.StringRenders = [];      // std::vector<GameEngineRender*>
		this.StringShadowRenders = []; // std::vector<GameEngineRender*>
		this.StringHoverRenders = []; // std::vector<GameEngineRender*>
		this.ButtonStrings = [];      // std::vector<std::string>
	}

	// 원본: std::vector<GlobalButton*>& GetSelectButtons() { return SelectButtons; }
	GetSelectButtons() {
		return this.SelectButtons;
	}

	// 원본: SetSelectionMenu(int _ActorOrder, int _RenderOrder) 오버로드와
	// (PM2ActorOrder, PM2RenderOrder) 오버로드(static_cast<int> 위임) — JS에서 하나로 통합
	SetSelectionMenu(_Count, _Pos, _xScale, _ActorOrder, _RenderOrder) {
		this.CountButton = _Count;
		this.SetMenuFrameScale(new float4(_xScale, (_Count * 26.0) + 40.0));
		this.SetPos(_Pos);
		this.SelectButtons = new Array(this.CountButton).fill(null); // 원본: SelectButtons.resize(CountButton)
		const Level = this.GetLevel();
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i] = Level.CreateActor(GlobalButton, _ActorOrder);
			this.SelectButtons[i].SetReleaseImage("SelectButton_Release.bmp");
			this.SelectButtons[i].SetHoverImage("SelectButton_Hover.bmp");
			this.SelectButtons[i].SetPressImage("SelectButton_Hover.bmp");
			this.SelectButtons[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.SelectButtons[i].SetScale(new float4(_xScale - 20, 26.0));
			this.SelectButtons[i].SetPos(_Pos.add(float4.Up.scale(this.SelectButtons[i].GetScale().half()).scale(this.SelectButtons.length - 1)).add(float4.Down.scale(this.SelectButtons[i].GetScale().scale(i))));
			this.SelectButtons[i].SetRenderOrder(_RenderOrder);
		}
		this.StringRenders = new Array(this.CountButton).fill(null);       // 원본: StringRenders.resize(CountButton)
		this.StringShadowRenders = new Array(this.CountButton).fill(null); // 원본: StringShadowRenders.resize(CountButton)
		this.StringHoverRenders = new Array(this.CountButton).fill(null);  // 원본: StringHoverRenders.resize(CountButton)
	}

	SetButtonString(_RenderOrder, _ButtonIndex, _Text) {
		this.StringRenders[_ButtonIndex] = this.CreateRender(_RenderOrder);
		this.StringRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(255, 255, 255), this.SelectButtons[_ButtonIndex].GetScale());
		const SetStringPosition = float4.Left.scale(this.SelectButtons[_ButtonIndex].GetScale().half())
			.add(float4.Up.scale(this.SelectButtons[_ButtonIndex].GetScale().half()).scale(this.SelectButtons.length - 1))
			.add(float4.Down.scale(this.SelectButtons[_ButtonIndex].GetScale().scale(_ButtonIndex)))
			.add(float4.Up.half().scale(this.StringRenders[_ButtonIndex].GetTextHeight()));
		this.StringRenders[_ButtonIndex].SetPosition(SetStringPosition);

		let OrderDifference = PM2RenderOrder.Menu0_Display - PM2RenderOrder.Menu0_Display_Shadow;
		this.StringShadowRenders[_ButtonIndex] = this.CreateRender(_RenderOrder - OrderDifference);
		this.StringShadowRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(0, 0, 0), this.SelectButtons[_ButtonIndex].GetScale());
		this.StringShadowRenders[_ButtonIndex].SetPosition(SetStringPosition.add(new float4(0, 2)));

		OrderDifference = PM2RenderOrder.Menu0_Display - PM2RenderOrder.Menu0_Display_Effect;
		this.StringHoverRenders[_ButtonIndex] = this.CreateRender(_RenderOrder - OrderDifference);
		this.StringHoverRenders[_ButtonIndex].SetText(_Text, 18, "굴림", TextAlign.Left, RGB(236, 152, 132), this.SelectButtons[_ButtonIndex].GetScale());
		this.StringHoverRenders[_ButtonIndex].SetPosition(SetStringPosition.add(new float4(0, 1)));

		this.StringHoverRenders[_ButtonIndex].Off();
	}

	On() {
		// 원본: GameEngineObject::On();
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i].On();
		}
	}

	Off() {
		// 원본: GameEngineObject::Off();
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < this.SelectButtons.length; i++) {
			this.SelectButtons[i].Off();
		}
	}

	Start() {

	}

	Update(_Deltatime) {
		for (let i = 0; i < this.SelectButtons.length; i++) {
			if (ButtonState.Release === this.SelectButtons[i].GetState()) {
				this.StringHoverRenders[i].Off();
				this.StringShadowRenders[i].On();
			}
			else {
				this.StringHoverRenders[i].On();
				this.StringShadowRenders[i].Off();
			}
		}
	}

	Render(_Time) {

	}
}

__PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"] = {"SelectionMenu": SelectionMenu};
})();
(function () {

// ===== GameEngineContents/ConverstionSelectionMenu.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// ConverstionSelectionMenu.h / ConverstionSelectionMenu.cpp 의 전사
// (파일명 오타 "Converstion"은 원본 그대로 유지)

class ConverstionSelectionMenu extends SelectionMenu {
	constructor() {
		super();
		this.AcMainMenu = null;
		this.ActorPos = new float4(685, 334);
		this.Xscale = 170.0;
	}

	Start() {
		this.AcMainMenu = MainMenu.GetAcMainMenu();

		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(3, this.ActorPos, this.Xscale, PM2ActorOrder.Menu1_Button, PM2RenderOrder.Menu0_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "부녀간의 이야기");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "용돈");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "설교");
		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			this.AcMainMenu.On();
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/ConverstionSelectionMenu.js"] = {"ConverstionSelectionMenu": ConverstionSelectionMenu};
})();
(function () {

// ===== GameEngineContents/SelectDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// SelectDialog.h / SelectDialog.cpp 의 전사

class SelectDialog extends Dialog {
	constructor() {
		super();
		this.ActorScale = new float4(310, 76);
		this.ActorPos = new float4(170, 300);
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetDialogScale(this.ActorScale);
		this.SetPos(this.ActorPos);
	}
}

__PM2_EXPORTS__["GameEngineContents/SelectDialog.js"] = {"SelectDialog": SelectDialog};
})();
(function () {

// ===== GameEngineContents/DietFinalConfirmSelectionMenu.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var CubeDialog = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeDialog"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var SelectDialog = __PM2_EXPORTS__["GameEngineContents/SelectDialog.js"]["SelectDialog"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// DietFinalConfirmSelectionMenu.h / DietFinalConfirmSelectionMenu.cpp 의 전사

class DietFinalConfirmSelectionMenu extends SelectionMenu {
	static DietState = Diet.Null;
	static AcCubeDialog = null;
	static AcDietFinalConfirmSelectionMenu = null;

	constructor() {
		super();
		this.ActorPos = new float4(685, 320);
		this.Xscale = 140;

		this.AcSelectDialog = null;

		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu = this;
	}

	On() {
		// 원본: SelectionMenu::On();
		super.On();
		this.AcSelectDialog.On();
	}

	Off() {
		// 원본: SelectionMenu::Off();
		super.Off();
		this.AcSelectDialog.Off();
	}

	SetDietState(_State) {
		DietFinalConfirmSelectionMenu.DietState = _State;
	}

	Start() {
		this.AcSelectDialog = this.GetLevel().CreateActor(SelectDialog, PM2ActorOrder.Menu2);
		this.AcSelectDialog.SetUpdateText(" ");
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())->GetAcCubeDialog()
		DietFinalConfirmSelectionMenu.AcCubeDialog = this.GetLevel().GetAcCubeDialog();

		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "이 방침으로");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "지금까지대로");
		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		switch (DietFinalConfirmSelectionMenu.DietState) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.AcSelectDialog.SetUpdateText("무리하지 않는다");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n30G 들어갑니다. 무리 없는 식\n생활을 보낼 수 있습니다」");
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.AcSelectDialog.SetUpdateText("어쨌든 튼튼하게");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n80G 들어갑니다. 체력이 올라가\n겠죠」");
				break;
			case Diet["얌전한_아이로"]:
				this.AcSelectDialog.SetUpdateText("얌전한 아이로");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n10G 들어갑니다. 약간 건강에 부\n담이 갈지도 모릅니다」");
				break;
			case Diet["다이어트_시킨다"]:
				this.AcSelectDialog.SetUpdateText("다이어트 시킨다");
				DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「그 방침이라면 매달 식비가\n5G 밖에 들지 않습니다. 아가씨의\n몸무게를 줄이고 싶다면, 이 방\n침으로 가시죠. 단, 체력을 상\n당히 소모하므로 주의하시기 바\n랍니다」");
				break;
			default:
				break;
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(DietFinalConfirmSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(DietFinalConfirmSelectionMenu.Click1);
	}

	static Click0(_Button) {
		Olive.OlivePlayer.SetOliveDiet(DietFinalConfirmSelectionMenu.DietState);
		DietFinalConfirmSelectionMenu.DietState = Diet.Null;
		DietFinalConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Proud, "예, 알겠습니다. 다음달부터 그\n렇게 하겠습니다");
		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu.Off();
	}

	static Click1(_Button) {
		DietFinalConfirmSelectionMenu.AcDietFinalConfirmSelectionMenu.Off();
		DietFinalConfirmSelectionMenu.AcCubeDialog.Off();
		MainMenu.GetAcMainMenu().On();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(DietFinalConfirmSelectionMenu.prototype, __m, { value: function (...args) { return DietFinalConfirmSelectionMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/DietFinalConfirmSelectionMenu.js"] = {"DietFinalConfirmSelectionMenu": DietFinalConfirmSelectionMenu};
})();
(function () {

// ===== GameEngineContents/DietSelectionMenu.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var CubeDialog = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeDialog"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var DietFinalConfirmSelectionMenu;
__PM2_LATE__.push(function () { DietFinalConfirmSelectionMenu = __PM2_EXPORTS__["GameEngineContents/DietFinalConfirmSelectionMenu.js"]["DietFinalConfirmSelectionMenu"]; });
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// DietSelectionMenu.h / DietSelectionMenu.cpp 의 전사

class DietSelectionMenu extends SelectionMenu {
	static AcDietSelectionMenu = null;
	static AcDietFinalConfirmSelectionMenu = null;
	static AcCubeDialog = null;

	constructor() {
		super();
		this.AcMainMenu = null;
		this.ActorPos = new float4(685, 346);
		this.Xscale = 170.0;

		DietSelectionMenu.AcDietSelectionMenu = this;
	}

	static GetAcDietSelectionMenu() {
		return DietSelectionMenu.AcDietSelectionMenu;
	}

	Start() {
		this.AcMainMenu = MainMenu.GetAcMainMenu();
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())->GetAcCubeDialog()
		DietSelectionMenu.AcCubeDialog = this.GetLevel().GetAcCubeDialog();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu = this.GetLevel().CreateActor(DietFinalConfirmSelectionMenu, PM2ActorOrder.Menu2);

		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(4, this.ActorPos, this.Xscale, PM2ActorOrder.Menu0_Button, PM2RenderOrder.Menu0_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "무리하지 않는다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "어쨌든 튼튼하게");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "얌전한 아이로");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 3, "다이어트 시킨다");

		this.SetButton();

		this.Off();
	}

	Update(_DeltaTime) {
		DietSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「주인님, 아가씨의 건강관리는\n어떤 방침으로 하시겠습니까?」");
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			DietSelectionMenu.AcCubeDialog.Off();
			this.AcMainMenu.On();
		}
	}

	SetButton() {
		this.GetSelectButtons()[0].SetClickCallBack(DietSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(DietSelectionMenu.Click1);
		this.GetSelectButtons()[2].SetClickCallBack(DietSelectionMenu.Click2);
		this.GetSelectButtons()[3].SetClickCallBack(DietSelectionMenu.Click3);
	}

	static Click0(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["무리하지_않는다"]);
	}

	static Click1(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["어쨌든_튼튼하게"]);
	}

	static Click2(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["얌전한_아이로"]);
	}

	static Click3(_Button) {
		DietSelectionMenu.AcDietSelectionMenu.Off();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.On();
		DietSelectionMenu.AcDietFinalConfirmSelectionMenu.SetDietState(Diet["다이어트_시킨다"]);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcDietSelectionMenu', 'Click0', 'Click1', 'Click2', 'Click3']) {
	Object.defineProperty(DietSelectionMenu.prototype, __m, { value: function (...args) { return DietSelectionMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/DietSelectionMenu.js"] = {"DietSelectionMenu": DietSelectionMenu};
})();
(function () {

// ===== GameEngineContents/HelthInformationWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// HelthInformationWindow.h / HelthInformationWindow.cpp 의 전사

class HelthInformationWindow extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(260, 184);
		this.ActorPos = new float4(154, 380);

		this.DiseaseIndex = 0;
		this.Delinquency = 0;
		this.Popularity = 0;

		this.DiseaseState = false;
		this.DelinquentState = false;

		this.DietState = Diet["무리하지_않는다"];

		this.interface_Disease = null;
		this.interface_Delinquency = null;
		this.interface_Popularity = null;
		this.interface_DietState = null;
		this.interface_DiseasePos = new float4(-118, -80);
		this.interface_DelinquencyPos = new float4(-118, -57);
		this.interface_PopularityPos = new float4(-118, -34);
		this.interface_DietStatePos = new float4(-118, 58);

		this.DiseaseRender = null;
		this.DelinquencyRender = null;
		this.PopularityRender = null;
		this.DiseaseStateRender = null;
		this.DelinquentStateRender = null;
		this.DietStateRender = null;
		this.DiseaseRenderPos = new float4(2, -80);
		this.DelinquencyRenderPos = new float4(2, -57);
		this.PopularityRenderPos = new float4(2, -34);
		this.DiseaseStateRenderPos = new float4(-118, -11);
		this.DelinquentStateRenderPos = new float4(-118, 12);
		this.DietStateRenderPos = new float4(-78, 58);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale1 = new float4(160, 20);
		this.TextBoxScale2 = new float4(60, 20);
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.Scale);
		this.SetPos(this.ActorPos);

		this.interface_Disease = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Disease.SetText("질병 지수", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Disease.SetPosition(this.interface_DiseasePos);

		this.interface_Delinquency = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Delinquency.SetText("불량화 지수", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Delinquency.SetPosition(this.interface_DelinquencyPos);

		this.interface_Popularity = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Popularity.SetText("인맥", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Popularity.SetPosition(this.interface_PopularityPos);

		this.interface_DietState = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_DietState.SetText("건강", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_DietState.SetPosition(this.interface_DietStatePos);

		this.DiseaseRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DiseaseRender.SetText(String(Math.trunc(this.DiseaseIndex)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.DiseaseRender.SetPosition(this.DiseaseRenderPos);
		this.DelinquencyRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DelinquencyRender.SetText(String(Math.trunc(this.Delinquency)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.DelinquencyRender.SetPosition(this.DelinquencyRenderPos);
		this.PopularityRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.PopularityRender.SetText(String(Math.trunc(this.Popularity)), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		this.PopularityRender.SetPosition(this.PopularityRenderPos);
		this.DiseaseStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.DiseaseState = Olive.OlivePlayer.IsDisease();
		switch (this.DiseaseState) {
			case false:
				this.DiseaseStateRender.SetText("건강합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case true:
				this.DiseaseStateRender.SetText("질병상태입니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
		}
		this.DiseaseStateRender.SetPosition(this.DiseaseStateRenderPos);
		this.DelinquentStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		switch (this.DelinquentState) {
			case false:
				this.DelinquentStateRender.SetText("솔직합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case true:
				this.DelinquentStateRender.SetText("불량합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
		}
		this.DelinquentStateRender.SetPosition(this.DelinquentStateRenderPos);

		this.DietStateRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		switch (this.DietState) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				this.DietStateRender.SetText("「무리하지 않는다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["어쨌든_튼튼하게"]:
				this.DietStateRender.SetText("「어쨌든 튼튼하게」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["얌전한_아이로"]:
				this.DietStateRender.SetText("「얌전한 아이로」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			case Diet["다이어트_시킨다"]:
				this.DietStateRender.SetText("「다이어트 시킨다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
				break;
			default:
				break;
		}
		this.DietStateRender.SetPosition(this.DietStateRenderPos);

		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdateHelthInformationWindow();
	}

	UpdateHelthInformationWindow() {
		if (this.DiseaseIndex !== Olive.OlivePlayer.GetDiseaseIndex()) {
			this.DiseaseIndex = Olive.OlivePlayer.GetDiseaseIndex();
			this.DiseaseRender.SetText(String(Math.trunc(this.DiseaseIndex)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.Delinquency !== Olive.OlivePlayer.GetDelinquency()) {
			this.Delinquency = Olive.OlivePlayer.GetDelinquency();
			this.DelinquencyRender.SetText(String(Math.trunc(this.Delinquency)) + " %", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.Popularity !== Olive.OlivePlayer.GetPopularity()) {
			this.Popularity = Olive.OlivePlayer.GetPopularity();
			this.PopularityRender.SetText(String(Math.trunc(this.Popularity)), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.DiseaseState !== Olive.OlivePlayer.IsDisease()) {
			this.DiseaseState = Olive.OlivePlayer.IsDisease();
			switch (this.DiseaseState) {
				case false:
					this.DiseaseStateRender.SetText("건강합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case true:
					this.DiseaseStateRender.SetText("질병상태입니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
			}
		}

		if (this.DelinquentState !== Olive.OlivePlayer.IsDelinquent()) {
			this.DelinquentState = Olive.OlivePlayer.IsDelinquent();
			switch (this.DelinquentState) {
				case false:
					this.DelinquentStateRender.SetText("솔직합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case true:
					this.DelinquentStateRender.SetText("불량합니다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
			}
		}

		if (this.DietState !== Olive.OlivePlayer.GetOliveDiet()) {
			this.DietState = Olive.OlivePlayer.GetOliveDiet();
			switch (this.DietState) {
				case Diet.Null:
					break;
				case Diet["무리하지_않는다"]:
					this.DietStateRender.SetText("「무리하지 않는다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["어쨌든_튼튼하게"]:
					this.DietStateRender.SetText("「어쨌든 튼튼하게」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["얌전한_아이로"]:
					this.DietStateRender.SetText("「얌전한 아이로」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				case Diet["다이어트_시킨다"]:
					this.DietStateRender.SetText("「다이어트 시킨다」", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
					break;
				default:
					break;
			}
		}

	}
}

__PM2_EXPORTS__["GameEngineContents/HelthInformationWindow.js"] = {"HelthInformationWindow": HelthInformationWindow};
})();
(function () {

// ===== GameEngineContents/PersonalInformationWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var BloodType = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["BloodType"];
var Zodiac = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Zodiac"];
var PatronGod = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PatronGod"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// PersonalInformationWindow.h / PersonalInformationWindow.cpp 의 전사

class PersonalInformationWindow extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(260, 184);
		this.ActorPos = new float4(154, 195);

		this.FirstName = "";
		this.LastName = "";
		this.BloodType = BloodType.Null;
		this.Age = 0;
		this.BirthDay = new Date();
		this.OliveZodiac = Zodiac.Null;
		this.OlivePatronGod = PatronGod.Null;

		this.interface_FirstName = null;
		this.interface_LastName = null;
		this.interface_BloodType = null;
		this.interface_Age = null;
		this.interface_BirthDay = null;
		this.interface_Zodiac = null;
		this.interface_PatronGod = null;
		this.interface_FirstNamePos = new float4(-118, -80);
		this.interface_LastNamePos = new float4(-118, -57);
		this.interface_BloodTypePos = new float4(-118, -34);
		this.interface_AgePos = new float4(-118, -11);
		this.interface_BirthDayPos = new float4(-118, 12);
		this.interface_ZodiacPos = new float4(-118, 35);
		this.interface_PatronGodPos = new float4(-118, 58);

		this.FirstNameRender = null;
		this.LastNameRender = null;
		this.BloodTypeRender = null;
		this.AgeRender = null;
		this.BirthDayRender = null;
		this.ZodiacRender = null;
		this.PatronGodRender = null;
		this.FirstNamePos = new float4(-38, -80);
		this.LastNamePos = new float4(-38, -57);
		this.BloodTypePos = new float4(-38, -34);
		this.AgePos = new float4(-38, -11);
		this.BirthDayPos = new float4(-38, 12);
		this.ZodiacPos = new float4(-38, 35);
		this.PatronGodPos = new float4(-38, 58);

		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale1 = new float4(80, 20);
		this.TextBoxScale2 = new float4(160, 20);
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.Scale);
		this.SetPos(this.ActorPos);

		this.interface_FirstName = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_FirstName.SetText("이름", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_FirstName.SetPosition(this.interface_FirstNamePos);

		this.interface_LastName = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_LastName.SetText("성", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_LastName.SetPosition(this.interface_LastNamePos);

		this.interface_BloodType = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_BloodType.SetText("혈액형", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_BloodType.SetPosition(this.interface_BloodTypePos);

		this.interface_Age = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Age.SetText("나이", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Age.SetPosition(this.interface_AgePos);

		this.interface_BirthDay = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_BirthDay.SetText("생일", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_BirthDay.SetPosition(this.interface_BirthDayPos);

		this.interface_Zodiac = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_Zodiac.SetText("별자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_Zodiac.SetPosition(this.interface_ZodiacPos);

		this.interface_PatronGod = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.interface_PatronGod.SetText("수호성", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale1);
		this.interface_PatronGod.SetPosition(this.interface_PatronGodPos);

		this.FirstNameRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.FirstNameRender.SetPosition(this.FirstNamePos);
		this.LastNameRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.LastNameRender.SetPosition(this.LastNamePos);
		this.BloodTypeRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.BloodTypeRender.SetPosition(this.BloodTypePos);
		this.AgeRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.AgeRender.SetPosition(this.AgePos);
		this.BirthDayRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.BirthDayRender.SetPosition(this.BirthDayPos);
		this.ZodiacRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.ZodiacRender.SetPosition(this.ZodiacPos);
		this.PatronGodRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.PatronGodRender.SetPosition(this.PatronGodPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdatePersonalInformationWindow();
	}

	UpdatePersonalInformationWindow() {
		if (this.FirstName !== Olive.OlivePlayer.GetOliveFirstName()) {
			this.FirstName = Olive.OlivePlayer.GetOliveFirstName();
			this.FirstNameRender.SetText(this.FirstName, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.LastName !== Olive.OlivePlayer.GetOliveLastName()) {
			this.LastName = Olive.OlivePlayer.GetOliveLastName();
			this.LastNameRender.SetText(this.LastName, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.BloodType !== Olive.OlivePlayer.GetBloodType()) {
			this.BloodType = Olive.OlivePlayer.GetBloodType();
			switch (this.BloodType) {
				case BloodType.Null:
					break;
				case BloodType.A:
					this.BloodTypeRender.SetText("A", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.B:
					this.BloodTypeRender.SetText("B", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.O:
					this.BloodTypeRender.SetText("O", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case BloodType.AB:
					this.BloodTypeRender.SetText("AB", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}

		if (this.Age !== Olive.OlivePlayer.GetOliveAge()) {
			this.Age = Olive.OlivePlayer.GetOliveAge();
			this.AgeRender.SetText(String(this.Age), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.BirthDay !== Olive.OlivePlayer.GetOliveBirthDay()) {
			this.BirthDay = Olive.OlivePlayer.GetOliveBirthDay();
			this.BirthDayRender.SetText(String(this.BirthDay.GetYear()) + "/" + String(this.BirthDay.GetMonth()) + "/" + String(this.BirthDay.GetDay()), this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
		}

		if (this.OliveZodiac !== Olive.OlivePlayer.GetOliveZodiac()) {
			this.OliveZodiac = Olive.OlivePlayer.GetOliveZodiac();
			switch (this.OliveZodiac) {
				case Zodiac.Null:
					break;
				case Zodiac["염소자리"]:
					this.ZodiacRender.SetText("염소자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["물병자리"]:
					this.ZodiacRender.SetText("물병자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["물고기자리"]:
					this.ZodiacRender.SetText("물고기자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["양자리"]:
					this.ZodiacRender.SetText("양자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["황소자리"]:
					this.ZodiacRender.SetText("황소자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["쌍둥이자리"]:
					this.ZodiacRender.SetText("쌍둥이자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["게자리"]:
					this.ZodiacRender.SetText("게자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["사자자리"]:
					this.ZodiacRender.SetText("사자자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["처녀자리"]:
					this.ZodiacRender.SetText("처녀자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["천칭자리"]:
					this.ZodiacRender.SetText("천칭자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["전갈자리"]:
					this.ZodiacRender.SetText("전갈자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case Zodiac["사수자리"]:
					this.ZodiacRender.SetText("사수자리", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}

		if (this.OlivePatronGod !== Olive.OlivePlayer.GetPatronGod()) {
			this.OlivePatronGod = Olive.OlivePlayer.GetPatronGod();
			switch (this.OlivePatronGod) {
				case PatronGod.Null:
					break;
				case PatronGod["태양신_솔"]:
					this.PatronGodRender.SetText("태양신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["달신_더문"]:
					this.PatronGodRender.SetText("달신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["화성신_마르스"]:
					this.PatronGodRender.SetText("화성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["수성신_머큐리"]:
					this.PatronGodRender.SetText("수성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["목성신_주피터"]:
					this.PatronGodRender.SetText("목성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["금성신_비너스"]:
					this.PatronGodRender.SetText("금성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["토성신_새턴"]:
					this.PatronGodRender.SetText("토성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["천왕성신_우라누스"]:
					this.PatronGodRender.SetText("천왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["해왕성신_넵튠"]:
					this.PatronGodRender.SetText("해왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				case PatronGod["명왕성신_하데스"]:
					this.PatronGodRender.SetText("명왕성신", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale2);
					break;
				default:
					break;
			}
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/PersonalInformationWindow.js"] = {"PersonalInformationWindow": PersonalInformationWindow};
})();
(function () {

// ===== GameEngineContents/PhysicalStatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// PhysicalStatusWindow.h / PhysicalStatusWindow.cpp 의 전사

class PhysicalStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(664, 350);

		this.HeightRender = null;
		this.WeightRender = null;
		this.BustRender = null;
		this.WaistRender = null;
		this.HipRender = null;

		this.Height = 0.0;
		this.Weight = 0.0;
		this.Bust = 0.0;
		this.Waist = 0.0;
		this.Hip = 0.0;

		this.Max = 200.0;

		this.Style = GaugeFrameStyle.Physical;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.HeightRender = this.InsertStatus("키", this.Max, this.Style);
		this.WeightRender = this.InsertStatus("몸무게", this.Max, this.Style);
		this.BustRender = this.InsertStatus("가슴", this.Max, this.Style);
		this.WaistRender = this.InsertStatus("허리", this.Max, this.Style);
		this.HipRender = this.InsertStatus("엉덩이", this.Max, this.Style);
		this.SetPos(this.ActorPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdatePhysicalStatusWindow();
	}

	UpdatePhysicalStatusWindow() {
		if (this.Height !== Olive.OlivePlayer.GetHeight()) {
			this.Height = Olive.OlivePlayer.GetHeight();
			this.HeightRender.UpdateValue(this.Height);
		}

		if (this.Weight !== Olive.OlivePlayer.GetWeight()) {
			this.Weight = Olive.OlivePlayer.GetWeight();
			this.WeightRender.UpdateValue(this.Weight);
		}

		if (this.Bust !== Olive.OlivePlayer.GetBust()) {
			this.Bust = Olive.OlivePlayer.GetBust();
			this.BustRender.UpdateValue(this.Bust);
		}

		if (this.Waist !== Olive.OlivePlayer.GetWaist()) {
			this.Waist = Olive.OlivePlayer.GetWaist();
			this.WaistRender.UpdateValue(this.Waist);
		}

		if (this.Hip !== Olive.OlivePlayer.GetHip()) {
			this.Hip = Olive.OlivePlayer.GetHip();
			this.HipRender.UpdateValue(this.Hip);
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/PhysicalStatusWindow.js"] = {"PhysicalStatusWindow": PhysicalStatusWindow};
})();
(function () {

// ===== GameEngineContents/InformationWindowManager.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var HelthInformationWindow = __PM2_EXPORTS__["GameEngineContents/HelthInformationWindow.js"]["HelthInformationWindow"];
var PersonalInformationWindow = __PM2_EXPORTS__["GameEngineContents/PersonalInformationWindow.js"]["PersonalInformationWindow"];
var PhysicalStatusWindow = __PM2_EXPORTS__["GameEngineContents/PhysicalStatusWindow.js"]["PhysicalStatusWindow"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
// InformationWindowManager.h / InformationWindowManager.cpp 의 전사

class InformationWindowManager extends GameEngineActor {
	constructor() {
		super();
		this.AcHelthInformationWindow = null;
		this.AcPersonalInformationWindow = null;
		this.AcPhysicalStatusWindow = null;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.AcHelthInformationWindow.On();
		this.AcPersonalInformationWindow.On();
		this.AcPhysicalStatusWindow.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.AcHelthInformationWindow.Off();
		this.AcPersonalInformationWindow.Off();
		this.AcPhysicalStatusWindow.Off();
	}

	Start() {
		this.AcHelthInformationWindow = this.GetLevel().CreateActor(HelthInformationWindow, PM2ActorOrder.Menu1);
		this.AcPersonalInformationWindow = this.GetLevel().CreateActor(PersonalInformationWindow, PM2ActorOrder.Menu1);
		this.AcPhysicalStatusWindow = this.GetLevel().CreateActor(PhysicalStatusWindow, PM2ActorOrder.Menu1);

		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			MainMenu.GetAcMainMenu().On();
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/InformationWindowManager.js"] = {"InformationWindowManager": InformationWindowManager};
})();
(function () {

// ===== GameEngineContents/ClassesAndJobs.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineRandom = __PM2_EXPORTS__["GameEngineBase/GameEngineRandom.js"]["GameEngineRandom"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var FrameAnimationParameter = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["FrameAnimationParameter"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
// ClassesAndJobs.h / ClassesAndJobs.cpp 의 전사

class ClassesAndJobs extends GameEngineActor {
	constructor() {
		super();
		// RaisingSimLevel* ParentLevel = nullptr;
		this.ParentLevel = null;

		this.Pay = 0;

		// Olive::Status Beginner_StatusVarianceMin = {}; (모든 필드 0)
		this.Beginner_StatusVarianceMin = new Olive.Status();
		this.Beginner_StatusVarianceMax = new Olive.Status();
		this.Beginner_StatusVariance = new Olive.Status();
		this.ActorPos = new float4(240, 380);

		this.BackgroundLayer1 = null;
		this.BackgroundLayer2 = null;

		this.OliveObject = null;
		this.OliveObjectPos = float4.Zero;
		this.OliveSuccessFrameStart = -1;
		this.OliveSuccessFrameEnd = -1;
		this.OliveFailFrameStart = -1;
		this.OliveFailFrameEnd = -1;
		this.OliveDontFrameStart = -1;
		this.OliveDontFrameEnd = -1;
		this.SuccessState = "Success";
		this.FailState = "Fail";
		this.DontState = "Dont";
		this.StopState = "Stop";

		this.Object1 = null;
		this.Object1Pos = float4.Zero;
		this.Object1FrameStart = -1;
		this.Object1FrameEnd = -1;
		this.Object2 = null;
		this.Object2Pos = float4.Zero;
		this.Object2FrameStart = -1;
		this.Object2FrameEnd = -1;
		this.Object3 = null;
		this.Object3Pos = float4.Zero;
		this.Object3FrameStart = -1;
		this.Object3FrameEnd = -1;
		this.Object4 = null;
		this.Object4Pos = float4.Zero;
		this.Object4FrameStart = -1;
		this.Object4FrameEnd = -1;
		this.Object5 = null;
		this.Object5Pos = float4.Zero;
		this.Object5FrameStart = -1;
		this.Object5FrameEnd = -1;

		this.ObjScale = float4.Zero;

		this.BackgroundLayer1_Name = "";
		this.BackgroundLayer2_Name = "";
		this.Object_Name = "";

		this.Time = 0;
		this.Count = 0;
	}

	GetStatusVarianceMin() {
		return this.Beginner_StatusVarianceMin;
	}

	GetStatusVarianceMax() {
		return this.Beginner_StatusVarianceMax;
	}

	GetStatusVariance() {
		const Random = new GameEngineRandom();
		this.Beginner_StatusVariance.Constitution = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Constitution), Math.trunc(this.Beginner_StatusVarianceMax.Constitution));
		this.Beginner_StatusVariance.Strength = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Strength), Math.trunc(this.Beginner_StatusVarianceMax.Strength));
		this.Beginner_StatusVariance.Intelligence = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Intelligence), Math.trunc(this.Beginner_StatusVarianceMax.Intelligence));
		this.Beginner_StatusVariance.Refinement = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Refinement), Math.trunc(this.Beginner_StatusVarianceMax.Refinement));
		this.Beginner_StatusVariance.Charisma = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Charisma), Math.trunc(this.Beginner_StatusVarianceMax.Charisma));
		this.Beginner_StatusVariance.Morality = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Morality), Math.trunc(this.Beginner_StatusVarianceMax.Morality));
		this.Beginner_StatusVariance.Faith = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Faith), Math.trunc(this.Beginner_StatusVarianceMax.Faith));
		this.Beginner_StatusVariance.Sin = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Sin), Math.trunc(this.Beginner_StatusVarianceMax.Sin));
		this.Beginner_StatusVariance.Sensitivity = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Sensitivity), Math.trunc(this.Beginner_StatusVarianceMax.Sensitivity));
		this.Beginner_StatusVariance.Stress = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Stress), Math.trunc(this.Beginner_StatusVarianceMax.Stress));
		this.Beginner_StatusVariance.Fighter = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Fighter), Math.trunc(this.Beginner_StatusVarianceMax.Fighter));
		this.Beginner_StatusVariance.CombatSkill = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatSkill), Math.trunc(this.Beginner_StatusVarianceMax.CombatSkill));
		this.Beginner_StatusVariance.CombatAttack = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatAttack), Math.trunc(this.Beginner_StatusVarianceMax.CombatAttack));
		this.Beginner_StatusVariance.CombatDefense = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.CombatDefense), Math.trunc(this.Beginner_StatusVarianceMax.CombatDefense));
		this.Beginner_StatusVariance.Magical = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Magical), Math.trunc(this.Beginner_StatusVarianceMax.Magical));
		this.Beginner_StatusVariance.MagicSkill = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicSkill), Math.trunc(this.Beginner_StatusVarianceMax.MagicSkill));
		this.Beginner_StatusVariance.MagicAttack = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicAttack), Math.trunc(this.Beginner_StatusVarianceMax.MagicAttack));
		this.Beginner_StatusVariance.MagicDefense = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.MagicDefense), Math.trunc(this.Beginner_StatusVarianceMax.MagicDefense));
		this.Beginner_StatusVariance.Social = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Social), Math.trunc(this.Beginner_StatusVarianceMax.Social));
		this.Beginner_StatusVariance.Decorum = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Decorum), Math.trunc(this.Beginner_StatusVarianceMax.Decorum));
		this.Beginner_StatusVariance.Art = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Art), Math.trunc(this.Beginner_StatusVarianceMax.Art));
		this.Beginner_StatusVariance.Conversation = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Conversation), Math.trunc(this.Beginner_StatusVarianceMax.Conversation));
		this.Beginner_StatusVariance.HouseWork = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.HouseWork), Math.trunc(this.Beginner_StatusVarianceMax.HouseWork));
		this.Beginner_StatusVariance.Cooking = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Cooking), Math.trunc(this.Beginner_StatusVarianceMax.Cooking));
		this.Beginner_StatusVariance.Cleaning = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Cleaning), Math.trunc(this.Beginner_StatusVarianceMax.Cleaning));
		this.Beginner_StatusVariance.Temperament = Random.RandomInt(Math.trunc(this.Beginner_StatusVarianceMin.Temperament), Math.trunc(this.Beginner_StatusVarianceMax.Temperament));

		return this.Beginner_StatusVariance;
	}

	DoClassAndJob() {
		// 원본: Olive::OlivePlayer->OliveStatus += GetStatusVariance(); (Status::operator+= → float4 규칙과 같은 형태)
		Olive.OlivePlayer.OliveStatus = Olive.OlivePlayer.OliveStatus.add(this.GetStatusVariance());
		this.ParentLevel.GoToNextDay();
	}

	PlayObj() {
		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation(this.SuccessState);
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Obj1");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Obj2");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Obj3");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Obj4");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Obj5");
		}
	}

	StopObj() {
		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation("Stop");
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Stop");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Stop");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Stop");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Stop");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Stop");
		}
	}

	SetPayGold(_Pay) {
		this.Pay = _Pay;
	}

	GetPayGold() {
		return this.Pay;
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();

		if (null !== this.OliveObject) {
			this.OliveObject.ChangeAnimation(this.SuccessState);
		}

		if (null !== this.Object1) {
			this.Object1.ChangeAnimation("Obj1");
		}

		if (null !== this.Object2) {
			this.Object2.ChangeAnimation("Obj2");
		}

		if (null !== this.Object3) {
			this.Object3.ChangeAnimation("Obj3");
		}

		if (null !== this.Object4) {
			this.Object4.ChangeAnimation("Obj4");
		}

		if (null !== this.Object5) {
			this.Object5.ChangeAnimation("Obj5");
		}

		this.SetPos(this.ActorPos);
		this.Off();
	}

	SetImageName(_Obj, _Back1, _Back2 = "") {
		this.Object_Name = _Obj;
		this.BackgroundLayer1_Name = _Back1;
		this.BackgroundLayer2_Name = _Back2;
	}

	SetBackground() {
		this.BackgroundLayer1 = this.CreateRender(this.BackgroundLayer1_Name, PM2RenderOrder.Menu2_Background_1);
		this.BackgroundLayer1.SetScaleToImage();
		if (0 !== this.BackgroundLayer2_Name.length) {
			this.BackgroundLayer2 = this.CreateRender(this.BackgroundLayer2_Name, PM2RenderOrder.Menu2_Background_1);
			this.BackgroundLayer2.SetScaleToImage();
		}
	}

	SetObjScale(_Scale) {
		this.ObjScale = _Scale;
	}

	SetOliveObj(_SuccessStart, _SuccessEnd, _FailStart, _FailEnd, _DontStart, _DontEnd, _Pos) {
		this.OliveSuccessFrameStart = _SuccessStart;
		this.OliveSuccessFrameEnd = _SuccessEnd;
		this.OliveFailFrameStart = _FailStart;
		this.OliveFailFrameEnd = _FailEnd;
		this.OliveDontFrameStart = _DontStart;
		this.OliveDontFrameEnd = _DontEnd;
		this.OliveObjectPos = _Pos;

		this.OliveObject = this.CreateRender(PM2RenderOrder.Menu2_Obj_2);
		this.OliveObject.SetScale(this.ObjScale);
		this.OliveObject.SetPosition(this.OliveObjectPos);
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.SuccessState, this.Object_Name, this.OliveSuccessFrameStart, this.OliveSuccessFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.FailState, this.Object_Name, this.OliveFailFrameStart, this.OliveFailFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.DontState, this.Object_Name, this.OliveDontFrameStart, this.OliveDontFrameEnd, 0, 0.2));
		this.OliveObject.CreateAnimation(new FrameAnimationParameter(this.StopState, this.Object_Name, this.OliveSuccessFrameStart, this.OliveSuccessFrameStart, 0, 0.2));
	}

	SetObj1(_Order, _Start, _End, _Pos) {
		this.Object1FrameStart = _Start;
		this.Object1FrameEnd = _End;
		this.Object1Pos = _Pos;
		this.Object1 = this.CreateRender(_Order);
		this.Object1.SetScale(this.ObjScale);
		this.Object1.SetPosition(this.Object1Pos);
		this.Object1.CreateAnimation(new FrameAnimationParameter("Obj1", this.Object_Name, this.Object1FrameStart, this.Object1FrameEnd, 0, 0.2));
		this.Object1.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object1FrameStart, this.Object1FrameStart, 0, 0.2));
	}

	SetObj2(_Order, _Start, _End, _Pos) {
		this.Object2FrameStart = _Start;
		this.Object2FrameEnd = _End;
		this.Object2Pos = _Pos;
		this.Object2 = this.CreateRender(_Order);
		this.Object2.SetScale(this.ObjScale);
		this.Object2.SetPosition(this.Object2Pos);
		this.Object2.CreateAnimation(new FrameAnimationParameter("Obj2", this.Object_Name, this.Object2FrameStart, this.Object2FrameEnd, 0, 0.2));
		this.Object2.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object2FrameStart, this.Object2FrameStart, 0, 0.2));
	}

	SetObj3(_Order, _Start, _End, _Pos) {
		this.Object3FrameStart = _Start;
		this.Object3FrameEnd = _End;
		this.Object3Pos = _Pos;
		this.Object3 = this.CreateRender(_Order);
		this.Object3.SetScale(this.ObjScale);
		this.Object3.SetPosition(this.Object3Pos);
		this.Object3.CreateAnimation(new FrameAnimationParameter("Obj3", this.Object_Name, this.Object3FrameStart, this.Object3FrameEnd, 0, 0.2));
		this.Object3.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object3FrameStart, this.Object3FrameStart, 0, 0.2));
	}

	SetObj4(_Order, _Start, _End, _Pos) {
		this.Object4FrameStart = _Start;
		this.Object4FrameEnd = _End;
		this.Object4Pos = _Pos;
		this.Object4 = this.CreateRender(_Order);
		this.Object4.SetScale(this.ObjScale);
		this.Object4.SetPosition(this.Object4Pos);
		this.Object4.CreateAnimation(new FrameAnimationParameter("Obj4", this.Object_Name, this.Object4FrameStart, this.Object4FrameEnd, 0, 0.2));
		this.Object4.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object4FrameStart, this.Object4FrameStart, 0, 0.2));
	}

	SetObj5(_Order, _Start, _End, _Pos) {
		this.Object5FrameStart = _Start;
		this.Object5FrameEnd = _End;
		this.Object5Pos = _Pos;
		this.Object5 = this.CreateRender(_Order);
		this.Object5.SetScale(this.ObjScale);
		this.Object5.SetPosition(this.Object5Pos);
		this.Object5.CreateAnimation(new FrameAnimationParameter("Obj5", this.Object_Name, this.Object5FrameStart, this.Object5FrameEnd, 0, 0.2));
		this.Object5.CreateAnimation(new FrameAnimationParameter("Stop", this.Object_Name, this.Object5FrameStart, this.Object5FrameStart, 0, 0.2));
	}
}

__PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"] = {"ClassesAndJobs": ClassesAndJobs};
})();
(function () {

// ===== GameEngineContents/DanceClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// DanceClass.h / DanceClass.cpp 의 전사

class DanceClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Dance.bmp", "Animation_Background_Dance.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 5, 6, 7, new float4(145, 14));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 8, 11, new float4(55, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-55, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 16, 17, new float4(-155, 14));

		// 원본: GetStatusVarianceMin().SetStatus({.Constitution = 1, .Charisma = 0, .Stress = 0, .Art = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Constitution = 1;
		StatusParaMin.Charisma = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Constitution = 1, .Charisma = 1, .Stress = 1, .Art = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Constitution = 1;
		StatusParaMax.Charisma = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-50);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/DanceClass.js"] = {"DanceClass": DanceClass};
})();
(function () {

// ===== GameEngineContents/DateViewer.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// DateViewer.h / DateViewer.cpp 의 전사

class DateViewer extends GameEngineActor {
	constructor() {
		super();
		this.Today = new Date();
		this.DateViewerFrameRender = null;
		this.Year = new NumberRenderObject();
		this.Month = null; // 원본: GameEngineRender* Month = {};
		this.Day = new NumberRenderObject();
		this.WeekDay = null; // 원본: GameEngineRender* WeekDay = {};
	}

	Start() {
		this.Today.SetDate(1000, 1, 1);

		this.SetPos(new float4(90, 50));
		this.DateViewerFrameRender = this.CreateRender("DateViewer.bmp", PM2RenderOrder.Menu0);
		this.DateViewerFrameRender.SetScaleToImage();

		this.Year.SetOwner(this);
		this.Year.SetImage("Num.bmp", new float4(10, 20), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.Year.SetAlign(Align.Center);
		this.Year.SetRenderPos(new float4(0.0, -30.0));

		this.Month = this.CreateRender("Num_Month.bmp", PM2RenderOrder.Menu0_Display);
		this.Month.SetScale(new float4(60.0, 20.0));
		this.Month.SetPosition(new float4(-50.0, 0.0));

		this.WeekDay = this.CreateRender("Num_WeekDay.bmp", PM2RenderOrder.Menu0_Display);
		this.WeekDay.SetScale(new float4(60.0, 20.0));
		this.WeekDay.SetPosition(new float4(-50.0, 30.0));

		this.Day.SetOwner(this);
		this.Day.SetImage("Num_Day.bmp", new float4(40.0, 50.0), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.Day.SetAlign(Align.Center);
		this.Day.SetRenderPos(new float4(40.0, 15.0));
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.Year.SetValue(this.Today.GetYear());
			this.Month.SetFrame(this.Today.GetMonth() - 1);
			this.Day.SetValue(this.Today.GetDay());
			this.WeekDay.SetFrame(this.Today.GetWeekDay());
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/DateViewer.js"] = {"DateViewer": DateViewer};
})();
(function () {

// ===== GameEngineContents/FencingClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// FencingClass.h / FencingClass.cpp 의 전사

class FencingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Fencing.bmp", "Animation_Background_Fencing.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 5, 6, 7, new float4(165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 8, 11, new float4(105, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-85, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 16, 20, new float4(-155, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 21, 24, new float4(5, -20));

		// 원본: GetStatusVarianceMin().SetStatus({ .Stress = 0, .CombatSkill = 0, .CombatAttack = 1});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 0;
		StatusParaMin.CombatAttack = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Stress = 1,.CombatSkill = 1, .CombatAttack = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		StatusParaMax.CombatAttack = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/FencingClass.js"] = {"FencingClass": FencingClass};
})();
(function () {

// ===== GameEngineContents/FightingClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// FightingClass.h / FightingClass.cpp 의 전사

class FightingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Fighting.bmp", "Animation_Background_Fighting.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 2, 3, 4, 5, 6, new float4(135, 14));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 9, new float4(-5, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 10, 12, new float4(65, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 13, 13, new float4(-135, 14));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 14, 18, new float4(-175, 14));

		// 원본: GetStatusVarianceMin().SetStatus({ .Stress = 0,.CombatSkill = 1, .CombatDefense = 0});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 1;
		StatusParaMin.CombatDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Stress = 1,.CombatSkill = 1, .CombatDefense = 0 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		StatusParaMax.CombatDefense = 0;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-30);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/FightingClass.js"] = {"FightingClass": FightingClass};
})();
(function () {

// ===== GameEngineContents/Flower.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Season = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Season"];
// Flower.h / Flower.cpp 의 전사

class Flower extends GameEngineActor {
	constructor() {
		super();
		this.SpringFlower = null;
		this.SummerFlower = null;
		this.FallFlower = null;
		this.WinterFlower = null;
		this.DiseaseFlower = null;

		// Season TodaySeason = Season::Null;
		this.TodaySeason = Season.Null;
		// RaisingSimLevel* ParentLevel = nullptr;
		this.ParentLevel = null;
	}

	UpdateFlower() {

	}

	Start() {
		this.SetPos(new float4(85, 285));
		this.SpringFlower = this.CreateRender("flower_spring.bmp", PM2RenderOrder.BackGroundObj);
		this.SpringFlower.SetScaleToImage();
		this.SpringFlower.Off();
		this.SummerFlower = this.CreateRender("flower_summer.bmp", PM2RenderOrder.BackGroundObj);
		this.SummerFlower.SetScaleToImage();
		this.SummerFlower.Off();
		this.FallFlower = this.CreateRender("flower_fall.bmp", PM2RenderOrder.BackGroundObj);
		this.FallFlower.SetScaleToImage();
		this.FallFlower.Off();
		this.WinterFlower = this.CreateRender("flower_winter.bmp", PM2RenderOrder.BackGroundObj);
		this.WinterFlower.SetScaleToImage();
		this.WinterFlower.Off();
		this.DiseaseFlower = this.CreateRender("flower_disease.bmp", PM2RenderOrder.BackGroundObj);
		this.DiseaseFlower.SetScaleToImage();
		this.DiseaseFlower.Off();

		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();

	}

	Update(_DeltaTime) {
		if (this.TodaySeason !== this.ParentLevel.GetTodaySeason()) {
			this.TodaySeason = this.ParentLevel.GetTodaySeason();
			switch (this.TodaySeason) {
				case Season.Spring:
					this.SpringFlower.On();
					this.SummerFlower.Off();
					this.FallFlower.Off();
					this.WinterFlower.Off();
					break;
				case Season.Summer:
					this.SpringFlower.Off();
					this.SummerFlower.On();
					this.FallFlower.Off();
					this.WinterFlower.Off();
					break;
				case Season.Fall:
					this.SpringFlower.Off();
					this.SummerFlower.Off();
					this.FallFlower.On();
					this.WinterFlower.Off();
					break;
				case Season.Winter:
					this.SpringFlower.Off();
					this.SummerFlower.Off();
					this.FallFlower.Off();
					this.WinterFlower.On();
					break;
				default:
					break;
			}
		}
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Flower.js"] = {"Flower": Flower};
})();
(function () {

// ===== GameEngineContents/MagicClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// MagicClass.h / MagicClass.cpp 의 전사

class MagicClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Magic.bmp", "Animation_Background_Magic.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 11, 0, 3, 12, 13, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 14, 17, new float4(-85, 14));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 18, 19, new float4(-25, 14));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_1, 20, 21, new float4(115, -30));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_1, 22, 23, new float4(-87, -30));
		this.SetObj5(PM2RenderOrder.Menu2_Obj_1, 24, 27, new float4(-165, -37));

		// 원본: GetStatusVarianceMin().SetStatus({.Stress = 0, .MagicSkill = 1, .MagicAttack = 0});
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicSkill = 1;
		StatusParaMin.MagicAttack = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({.Stress = 1,.MagicSkill = 1, .MagicAttack = 2 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicSkill = 1;
		StatusParaMax.MagicAttack = 2;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-60);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/MagicClass.js"] = {"MagicClass": MagicClass};
})();
(function () {

// ===== GameEngineContents/MousePoint.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// MousePoint.h / MousePoint.cpp 의 전사

class MousePoint extends GameEngineActor {
	static MainMouse = null;

	constructor() {
		super();
		this.MousePointCollision = null;
		this.MousePointRender = null;
	}

	GetMousePointCollision() {
		return this.MousePointCollision;
	}

	Start() {
		MousePoint.MainMouse = this;
		GameEngineInput.MouseCursorOff();
		this.MousePointCollision = this.CreateCollision(PM2CollisionOrder.MousePoint);
		this.MousePointCollision.SetScale(new float4(1, 1));
		this.MousePointRender = this.CreateRender(PM2RenderOrder.MousePoint);
		this.MousePointRender.SetImageToScaleToImage("Cursor.bmp");
		this.MousePointRender.SetPosition(this.MousePointRender.GetScale().half());
	}

	Update(_DeltaTime) {
		this.SetPos(this.GetLevel().GetMousePos());
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/MousePoint.js"] = {"MousePoint": MousePoint};
})();
(function () {

// ===== GameEngineContents/Paint.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// Paint.h / Paint.cpp 의 전사

class Paint extends GameEngineActor {
	constructor() {
		super();
		this.PaintRender = null;
	}

	Start() {
		this.PaintRender = this.CreateRender("paint_default.bmp", PM2RenderOrder.BackGroundObj);
		this.PaintRender.SetScaleToImage();
		this.SetPos(new float4(519, 157));
	}

	Update(_DeltaTime) {
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Paint.js"] = {"Paint": Paint};
})();
(function () {

// ===== GameEngineContents/PaintingClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// PaintingClass.h / PaintingClass.cpp 의 전사

class PaintingClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Painting.bmp", "Animation_Background_Painting.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 4, 5, 6, new float4(-165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 9, new float4(-85, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-15, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 12, 17, new float4(115, 12));

		// 원본: GetStatusVarianceMin().SetStatus({  .Sensitivity = 0,.Stress = 0, .Art = 1 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Sensitivity = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Sensitivity = 1,.Stress = 1, .Art = 1});
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Sensitivity = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/PaintingClass.js"] = {"PaintingClass": PaintingClass};
})();
(function () {

// ===== GameEngineContents/PoetryClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// PoetryClass.h / PoetryClass.cpp 의 전사

class PoetryClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Poetry.bmp", "Animation_Background_Poetry.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 3, 4, 7, 8, 9, new float4(135, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-5, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 12, 13, new float4(65, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 14, 15, new float4(-115, -1));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 0, .Refinement = 0, .Sensitivity = 1, .Stress = 0,.Art = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 0;
		StatusParaMin.Refinement = 0;
		StatusParaMin.Sensitivity = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.Art = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 1, .Refinement = 1, .Sensitivity = 1,.Stress = 1, .Art = 2 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 1;
		StatusParaMax.Refinement = 1;
		StatusParaMax.Sensitivity = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Art = 2;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/PoetryClass.js"] = {"PoetryClass": PoetryClass};
})();
(function () {

// ===== GameEngineContents/ProtocolClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// ProtocolClass.h / ProtocolClass.cpp 의 전사

class ProtocolClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Protocol.bmp", "Animation_Background_Protocol.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(165, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(95, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(-165, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-85, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 13, 17, new float4(5, -3));

		// 원본: GetStatusVarianceMin().SetStatus({.Refinement = 1, .Stress = 0,.Decorum = 1 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Refinement = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.Decorum = 1;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Refinement = 1,.Stress = 1, .Decorum = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Refinement = 1;
		StatusParaMax.Stress = 1;
		StatusParaMax.Decorum = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/ProtocolClass.js"] = {"ProtocolClass": ProtocolClass};
})();
(function () {

// ===== GameEngineContents/ScheduleDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var MugShotLR = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["MugShotLR"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
// ScheduleDialog.h / ScheduleDialog.cpp 의 전사

// enum class ScheduleSituation
const ScheduleSituation = Object.freeze({
	Null: -1,
	ScheduleFirstStart: 0,
	ScheduleStart: 1,
	ScheduleEnd: 2,
	ScheduleEnd_NoMoney: 3,
	ScheduleEnd_Bonus: 4,
	End: 5,
});

// 원본: struct ScheduleScript
class ScheduleScript {
	constructor(_Char = ScheduleLabel.Null, _Situ = ScheduleSituation.Null) {
		this.Character = _Char;
		this.Situation = _Situ;
	}
}

class ScheduleDialog extends Dialog {
	constructor() {
		super();
		this.ActorPos = new float4(253, 400);
		this.ScheduleMugshot = new Map();
		this.IsFirstUpdate = true;
	}

	// 원본 오버로딩: UpdateScheduleDialog(const ScheduleLabel& _Mug, const std::string_view& _Dialog)
	//             / UpdateScheduleDialog(ScheduleLabel _Char, ScheduleSituation _Situ)
	UpdateScheduleDialog(_Mug, _DialogOrSitu) {
		if (typeof _DialogOrSitu === "string") {
			this.On();
			this.SetMugPic(this.ScheduleMugshot.get(_Mug));
			this.SetUpdateText(_DialogOrSitu);
			return;
		}

		const _Situ = _DialogOrSitu;
		this.On();
		this.SetMugPic(this.ScheduleMugshot.get(_Mug));
		switch (_Mug) {
			case ScheduleLabel.Null:
				break;
			case ScheduleLabel["자연과학"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("연금술사 버크레오\n 「세상의 모든 일은 수학과 물\n리로 설명할 수 있지. 신비주의\n는 인간의 무지가 만들어낸 산\n물. 기적이나 마법도 과학적 현\n상에 지나지 않아.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「오늘로 수업을 마치겠다. 모\n두 과학의 마음을 잊지 말고, \n정진해주길.」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["신학"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("시스터 리이\n 「여러분, 저는 교회의 여신도\n인 리이입니다.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「이번 수업은 오늘로 끝입니다\n. 다음에도 와주기를 기대하겠\n어요」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["군사학"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("크루거 장군\n 「제군. 내가 바로 왕국의 상장\n군, 『백승장군』 이라 불리우는 \n엘윈 요하네스 오이겐크루거다\n.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「이것으로 강의를 마치겠다」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["검술"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("검사 레프톨\n 「여어, 내가 이 도장의 사범.\n성은 올, 이름은 레프트다. 레\n프톨이라 불러줘. 내 지도는 조\n금 거칠지만 실전형이라 도움이\n될거다.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「일단 이걸로 끝이다. 평소에\n도 수련을 게을리 하지 말도록」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["격투술"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("격투가 칼 폭스\n 「싸움은 검이 전부가 아니다.\n무기에 의존하지 않는 격투술의 \n극의는 공격을 한계까지 피하는\n체술의 습득에 있지.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「이것으로 일단 격투술 수업을\n끝내겠다. 모두 정진을 게을리\n하지 말도록.」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["마법"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("마법사 패트남\n 「안녕하세요. 제가 마법교실의\n 선생입니다. 여러분과 함께 실\n용마법을 배우도록 하죠」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「그럼 이번 마법 교실은 이것으\n로 마치겠습니다」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["시문학"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("시인 컴스톡\n 「시는 사람의 마음을 풍요롭게\n해줍니다. 옛 사람들의 시는 우\n리들에게 남겨진 보물, 창작은\n미래에 남기는 유산. 자, 함께\n공부합시다. 문학의 왕도를」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「수업은 오늘로 끝입니다. 여\n러분, 시를 사랑하는 마음을 잊\n지 마세요」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["예법"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("노사 바트사스\n 「잘 왔다. 이 늙은이는 예로부\n터 전해 내려오는 궁중예법과\n예의범절을 가르치는 사람이지」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「그럼, 다음에 다시 봅시다…\n…」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["무용"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("무용 선생 트베\n 「사교계 데뷔를 목표하는 여성\n에게 있어, 무용 실력은 커다란 \n무기가 됩니다. 열심히 익히세\n요. 자신을 위해서」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「이번 레슨은 오늘까지 입니다」");
						break;
					default:
						break;
				}
				break;
			case ScheduleLabel["미술"]:
				switch (_Situ) {
					case ScheduleSituation.ScheduleStart:
						this.SetUpdateText("왕궁화가 필킨스\n 「내가 왕궁화가인 필킨스다. \n그림을 통해서 예술의 심오함을 \n가르쳐 주도록 하지.」");
						break;
					case ScheduleSituation.ScheduleEnd:
						this.SetUpdateText("「이것으로 이번 강좌를 마치겠\n다」");
						break;
					default:
						break;
				}
				break;
			default:
				break;
		}
	}

	Start() {
		super.Start();
		this.SetScheduleMugshot();

		this.SetMugPic(this.ScheduleMugshot.get(ScheduleLabel["자연과학"]));
		this.SetMugLoc(MugShotLR.Left);
		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.IsFirstUpdate) {
			this.IsFirstUpdate = false;
			return;
		}

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			this.IsFirstUpdate = true;
		}
		super.Update(_DeltaTime);
	}

	SetScheduleMugshot() {
		this.ScheduleMugshot.set(ScheduleLabel["자연과학"], "Mug_Barcleo.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["예법"], "Mug_Bartholomew.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["격투술"], "Mug_CarlFox.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["시문학"], "Mug_Comstock.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["미술"], "Mug_Filkins.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["군사학"], "Mug_Kruger.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["검술"], "Mug_Leftor.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["마법"], "Mug_Putnam.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["신학"], "Mug_SisterLee.bmp");
		this.ScheduleMugshot.set(ScheduleLabel["무용"], "Mug_Tobi.bmp");
	}
}

__PM2_EXPORTS__["GameEngineContents/ScheduleDialog.js"] = {"ScheduleSituation": ScheduleSituation, "ScheduleScript": ScheduleScript, "ScheduleDialog": ScheduleDialog};
})();
(function () {

// ===== GameEngineContents/ScienceClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// ScienceClass.h / ScienceClass.cpp 의 전사

class ScienceClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Science.bmp", "Animation_Background_Science.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(-35, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(45, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-165, 12));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Faith = 0, .Stress = 0,.MagicDefense = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Faith = 0;
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 4, .Faith = 0,.Stress = 1, .MagicDefense = 0 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 4;
		StatusParaMax.Faith = 0;
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicDefense = 0;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-30);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/ScienceClass.js"] = {"ScienceClass": ScienceClass};
})();
(function () {

// ===== GameEngineContents/StrategyClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// StrategyClass.h / StrategyClass.cpp 의 전사

class StrategyClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Strategy.bmp", "Animation_Background_Strategy.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 4, 5, 6, new float4(125, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 7, 8, new float4(-35, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 9, 10, new float4(45, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 11, 12, new float4(-125, -11));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Sensitivity = -1, .Stress = 0,.CombatSkill = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Sensitivity = -1;
		StatusParaMin.Stress = 0;
		StatusParaMin.CombatSkill = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 2, .Sensitivity = 0, .Stress = 1,.CombatSkill = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 2;
		StatusParaMax.Sensitivity = 0;
		StatusParaMax.Stress = 1;
		StatusParaMax.CombatSkill = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-50);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/StrategyClass.js"] = {"StrategyClass": StrategyClass};
})();
(function () {

// ===== GameEngineContents/TheologyClass.js =====
var ClassesAndJobs = __PM2_EXPORTS__["GameEngineContents/ClassesAndJobs.js"]["ClassesAndJobs"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// TheologyClass.h / TheologyClass.cpp 의 전사

class TheologyClass extends ClassesAndJobs {
	constructor() {
		super();
	}

	Start() {
		this.SetImageName("Animation_Object_Theology.bmp", "Animation_Background_Theology.bmp");
		this.SetBackground();
		this.SetObjScale(new float4(50, 100));
		this.SetOliveObj(0, 1, 2, 3, 4, 5, new float4(85, 12));
		this.SetObj1(PM2RenderOrder.Menu2_Obj_2, 6, 7, new float4(175, 12));
		this.SetObj2(PM2RenderOrder.Menu2_Obj_2, 8, 9, new float4(-95, 12));
		this.SetObj3(PM2RenderOrder.Menu2_Obj_2, 10, 11, new float4(-175, 12));
		this.SetObj4(PM2RenderOrder.Menu2_Obj_2, 12, 15, new float4(-25, 12));

		// 원본: GetStatusVarianceMin().SetStatus({.Intelligence = 1, .Faith = 1, .Stress = 0,.MagicDefense = 0 });
		// 지정 초기화자 → Status 임시객체(미지정 필드는 0)
		const StatusParaMin = new Olive.Status();
		StatusParaMin.Intelligence = 1;
		StatusParaMin.Faith = 1;
		StatusParaMin.Stress = 0;
		StatusParaMin.MagicDefense = 0;
		this.GetStatusVarianceMin().SetStatus(StatusParaMin);

		// 원본: GetStatusVarianceMax().SetStatus({ .Intelligence = 1, .Faith = 2,.Stress = 1, .MagicDefense = 1 });
		const StatusParaMax = new Olive.Status();
		StatusParaMax.Intelligence = 1;
		StatusParaMax.Faith = 2;
		StatusParaMax.Stress = 1;
		StatusParaMax.MagicDefense = 1;
		this.GetStatusVarianceMax().SetStatus(StatusParaMax);

		this.SetPayGold(-40);

		// 원본: ClassesAndJobs::Start();
		ClassesAndJobs.prototype.Start.call(this);
	}
}

__PM2_EXPORTS__["GameEngineContents/TheologyClass.js"] = {"TheologyClass": TheologyClass};
})();
(function () {

// ===== GameEngineContents/UIManager.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// UIManager.h / UIManager.cpp 의 전사

class UIManager extends GameEngineActor {
	static ParentLevel = null;
	static AcMainMenu = null;
	static AcCubeDialog = null;

	constructor() {
		super();
	}

	GetMainMenu() {
		return UIManager.AcMainMenu;
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		UIManager.ParentLevel = this.GetLevel();
		UIManager.AcMainMenu = UIManager.ParentLevel.CreateActor(MainMenu, PM2ActorOrder.Menu0);
		UIManager.AcCubeDialog = UIManager.ParentLevel.GetAcCubeDialog();

		UIManager.AcCubeDialog.SetUpdateText("「주인님, 안녕하십니까. 집사 \n큐브 입니다.」");
	}

	Update(_DeltaTime) {
		this.SetEngineRightClick();
	}

	SetEngineRightClick() {
		if (GameEngineInput.IsUp("EngineMouseRight"))
		{
			if (UIManager.AcCubeDialog.IsUpdate())
			{
				if (UIManager.AcCubeDialog.GetUpdateText() === "「주인님, 안녕하십니까. 집사 \n큐브 입니다.」")
				{
					UIManager.AcCubeDialog.SetUpdateText("「아가씨는 오늘도 건강하십니\n다. 그럼 속히 아가씨의 이번 \n달 스케줄을 결정해 주십시오」");
				}
				else if (UIManager.AcCubeDialog.GetUpdateText() === "「아가씨는 오늘도 건강하십니\n다. 그럼 속히 아가씨의 이번 \n달 스케줄을 결정해 주십시오」")
				{
					UIManager.AcCubeDialog.Off();
					UIManager.AcMainMenu.On();
				}
				else if (UIManager.AcCubeDialog.GetUpdateText() === "예, 알겠습니다. 다음달부터 그\n렇게 하겠습니다")
				{
					UIManager.AcCubeDialog.Off();
					UIManager.AcMainMenu.On();
				}
			}
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/UIManager.js"] = {"UIManager": UIManager};
})();
(function () {

// ===== GameEngineContents/RaisingSimLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineSoundPlayer = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineSoundPlayer"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var Season = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Season"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var Background = __PM2_EXPORTS__["GameEngineContents/Background.js"]["Background"];
var UIManager;
__PM2_LATE__.push(function () { UIManager = __PM2_EXPORTS__["GameEngineContents/UIManager.js"]["UIManager"]; });
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var Flower = __PM2_EXPORTS__["GameEngineContents/Flower.js"]["Flower"];
var Paint = __PM2_EXPORTS__["GameEngineContents/Paint.js"]["Paint"];
var DateViewer = __PM2_EXPORTS__["GameEngineContents/DateViewer.js"]["DateViewer"];
var BasicInfo = __PM2_EXPORTS__["GameEngineContents/BasicInfo.js"]["BasicInfo"];
var CubeDialog = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeDialog"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var ScheduleDialog = __PM2_EXPORTS__["GameEngineContents/ScheduleDialog.js"]["ScheduleDialog"];
var MousePoint = __PM2_EXPORTS__["GameEngineContents/MousePoint.js"]["MousePoint"];
var DanceClass = __PM2_EXPORTS__["GameEngineContents/DanceClass.js"]["DanceClass"];
var FencingClass = __PM2_EXPORTS__["GameEngineContents/FencingClass.js"]["FencingClass"];
var FightingClass = __PM2_EXPORTS__["GameEngineContents/FightingClass.js"]["FightingClass"];
var MagicClass = __PM2_EXPORTS__["GameEngineContents/MagicClass.js"]["MagicClass"];
var PaintingClass = __PM2_EXPORTS__["GameEngineContents/PaintingClass.js"]["PaintingClass"];
var PoetryClass = __PM2_EXPORTS__["GameEngineContents/PoetryClass.js"]["PoetryClass"];
var ProtocolClass = __PM2_EXPORTS__["GameEngineContents/ProtocolClass.js"]["ProtocolClass"];
var ScienceClass = __PM2_EXPORTS__["GameEngineContents/ScienceClass.js"]["ScienceClass"];
var StrategyClass = __PM2_EXPORTS__["GameEngineContents/StrategyClass.js"]["StrategyClass"];
var TheologyClass = __PM2_EXPORTS__["GameEngineContents/TheologyClass.js"]["TheologyClass"];
// RaisingSimLevel.h / RaisingSimLevel.cpp 의 전사







class RaisingSimLevel extends GameEngineLevel {
	static AcCubeDialog = null;
	static AcScheduleDialog = null;

	constructor() {
		super();
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;

		this.AcOlive = null;
		this.Today = new Date(1000, 10, 10);
		this.TodaySeason = Season.Null;

		this.AcBackground = null;
		this.AcFlower = null;
		this.AcPaint = null;
		this.AcUIManager = null;

		this.BGMPlayer = new GameEngineSoundPlayer();

		this.Time = 0;

		this.SeasonChange = false;
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		RaisingSimLevel.AcCubeDialog = this.CreateActor(CubeDialog, PM2ActorOrder.Dialog1);
		RaisingSimLevel.AcScheduleDialog = this.CreateActor(ScheduleDialog, PM2ActorOrder.Dialog2);
		this.AcBackground = this.CreateActor(Background, PM2ActorOrder.BackGround);
		this.CreateActor(DateViewer, PM2ActorOrder.Menu0);
		this.CreateActor(BasicInfo, PM2ActorOrder.Menu0);

		this.AcDanceClass = this.CreateActor(DanceClass, PM2ActorOrder.Menu2);
		this.AcFencingClass = this.CreateActor(FencingClass, PM2ActorOrder.Menu2);
		this.AcFightingClass = this.CreateActor(FightingClass, PM2ActorOrder.Menu2);
		this.AcMagicClass = this.CreateActor(MagicClass, PM2ActorOrder.Menu2);
		this.AcPaintingClass = this.CreateActor(PaintingClass, PM2ActorOrder.Menu2);
		this.AcPoetryClass = this.CreateActor(PoetryClass, PM2ActorOrder.Menu2);
		this.AcProtocolClass = this.CreateActor(ProtocolClass, PM2ActorOrder.Menu2);
		this.AcScienceClass = this.CreateActor(ScienceClass, PM2ActorOrder.Menu2);
		this.AcStrategyClass = this.CreateActor(StrategyClass, PM2ActorOrder.Menu2);
		this.AcTheologyClass = this.CreateActor(TheologyClass, PM2ActorOrder.Menu2);

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.CreateActor(Olive, PM2ActorOrder.Olive);
		this.CreateActor(Flower, PM2ActorOrder.BackGround);
		this.CreateActor(Paint, PM2ActorOrder.BackGround);


		this.AcUIManager = this.CreateActor(UIManager);
		GameEngineInput.CreateKey("3", '3'.charCodeAt(0));
		GameEngineInput.CreateKey("4", '4'.charCodeAt(0));
		GameEngineInput.CreateKey("5", '5'.charCodeAt(0));
		GameEngineInput.CreateKey("q", 'q'.charCodeAt(0));
		GameEngineInput.CreateKey("w", 'w'.charCodeAt(0));
		GameEngineInput.CreateKey("e", 'e'.charCodeAt(0));
		GameEngineInput.CreateKey("r", 'r'.charCodeAt(0));
		GameEngineInput.CreateKey("a", 'a'.charCodeAt(0));
		GameEngineInput.CreateKey("s", 's'.charCodeAt(0));
	}

	Update(_DeltaTime) {
		if (GameEngineInput.IsDown("LevelChange"))
		{
			GameEngineCore.GetInst().ChangeLevel("Ending");
		}

		if (GameEngineInput.IsDown("1"))
		{
			GameEngineCore.GetInst().DebugSwitch();
		}

		if (GameEngineInput.IsDown("2"))
		{
			// 원본: ++Today;
			this.Today = this.Today.GetNextDate();
		}

		if (GameEngineInput.IsDown("3"))
		{
			this.GoToBeforBirthDay();
		}

		if (GameEngineInput.IsDown("4"))
		{
			this.OliveAllStatMax();
		}

		if (GameEngineInput.IsDown("5"))
		{
			this.OliveAllStatMaxExeptSin();
		}

		if (this.Today.GetMonth() === this.AcOlive.GetOliveBirthDay().GetMonth() && this.Today.GetDay() === this.AcOlive.GetOliveBirthDay().GetDay() && this.AcOlive.GetOliveAge() === 18)
		{
			GameEngineCore.GetInst().ChangeLevel("Ending");
		}

		this.OliveStateChange();
		this.UpdateSeason();
		this.BGMUpdate();
	}

	LevelChangeEnd(_NextLevel) {
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.AcOlive = Olive.OlivePlayer;
		Olive.OlivePlayer.On();
		this.AcUIManager.GetMainMenu().Off();
		RaisingSimLevel.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "「주인님, 안녕하십니까. 집사 \n큐브 입니다.」");
		this.UpdateSeason();
		switch (this.TodaySeason)
		{
			case Season.Spring:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
				break;
			case Season.Summer:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
				break;
			case Season.Fall:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
				break;
			case Season.Winter:
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
				break;
			default:
				break;
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("04_Main_screen_(Spring).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("05_Main_screen_(Summer).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("06_Main_screen_(Autumn).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("07_Main_screen_(Winter).mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("13_Training.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("RaisingLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("paint_default.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_spring.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_summer.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_fall.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_winter.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("flower_disease.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("background.BMP"));

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("DateViewer.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_WeekDay.BMP")).Cut(7, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Month.BMP")).Cut(12, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Day.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num.BMP")).Cut(10, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BasicInfo.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Age.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu_Buttons.bmp")).Cut(4, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MainMenu_Schedule.bmp"));

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Detail.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Estemate.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer1_Physical.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Detail.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Estemate.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGaugeFrame_Layer2_Physical.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("StatusGauge.bmp")).Cut(2, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Status.bmp")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Num_Status_etc.bmp")).Cut(3, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Icon.bmp")).Cut(15, 7);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BloodTypeRender.bmp")).Cut(4, 1);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Calendar.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("IconButton_Hover.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FoodCost.bmp"));


		Dir.Move("Cube");

		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Cube");
		Dir.Move("Classes");

		AllFile.length = 0;
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.Move("Object");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Dance.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Fencing.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Fighting.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Magic.bmp")).Cut(13, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Painting.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Poetry.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Protocol.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Science.bmp")).Cut(13, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Strategy.bmp")).Cut(13, 2);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Animation_Object_Theology.bmp")).Cut(13, 2);

		Dir.MoveParentToDirectory("Object");
		Dir.Move("Mug");
		AllFile.length = 0;
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}
	}

	GoToBeforBirthDay() {
		this.Today.SetDate(this.Today.GetYear() + 1, this.AcOlive.GetOliveBirthDay().GetMonth(), this.AcOlive.GetOliveBirthDay().GetDay() - 1);
	}

	OliveAllStatMax() {
		Olive.OlivePlayer.OliveStatus.Constitution = Olive.OlivePlayer.OliveStatus.MaxConstitution;
		Olive.OlivePlayer.OliveStatus.Strength = Olive.OlivePlayer.OliveStatus.MaxStrength;
		Olive.OlivePlayer.OliveStatus.Intelligence = Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		Olive.OlivePlayer.OliveStatus.Refinement = Olive.OlivePlayer.OliveStatus.MaxRefinement;
		Olive.OlivePlayer.OliveStatus.Charisma = Olive.OlivePlayer.OliveStatus.MaxCharisma;
		Olive.OlivePlayer.OliveStatus.Morality = Olive.OlivePlayer.OliveStatus.MaxMorality;
		Olive.OlivePlayer.OliveStatus.Faith = Olive.OlivePlayer.OliveStatus.MaxFaith;
		Olive.OlivePlayer.OliveStatus.Sin = Olive.OlivePlayer.OliveStatus.MaxSin;
		Olive.OlivePlayer.OliveStatus.Sensitivity = Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		Olive.OlivePlayer.OliveStatus.CombatSkill = Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		Olive.OlivePlayer.OliveStatus.CombatAttack = Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		Olive.OlivePlayer.OliveStatus.CombatDefense = Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		Olive.OlivePlayer.OliveStatus.MagicSkill = Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		Olive.OlivePlayer.OliveStatus.MagicAttack = Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		Olive.OlivePlayer.OliveStatus.MagicDefense = Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		Olive.OlivePlayer.OliveStatus.Decorum = Olive.OlivePlayer.OliveStatus.MaxDecorum;
		Olive.OlivePlayer.OliveStatus.Art = Olive.OlivePlayer.OliveStatus.MaxArt;
		Olive.OlivePlayer.OliveStatus.Conversation = Olive.OlivePlayer.OliveStatus.MaxConversation;
		Olive.OlivePlayer.OliveStatus.Cooking = Olive.OlivePlayer.OliveStatus.MaxCooking;
		Olive.OlivePlayer.OliveStatus.Cleaning = Olive.OlivePlayer.OliveStatus.MaxCleaning;
		Olive.OlivePlayer.OliveStatus.Temperament = Olive.OlivePlayer.OliveStatus.MaxTemperament;
	}

	OliveAllStatMaxExeptSin() {
		Olive.OlivePlayer.OliveStatus.Constitution = Olive.OlivePlayer.OliveStatus.MaxConstitution;
		Olive.OlivePlayer.OliveStatus.Strength = Olive.OlivePlayer.OliveStatus.MaxStrength;
		Olive.OlivePlayer.OliveStatus.Intelligence = Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		Olive.OlivePlayer.OliveStatus.Refinement = Olive.OlivePlayer.OliveStatus.MaxRefinement;
		Olive.OlivePlayer.OliveStatus.Charisma = Olive.OlivePlayer.OliveStatus.MaxCharisma;
		Olive.OlivePlayer.OliveStatus.Morality = Olive.OlivePlayer.OliveStatus.MaxMorality;
		Olive.OlivePlayer.OliveStatus.Faith = Olive.OlivePlayer.OliveStatus.MaxFaith;
		Olive.OlivePlayer.OliveStatus.Sin = 0;
		Olive.OlivePlayer.OliveStatus.Sensitivity = Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		Olive.OlivePlayer.OliveStatus.CombatSkill = Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		Olive.OlivePlayer.OliveStatus.CombatAttack = Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		Olive.OlivePlayer.OliveStatus.CombatDefense = Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		Olive.OlivePlayer.OliveStatus.MagicSkill = Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		Olive.OlivePlayer.OliveStatus.MagicAttack = Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		Olive.OlivePlayer.OliveStatus.MagicDefense = Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		Olive.OlivePlayer.OliveStatus.Decorum = Olive.OlivePlayer.OliveStatus.MaxDecorum;
		Olive.OlivePlayer.OliveStatus.Art = Olive.OlivePlayer.OliveStatus.MaxArt;
		Olive.OlivePlayer.OliveStatus.Conversation = Olive.OlivePlayer.OliveStatus.MaxConversation;
		Olive.OlivePlayer.OliveStatus.Cooking = Olive.OlivePlayer.OliveStatus.MaxCooking;
		Olive.OlivePlayer.OliveStatus.Cleaning = Olive.OlivePlayer.OliveStatus.MaxCleaning;
		Olive.OlivePlayer.OliveStatus.Temperament = Olive.OlivePlayer.OliveStatus.MaxTemperament;
	}

	OliveStateChange() {
		if (GameEngineInput.IsDown("q"))
		{
			Olive.OlivePlayer.OliveStatus.Constitution = 100;
			Olive.OlivePlayer.OliveStatus.Stress = 150;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("w"))
		{
			Olive.OlivePlayer.OliveStatus.Constitution = 100;
			Olive.OlivePlayer.OliveStatus.Stress = 50;
			Olive.OlivePlayer.OliveStatus.Morality = 0;
			Olive.OlivePlayer.OliveStatus.Faith = 0;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("e"))
		{
			Olive.OlivePlayer.OliveStatus.Stress = 0;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

		if (GameEngineInput.IsDown("r"))
		{
			Olive.OlivePlayer.OliveStatus.Stress = 1;
			Olive.OlivePlayer.OliveStatus.Morality = 100;
			Olive.OlivePlayer.OliveStatus.Faith = 100;
			Olive.OlivePlayer.OliveStateUpdate();
			Olive.OlivePlayer.OliveRenderUpdate();
		}

	}

	UpdateSeason() {
		const Month = this.Today.GetMonth();
		if (Month >= 3 && Month < 6)
		{
			this.TodaySeason = Season.Spring;
		}
		else if (Month >= 6 && Month < 9)
		{
			this.TodaySeason = Season.Summer;
		}
		else if (Month >= 9 && Month < 12)
		{
			this.TodaySeason = Season.Fall;
		}
		else if (Month >= 1 && Month < 3 || Month === 12)
		{
			this.TodaySeason = Season.Winter;
		}
	}

	BGMUpdate() {
		if (this.IsFirstMonthOfSeason() && !this.SeasonChange && Date.GetMonthLastDate(this.Today).IsEqual(this.Today))
		{
			this.SeasonChange = true;
			switch (this.TodaySeason)
			{
				case Season.Spring:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
					break;
				case Season.Summer:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
					break;
				case Season.Fall:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
					break;
				case Season.Winter:
					this.BGMPlayer.Stop();
					this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
					break;
				default:
					break;
			}
		}
		else if (!this.IsFirstMonthOfSeason())
		{
			this.SeasonChange = false;
		}
	}

	IsFirstMonthOfSeason() {
		if (this.Today.GetMonth() === 12 || this.Today.GetMonth() === 3 || this.Today.GetMonth() === 6 || this.Today.GetMonth() === 9)
		{
			return true;
		}
		return false;
	}

	SetToday(_Today) {
		this.Today.SetDate(_Today.GetYear(), _Today.GetMonth(), _Today.GetDay());
	}

	GetToday() {
		return this.Today;
	}

	GoToNextDay() {
		// 원본: ++Today;
		this.Today = this.Today.GetNextDate();
	}

	static GetAcCubeDialog() {
		return RaisingSimLevel.AcCubeDialog;
	}

	static GetAcScheduleDialog() {
		return RaisingSimLevel.AcScheduleDialog;
	}

	GetUIManager() {
		return this.AcUIManager;
	}

	GetTodaySeason() {
		return this.TodaySeason;
	}

	GetBGMPlayer() {
		return this.BGMPlayer;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcCubeDialog', 'GetAcScheduleDialog']) {
	Object.defineProperty(RaisingSimLevel.prototype, __m, { value: function (...args) { return RaisingSimLevel[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/RaisingSimLevel.js"] = {"RaisingSimLevel": RaisingSimLevel};
})();
(function () {

// ===== GameEngineContents/ScheduleSelectionMenu.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var ClassSelectWindow;
__PM2_LATE__.push(function () { ClassSelectWindow = __PM2_EXPORTS__["GameEngineContents/ClassSelectWindow.js"]["ClassSelectWindow"]; });
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var RaisingSimLevel;
__PM2_LATE__.push(function () { RaisingSimLevel = __PM2_EXPORTS__["GameEngineContents/RaisingSimLevel.js"]["RaisingSimLevel"]; });
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
// ScheduleSelectionMenu.h / ScheduleSelectionMenu.cpp 의 전사

class ScheduleSelectionMenu extends SelectionMenu {
	static AcScheduleSelectionMenu = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleSelectionMenu.AcScheduleSelectionMenu = this;
		this.Xscale = 200;
		this.ActorPos = new float4(700, 347);
		this.AcCubeDialog = null;
		this.AcScheduleCalendar = null;
	}

	static GetAcScheduleSelectionMenu() {
		return ScheduleSelectionMenu.AcScheduleSelectionMenu;
	}

	// 원본: static ClassSelectWindow* AcClassSelectWindow;
	static AcClassSelectWindow = null;

	Start() {
		ScheduleSelectionMenu.AcClassSelectWindow = this.GetLevel().CreateActor(ClassSelectWindow, PM2ActorOrder.Menu2);
		this.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		this.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		this.InitMenuFrameRender(PM2RenderOrder.Menu1, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(4, this.ActorPos, this.Xscale, PM2ActorOrder.Menu1_Button, PM2RenderOrder.Menu1_Button);
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 0, "딸을 단련시킨다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 1, "딸에게 일을 시킨다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 2, "무사수행을 보낸다");
		this.SetButtonString(PM2RenderOrder.Menu1_Display, 3, "휴식을 준다");

		this.SetButtonClick();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 1 번째 )");
		}
		else if (this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 2 번째 )");
		}
		else if (this.AcScheduleCalendar.FirstScheduleSet && this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
			this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번 달 딸의 예정은? ( 3 번째 )");
		}


		if (GameEngineInput.IsUp("EngineMouseRight")) {
			if (!this.AcScheduleCalendar.FirstScheduleSet && !this.AcScheduleCalendar.SecondScheduleSet && !this.AcScheduleCalendar.ThirdScheduleSet) {
				this.AcScheduleCalendar.Off();
				this.AcCubeDialog.Off();
				this.Off();
				MainMenu.GetAcMainMenu().On();
			}
			else {
				this.AcScheduleCalendar.CancelSchedule();
			}
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(ScheduleSelectionMenu.Click0);
	}

	static Click0(_Button) {
		ScheduleSelectionMenu.AcClassSelectWindow.On();
		ScheduleSelectionMenu.AcScheduleSelectionMenu.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcScheduleSelectionMenu', 'Click0']) {
	Object.defineProperty(ScheduleSelectionMenu.prototype, __m, { value: function (...args) { return ScheduleSelectionMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/ScheduleSelectionMenu.js"] = {"ScheduleSelectionMenu": ScheduleSelectionMenu};
})();
(function () {

// ===== GameEngineContents/EstimateStatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// EstimateStatusWindow.h / EstimateStatusWindow.cpp 의 전사

class EstimateStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 455);

		this.Fighter = 0;
		this.FighterRender = null;
		this.Magical = 0;
		this.MagicalRender = null;
		this.Social = 0;
		this.SocialRender = null;
		this.HouseWork = 0;
		this.HouseWorkRender = null;

		this.Max = 300;

		this.Style = GaugeFrameStyle.Estemate;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);

		this.FighterRender = this.InsertStatus("전사평가", this.Max, this.Style);
		this.MagicalRender = this.InsertStatus("마법평가", this.Max, this.Style);
		this.SocialRender = this.InsertStatus("사교평가", this.Max, this.Style);
		this.HouseWorkRender = this.InsertStatus("가사평가", this.Max, this.Style);

		this.SetPos(new float4(GameEngineWindow.GetScreenSize().x, GameEngineWindow.GetScreenSize().hy()).add(float4.Left.mul(this.GetMenuFrameScale().half())).add(new float4(-10, 0)).add(new float4(0, 20)));
	}

	Update(_DeltaTime) {
		if (this.Fighter !== Olive.OlivePlayer.GetStatue().Fighter) {
			this.Fighter = Olive.OlivePlayer.GetStatue().Fighter;
			this.FighterRender.UpdateValue(this.Fighter);
		}
		if (this.Magical !== Olive.OlivePlayer.GetStatue().Magical) {
			this.Magical = Olive.OlivePlayer.GetStatue().Magical;
			this.MagicalRender.UpdateValue(this.Magical);
		}
		if (this.Social !== Olive.OlivePlayer.GetStatue().Social) {
			this.Social = Olive.OlivePlayer.GetStatue().Social;
			this.SocialRender.UpdateValue(this.Social);
		}
		if (this.HouseWork !== Olive.OlivePlayer.GetStatue().HouseWork) {
			this.HouseWork = Olive.OlivePlayer.GetStatue().HouseWork;
			this.HouseWorkRender.UpdateValue(this.HouseWork);
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/EstimateStatusWindow.js"] = {"EstimateStatusWindow": EstimateStatusWindow};
})();
(function () {

// ===== GameEngineContents/FighterAndMagicalStatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// FighterAndMagicalStatusWindow.h / FighterAndMagicalStatusWindow.cpp 의 전사

class FighterAndMagicalStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(130, 455);

		this.CombatSkill = 0;
		this.CombatSkillRender = null;
		this.CombatAttack = 0;
		this.CombatAttackRender = null;
		this.CombatDefense = 0;
		this.CombatDefenseRender = null;

		this.MagicSkill = 0;
		this.MagicSkillRender = null;
		this.MagicAttack = 0;
		this.MagicAttackRender = null;
		this.MagicDefense = 0;
		this.MagicDefenseRender = null;

		this.Max = 100;

		this.Style = GaugeFrameStyle.Detail;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.CombatSkillRender = this.InsertStatus("전투기술", this.Max, this.Style);
		this.CombatAttackRender = this.InsertStatus("공격력", this.Max, this.Style);
		this.CombatDefenseRender = this.InsertStatus("방어력", this.Max, this.Style);

		this.MagicSkillRender = this.InsertStatus("마법기술", this.Max, this.Style);
		this.MagicAttackRender = this.InsertStatus("마력", this.Max, this.Style);
		this.MagicDefenseRender = this.InsertStatus("항마력", this.Max, this.Style);

		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.CombatSkill !== Olive.OlivePlayer.GetStatue().CombatSkill) {
			this.CombatSkill = Olive.OlivePlayer.GetStatue().CombatSkill;
			this.CombatSkillRender.UpdateValue(this.CombatSkill);
		}
		if (this.CombatAttack !== Olive.OlivePlayer.GetStatue().CombatAttack) {
			this.CombatAttack = Olive.OlivePlayer.GetStatue().CombatAttack;
			this.CombatAttackRender.UpdateValue(this.CombatAttack);
		}
		if (this.CombatDefense !== Olive.OlivePlayer.GetStatue().CombatDefense) {
			this.CombatDefense = Olive.OlivePlayer.GetStatue().CombatDefense;
			this.CombatDefenseRender.UpdateValue(this.CombatDefense);
		}
		if (this.MagicSkill !== Olive.OlivePlayer.GetStatue().MagicSkill) {
			this.MagicSkill = Olive.OlivePlayer.GetStatue().MagicSkill;
			this.MagicSkillRender.UpdateValue(this.MagicSkill);
		}
		if (this.MagicAttack !== Olive.OlivePlayer.GetStatue().MagicAttack) {
			this.MagicAttack = Olive.OlivePlayer.GetStatue().MagicAttack;
			this.MagicAttackRender.UpdateValue(this.MagicAttack);
		}
		if (this.MagicDefense !== Olive.OlivePlayer.GetStatue().MagicDefense) {
			this.MagicDefense = Olive.OlivePlayer.GetStatue().MagicDefense;
			this.MagicDefenseRender.UpdateValue(this.MagicDefense);
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/FighterAndMagicalStatusWindow.js"] = {"FighterAndMagicalStatusWindow": FighterAndMagicalStatusWindow};
})();
(function () {

// ===== GameEngineContents/SocialAndHouseworkStatusWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// SocialAndHouseworkStatusWindow.h / SocialAndHouseworkStatusWindow.cpp 의 전사

class SocialAndHouseworkStatusWindow extends StatusWindow {
	constructor() {
		super();
		this.ActorPos = new float4(670, 455);

		this.Decorum = 0;
		this.DecorumRender = null;
		this.Art = 0;
		this.ArtRender = null;
		this.Conversation = 0;
		this.ConversationRender = null;

		this.Cooking = 0;
		this.CookingRender = null;
		this.Cleaning = 0;
		this.CleaningRender = null;
		this.Temperament = 0;
		this.TemperamentRender = null;

		this.Max = 100;

		this.Style = GaugeFrameStyle.Detail;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.DecorumRender = this.InsertStatus("예의범절", this.Max, this.Style);
		this.ArtRender = this.InsertStatus("예술", this.Max, this.Style);
		this.ConversationRender = this.InsertStatus("화술", this.Max, this.Style);

		this.CookingRender = this.InsertStatus("요리", this.Max, this.Style);
		this.CleaningRender = this.InsertStatus("청소세탁", this.Max, this.Style);
		this.TemperamentRender = this.InsertStatus("성품", this.Max, this.Style);

		this.SetPos(this.ActorPos);
	}

	Update(_DeltaTime) {
		if (this.Decorum !== Olive.OlivePlayer.GetStatue().Decorum) {
			this.Decorum = Olive.OlivePlayer.GetStatue().Decorum;
			this.DecorumRender.UpdateValue(this.Decorum);
		}
		if (this.Art !== Olive.OlivePlayer.GetStatue().Art) {
			this.Art = Olive.OlivePlayer.GetStatue().Art;
			this.ArtRender.UpdateValue(this.Art);
		}
		if (this.Conversation !== Olive.OlivePlayer.GetStatue().Conversation) {
			this.Conversation = Olive.OlivePlayer.GetStatue().Conversation;
			this.ConversationRender.UpdateValue(this.Conversation);
		}
		if (this.Cooking !== Olive.OlivePlayer.GetStatue().Cooking) {
			this.Cooking = Olive.OlivePlayer.GetStatue().Cooking;
			this.CookingRender.UpdateValue(this.Cooking);
		}
		if (this.Cleaning !== Olive.OlivePlayer.GetStatue().Cleaning) {
			this.Cleaning = Olive.OlivePlayer.GetStatue().Cleaning;
			this.CleaningRender.UpdateValue(this.Cleaning);
		}
		if (this.Temperament !== Olive.OlivePlayer.GetStatue().Temperament) {
			this.Temperament = Olive.OlivePlayer.GetStatue().Temperament;
			this.TemperamentRender.UpdateValue(this.Temperament);
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/SocialAndHouseworkStatusWindow.js"] = {"SocialAndHouseworkStatusWindow": SocialAndHouseworkStatusWindow};
})();
(function () {

// ===== GameEngineContents/StatusWindowManager.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var BasicStatusWindow = __PM2_EXPORTS__["GameEngineContents/BasicStatusWindow.js"]["BasicStatusWindow"];
var EstimateStatusWindow = __PM2_EXPORTS__["GameEngineContents/EstimateStatusWindow.js"]["EstimateStatusWindow"];
var FighterAndMagicalStatusWindow = __PM2_EXPORTS__["GameEngineContents/FighterAndMagicalStatusWindow.js"]["FighterAndMagicalStatusWindow"];
var SocialAndHouseworkStatusWindow = __PM2_EXPORTS__["GameEngineContents/SocialAndHouseworkStatusWindow.js"]["SocialAndHouseworkStatusWindow"];
// StatusWindowManager.h / StatusWindowManager.cpp 의 전사

class StatusWindowManager extends GameEngineActor {
	constructor() {
		super();
		this.AcMainMenu = null;

		this.AcBasicStatusWindow = null;
		this.AcEstimateStatusWindow = null;
		this.AcFighterAndMagicalStatusWindow = null;
		this.AcSocialAndHouseworkStatusWindow = null;
	}

	On() {
		super.On();
		this.AcBasicStatusWindow.On();
		this.AcEstimateStatusWindow.On();
		this.AcFighterAndMagicalStatusWindow.On();
		this.AcSocialAndHouseworkStatusWindow.On();
	}

	Off() {
		super.Off();
		this.AcBasicStatusWindow.Off();
		this.AcEstimateStatusWindow.Off();
		this.AcFighterAndMagicalStatusWindow.Off();
		this.AcSocialAndHouseworkStatusWindow.Off();
	}

	Start() {
		const Level = this.GetLevel();
		this.AcMainMenu = MainMenu.GetAcMainMenu();

		this.AcBasicStatusWindow = Level.CreateActor(BasicStatusWindow, PM2ActorOrder.Menu1);
		this.AcEstimateStatusWindow = Level.CreateActor(EstimateStatusWindow, PM2ActorOrder.Menu1);
		this.AcFighterAndMagicalStatusWindow = Level.CreateActor(FighterAndMagicalStatusWindow, PM2ActorOrder.Menu1);
		this.AcSocialAndHouseworkStatusWindow = Level.CreateActor(SocialAndHouseworkStatusWindow, PM2ActorOrder.Menu1);
		this.Off();
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			this.AcMainMenu.On();
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/StatusWindowManager.js"] = {"StatusWindowManager": StatusWindowManager};
})();
(function () {

// ===== GameEngineContents/MainMenu.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var StatusWindowManager;
__PM2_LATE__.push(function () { StatusWindowManager = __PM2_EXPORTS__["GameEngineContents/StatusWindowManager.js"]["StatusWindowManager"]; });
var ConverstionSelectionMenu;
__PM2_LATE__.push(function () { ConverstionSelectionMenu = __PM2_EXPORTS__["GameEngineContents/ConverstionSelectionMenu.js"]["ConverstionSelectionMenu"]; });
var DietSelectionMenu;
__PM2_LATE__.push(function () { DietSelectionMenu = __PM2_EXPORTS__["GameEngineContents/DietSelectionMenu.js"]["DietSelectionMenu"]; });
var InformationWindowManager;
__PM2_LATE__.push(function () { InformationWindowManager = __PM2_EXPORTS__["GameEngineContents/InformationWindowManager.js"]["InformationWindowManager"]; });
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var ScheduleSelectionMenu;
__PM2_LATE__.push(function () { ScheduleSelectionMenu = __PM2_EXPORTS__["GameEngineContents/ScheduleSelectionMenu.js"]["ScheduleSelectionMenu"]; });
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
// MainMenu.h / MainMenu.cpp 의 전사

class MainMenu extends GameEngineActor {
	static AcMainMenu = null;
	static AcStatusWindowManager = null;
	static AcConverstionSelectionMenu = null;
	static AcDietSelectionMenu = null;
	static AcInformationWindowManager = null;

	static AcScheduleCalendar = null;
	static AcScheduleSelectionMenu = null;

	constructor() {
		super();
		this.ActorPos = new float4(700, 278);
		this.MainMenuRender = null;
		this.MainMenuButtons = []; // std::vector<std::vector<GlobalButton*>>
		this.MainMenuButtonScale = new float4(50, 40);
		this.FirstButtonSetPos = new float4(-75, -40);

		this.ScheduleButton = null;
		this.ScheduleButtonScale = new float4(200, 40);
		this.ScheduleButtonPos = new float4(0, 40);

		MainMenu.AcMainMenu = this;
	}

	GetMainMenuButton() {
		return this.MainMenuButtons;
	}

	GetScheduleButton() {
		return this.ScheduleButton;
	}

	static GetAcMainMenu() {
		return MainMenu.AcMainMenu;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x].On();
			}
		}
		this.ScheduleButton.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x].Off();
			}
		}
		this.ScheduleButton.Off();
	}

	Start() {
		const Level = this.GetLevel();
		this.SetPos(this.ActorPos);
		this.MainMenuRender = this.CreateRender("MainMenu.bmp", PM2RenderOrder.Menu0);
		this.MainMenuRender.SetScaleToImage();
		this.SetMainMenuButtons();

		MainMenu.AcStatusWindowManager = Level.CreateActor(StatusWindowManager, PM2ActorOrder.Menu1);
		MainMenu.AcConverstionSelectionMenu = Level.CreateActor(ConverstionSelectionMenu, PM2ActorOrder.Menu1);
		MainMenu.AcDietSelectionMenu = Level.CreateActor(DietSelectionMenu, PM2ActorOrder.Menu1);
		MainMenu.AcInformationWindowManager = Level.CreateActor(InformationWindowManager, PM2ActorOrder.Menu1);

		MainMenu.AcScheduleCalendar = Level.CreateActor(ScheduleCalendar, PM2ActorOrder.Menu1);
		MainMenu.AcScheduleSelectionMenu = Level.CreateActor(ScheduleSelectionMenu, PM2ActorOrder.Menu1);
		this.SetClickButton();
	}

	Update(_DeltaTime) {

	}

	Render(_Time) {
	}

	SetMainMenuButtons() {
		const Level = this.GetLevel();
		// 원본: MainMenuButtons.resize(2) 후 각 행 resize(4)
		this.MainMenuButtons.length = 2;
		for (let x = 0; x < this.MainMenuButtons.length; x++) {
			this.MainMenuButtons[x] = new Array(4).fill(null);
		}


		for (let y = 0; y < this.MainMenuButtons.length; y++) {
			for (let x = 0; x < this.MainMenuButtons[y].length; x++) {
				this.MainMenuButtons[y][x] = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.MainMenuButtons[y][x].SetScale(this.MainMenuButtonScale);
				this.MainMenuButtons[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.MainMenuButtons[y][x].SetReleaseImage("SelectButton_Release.bmp");
				this.MainMenuButtons[y][x].SetHoverImage("MainMenu_Buttons.bmp", x + 4 * y);
				this.MainMenuButtons[y][x].SetPressImage("MainMenu_Buttons.bmp", x + 4 * y);
				this.MainMenuButtons[y][x].SetPos(this.ActorPos.add(this.FirstButtonSetPos.add(this.MainMenuButtonScale.mul(new float4((x), (y))))));
			}
		}

		this.ScheduleButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.ScheduleButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.ScheduleButton.SetScale(this.ScheduleButtonScale);
		this.ScheduleButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.ScheduleButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.ScheduleButton.SetReleaseImage("SelectButton_Release.bmp");
		this.ScheduleButton.SetHoverImage("MainMenu_Schedule.bmp");
		this.ScheduleButton.SetPressImage("MainMenu_Schedule.bmp");
		this.ScheduleButton.SetPos(this.ActorPos.add(this.ScheduleButtonPos));
	}

	SetClickButton() {
		this.MainMenuButtons[0][0].SetClickCallBack(MainMenu.ClickMainMenu_00);
		this.MainMenuButtons[0][1].SetClickCallBack(MainMenu.ClickMainMenu_01);
		this.MainMenuButtons[0][2].SetClickCallBack(MainMenu.ClickMainMenu_02);
		this.MainMenuButtons[0][3].SetClickCallBack(MainMenu.ClickMainMenu_03);

		this.ScheduleButton.SetClickCallBack(MainMenu.ClickMainMenu_S);
	}

	static ClickMainMenu_00(_Btn) {
		MainMenu.AcStatusWindowManager.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_01(_Btn) {
		MainMenu.AcConverstionSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_02(_Btn) {
		MainMenu.AcDietSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_03(_Btn) {
		MainMenu.AcInformationWindowManager.On();
		MainMenu.AcMainMenu.Off();
	}

	static ClickMainMenu_S(_Btn) {
		MainMenu.AcScheduleCalendar.On();
		MainMenu.AcScheduleSelectionMenu.On();
		MainMenu.AcMainMenu.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcMainMenu', 'ClickMainMenu_00', 'ClickMainMenu_01', 'ClickMainMenu_02', 'ClickMainMenu_03', 'ClickMainMenu_S']) {
	Object.defineProperty(MainMenu.prototype, __m, { value: function (...args) { return MainMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/MainMenu.js"] = {"MainMenu": MainMenu};
})();
(function () {

// ===== GameEngineContents/ScheduleAnimationPlayer.js =====
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// ScheduleAnimationPlayer.h / ScheduleAnimationPlayer.cpp 의 전사

// enum class AnimationState
const AnimationState = Object.freeze({
	Null: -1,
	Dance: 0,
	Fencing: 1,
	Fighting: 2,
	Magic: 3,
	Painting: 4,
	Poetry: 5,
	Protocol: 6,
	Science: 7,
	Strategy: 8,
	Theology: 9,
});

class ScheduleAnimationPlayer extends MenuFrame {
	constructor() {
		super();
		this.ActorPos = new float4(240, 380);
		this.BoxScale = new float4(420, 180);
		this.StateValue = AnimationState.Null;
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;
	}

	Start() {
		// 원본: RaisingSimLevel* Level = dynamic_cast<RaisingSimLevel*>(GetLevel());
		const Level = this.GetLevel();
		this.SetPos(this.ActorPos);
		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Nomal);
		this.SetMenuFrameScale(this.BoxScale);

		this.AcDanceClass = Level.AcDanceClass;
		this.AcFencingClass = Level.AcFencingClass;
		this.AcFightingClass = Level.AcFightingClass;
		this.AcMagicClass = Level.AcMagicClass;
		this.AcPaintingClass = Level.AcPaintingClass;
		this.AcPoetryClass = Level.AcPoetryClass;
		this.AcProtocolClass = Level.AcProtocolClass;
		this.AcScienceClass = Level.AcScienceClass;
		this.AcStrategyClass = Level.AcStrategyClass;
		this.AcTheologyClass = Level.AcTheologyClass;

		this.Off();
	}

	Update(_DeltaTime) {

	}
}

__PM2_EXPORTS__["GameEngineContents/ScheduleAnimationPlayer.js"] = {"AnimationState": AnimationState, "ScheduleAnimationPlayer": ScheduleAnimationPlayer};
})();
(function () {

// ===== GameEngineContents/ScheduleMessageBox.js =====
var MenuFrame = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrame"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
// ScheduleMessageBox.h / ScheduleMessageBox.cpp 의 전사

class ScheduleMessageBox extends MenuFrame {
	constructor() {
		super();
		this.Scale = new float4(310, 180);
		this.ActorPos = new float4(619, 380);
		this.TextRender = null;
		this.TextHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(290, 160);
		this.TextRenderPos = new float4(-145, -80);
		this.StartStatus = new Olive.Status();
		this.EndStatus = new Olive.Status();
		this.Schedule = " ";
		this.DayCount = 0;
	}

	SetScheduleString(_ScheduleLabel) {
		switch (_ScheduleLabel) {
			case ScheduleLabel.Null:
				break;
			case ScheduleLabel["자연과학"]:
				this.Schedule = "자연과학";
				break;
			case ScheduleLabel["신학"]:
				this.Schedule = "신학";
				break;
			case ScheduleLabel["군사학"]:
				this.Schedule = "군사학";
				break;
			case ScheduleLabel["검술"]:
				this.Schedule = "검술";
				break;
			case ScheduleLabel["격투술"]:
				this.Schedule = "격투술";
				break;
			case ScheduleLabel["마법"]:
				this.Schedule = "마법";
				break;
			case ScheduleLabel["시문학"]:
				this.Schedule = "시문학";
				break;
			case ScheduleLabel["예법"]:
				this.Schedule = "예법";
				break;
			case ScheduleLabel["무용"]:
				this.Schedule = "무용";
				break;
			case ScheduleLabel["미술"]:
				this.Schedule = "미술";
				break;
			case ScheduleLabel["집안일"]:
				this.Schedule = "집안일";
				break;
			case ScheduleLabel["보모"]:
				this.Schedule = "보모";
				break;
			case ScheduleLabel["여관"]:
				this.Schedule = "여관";
				break;
			case ScheduleLabel["농장"]:
				this.Schedule = "농장";
				break;
			case ScheduleLabel["교회"]:
				this.Schedule = "교회";
				break;
			case ScheduleLabel["요리점"]:
				this.Schedule = "요리점";
				break;
			case ScheduleLabel["나무꾼"]:
				this.Schedule = "나무꾼";
				break;
			case ScheduleLabel["미용실"]:
				this.Schedule = "미용실";
				break;
			case ScheduleLabel["미장이"]:
				this.Schedule = "미장이";
				break;
			case ScheduleLabel["사냥꾼"]:
				this.Schedule = "사냥꾼";
				break;
			case ScheduleLabel["묘지기"]:
				this.Schedule = "묘지기";
				break;
			case ScheduleLabel["가정교사"]:
				this.Schedule = "가정교사";
				break;
			case ScheduleLabel["주점"]:
				this.Schedule = "주점";
				break;
			case ScheduleLabel["어둠의주점"]:
				this.Schedule = "어둠의주점";
				break;
			case ScheduleLabel["어둠의전당"]:
				this.Schedule = "어둠의전당";
				break;
			default:
				break;
		}
	}

	SetDayCount(_DayCount) {
		this.DayCount = _DayCount;
	}

	SetStartStatus(_StartStatus) {
		this.StartStatus = _StartStatus;
	}

	SetEndStatus(_EndStatus) {
		this.EndStatus = _EndStatus;
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu1);
		// 원본: SetMenuFrameScale({ Scale }); — float4 복사 생성
		this.SetMenuFrameScale(this.Scale.copy());
		this.SetPos(this.ActorPos);
		this.TextRender = this.CreateRender(PM2RenderOrder.Menu1_Display);
		this.TextRender.SetPosition(this.TextRenderPos);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);

		this.Off();
	}

	Update(_DeltaTime) {
		this.UpdateTextRender();
	}

	UpdateTextRender() {
		this.TextRender.SetText(this.Schedule + " " + String(this.DayCount) + "일째\n 서서히 성과가 나오고 있습니다.", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}

	UpdateScheduleEndText() {
		this.TextRender.SetText("스케줄이 끝났다", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/ScheduleMessageBox.js"] = {"ScheduleMessageBox": ScheduleMessageBox};
})();
(function () {

// ===== GameEngineContents/SchedulePlayerGuage.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var StatusWindow = __PM2_EXPORTS__["GameEngineContents/StatusWindow.js"]["StatusWindow"];
var GaugeFrameStyle = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeFrameStyle"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
// SchedulePlayerGuage.h / SchedulePlayerGuage.cpp 의 전사

// 원본: const float* (OliveStatus 멤버 주소) 대응 — JS 에는 멤버 주소가 없으므로
// {상태 객체, 필드 키} 짝으로 동일한 의미를 유지한다. 역참조(*ptr) → Status[Key], 주소 비교 → Key 비교.
function StatusPtr(Status, Key) {
	return { Status: Status, Key: Key };
}

class SchedulePlayerGuage extends GameEngineActor {
	constructor() {
		super();
		// construtor destructor
		this.CountStatus = 6;
		this.AcGauge11 = null;
		this.AcGauge12 = null;
		this.AcGauge13 = null;
		this.AcGauge21 = null;
		this.AcGauge22 = null;
		this.AcGauge23 = null;
		this.Render1 = null;
		this.Render11 = null;
		this.Render12 = null;
		this.Render3 = null;
		this.Render33 = null;
		this.Render34 = null;
		this.Render5 = null;
		this.Render55 = null;
		this.Render56 = null;
		this.Status1 = null;
		this.Status2 = null;
		this.Status3 = null;
		this.Status4 = null;
		this.Status5 = null;
		this.Status6 = null;
	}

	On() {
		super.On();
		switch (this.CountStatus) {
			case 0:
				this.Off();
				break;
			case 1:
				this.AcGauge11.On();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.Off();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 2:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 3:
				this.AcGauge11.Off();
				this.AcGauge12.On();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 4:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 5:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.On();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 6:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.On();
				break;
			default:
				break;
		}
	}

	Off() {
		super.Off();
		this.AcGauge11.Off();
		this.AcGauge12.Off();
		this.AcGauge13.Off();
		this.AcGauge21.Off();
		this.AcGauge22.Off();
		this.AcGauge23.Off();
	}

	Start() {
		this.SetAcGauge();
		this.Off();
	}

	Update(_DeltaTime) {
		if (null !== this.Status1) {
			this.Render1.UpdateValue(this.Status1.Status[this.Status1.Key]);
			this.Render11.UpdateValue(this.Status1.Status[this.Status1.Key]);
		}

		if (null !== this.Status2) {
			this.Render12.UpdateValue(this.Status2.Status[this.Status2.Key]);
		}

		if (null !== this.Status3) {
			this.Render3.UpdateValue(this.Status3.Status[this.Status3.Key]);
			this.Render33.UpdateValue(this.Status3.Status[this.Status3.Key]);
		}

		if (null !== this.Status4) {
			this.Render34.UpdateValue(this.Status4.Status[this.Status4.Key]);
		}

		if (null !== this.Status5) {
			this.Render5.UpdateValue(this.Status5.Status[this.Status5.Key]);
			this.Render55.UpdateValue(this.Status5.Status[this.Status5.Key]);
		}

		if (null !== this.Status6) {
			this.Render56.UpdateValue(this.Status6.Status[this.Status6.Key]);
		}

	}

	SetAcGauge() {
		this.AcGauge11 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge11.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render1 = this.AcGauge11.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge11.SetPos(new float4(160, 495));

		this.AcGauge12 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge12.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render3 = this.AcGauge12.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge12.SetPos(new float4(400, 495));

		this.AcGauge13 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge13.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render5 = this.AcGauge13.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge13.SetPos(new float4(640, 495));

		this.AcGauge21 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge21.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render11 = this.AcGauge21.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render12 = this.AcGauge21.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge21.SetPos(new float4(160, 505));

		this.AcGauge22 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge22.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render33 = this.AcGauge22.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render34 = this.AcGauge22.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge22.SetPos(new float4(400, 505));

		this.AcGauge23 = this.GetLevel().CreateActor(StatusWindow, PM2ActorOrder.Menu1);
		this.AcGauge23.InitMenuFrameRender(PM2RenderOrder.Menu1);
		this.Render55 = this.AcGauge23.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.Render56 = this.AcGauge23.InsertStatus(" ", 999, GaugeFrameStyle.Nomal);
		this.AcGauge23.SetPos(new float4(640, 505));
	}

	SetActorCount(_Count) {
		this.CountStatus = _Count;

		switch (this.CountStatus) {
			case 0:
				this.Off();
				break;
			case 1:
				this.AcGauge11.On();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.Off();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 2:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 3:
				this.AcGauge11.Off();
				this.AcGauge12.On();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.Off();
				this.AcGauge23.Off();
				break;
			case 4:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 5:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.On();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.Off();
				break;
			case 6:
				this.AcGauge11.Off();
				this.AcGauge12.Off();
				this.AcGauge13.Off();
				this.AcGauge21.On();
				this.AcGauge22.On();
				this.AcGauge23.On();
				break;
			default:
				break;
		}
	}

	SetGaugeRender(_Count, _Name1 = " ", _OliveStatusPtr1 = null, _Name2 = " ", _OliveStatusPtr2 = null, _Name3 = " ", _OliveStatusPtr3 = null, _Name4 = " ", _OliveStatusPtr4 = null, _Name5 = " ", _OliveStatusPtr5 = null, _Name6 = " ", _OliveStatusPtr6 = null) {
		this.SetActorCount(_Count);
		if (1 === _Count) {
			if (null === _OliveStatusPtr1) {
				MsgAssert("그럴수없습니다");
			}
			this.Render1.SetNameRender(_Name1);
			this.Render1.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
		}
		else if (2 === _Count) {
			if (null === _OliveStatusPtr2) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr2;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
		}
		else if (3 === _Count) {
			if (null === _OliveStatusPtr3) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render3.SetNameRender(_Name3);
			this.Render3.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
		}
		else if (4 === _Count) {
			if (null === _OliveStatusPtr4) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
		}
		else if (5 === _Count) {
			if (null === _OliveStatusPtr5) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
			this.Render5.SetNameRender(_Name5);
			this.Render5.SetMax(this.FindMax(_OliveStatusPtr5));
			this.Status5 = _OliveStatusPtr5;
		}
		else if (6 === _Count) {
			if (null === _OliveStatusPtr6) {
				MsgAssert("그럴수없습니다");
			}
			this.Render11.SetNameRender(_Name1);
			this.Render11.SetMax(this.FindMax(_OliveStatusPtr1));
			this.Status1 = _OliveStatusPtr1;
			this.Render12.SetNameRender(_Name2);
			this.Render12.SetMax(this.FindMax(_OliveStatusPtr2));
			this.Status2 = _OliveStatusPtr2;
			this.Render33.SetNameRender(_Name3);
			this.Render33.SetMax(this.FindMax(_OliveStatusPtr3));
			this.Status3 = _OliveStatusPtr3;
			this.Render34.SetNameRender(_Name4);
			this.Render34.SetMax(this.FindMax(_OliveStatusPtr4));
			this.Status4 = _OliveStatusPtr4;
			this.Render55.SetNameRender(_Name5);
			this.Render55.SetMax(this.FindMax(_OliveStatusPtr5));
			this.Status5 = _OliveStatusPtr5;
			this.Render56.SetNameRender(_Name6);
			this.Render56.SetMax(this.FindMax(_OliveStatusPtr6));
			this.Status6 = _OliveStatusPtr6;
		}
	}

	FindMax(_OliveStatusPtr) {
		// 원본: &(Olive::OlivePlayer->OliveStatus.Constitution) == _OliveStatusPtr — 멤버 주소 비교를 키 비교로 대응
		if (_OliveStatusPtr.Key === "Constitution") {
			return Olive.OlivePlayer.OliveStatus.MaxConstitution;
		}
		else if (_OliveStatusPtr.Key === "Strength") {
			return Olive.OlivePlayer.OliveStatus.MaxStrength;
		}
		else if (_OliveStatusPtr.Key === "Intelligence") {
			return Olive.OlivePlayer.OliveStatus.MaxIntelligence;
		}
		else if (_OliveStatusPtr.Key === "Refinement") {
			return Olive.OlivePlayer.OliveStatus.MaxRefinement;
		}
		else if (_OliveStatusPtr.Key === "Charisma") {
			return Olive.OlivePlayer.OliveStatus.MaxCharisma;
		}
		else if (_OliveStatusPtr.Key === "Morality") {
			return Olive.OlivePlayer.OliveStatus.MaxMorality;
		}
		else if (_OliveStatusPtr.Key === "Faith") {
			return Olive.OlivePlayer.OliveStatus.MaxFaith;
		}
		else if (_OliveStatusPtr.Key === "Sin") {
			return Olive.OlivePlayer.OliveStatus.MaxSin;
		}
		else if (_OliveStatusPtr.Key === "Sensitivity") {
			return Olive.OlivePlayer.OliveStatus.MaxSensitivity;
		}
		else if (_OliveStatusPtr.Key === "Stress") {
			return Olive.OlivePlayer.OliveStatus.MaxStress;
		}
		else if (_OliveStatusPtr.Key === "CombatSkill") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatSkill;
		}
		else if (_OliveStatusPtr.Key === "CombatAttack") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatAttack;
		}
		else if (_OliveStatusPtr.Key === "CombatDefense") {
			return Olive.OlivePlayer.OliveStatus.MaxCombatDefense;
		}
		else if (_OliveStatusPtr.Key === "MagicSkill") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicSkill;
		}
		else if (_OliveStatusPtr.Key === "MagicAttack") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicAttack;
		}
		else if (_OliveStatusPtr.Key === "MagicDefense") {
			return Olive.OlivePlayer.OliveStatus.MaxMagicDefense;
		}
		else if (_OliveStatusPtr.Key === "Decorum") {
			return Olive.OlivePlayer.OliveStatus.MaxDecorum;
		}
		else if (_OliveStatusPtr.Key === "Art") {
			return Olive.OlivePlayer.OliveStatus.MaxArt;
		}
		else if (_OliveStatusPtr.Key === "Conversation") {
			return Olive.OlivePlayer.OliveStatus.MaxConversation;
		}
		else if (_OliveStatusPtr.Key === "Cooking") {
			return Olive.OlivePlayer.OliveStatus.MaxCooking;
		}
		else if (_OliveStatusPtr.Key === "Cleaning") {
			return Olive.OlivePlayer.OliveStatus.MaxCleaning;
		}
		else if (_OliveStatusPtr.Key === "Temperament") {
			return Olive.OlivePlayer.OliveStatus.MaxTemperament;
		}

	}

	InitGauge() {
		this.Render1 = null;
		this.Render11 = null;
		this.Render12 = null;
		this.Render3 = null;
		this.Render33 = null;
		this.Render34 = null;
		this.Render5 = null;
		this.Render55 = null;
		this.Render56 = null;

		this.Status1 = null;
		this.Status2 = null;
		this.Status3 = null;
		this.Status4 = null;
		this.Status5 = null;
		this.Status6 = null;
	}

	SetSchedule(_Schedule) {
		switch (_Schedule) {
			case ScheduleLabel.Null:
				break;
			case ScheduleLabel["자연과학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "신앙심", StatusPtr(Olive.OlivePlayer.OliveStatus, "Faith"), "항마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["신학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "신앙심", StatusPtr(Olive.OlivePlayer.OliveStatus, "Faith"), "항마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["군사학"]:
				this.SetGaugeRender(4, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["검술"]:
				this.SetGaugeRender(3, "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "공격력", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatAttack"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["격투술"]:
				this.SetGaugeRender(3, "전투기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatSkill"), "방어력", StatusPtr(Olive.OlivePlayer.OliveStatus, "CombatDefense"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["마법"]:
				this.SetGaugeRender(3, "마법기술", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicSkill"), "마력", StatusPtr(Olive.OlivePlayer.OliveStatus, "MagicAttack"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["시문학"]:
				this.SetGaugeRender(5, "지능", StatusPtr(Olive.OlivePlayer.OliveStatus, "Intelligence"), "기품", StatusPtr(Olive.OlivePlayer.OliveStatus, "Refinement"), "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["예법"]:
				this.SetGaugeRender(3, "기품", StatusPtr(Olive.OlivePlayer.OliveStatus, "Refinement"), "예의범절", StatusPtr(Olive.OlivePlayer.OliveStatus, "Decorum"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["무용"]:
				this.SetGaugeRender(4, "체력", StatusPtr(Olive.OlivePlayer.OliveStatus, "Constitution"), "색기", StatusPtr(Olive.OlivePlayer.OliveStatus, "Charisma"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			case ScheduleLabel["미술"]:
				this.SetGaugeRender(3, "감수성", StatusPtr(Olive.OlivePlayer.OliveStatus, "Sensitivity"), "예술", StatusPtr(Olive.OlivePlayer.OliveStatus, "Art"), "스트레스", StatusPtr(Olive.OlivePlayer.OliveStatus, "Stress"));
				break;
			default:
				break;
		}
	}
}

__PM2_EXPORTS__["GameEngineContents/SchedulePlayerGuage.js"] = {"SchedulePlayerGuage": SchedulePlayerGuage};
})();
(function () {

// ===== GameEngineContents/SchedulePlayer.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var ScheduleAnimationPlayer = __PM2_EXPORTS__["GameEngineContents/ScheduleAnimationPlayer.js"]["ScheduleAnimationPlayer"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var FoodCostDialog = __PM2_EXPORTS__["GameEngineContents/FoodCostDialog.js"]["FoodCostDialog"];
var ScheduleDialog = __PM2_EXPORTS__["GameEngineContents/ScheduleDialog.js"]["ScheduleDialog"];
var ScheduleSituation = __PM2_EXPORTS__["GameEngineContents/ScheduleDialog.js"]["ScheduleSituation"];
var MainMenu;
__PM2_LATE__.push(function () { MainMenu = __PM2_EXPORTS__["GameEngineContents/MainMenu.js"]["MainMenu"]; });
var SchedulePlayerGuage = __PM2_EXPORTS__["GameEngineContents/SchedulePlayerGuage.js"]["SchedulePlayerGuage"];
var ScheduleMessageBox = __PM2_EXPORTS__["GameEngineContents/ScheduleMessageBox.js"]["ScheduleMessageBox"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var Season = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Season"];
var Diet = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["Diet"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
// SchedulePlayer.h / SchedulePlayer.cpp 의 전사

// 원본: struct ScheduleSave
class ScheduleSave {
	constructor(_Order = 0, _Date = new Date(), _Schedule = ScheduleLabel.Null) {
		this.Order = _Order;
		this.DateSave = _Date;
		this.Schedule = _Schedule;
	}
}

class SchedulePlayer extends GameEngineActor {
	static AcSchedulePlayer = null;
	static IsPartOfScheduleEnd = false;

	constructor() {
		super();		this.IsPartOfScheduleEnd = false; // 원본 SchedulePlayer.h: bool IsPartOfScheduleEnd = 선언

		// construtor destructor
		SchedulePlayer.AcSchedulePlayer = this;
		this.Time = 1;
		this.Save = [];
		this.FirstUpdateCheck = false;
		this.ParentLevel = null;
		this.AcScheduleAnimationPlayer = null;
		this.AcScheduleCalendar = null;
		this.AcSchedulePlayerGuage = null;
		this.AcScheduleMessageBox = null;
		this.AcDanceClass = null;
		this.AcFencingClass = null;
		this.AcFightingClass = null;
		this.AcMagicClass = null;
		this.AcPaintingClass = null;
		this.AcPoetryClass = null;
		this.AcProtocolClass = null;
		this.AcScienceClass = null;
		this.AcStrategyClass = null;
		this.AcTheologyClass = null;
		this.AcFoodCostDialog = null;
		this.AcScheduleDialog = null;
		this.FirstScheduleUpdateCheck = false;
		this.DayCount = 0;
		this.BGMPlayer = null;
	}

	static GetAcSchedulePlayer() {
		return SchedulePlayer.AcSchedulePlayer;
	}

	GetSave() {
		return this.Save;
	}

	Off() {
		super.Off();
		this.AcScheduleAnimationPlayer.Off();
		this.AcFoodCostDialog.Off();
		this.AcPaintingClass.Off();
	}

	Start() {
		// 원본: ParentLevel = dynamic_cast<RaisingSimLevel*>(GetLevel());
		this.ParentLevel = this.GetLevel();
		this.AcScheduleAnimationPlayer = this.ParentLevel.CreateActor(ScheduleAnimationPlayer, PM2ActorOrder.Menu2);
		this.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();

		this.AcDanceClass = this.ParentLevel.AcDanceClass;
		this.AcFencingClass = this.ParentLevel.AcFencingClass;
		this.AcFightingClass = this.ParentLevel.AcFightingClass;
		this.AcMagicClass = this.ParentLevel.AcMagicClass;
		this.AcPaintingClass = this.ParentLevel.AcPaintingClass;
		this.AcPoetryClass = this.ParentLevel.AcPoetryClass;
		this.AcProtocolClass = this.ParentLevel.AcProtocolClass;
		this.AcScienceClass = this.ParentLevel.AcScienceClass;
		this.AcStrategyClass = this.ParentLevel.AcStrategyClass;
		this.AcTheologyClass = this.ParentLevel.AcTheologyClass;

		this.AcFoodCostDialog = this.ParentLevel.CreateActor(FoodCostDialog, PM2ActorOrder.Menu2);
		this.AcScheduleDialog = this.ParentLevel.GetAcScheduleDialog();
		this.AcSchedulePlayerGuage = this.ParentLevel.CreateActor(SchedulePlayerGuage, PM2ActorOrder.Menu2);
		this.AcScheduleMessageBox = this.ParentLevel.CreateActor(ScheduleMessageBox, PM2ActorOrder.Menu2);

		this.BGMPlayer = this.ParentLevel.GetBGMPlayer();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!this.FirstUpdateCheck) {
			this.FirstUpdateCheck = true;
			this.PayDiet();
			this.AcFoodCostDialog.On();
			this.BGMPlayer.Stop();
			// 원본: *BGMPlayer = GameEngineResources::GetInst().SoundPlayToControl("13_Training.mp3");
			// (GetBGMPlayer() 가 &BGMPlayer 반환 — 참조 대상인 RaisingSimLevel.BGMPlayer 에 대입)
			this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("13_Training.mp3");
			this.BGMPlayer = this.ParentLevel.BGMPlayer;
		}
		else if (!this.AcFoodCostDialog.IsUpdate()) {
			if (!this.FirstScheduleUpdateCheck) {
				SchedulePlayer.IsPartOfScheduleEnd = false;
				this.FirstScheduleUpdateCheck = true;
				this.AcScheduleDialog.UpdateScheduleDialog(this.Save[0].Schedule, ScheduleSituation.ScheduleStart);
			}
			else if (!this.AcScheduleDialog.IsUpdate()) {
				// 원본: ScheduleSave Prev = *(Save.begin()); — 값 복사이나 JS 참조로 동등(팝된 객체 수명 유지)
				const Prev = this.Save[0];

				this.Time += _DeltaTime;
				if (this.Time >= 1) {
					SchedulePlayer.IsPartOfScheduleEnd = false;
					this.Time = 0;
					this.AnimationPlay();
					this.PlayOneDaySchedule();
					this.Save.shift();
				}

				if (this.Save.length === 0) {
					SchedulePlayer.IsPartOfScheduleEnd = true;
					this.AnimationOff();
					this.AcScheduleDialog.UpdateScheduleDialog(Prev.Schedule, ScheduleSituation.ScheduleEnd);
					this.FirstUpdateCheck = false;
					this.FirstScheduleUpdateCheck = false;
					MainMenu.GetAcMainMenu().On();
					this.AcScheduleCalendar.Reset();
					this.Off();
					this.BGMPlayer.Stop();
					switch (this.ParentLevel.GetTodaySeason()) {
						case Season.Spring:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("04_Main_screen_(Spring).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Summer:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("05_Main_screen_(Summer).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Fall:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("06_Main_screen_(Autumn).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						case Season.Winter:
							this.ParentLevel.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("07_Main_screen_(Winter).mp3");
							this.BGMPlayer = this.ParentLevel.BGMPlayer;
							break;
						default:
							break;
					}
					return;
				}

				const Next = this.Save[0];

				if (Prev.Order !== Next.Order) {
					SchedulePlayer.IsPartOfScheduleEnd = true;
					this.AnimationOff();
					this.AcScheduleDialog.UpdateScheduleDialog(Prev.Schedule, ScheduleSituation.ScheduleEnd);
				}

				if (!this.AcScheduleDialog.IsUpdate() && SchedulePlayer.IsPartOfScheduleEnd) {
					this.FirstScheduleUpdateCheck = false;
				}
			}
		}
	}

	PlayOneDaySchedule() {
		this.AcScheduleAnimationPlayer.On();
		this.AcSchedulePlayerGuage.On();
		this.AcScheduleMessageBox.On();
		this.AcScheduleMessageBox.SetDayCount(++this.DayCount);
		this.AcScheduleMessageBox.SetScheduleString(this.Save[0].Schedule);
		this.AcSchedulePlayerGuage.SetSchedule(this.Save[0].Schedule);
		switch (this.Save[0].Schedule) {
			case ScheduleLabel["무용"]:
				this.AcDanceClass.On();
				// 원본: Olive::OlivePlayer->OliveStatus += AcDanceClass->GetStatusVariance();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcDanceClass.GetStatusVariance());
				// 원본: Olive::OlivePlayer->GetGold() += AcDanceClass->GetPayGold(); (int& 반환 — 참조 대상 Gold 에 대입)
				Olive.OlivePlayer.Gold += this.AcDanceClass.GetPayGold();
				break;
			case ScheduleLabel["검술"]:
				this.AcFencingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcFencingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcFencingClass.GetPayGold();
				break;
			case ScheduleLabel["격투술"]:
				this.AcFightingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcFightingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcFightingClass.GetPayGold();
				break;
			case ScheduleLabel["마법"]:
				this.AcMagicClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcMagicClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcMagicClass.GetPayGold();
				break;
			case ScheduleLabel["미술"]:
				this.AcPaintingClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcPaintingClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcPaintingClass.GetPayGold();
				break;
			case ScheduleLabel["시문학"]:
				this.AcPoetryClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcPoetryClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcPoetryClass.GetPayGold();
				break;
			case ScheduleLabel["예법"]:
				this.AcProtocolClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcProtocolClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcProtocolClass.GetPayGold();
				break;
			case ScheduleLabel["자연과학"]:
				this.AcScienceClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcScienceClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcScienceClass.GetPayGold();
				break;
			case ScheduleLabel["군사학"]:
				this.AcStrategyClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcStrategyClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcStrategyClass.GetPayGold();
				break;
			case ScheduleLabel["신학"]:
				this.AcTheologyClass.On();
				Olive.OlivePlayer.OliveStatus.AddAssign(this.AcTheologyClass.GetStatusVariance());
				Olive.OlivePlayer.Gold += this.AcTheologyClass.GetPayGold();
				break;
			default:
				break;
		}

		this.ParentLevel.GoToNextDay();
	}

	AnimationOff() {
		this.DayCount = 0;
		this.AcScheduleMessageBox.Off();
		this.AcScheduleAnimationPlayer.Off();
		this.AcDanceClass.Off();
		this.AcFencingClass.Off();
		this.AcFightingClass.Off();
		this.AcMagicClass.Off();
		this.AcPaintingClass.Off();
		this.AcPoetryClass.Off();
		this.AcProtocolClass.Off();
		this.AcScienceClass.Off();
		this.AcStrategyClass.Off();
		this.AcTheologyClass.Off();

		this.AcSchedulePlayerGuage.Off();
	}

	AnimationPlay() {
		this.AcDanceClass.PlayObj();
		this.AcFencingClass.PlayObj();
		this.AcFightingClass.PlayObj();
		this.AcMagicClass.PlayObj();
		this.AcPaintingClass.PlayObj();
		this.AcPoetryClass.PlayObj();
		this.AcProtocolClass.PlayObj();
		this.AcScienceClass.PlayObj();
		this.AcStrategyClass.PlayObj();
		this.AcTheologyClass.PlayObj();
	}

	AnimationStop() {
		this.AcDanceClass.StopObj();
		this.AcFencingClass.StopObj();
		this.AcFightingClass.StopObj();
		this.AcMagicClass.StopObj();
		this.AcPaintingClass.StopObj();
		this.AcPoetryClass.StopObj();
		this.AcProtocolClass.StopObj();
		this.AcScienceClass.StopObj();
		this.AcStrategyClass.StopObj();
		this.AcTheologyClass.StopObj();
	}

	PayDiet() {
		const Value = Olive.OlivePlayer.GetOliveDiet();
		switch (Value) {
			case Diet.Null:
				break;
			case Diet["무리하지_않는다"]:
				// 원본: GetGold() -= 30; (int& 반환 — 참조 대상 Gold 에 대입)
				Olive.OlivePlayer.Gold -= 30;
				break;
			case Diet["어쨌든_튼튼하게"]:
				Olive.OlivePlayer.Gold -= 80;
				break;
			case Diet["얌전한_아이로"]:
				Olive.OlivePlayer.Gold -= 10;
				break;
			case Diet["다이어트_시킨다"]:
				Olive.OlivePlayer.Gold -= 5;
				break;
		default:
				break;
		}
		
	}
}

__PM2_EXPORTS__["GameEngineContents/SchedulePlayer.js"] = {"ScheduleSave": ScheduleSave, "SchedulePlayer": SchedulePlayer};
})();
(function () {

// ===== GameEngineContents/ScheduleCalendar.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var OnedaySchedule = __PM2_EXPORTS__["GameEngineContents/OnedaySchedule.js"]["OnedaySchedule"];
var SchedulePlayer;
__PM2_LATE__.push(function () { SchedulePlayer = __PM2_EXPORTS__["GameEngineContents/SchedulePlayer.js"]["SchedulePlayer"]; });
var ScheduleSave;
__PM2_LATE__.push(function () { ScheduleSave = __PM2_EXPORTS__["GameEngineContents/SchedulePlayer.js"]["ScheduleSave"]; });
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
// ScheduleCalendar.h / ScheduleCalendar.cpp 의 전사

class ScheduleCalendar extends GameEngineActor {
	static AcScheduleCalendar = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleCalendar.AcScheduleCalendar = this;
		this.FirstScheduleSet = false;
		this.SecondScheduleSet = false;
		this.ThirdScheduleSet = false;
		this.ScheduleSetEnd = false;
		this.ActorPos = new float4(160, 263);
		this.Today = new Date(1000, 10, 10);
		this.NextDate = new Date(1000, 10, 11);
		this.FirstScheduleEndDate = new Date();
		this.SecondScheduleEndDate = new Date();
		this.ThirdScheduleEndDate = new Date();
		this.ThisMonthSchedule = [];
		this.CalendarFrame = null;
		this.FirstScheduleActorPos = new float4(40, 183);
		this.ScheduleActorInterval = new float4(40, 40);
		this.YearNumRender = new NumberRenderObject();
		this.YearNumRenderScale = new float4(10, 20);
		this.YearNumRenderPos = new float4(-25, -130);
		this.MonthRender = null;
		this.MonthRenderScale = new float4(60, 20);
		this.MonthRenderPos = new float4(30, -130);
		// 원본: GameEngineRender* IconRender[6][7] = {};
		this.IconRender = Array.from({ length: 6 }, () => Array.from({ length: 7 }, () => null));
		this.IconScale = new float4(34, 34);
		this.FirstIconPos = new float4(-120, -80);
	}

	static GetAcScheduleCalendar() {
		return ScheduleCalendar.AcScheduleCalendar;
	}

	On() {
		super.On();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].On();
			}
		}

	}

	Off() {
		super.Off();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].Off();
			}
		}
	}

	ScheduleSetting(_Schedule) {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		const StartDate = this.NextDate;
		const LastDate = Date.GetMonthLastDate(this.NextDate);
		if (!this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.FirstScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate)) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(1);
						this.FirstScheduleEndDate = this.ThisMonthSchedule[y][x].DateValue;
						if (this.ThisMonthSchedule[y][x].DateValue.Equals(LastDate)) {
							this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
							this.ThisMonthSchedule[y][x].SetScheduleOrder(1);
							Save.push(new ScheduleSave(1, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
							this.FirstScheduleEndDate = LastDate;
							this.ScheduleSetEnd = true;
							return;
						}
						Save.push(new ScheduleSave(1, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
					}
				}
			}
		}
		else if (this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.SecondScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(10)) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(2);
						this.SecondScheduleEndDate = this.ThisMonthSchedule[y][x].DateValue;
						if (this.ThisMonthSchedule[y][x].DateValue.Equals(LastDate)) {
							this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
							this.ThisMonthSchedule[y][x].SetScheduleOrder(2);
							Save.push(new ScheduleSave(2, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
							this.SecondScheduleEndDate = LastDate;
							this.ScheduleSetEnd = true;
							return;
						}
						Save.push(new ScheduleSave(2, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.ThirdScheduleSet = true;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(20)) && this.ThisMonthSchedule[y][x].DateValue.LessEquals(LastDate)) {
						this.ThisMonthSchedule[y][x].ScheduleValue = _Schedule;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(3);
						Save.push(new ScheduleSave(3, this.ThisMonthSchedule[y][x].DateValue, _Schedule));
						this.ThirdScheduleEndDate = LastDate;
					}
					this.ScheduleSetEnd = true;
				}
			}
		}
		else {
			MsgAssert("순서 제대로 셋팅 안해줬습니다");
		}

	}

	CancelSchedule() {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		const StartDate = this.NextDate;
		const LastDate = Date.GetMonthLastDate(this.NextDate);
		if (this.FirstScheduleSet && !this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.FirstScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate)) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && !this.ThirdScheduleSet) {
			this.SecondScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(10))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(10)) && this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
		else if (this.FirstScheduleSet && this.SecondScheduleSet && this.ThirdScheduleSet) {
			this.ThirdScheduleSet = false;
			for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
				for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
					if (this.ThisMonthSchedule[y][x].DateValue.Less(StartDate.add(20))) {
						continue;
					}
					else if (this.ThisMonthSchedule[y][x].DateValue.GreaterEquals(StartDate.add(20)) && this.ThisMonthSchedule[y][x].DateValue.LessEquals(LastDate)) {
						this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
						this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
						Save.pop();
						this.ScheduleSetEnd = false;
					}
				}
			}
		}
	}

	Reset() {
		const Save = SchedulePlayer.GetAcSchedulePlayer().GetSave();
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x].ScheduleValue = ScheduleLabel.Null;
				this.ThisMonthSchedule[y][x].SetScheduleOrder(0);
			}
		}
		this.FirstScheduleSet = false;
		this.SecondScheduleSet = false;
		this.ThirdScheduleSet = false;
		this.ScheduleSetEnd = false;

		Save.length = 0;
	}

	GetThisMonthSchedule() {
		return this.ThisMonthSchedule;
	}

	GetFirstScheduleEndDate() {
		return this.FirstScheduleEndDate;
	}

	GetSecondScheduleEndDate() {
		return this.SecondScheduleEndDate;
	}

	GetThirdScheduleEndDate() {
		return this.ThirdScheduleEndDate;
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.CalendarFrame = this.CreateRender("Calendar.bmp", PM2RenderOrder.Menu1);
		this.CalendarFrame.SetScaleToImage();
		this.SetThisMonthSchedule();
		this.SetYearNumRender();
		this.SetMonthRender();
		this.Off();
	}

	Update(_DeltaTime) {
		if (this.Today.NotEquals(this.GetLevel().GetToday())) {
			this.Today = this.GetLevel().GetToday();
			this.NextDate = this.Today.GetNextDate();
			this.UpdateMonthCalendar();
			this.UpdateYearNumRender();
			this.UpdateMonthRender();

		}
	}

	SetThisMonthSchedule() {
		// 원본: ThisMonthSchedule.resize(6);
		for (let y = 0; y < 6; y++) {
			this.ThisMonthSchedule.push([]);
		}
		// 원본: ThisMonthSchedule[y].resize(7); (nullptr 채움)
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < 7; x++) {
				this.ThisMonthSchedule[y].push(null);
			}
		}

		const Level = this.GetLevel();

		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				this.ThisMonthSchedule[y][x] = Level.CreateActor(OnedaySchedule, PM2ActorOrder.Menu1);
				this.ThisMonthSchedule[y][x].SetPos(this.FirstScheduleActorPos.add(this.ScheduleActorInterval.mul(new float4(x, y))));
			}
		}
	}

	UpdateMonthCalendar() {
		const OneMonthCalendar = Date.GetOneMonthCalendar(this.NextDate.GetYear(), this.NextDate.GetMonth());

		const MonthFirstWeekday = Date.FindMonthFirstWeekday(this.NextDate.GetYear(), this.NextDate.GetMonth());
		let DayIndex = 0;
		for (let y = 0; y < this.ThisMonthSchedule.length; y++) {
			for (let x = 0; x < this.ThisMonthSchedule[y].length; x++) {
				if (x + (y * 7) < MonthFirstWeekday) {
					this.ThisMonthSchedule[y][x].DateValue.SetNullDate();
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
				else if (x + (y * 7) < MonthFirstWeekday + OneMonthCalendar.length) {
					this.ThisMonthSchedule[y][x].DateValue.SetDate(OneMonthCalendar[DayIndex++]);
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
				else {
					this.ThisMonthSchedule[y][x].DateValue.SetNullDate();
					this.ThisMonthSchedule[y][x].UpdateDayNumRender();
				}
			}
		}
	}

	UpdateDayNumRender() {

	}

	SetYearNumRender() {
		this.YearNumRender.SetOwner(this);
		this.YearNumRender.SetImage("Num.bmp", this.YearNumRenderScale, PM2RenderOrder.Menu1_Display, RGB(255, 0, 255));
		this.YearNumRender.SetAlign(Align.Right);
		this.YearNumRender.SetRenderPos(this.YearNumRenderPos);
	}

	SetMonthRender() {
		this.MonthRender = this.CreateRender("Num_Month.bmp", PM2RenderOrder.Menu1_Display);
		this.MonthRender.SetScale(this.MonthRenderScale);
		this.MonthRender.SetPosition(this.MonthRenderPos);
	}

	UpdateYearNumRender() {
		this.YearNumRender.SetValue(this.NextDate.GetYear());
	}

	UpdateMonthRender() {
		this.MonthRender.SetFrame(this.NextDate.GetMonth() - 1);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetAcScheduleCalendar']) {
	Object.defineProperty(ScheduleCalendar.prototype, __m, { value: function (...args) { return ScheduleCalendar[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"] = {"ScheduleCalendar": ScheduleCalendar};
})();
(function () {

// ===== GameEngineContents/ScheduleFinalConfirm.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var RaisingSimLevel;
__PM2_LATE__.push(function () { RaisingSimLevel = __PM2_EXPORTS__["GameEngineContents/RaisingSimLevel.js"]["RaisingSimLevel"]; });
var ScheduleSelectionMenu;
__PM2_LATE__.push(function () { ScheduleSelectionMenu = __PM2_EXPORTS__["GameEngineContents/ScheduleSelectionMenu.js"]["ScheduleSelectionMenu"]; });
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var SchedulePlayer;
__PM2_LATE__.push(function () { SchedulePlayer = __PM2_EXPORTS__["GameEngineContents/SchedulePlayer.js"]["SchedulePlayer"]; });
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
// ScheduleFinalConfirm.h / ScheduleFinalConfirm.cpp 의 전사

class ScheduleFinalConfirm extends SelectionMenu {
	static AcScheduleFinalConfirm = null;

	// 원본: static CubeDialog* AcCubeDialog;
	static AcCubeDialog = null;
	static AcScheduleSelectionMenu = null;
	static AcScheduleCalendar = null;
	static AcSchedulePlayer = null;

	constructor() {
		super();
		// construtor destructor
		ScheduleFinalConfirm.AcScheduleFinalConfirm = this;
		this.ActorPos = new float4(670, 321);
		this.Xscale = 140;
	}

	Start() {
		ScheduleFinalConfirm.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		ScheduleFinalConfirm.AcScheduleSelectionMenu = ScheduleSelectionMenu.GetAcScheduleSelectionMenu();
		ScheduleFinalConfirm.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		ScheduleFinalConfirm.AcSchedulePlayer = this.GetLevel().CreateActor(SchedulePlayer, PM2ActorOrder.Menu2);

		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "스케줄을 실행");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "취소");
		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		ScheduleFinalConfirm.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "이번달은 이 스케줄로\n좋습니까?");

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			ScheduleFinalConfirm.AcScheduleSelectionMenu.On();
			ScheduleFinalConfirm.AcScheduleCalendar.Reset();
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(ScheduleFinalConfirm.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(ScheduleFinalConfirm.Click1);
	}

	static Click0(_Button) {
		ScheduleFinalConfirm.AcSchedulePlayer.On();
		ScheduleFinalConfirm.AcScheduleFinalConfirm.Off();
		ScheduleFinalConfirm.AcScheduleCalendar.Off();
		ScheduleFinalConfirm.AcCubeDialog.Off();
	}

	static Click1(_Button) {
		ScheduleFinalConfirm.AcScheduleFinalConfirm.Off();
		ScheduleFinalConfirm.AcScheduleSelectionMenu.On();
		ScheduleFinalConfirm.AcScheduleCalendar.Reset();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(ScheduleFinalConfirm.prototype, __m, { value: function (...args) { return ScheduleFinalConfirm[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/ScheduleFinalConfirm.js"] = {"ScheduleFinalConfirm": ScheduleFinalConfirm};
})();
(function () {

// ===== GameEngineContents/SchedulingConfirmSelectionMenu.js =====
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var RaisingSimLevel;
__PM2_LATE__.push(function () { RaisingSimLevel = __PM2_EXPORTS__["GameEngineContents/RaisingSimLevel.js"]["RaisingSimLevel"]; });
var ScheduleSelectionMenu;
__PM2_LATE__.push(function () { ScheduleSelectionMenu = __PM2_EXPORTS__["GameEngineContents/ScheduleSelectionMenu.js"]["ScheduleSelectionMenu"]; });
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var ScheduleFinalConfirm;
__PM2_LATE__.push(function () { ScheduleFinalConfirm = __PM2_EXPORTS__["GameEngineContents/ScheduleFinalConfirm.js"]["ScheduleFinalConfirm"]; });
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
// SchedulingConfirmSelectionMenu.h / SchedulingConfirmSelectionMenu.cpp 의 전사

class SchedulingConfirmSelectionMenu extends SelectionMenu {
	static AcCubeDialog = null;
	static ScheduleState = ScheduleLabel.Null;
	static AcScheduleSelectionMenu = null;
	static AcSchedulingConfirmSelectionMenu = null;
	static AcScheduleCalendars = null;
	static AcScheduleFinalConfirm = null;

	constructor() {
		super();
		// construtor destructor
		SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu = this;
		this.ActorPos = new float4(695, 371);
		this.Xscale = 190;
	}

	SetScheduleState(_State) {
		SchedulingConfirmSelectionMenu.ScheduleState = _State;
	}

	Start() {
		SchedulingConfirmSelectionMenu.AcCubeDialog = RaisingSimLevel.GetAcCubeDialog();
		SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu = ScheduleSelectionMenu.GetAcScheduleSelectionMenu();
		SchedulingConfirmSelectionMenu.AcScheduleCalendars = ScheduleCalendar.GetAcScheduleCalendar();
		SchedulingConfirmSelectionMenu.AcScheduleFinalConfirm = this.GetLevel().CreateActor(ScheduleFinalConfirm, PM2ActorOrder.Menu2);
		this.InitMenuFrameRender(PM2RenderOrder.Menu2, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(2, this.ActorPos, this.Xscale, PM2ActorOrder.Menu2_Button, PM2RenderOrder.Menu2_Button);
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 0, "스케줄에 편성한다");
		this.SetButtonString(PM2RenderOrder.Menu2_Display, 1, "취소");

		this.SetButtonClick();
		this.Off();
	}

	Update(_DeltaTime) {
		switch (SchedulingConfirmSelectionMenu.ScheduleState) {
			case ScheduleLabel["자연과학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "자연과학.\n미신을 부정하고, 과학적, 합리\n적인 안목을 키운다");
				break;
			case ScheduleLabel["신학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "신학.\n신앙을 기초로 과학관의 수양.\n학문의 왕도");
				break;
			case ScheduleLabel["군사학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "군사학.\n전투의 기술을 학문으로서 배운\n다");
				break;
			case ScheduleLabel["검술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "검술.\n도장을 통해서 검술을 배운다");
				break;
			case ScheduleLabel["격투술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "격투술.\n무기를 의존하지 않고, 격투술\n을 중심으로 하는 전투법을 배\n운다");
				break;
			case ScheduleLabel["마법"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "마법.\n마법의 기초부터, 강력한 주문\n까지 습득");
				break;
			case ScheduleLabel["시문학"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "시문학.\n시를 낭독하거나 창작. 시문을\n배우는 것은, 교양인의 지식의\n상징");
				break;
			case ScheduleLabel["예법"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "예법.\n숙녀의 교양부터, 오랜 세월에\n걸쳐 내려온 궁중 예법까지 전수");
				break;
			case ScheduleLabel["무용"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "무용.\n본격적인 궁중 무용을 전수");
				break;
			case ScheduleLabel["미술"]:
				SchedulingConfirmSelectionMenu.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "미술.\n그림을 그려 예술적인 센스를\n갈고 닦는다");
				break;
			default:
				break;
		}

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
		}
	}

	SetButtonClick() {
		this.GetSelectButtons()[0].SetClickCallBack(SchedulingConfirmSelectionMenu.Click0);
		this.GetSelectButtons()[1].SetClickCallBack(SchedulingConfirmSelectionMenu.Click1);
	}

	static Click0(_Button) {
		SchedulingConfirmSelectionMenu.AcScheduleCalendars.ScheduleSetting(SchedulingConfirmSelectionMenu.ScheduleState);
		if (!SchedulingConfirmSelectionMenu.AcScheduleCalendars.ScheduleSetEnd) {
			SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
			SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
		}
		else {
			SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
			SchedulingConfirmSelectionMenu.AcScheduleFinalConfirm.On();
		}
	}

	static Click1(_Button) {
		SchedulingConfirmSelectionMenu.AcSchedulingConfirmSelectionMenu.Off();
		SchedulingConfirmSelectionMenu.AcScheduleSelectionMenu.On();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['Click0', 'Click1']) {
	Object.defineProperty(SchedulingConfirmSelectionMenu.prototype, __m, { value: function (...args) { return SchedulingConfirmSelectionMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/SchedulingConfirmSelectionMenu.js"] = {"SchedulingConfirmSelectionMenu": SchedulingConfirmSelectionMenu};
})();
(function () {

// ===== GameEngineContents/ClassSelectWindow.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var IconCode = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["IconCode"];
var ScheduleLabel = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["ScheduleLabel"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var IconButton = __PM2_EXPORTS__["GameEngineContents/IconButton.js"]["IconButton"];
var CubeFace = __PM2_EXPORTS__["GameEngineContents/CubeDialog.js"]["CubeFace"];
var ScheduleCalendar;
__PM2_LATE__.push(function () { ScheduleCalendar = __PM2_EXPORTS__["GameEngineContents/ScheduleCalendar.js"]["ScheduleCalendar"]; });
var SchedulingConfirmSelectionMenu;
__PM2_LATE__.push(function () { SchedulingConfirmSelectionMenu = __PM2_EXPORTS__["GameEngineContents/SchedulingConfirmSelectionMenu.js"]["SchedulingConfirmSelectionMenu"]; });
var ScheduleSelectionMenu;
__PM2_LATE__.push(function () { ScheduleSelectionMenu = __PM2_EXPORTS__["GameEngineContents/ScheduleSelectionMenu.js"]["ScheduleSelectionMenu"]; });
// ClassSelectWindow.h / ClassSelectWindow.cpp 의 전사

class ClassSelectWindow extends GameEngineActor {
	static ParentLevel = null;
	static AcScheduleCalendar = null;
	static AcSchedulingConfirmSelectionMenu = null;
	static AcClassSelectWindow = null;

	static AcPaintingClass = null;
	static AcDanceClass = null;
	static AcMagicClass = null;
	static AcProtocolClass = null;
	static AcFencingClass = null;
	static AcFightingClass = null;
	static AcTheologyClass = null;
	static AcStrategyClass = null;
	static AcScienceClass = null;
	static AcPoetryClass = null;

	constructor() {
		super();
		this.AcCubeDialog = null;
		this.Painting = null;
		this.Button1Pos = new float4(540, 400);

		this.Dance = null;
		this.Button2Pos = new float4(710, 400);

		this.Magic = null;
		this.Button3Pos = new float4(540, 340);

		this.Protocol = null;
		this.Button4Pos = new float4(710, 340);

		this.Fencing = null;
		this.Button5Pos = new float4(540, 280);

		this.Fighting = null;
		this.Button6Pos = new float4(710, 280);

		this.Theology = null;
		this.Button7Pos = new float4(540, 220);

		this.Strategy = null;
		this.Button8Pos = new float4(710, 220);

		this.Science = null;
		this.Button9Pos = new float4(540, 160);

		this.Poetry = null;
		this.Button10Pos = new float4(710, 160);

		ClassSelectWindow.AcClassSelectWindow = this;
	}

	GetPaintingButton() {
		return this.Painting.GetButton();
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		this.Painting.On();
		this.Dance.On();
		this.Magic.On();
		this.Protocol.On();
		this.Fencing.On();
		this.Fighting.On();
		this.Theology.On();
		this.Strategy.On();
		this.Science.On();
		this.Poetry.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		this.Painting.Off();
		this.Dance.Off();
		this.Magic.Off();
		this.Protocol.Off();
		this.Fencing.Off();
		this.Fighting.Off();
		this.Theology.Off();
		this.Strategy.Off();
		this.Science.Off();
		this.Poetry.Off();
	}

	Start() {
		// 원본: dynamic_cast<RaisingSimLevel*>(GetLevel())
		ClassSelectWindow.ParentLevel = this.GetLevel();
		this.AcCubeDialog = ClassSelectWindow.ParentLevel.GetAcCubeDialog();
		ClassSelectWindow.AcScheduleCalendar = ScheduleCalendar.GetAcScheduleCalendar();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu = ClassSelectWindow.ParentLevel.CreateActor(SchedulingConfirmSelectionMenu, PM2ActorOrder.Menu2);

		this.Painting = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Dance = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Magic = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Protocol = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Fencing = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Fighting = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Theology = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Strategy = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Science = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);
		this.Poetry = ClassSelectWindow.ParentLevel.CreateActor(IconButton, PM2ActorOrder.Menu2_Button);

		this.Painting.SetIconButton(IconCode["미술"], "미술", "초급", 40, this.Button1Pos);
		this.Dance.SetIconButton(IconCode["무용"], "무도", "초급", 50, this.Button2Pos);
		this.Magic.SetIconButton(IconCode["마법"], "마법", "초급", 60, this.Button3Pos);
		this.Protocol.SetIconButton(IconCode["예법"], "예법", "초급", 40, this.Button4Pos);
		this.Fencing.SetIconButton(IconCode["검술"], "검술", "초급", 40, this.Button5Pos);
		this.Fighting.SetIconButton(IconCode["격투술"], "격투술", "초급", 30, this.Button6Pos);
		this.Theology.SetIconButton(IconCode["신학"], "신학", "초급", 40, this.Button7Pos);
		this.Strategy.SetIconButton(IconCode["군사학"], "군사학\t", "초급", 50, this.Button8Pos);
		this.Science.SetIconButton(IconCode["자연과학"], "자연과학", "초급", 30, this.Button9Pos);
		this.Poetry.SetIconButton(IconCode["시문학"], "시문", "초급", 40, this.Button10Pos);

		ClassSelectWindow.AcDanceClass = ClassSelectWindow.ParentLevel.AcDanceClass;
		ClassSelectWindow.AcFencingClass = ClassSelectWindow.ParentLevel.AcFencingClass;
		ClassSelectWindow.AcFightingClass = ClassSelectWindow.ParentLevel.AcFightingClass;
		ClassSelectWindow.AcMagicClass = ClassSelectWindow.ParentLevel.AcMagicClass;
		ClassSelectWindow.AcPaintingClass = ClassSelectWindow.ParentLevel.AcPaintingClass;
		ClassSelectWindow.AcPoetryClass = ClassSelectWindow.ParentLevel.AcPoetryClass;
		ClassSelectWindow.AcProtocolClass = ClassSelectWindow.ParentLevel.AcProtocolClass;
		ClassSelectWindow.AcScienceClass = ClassSelectWindow.ParentLevel.AcScienceClass;
		ClassSelectWindow.AcStrategyClass = ClassSelectWindow.ParentLevel.AcStrategyClass;
		ClassSelectWindow.AcTheologyClass = ClassSelectWindow.ParentLevel.AcTheologyClass;

		this.SetButtonClick();

		this.Off();
	}

	Update(_DeltaTime) {
		this.AcCubeDialog.UpdateCubeDialog(CubeFace.Nomal, "딸에게 무엇을 가르치시겠습니\n까?");

		if (GameEngineInput.IsUp("EngineMouseRight")) {
			this.Off();
			ScheduleSelectionMenu.GetAcScheduleSelectionMenu().On();
		}
	}

	SetButtonClick() {
		this.Painting.GetButton().SetClickCallBack(ClassSelectWindow.ClickPainting);
		this.Dance.GetButton().SetClickCallBack(ClassSelectWindow.ClickDance);
		this.Magic.GetButton().SetClickCallBack(ClassSelectWindow.ClickMagic);
		this.Protocol.GetButton().SetClickCallBack(ClassSelectWindow.ClickProtocol);
		this.Fencing.GetButton().SetClickCallBack(ClassSelectWindow.ClickFencing);
		this.Fighting.GetButton().SetClickCallBack(ClassSelectWindow.ClickFighting);
		this.Theology.GetButton().SetClickCallBack(ClassSelectWindow.ClickTheology);
		this.Strategy.GetButton().SetClickCallBack(ClassSelectWindow.ClickStrategy);
		this.Science.GetButton().SetClickCallBack(ClassSelectWindow.ClickScience);
		this.Poetry.GetButton().SetClickCallBack(ClassSelectWindow.ClickPoetry);
	}

	static ClickPainting(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["미술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickDance(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["무용"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickMagic(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["마법"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickProtocol(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["예법"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickFencing(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["검술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickFighting(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["격투술"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickTheology(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["신학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickStrategy(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["군사학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickScience(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["자연과학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}

	static ClickPoetry(_Button) {
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.On();
		ClassSelectWindow.AcSchedulingConfirmSelectionMenu.SetScheduleState(ScheduleLabel["시문학"]);
		ClassSelectWindow.AcClassSelectWindow.Off();
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['ClickPainting', 'ClickDance', 'ClickMagic', 'ClickProtocol', 'ClickFencing', 'ClickFighting', 'ClickTheology', 'ClickStrategy', 'ClickScience', 'ClickPoetry']) {
	Object.defineProperty(ClassSelectWindow.prototype, __m, { value: function (...args) { return ClassSelectWindow[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/ClassSelectWindow.js"] = {"ClassSelectWindow": ClassSelectWindow};
})();
(function () {

// ===== GameEngineContents/Cutscene.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// Cutscene.h / Cutscene.cpp 의 전사

// enum class BackgroundColor
const BackgroundColor = Object.freeze({
	Black: 0,
	White: 1
});

class Cutscene extends GameEngineActor {
	constructor() {
		super();
		this.CutScenes = [];  // std::vector<GameEngineRender*>
		this.Background = []; // std::vector<GameEngineRender*>
	}

	OnCutScene(_index) {
		for (let i = 0; i < this.CutScenes.length; i++) {
			if (i === _index) {
				this.CutScenes[i].On();
			}
			else {
				this.CutScenes[i].Off();
			}
		}
	}

	OffCutScene() {
		for (let i = 0; i < this.CutScenes.length; i++) {
			this.CutScenes[i].Off();
		}
	}

	SelectBackgroundColor(_Color) {
		if (_Color === BackgroundColor.Black) {
			this.Background[0].On();
			this.Background[1].Off();
		}
		else {
			this.Background[0].Off();
			this.Background[1].On();
		}
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		// 원본: CutScenes.resize(7);
		this.CutScenes = new Array(7).fill(null);
		this.CutScenes[0] = this.CreateRender("CutScene1.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[1] = this.CreateRender("CutScene2.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[2] = this.CreateRender("CutScene3.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[3] = this.CreateRender("CutScene4.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[4] = this.CreateRender("CutScene5.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[5] = this.CreateRender("CutScene6.BMP", PM2RenderOrder.BackGroundObj);
		this.CutScenes[6] = this.CreateRender("CutScene7.BMP", PM2RenderOrder.BackGroundObj);

		// 원본: Background.resize(2);
		this.Background = new Array(2).fill(null);
		this.Background[0] = this.CreateRender("BlackBackground.bmp", PM2RenderOrder.BackGround);
		this.Background[1] = this.CreateRender("WhiteBackground.bmp", PM2RenderOrder.BackGround);

		for (const i of this.CutScenes) {
			i.SetScaleToImage();
		}

		for (const i of this.Background) {
			i.SetScaleToImage();
		}

		this.Off();
	}

	Update(_DeltaTime) {
	}

	Render(_time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/Cutscene.js"] = {"BackgroundColor": BackgroundColor, "Cutscene": Cutscene};
})();
(function () {

// ===== GameEngineContents/EndingDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
// EndingDialog.h / EndingDialog.cpp 의 전사

class EndingDialog extends Dialog {
	constructor() {
		super();
		this.ActorPos = new float4(400, 400);
	}

	UpdateText(_Script) {
		this.SetUpdateText(_Script);
		this.On();
	}

	Start() {
		// 원본: Dialog::Start();
		Dialog.prototype.Start.call(this);
		this.SetDialogScale(new float4(390, 150));
		this.SetPos(this.ActorPos);
	}
}

__PM2_EXPORTS__["GameEngineContents/EndingDialog.js"] = {"EndingDialog": EndingDialog};
})();
(function () {

// ===== GameEngineContents/EndingPortrait.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var Ending;
__PM2_LATE__.push(function () { Ending = __PM2_EXPORTS__["GameEngineContents/EndingLevel.js"]["Ending"]; });
var EndingDialog = __PM2_EXPORTS__["GameEngineContents/EndingDialog.js"]["EndingDialog"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// EndingPortrait.h / EndingPortrait.cpp 의 전사

class EndingPortrait extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.Background = null;
		// 원본: Ending* OliveEnding = nullptr; — EndingLevel::OliveEnding 멤버를 가리키는 포인터.
		// JS에는 값(열거형)에 대한 참조가 없으므로 현재값을 읽는 클로저로 전사했다.
		// (원본 *OliveEnding 역참조 → this.OliveEnding() 호출, Update 참고)
		this.OliveEnding = null;
		this.Potrait = null;
		this.AcEndingDialog = null;
		this.AcOlive = null;
	}

	On() {
		// 원본: GameEngineObject::On();
		GameEngineObject.prototype.On.call(this);
		this.AcEndingDialog.On();
	}

	Off() {
		// 원본: GameEngineObject::Off();
		GameEngineObject.prototype.Off.call(this);
		this.AcEndingDialog.Off();
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.Background = this.CreateRender("EndingPortrait.bmp", PM2RenderOrder.BackGround);
		this.Background.SetScaleToImage();
		// 원본: OliveEnding = dynamic_cast<EndingLevel*>(GetLevel())->GetOliveEnding();
		this.OliveEnding = () => this.GetLevel().GetOliveEnding();
		this.Potrait = this.CreateRender(PM2RenderOrder.BackGroundObj);
		this.AcEndingDialog = this.GetLevel().CreateActor(EndingDialog, PM2ActorOrder.Dialog1);
		this.Off();
	}

	Update(_DeltaTime) {
		switch (this.OliveEnding())
		{
			case Ending.Null:
				break;
			case Ending["마왕"]:
				this.Potrait.SetImage("PrincessOfDarkness.bmp");
				this.AcEndingDialog.UpdateText("다음날, " + Olive.OlivePlayer.GetOliveFirstName() + "는 홀연히 모습을 감추고,\n 두번 다시 집에 돌아오지 않았다고 한다……\n올리브의 소식은 아직도 아무도 모른다.\n단, 떠돌이 검사가 용암지대의 동굴에서,\n 마왕의 축제를 잠시 보았는데, 그 마왕은 \n젊은 여자의 모습이었다고 한다……\n");
				break;
			case Ending["SM여왕"]:
				this.Potrait.SetImage("BondageQueen.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 비밀 클럽에서 쇼를 하게 되었다…\n 아- 아…");
				break;
			case Ending["암흑가의보스"]:
				this.Potrait.SetImage("CrimeBoss.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 집에서 가져온 돈으로 무시무시한 옷을 입고, 암흑가의 불략배를 두드리는 나날을 보내게 되었다…\n 아- 아…");
				break;
			case Ending["폭력배"]:
				this.Potrait.SetImage("Bandit.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 뒷골목의 암흑가에 있으면서, 불량배들의 친구가 되었다…\n 아- 아…");
				break;
			case Ending["고급창부"]:
				this.Potrait.SetImage("RefineHarlot.bmp");
				this.AcEndingDialog.UpdateText("호기심에 들렀던 뒷골목의 거리에 발을 딛게 된 " + Olive.OlivePlayer.GetOliveFirstName() + "…\n 그것이" + Olive.OlivePlayer.GetOliveFirstName() + "의 운명의 길이었다……");
				break;
			case Ending["사기꾼"]:
				this.Potrait.SetImage("ConArtist.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 사기꾼의 길을 걷게 되었다…\n 아- 아…");
				break;
			case Ending["창부"]:
				this.Potrait.SetImage("Harlot.bmp");
				this.AcEndingDialog.UpdateText("호기심에 들렀던 뒷골목의 거리에 발을 딛게 된 " + Olive.OlivePlayer.GetOliveFirstName() + "…\n 그것이" + Olive.OlivePlayer.GetOliveFirstName() + "의 운명의 길이었다……");
				break;
			case Ending["여왕"]:
				this.Potrait.SetImage("Queen.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 국왕으로부터 왕위를 \n계승받아, 왕국의 새로운 여왕이 되었다.");
				break;
			case Ending["재상"]:
				this.Potrait.SetImage("PrimeMinister.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 재상이 되기\n위해 왕궁에서 정치 공부를 시작했다…");
				break;
			case Ending["박사"]:
				this.Potrait.SetImage("Scholar.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕립 대학원에서 학문\n을 추구하는 생활을 시작했다…");
				break;
			case Ending["대신"]:
				this.Potrait.SetImage("CabinetMinister.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 대신이 되어, \n성에 들어가 정치 공부를 시작했다…");
				break;
			case Ending["대주교"]:
				this.Potrait.SetImage("ArchBishop.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국의 주교가 되기 위\n하여, 왕궁에서 공부를 시작했다…");
				break;
			case Ending["학사"]:
				this.Potrait.SetImage("Researcher.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕립 대학원의 학사가 되\n어, 학문의 길을 걸었다…");
				break;
			case Ending["재판관"]:
				this.Potrait.SetImage("Judge.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 왕국 최초의 여성 재판관\n이 되었다…");
				break;
			case Ending["수녀"]:
				this.Potrait.SetImage("Nun.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 성당에 들어가, 성직자\n로서의 인생을 시작했다…");
				break;
			case Ending["궁녀"]:
				this.Potrait.SetImage("LadyInWaiting.bmp");
				this.AcEndingDialog.UpdateText("그리하여 " + Olive.OlivePlayer.GetOliveFirstName() + "는 성의 궁녀로서의 인생\n을 시작했다…");
				break;
			default:
				break;
		}

		this.Potrait.SetScaleToImage();
	}
}

__PM2_EXPORTS__["GameEngineContents/EndingPortrait.js"] = {"EndingPortrait": EndingPortrait};
})();
(function () {

// ===== GameEngineContents/FirstScene.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// FirstScene.h / FirstScene.cpp 의 전사

class FirstScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);

		this.BackgroundRedner = null;
		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-400, -50);
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("FirstSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText((" "), this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText("8년 간이 꿈처럼 지나갔다…\n\n" + Olive.OlivePlayer.GetOliveLastName() + "의 딸 " + Olive.OlivePlayer.GetOliveFirstName() + "의 나이도 어느덧 18세, 성인이 된 것이었다.", this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/FirstScene.js"] = {"FirstScene": FirstScene};
})();
(function () {

// ===== GameEngineContents/FourthScene.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// FourthScene.h / FourthScene.cpp 의 전사

class FourthScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);

		this.BackgroundRedner = null;
		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-400, -50);
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("FirstSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();


		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText((" "), this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText("18세… 그것은 부모에게서 떠나, 사회를 향해 떠나는 시기……\n\n" + Olive.OlivePlayer.GetOliveFirstName() + "은 대체 어떤 길을 선택할 것인가……", this.TextHeight, this.TextType, TextAlign.Center, this.TextColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/FourthScene.js"] = {"FourthScene": FourthScene};
})();
(function () {

// ===== GameEngineContents/SecondScene.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// SecondScene.h / SecondScene.cpp 의 전사

class SecondScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.BackgroundRedner = null;

		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-300, -200);

		this.TextRenderShadow = null;
		this.TextShadowColor = RGB(0, 0, 0);
		this.TextShadowRenderPos = new float4(-300, -199);

		this.Script = "아버지.\n\n그동안 저를 애지중지 키워주셔서 고마워요.\n\n저는 아버지의 지도로, 이렇게 훌륭하게 성장했어요.\n\n아버지와 함께한 소녀 시절을 되돌아보면 여러가지가 떠올라요.\n\n모두 함께 공부한것도 즐거운 추억이에요.\n\n좋은 경험을 하게 해줘서 감사하고 있어요.";
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("SecondSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);

		this.TextRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.TextRenderShadow.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
		this.TextRenderShadow.SetPosition(this.TextShadowRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRenderShadow.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/SecondScene.js"] = {"SecondScene": SecondScene};
})();
(function () {

// ===== GameEngineContents/ThirdScene.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// ThirdScene.h / ThirdScene.cpp 의 전사

class ThirdScene extends GameEngineActor {
	constructor() {
		super();
		this.ActorPos = new float4(400, 300);
		this.BackgroundRedner = null;

		this.TextRender = null;
		this.TextHeight = 20;
		this.TextType = "굴림";
		this.TextColor = RGB(255, 255, 255);
		this.TextBoxScale = new float4(800, 200);
		this.TextRenderPos = new float4(-300, -200);

		this.TextRenderShadow = null;
		this.TextShadowColor = RGB(0, 0, 0);
		this.TextShadowRenderPos = new float4(-300, -199);

		this.Script = "아무튼, 저도 어른이 되었어요.\n\n지금까지 무엇을 하든 아버지에게 기대기만 했지만,\n\n오늘부터는 저 자신의 힘으로 살아가겠어요.\n\n지금까지의 경험을 살려서 열심히 할 테니,\n\n따뜻하게 지켜봐 주세요.";
	}

	Start() {
		this.SetPos(this.ActorPos);
		this.BackgroundRedner = this.CreateRender("ThirdSceneBackground.bmp", PM2RenderOrder.BackGround);
		this.BackgroundRedner.SetScaleToImage();

		this.TextRender = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.TextRender.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRender.SetPosition(this.TextRenderPos);

		this.TextRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.TextRenderShadow.SetText(" ", this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
		this.TextRenderShadow.SetPosition(this.TextShadowRenderPos);
		this.Off();
	}

	Update(_DeltaTime) {
		this.TextRender.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextColor, this.TextBoxScale);
		this.TextRenderShadow.SetText(this.Script, this.TextHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.TextBoxScale);
	}
}

__PM2_EXPORTS__["GameEngineContents/ThirdScene.js"] = {"ThirdScene": ThirdScene};
})();
(function () {

// ===== GameEngineContents/EndingLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineSoundPlayer = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineSoundPlayer"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var FirstScene = __PM2_EXPORTS__["GameEngineContents/FirstScene.js"]["FirstScene"];
var SecondScene = __PM2_EXPORTS__["GameEngineContents/SecondScene.js"]["SecondScene"];
var ThirdScene = __PM2_EXPORTS__["GameEngineContents/ThirdScene.js"]["ThirdScene"];
var FourthScene = __PM2_EXPORTS__["GameEngineContents/FourthScene.js"]["FourthScene"];
var EndingPortrait;
__PM2_LATE__.push(function () { EndingPortrait = __PM2_EXPORTS__["GameEngineContents/EndingPortrait.js"]["EndingPortrait"]; });
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
// EndingLevel.h / EndingLevel.cpp 의 전사


// enum class Ending (Null = -1, 이후 선언 순서대로 0부터)
const Ending = Object.freeze({
	"Null": -1,
	"마왕": 0,
	"SM여왕": 1,
	"암흑가의보스": 2,
	"폭력배": 3,
	"고급창부": 4,
	"사기꾼": 5,
	"창부": 6,
	"광대": 7,
	"작가": 8,
	"화가": 9,
	"무용수": 10,
	"여왕": 11,
	"재상": 12,
	"박사": 13,
	"대신": 14,
	"대주교": 15,
	"학사": 16,
	"재판관": 17,
	"수녀": 18,
	"보모": 19,
	"여관직원": 20,
	"농부": 21,
	"교회직원": 22,
	"요리사": 23,
	"나무꾼": 24,
	"미용사": 25,
	"미장이": 26,
	"사냥꾼": 27,
	"묘지기": 28,
	"가정교사": 29,
	"주점직원": 30,
	"어둠의주점원": 31,
	"밤의무희": 32,
	"궁녀": 33,
	"용사": 34,
	"장군": 35,
	"근위대장": 36,
	"기사": 37,
	"무도사범": 38,
	"현상금사냥꾼": 39,
	"병사": 40,
	"용병": 41,
	"마법용사": 42,
	"왕궁마법사": 43,
	"마법사범": 44,
	"마도사": 45,
	"마법사": 46,
	"점술사": 47,
	"마술사": 48,
	"거리의광대": 49,
	"왕비": 50,
	"왕의후궁": 51,
	"백작부인": 52,
	"부호의처": 53,
	"상인의처": 54,
	"농부의처": 55,
	"지주의첩": 56,
	"이혼녀": 57,
	"신부수업": 58
});

class EndingLevel extends GameEngineLevel {
	constructor() {
		super();
		this.Time = 0;
		this.AcOlive = null;

		this.OliveEnding = Ending.Null;

		this.AcFirstScene = null;
		this.AcSecondScene = null;
		this.AcThirdScene = null;
		this.AcFourthScene = null;

		this.AcEndingPortrait = null;
		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	Loading() {
		this.ImageLoad();
		this.SoundLoad();
		this.AcFirstScene = this.CreateActor(FirstScene, PM2ActorOrder.BackGround);
		this.AcSecondScene = this.CreateActor(SecondScene, PM2ActorOrder.BackGround);
		this.AcThirdScene = this.CreateActor(ThirdScene, PM2ActorOrder.BackGround);
		this.AcFourthScene = this.CreateActor(FourthScene, PM2ActorOrder.BackGround);
		this.AcEndingPortrait = this.CreateActor(EndingPortrait, PM2ActorOrder.BackGround);

	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("1"))
		{
			GameEngineCore.GetInst().DebugSwitch();
		}

		let LocalDeltaTime = _DeltaTime;

		if (GameEngineInput.IsPress("2"))
		{
			LocalDeltaTime *= 16;
			this.Time += LocalDeltaTime;
		}
		else
		{
			this.Time += LocalDeltaTime;
		}

		this.Time += _DeltaTime;
		if (this.Time >= 0 && this.Time < 10)
		{
			this.AcFirstScene.On();
		}
		else if (this.Time >= 10 && this.Time < 25)
		{
			this.AcFirstScene.Off();
			this.AcSecondScene.On();
		}
		else if (this.Time >= 25 && this.Time < 40)
		{
			this.AcSecondScene.Off();
			this.AcThirdScene.On();
		}
		else if (this.Time >= 40 && this.Time < 50)
		{
			this.AcThirdScene.Off();
			this.AcFourthScene.On();
		}
		else if (this.Time >= 50)
		{
			this.AcFourthScene.Off();
			this.AcEndingPortrait.On();
		}

		if (GameEngineInput.IsDown("LevelChange"))
		{
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}
	}

	LevelChangeEnd(_NextLevel) {
		this.Time = 0;
		this.AcFirstScene.Off();
		this.AcSecondScene.Off();
		this.AcThirdScene.Off();
		this.AcFourthScene.Off();
		this.AcEndingPortrait.Off();
		this.BGMPlayer.Stop();
		this.AcOlive.SetOliveAge(17);
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("30_Ending.mp3");
		this.AcOlive = Olive.OlivePlayer;
		if (this.AcOlive.OliveStatus.Fighter >= 300 && this.AcOlive.OliveStatus.Magical >= 200 && this.AcOlive.OliveStatus.Sin >= 500)
		{
			this.OliveEnding = Ending["마왕"];
		}
		else if ((this.AcOlive.OliveStatus.Morality === 0 && this.AcOlive.OliveStatus.Sin >= 100) || (this.AcOlive.OliveStatus.Morality < 30 && this.AcOlive.OliveStatus.Sin >= 250))
		{
			if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1 && this.AcOlive.OliveStatus.Refinement >= 200 && this.AcOlive.OliveStatus.Charisma >= 200)
			{
				this.OliveEnding = Ending["SM여왕"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1 && this.AcOlive.OliveStatus.Refinement >= 200 && this.AcOlive.OliveStatus.Charisma < 200)
			{
				this.OliveEnding = Ending["암흑가의보스"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) >= 1)
			{
				this.OliveEnding = Ending["폭력배"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0 && this.AcOlive.OliveStatus.Charisma >= 200 && this.AcOlive.OliveStatus.Conversation >= 70 && this.AcOlive.OliveStatus.Temperament >= 70)
			{
				this.OliveEnding = Ending["고급창부"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0 && this.AcOlive.OliveStatus.Charisma < 200 && this.AcOlive.OliveStatus.Conversation >= 70)
			{
				this.OliveEnding = Ending["사기꾼"];
			}
			else if (this.EstimateGrade(this.AcOlive.OliveStatus.Fighter) === 0)
			{
				this.OliveEnding = Ending["창부"];
			}
		}
		else if (this.EstimateMaxMinusMin() < 50 && this.EstimateGrade(this.EstimateMax()) >= 2)
		{
			if (this.EstimateGrade(this.EstimateMax()) === 4 && this.AcOlive.OliveStatus.Refinement >= 800)
			{
				this.OliveEnding = Ending["여왕"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 4 && this.AcOlive.OliveStatus.Refinement < 800)
			{
				this.OliveEnding = Ending["재상"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["박사"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Morality >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["대신"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 3 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Faith && this.AcOlive.OliveStatus.Morality < this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["대주교"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Intelligence >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["학사"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Morality && this.AcOlive.OliveStatus.Morality >= this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["재판관"];
			}
			else if (this.EstimateGrade(this.EstimateMax()) === 2 && this.AcOlive.OliveStatus.Intelligence < this.AcOlive.OliveStatus.Faith && this.AcOlive.OliveStatus.Morality < this.AcOlive.OliveStatus.Faith)
			{
				this.OliveEnding = Ending["수녀"];
			}
		}
		else
		{
			this.OliveEnding = Ending["궁녀"];
		}

	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("EndingLevel");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FirstSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SecondSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("ThirdSceneBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("EndingPortrait.BMP"));
		Dir.Move("EndingIllustration");
		const AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++)
		{
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("30_Ending.mp3"));
	}

	EstimateGrade(_Estimate) {
		if (60 >= _Estimate)
		{
			return 0;
		}
		else if (60 < _Estimate && 160 >= _Estimate)
		{
			return 1;
		}
		else if (160 < _Estimate && 230 >= _Estimate)
		{
			return 2;
		}
		else if (230 < _Estimate && 270 >= _Estimate)
		{
			return 3;
		}
		else if (270 < _Estimate)
		{
			return 4;
		}
	}

	EstimateMaxMinusMin() {
		return this.EstimateMax() - this.EstimateMin();
	}

	EstimateMax() {
		const Estimate = [];
		// 원본: Estimate.reserve(4);
		Estimate.push(this.AcOlive.OliveStatus.Fighter);
		Estimate.push(this.AcOlive.OliveStatus.Magical);
		Estimate.push(this.AcOlive.OliveStatus.Social);
		Estimate.push(this.AcOlive.OliveStatus.HouseWork);

		let Max = Estimate[0];
		for (const i of Estimate)
		{
			Max = Max > i ? Max : i;
		}
		return Max;
	}

	EstimateMin() {
		const Estimate = [];
		// 원본: Estimate.reserve(4);
		Estimate.push(this.AcOlive.OliveStatus.Fighter);
		Estimate.push(this.AcOlive.OliveStatus.Magical);
		Estimate.push(this.AcOlive.OliveStatus.Social);
		Estimate.push(this.AcOlive.OliveStatus.HouseWork);

		let Min = Estimate[0];
		for (const i of Estimate)
		{
			Min = Min > i ? i : Min;
		}
		return Min;
	}

	GetOliveEnding() {
		return this.OliveEnding;
	}

	GetAcOlive() {
		return this.AcOlive;
	}
}

__PM2_EXPORTS__["GameEngineContents/EndingLevel.js"] = {"Ending": Ending, "EndingLevel": EndingLevel};
})();
(function () {

// ===== GameEngineContents/OliveCalendar.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var Button = __PM2_EXPORTS__["GameEngineCore/Button.js"]["Button"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var GameEngineMath = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["GameEngineMath"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var Button_Date = __PM2_EXPORTS__["GameEngineContents/Button_Date.js"]["Button_Date"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var FirstSetLevel;
__PM2_LATE__.push(function () { FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"]; });
var ActorState;
__PM2_LATE__.push(function () { ActorState = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["ActorState"]; });
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// OliveCalendar.h / OliveCalendar.cpp 의 전사

class OliveCalendar extends GameEngineActor {
	static FirstUpdate = false;

	constructor() {
		super();		this.FirstUpdate = false; // 원본 OliveCalendar.h: bool FirstUpdate = 선언

		this.StartDate = new Date();

		this.EcahMonthCalendarInterval = new float4(250, 105);

		// 원본 고정 크기 배열: Button_Date* DateButton[4][3][6][7] = {};
		this.DateButton = [];
		for (let w = 0; w < 4; w++) {
			this.DateButton.push([]);
			for (let z = 0; z < 3; z++) {
				this.DateButton[w].push([]);
				for (let y = 0; y < 6; y++) {
					this.DateButton[w][z].push([]);
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y].push(null);
					}
				}
			}
		}
		this.DateButtonScale = new float4(20, 14);
		this.FirstDaySetPos = new float4(-330, -177);
		this.EachDayNumInterval = new float4(30, 15);

		// 원본 고정 크기 배열: GameEngineRender* WeekRender[4][3] = {};
		this.WeekRender = [];
		for (let y = 0; y < 4; y++) {
			this.WeekRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.WeekRender[y].push(null);
			}
		}
		this.WeekRenderScale = new float4(210, 10);
		this.FirstWeekSetPos = new float4(-235, -192);

		// 원본 고정 크기 배열: GameEngineRender* YearRender[4][3][4] = {};
		this.YearRender = [];
		for (let z = 0; z < 4; z++) {
			this.YearRender.push([]);
			for (let y = 0; y < 3; y++) {
				this.YearRender[z].push([]);
				for (let x = 0; x < 4; x++) {
					this.YearRender[z][y].push(null);
				}
			}
		}
		this.YearRenderScale = new float4(8, 12);
		this.FirstYearSetPos = new float4(-370, -182);

		// 원본 고정 크기 배열: GameEngineRender* MonthRender[4][3] = {};
		this.MonthRender = [];
		for (let y = 0; y < 4; y++) {
			this.MonthRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.MonthRender[y].push(null);
			}
		}
		this.MonthRenderScale = new float4(20, 16);
		this.FirstMonthSetPos = new float4(-360, -165);

		this.BackgroundRender = null;

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(192, 120, 178);

		this.HoverButtonDateRender_Year = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Year = new float4(-335, -221);
		this.HoverButtonDateRender_Month = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Month = new float4(-305, -221);
		this.HoverButtonDateRender_Day = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Day = new float4(-275, -221);
	}

	SetStartDate(_YYYY, _MM, _DD) {
		this.StartDate.SetDate(_YYYY, _MM, _DD);
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (0 !== this.DateButton[w][z][y][x].GetReleaseIndex()) {
							this.DateButton[w][z][y][x].On();
						}
					}
				}
			}
		}
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y][x].Off();
					}
				}
			}
		}
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.SetStartDate(1200, 1, 1);

		this.HoverButtonDateRender_Year.SetOwner(this);
		this.HoverButtonDateRender_Year.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Year.SetAlign(Align.Right);
		this.HoverButtonDateRender_Year.SetRenderPos(this.Pos_HoverButtonDateRender_Year);

		this.HoverButtonDateRender_Month.SetOwner(this);
		this.HoverButtonDateRender_Month.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Month.SetAlign(Align.Right);
		this.HoverButtonDateRender_Month.SetRenderPos(this.Pos_HoverButtonDateRender_Month);
		this.HoverButtonDateRender_Month.SetNumOfDigits(2);

		this.HoverButtonDateRender_Day.SetOwner(this);
		this.HoverButtonDateRender_Day.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Day.SetAlign(Align.Right);
		this.HoverButtonDateRender_Day.SetRenderPos(this.Pos_HoverButtonDateRender_Day);
		this.HoverButtonDateRender_Day.SetNumOfDigits(2);

		this.BackgroundRender = this.CreateRender("SetOliveBirth.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();
		this.SetExplainRender();
		this.SetDateNumButton();
		this.SetMonthRender();
		this.SetYearRender();
		this.SetWeekdayRender();

		this.Off();
	}

	Update(_DeltaTime) {
		const Index = this.WichButtonNotRelease();
		if (
			0 > Index.x &&
			0 > Index.y &&
			0 > Index.z &&
			0 > Index.w
		) {
			this.HoverButtonDateRender_Year.Off();
			this.HoverButtonDateRender_Month.Off();
			this.HoverButtonDateRender_Day.Off();
		}
		else {
			this.HoverButtonDateRender_Year.On();
			this.HoverButtonDateRender_Month.On();
			this.HoverButtonDateRender_Day.On();

			this.HoverButtonDateRender_Year.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetYear());
			this.HoverButtonDateRender_Month.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetMonth());
			this.HoverButtonDateRender_Day.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetDay());
		}

	}

	Render(_DeltaTime) {

	}

	SetDateNumButton() {
		let FirstMonth = this.StartDate.GetMonth();
		let Month = FirstMonth;
		let Year = this.StartDate.GetYear();
		const MonthLen = new Array(12).fill(0);

		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			MonthLen[i] = Date.GetMonthLenth(Year, Month);
			Month++;
		}

		const FirstWeekday = Date.FindMonthFirstWeekday(this.StartDate.GetYear(), FirstMonth);
		let MonthFirstWeekday = FirstWeekday;
		Month = FirstMonth;
		Year = this.StartDate.GetYear();
		const Level = this.GetLevel();

		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				if (Month === 13) {
					Month = 1;
					Year++;
				}
				let Day = 1;
				const FirstMonth = (z + 1) + (w * 3); // 원본: 외부 FirstMonth를 가리는 지역 변수
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						const fx = (x);
						const fy = (y);
						const fz = (z);
						const fw = (w);
						this.DateButton[w][z][y][x] = Level.CreateActor(Button_Date, PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
						this.DateButton[w][z][y][x].SetScale(this.DateButtonScale);
						this.DateButton[w][z][y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetPos(this.GetPos().add(this.FirstDaySetPos.add(this.EachDayNumInterval.mul(new float4(fx, fy))).add(this.EcahMonthCalendarInterval.mul(new float4(fz, fw)))));
						if (x + (y * 7) < MonthFirstWeekday) {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("OliveCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("OliveCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("OliveCalendarNum.bmp", 0);
						}
						else if (x + (y * 7) < MonthFirstWeekday + MonthLen[FirstMonth - 1]) {
							if (0 === x) {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("OliveCalendarNum.bmp", 32 + Day);
								this.DateButton[w][z][y][x].SetHoverImage("OliveCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("OliveCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(OliveCalendar.SetOliveBirthDay);
							}
							else {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("OliveCalendarNum.bmp", Day);
								this.DateButton[w][z][y][x].SetHoverImage("OliveCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("OliveCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(OliveCalendar.SetOliveBirthDay);
							}
						}
						else {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("OliveCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("OliveCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("OliveCalendarNum.bmp", 0);
						}
					}
				}
				Month++;
				MonthFirstWeekday = (MonthFirstWeekday + MonthLen[FirstMonth - 1]) % 7;
			}
		}
	}

	SetYearRender() {
		let Month = this.StartDate.GetMonth();
		let Year = this.StartDate.GetYear();
		let YearDigits = GameEngineMath.GetDigits(Year); // std::vector<unsigned int>

		for (let z = 0; z < 4; z++) {
			for (let y = 0; y < 3; y++) {

				if (Month === 13) {
					Month = 1;
					Year++;
					YearDigits = GameEngineMath.GetDigits(Year);
				}

				for (let x = 0; x < 4; x++) {
					const fx = (x);
					const fy = (y);
					const fz = (z);
					this.YearRender[z][y][x] = this.CreateRender("OliveYearNum.BMP", PM2RenderOrder.Contents);
					this.YearRender[z][y][x].SetScale(this.YearRenderScale);
					this.YearRender[z][y][x].SetPosition(this.FirstYearSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fy, fz))).add(float4.Right.scale(fx).scale(this.YearRenderScale.x)));
				}


				this.YearRender[z][y][0].SetFrame(YearDigits[0]);
				this.YearRender[z][y][1].SetFrame(YearDigits[1]);
				this.YearRender[z][y][2].SetFrame(YearDigits[2]);
				this.YearRender[z][y][3].SetFrame(YearDigits[3]);

				Month++;
			}
		}
	}

	SetWeekdayRender() {
		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.WeekRender[y][x] = this.CreateRender("OliveWeek.BMP", PM2RenderOrder.Contents);
				this.WeekRender[y][x].SetScale(this.WeekRenderScale);
				this.WeekRender[y][x].SetPosition(this.FirstWeekSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	SetMonthRender() {
		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.MonthRender[y][x] = this.CreateRender("OliveCalendarNum.BMP", PM2RenderOrder.Contents);
				this.MonthRender[y][x].SetFrame(x + 1 + (y * 3));
				this.MonthRender[y][x].SetScale(new float4(20, 16));
				this.MonthRender[y][x].SetPosition(this.FirstMonthSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("딸의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = new float4(this.ExplainTextBoxScale.hx(), 0).neg().sub(new float4(0, 223));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("딸의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("딸의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static SetOliveBirthDay(_Btn) {
		// 원본: dynamic_cast<Button_Date*>(_Btn)
		const Ptr = _Btn;
		Olive.OlivePlayer.SetOliveBirthDay(Ptr.Value);
		FirstSetLevel.SetStateValue(ActorState.SetPlayerAge);
	}

	WichButtonNotRelease() {
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (ButtonState.Release !== this.DateButton[w][z][y][x].GetState()) {
							return new float4((x), (y), (z), (w));
						}
					}
				}
			}
		}
		return new float4(-1, -1, -1, -1);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['SetOliveBirthDay']) {
	Object.defineProperty(OliveCalendar.prototype, __m, { value: function (...args) { return OliveCalendar[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/OliveCalendar.js"] = {"OliveCalendar": OliveCalendar};
})();
(function () {

// ===== GameEngineContents/SetOliveBloodType.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Button_BloodType = __PM2_EXPORTS__["GameEngineContents/Button_BloodType.js"]["Button_BloodType"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// SetOliveBloodType.h / SetOliveBloodType.cpp 의 전사

class SetOliveBloodType extends GameEngineActor {
	static FirstUpdate = false;

	constructor() {
		super();		this.FirstUpdate = false; // 원본 SetOliveBloodType.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;
		// 원본: Button_BloodType* BloodTypeButton[4] = {};
		this.BloodTypeButton = new Array(4).fill(null);
		this.BloodTypeButtonRender1 = new Array(4).fill(null);
		this.BloodTypeButtonRender2 = new Array(4).fill(null);
		this.BloodTypeButtonEffect1Render = new Array(4).fill(null);
		this.BloodTypeButtonEffect2Render = new Array(4).fill(null);
		this.BloodTypeButtonEffect3Render = new Array(4).fill(null);
		this.BloodTypeButtonShadowRender = new Array(4).fill(null);

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.ButtonScale = new float4(24, 24);
		this.ButtonInterval = new float4(64, 0);
		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(192, 120, 178);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i].On();
		}
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i].Off();
		}
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetOliveBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();
		this.SetExplainRender();
		this.SetBloodTypeButton();
		this.SetBloodTypeButtonRender();

		this.Off();
	}

	Update(_DeltaTime) {
		for (let i = 0; i < 4; i++) {
			if (ButtonState.Release === this.BloodTypeButton[i].GetState()) {
				this.BloodTypeButtonEffect1Render[i].Off();
				this.BloodTypeButtonEffect2Render[i].Off();
				this.BloodTypeButtonEffect3Render[i].Off();

				this.BloodTypeButtonRender1[i].On();
				this.BloodTypeButtonRender2[i].On();
				this.BloodTypeButtonShadowRender[i].On();
			}
			else {
				this.BloodTypeButtonEffect1Render[i].On();
				this.BloodTypeButtonEffect2Render[i].On();
				this.BloodTypeButtonEffect3Render[i].On();

				this.BloodTypeButtonRender1[i].Off();
				this.BloodTypeButtonRender2[i].Off();
				this.BloodTypeButtonShadowRender[i].Off();
			}
		}
	}

	Render(_DeltaTime) {
	}

	SetBloodTypeButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(GameEngineWindow.GetScreenSize().x + float4.Left.x * 3 * (this.ButtonScale.hx() + this.ButtonInterval.hx()), 360);

		let Start = 0;

		for (let i = 0; i < 4; i++) {
			this.BloodTypeButton[i] = Level.CreateActor(Button_BloodType, PM2ActorOrder.Menu0_Button);
			this.BloodTypeButton[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.BloodTypeButton[i].SetScale(this.ButtonScale);
			this.BloodTypeButton[i].SetRenderOrder(PM2RenderOrder.Menu0_Button);
			this.BloodTypeButton[i].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
			this.BloodTypeButton[i].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(i, 0))));
			this.BloodTypeButton[i].SetReleaseImage("SelectButton_Release.Bmp");
			this.BloodTypeButton[i].SetHoverImage("SelectButton_Release.Bmp");
			this.BloodTypeButton[i].SetPressImage("SelectButton_Release.Bmp");
			// 원본: BloodTypeValue = static_cast<BloodType>(Start++);
			this.BloodTypeButton[i].BloodTypeValue = Start++;
			this.BloodTypeButton[i].SetClickCallBack(SetOliveBloodType.ClickBloodType);
		}
	}

	SetBloodTypeButtonRender() {
		this.BloodTypeButtonRender1[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		let LetterRenderPos = this.BloodTypeButton[0].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[0].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[0].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[0].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[0].Off();

		this.BloodTypeButtonEffect2Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[0].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[0].Off();

		this.BloodTypeButtonEffect3Render[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[0].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[0].Off();

		this.BloodTypeButtonShadowRender[0] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[0].SetText("A", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[0].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[1].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[1].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[1].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[1].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[1].Off();

		this.BloodTypeButtonEffect2Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[1].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[1].Off();

		this.BloodTypeButtonEffect3Render[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[1].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[1].Off();

		this.BloodTypeButtonShadowRender[1] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[1].SetText("B", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[1].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[2].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[2].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[2].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[2].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[2].Off();

		this.BloodTypeButtonEffect2Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[2].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[2].Off();

		this.BloodTypeButtonEffect3Render[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[2].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[2].Off();

		this.BloodTypeButtonShadowRender[2] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[2].SetText("O", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[2].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

		this.BloodTypeButtonRender1[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender1[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		LetterRenderPos = this.BloodTypeButton[3].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
		this.BloodTypeButtonRender1[3].SetPosition(LetterRenderPos);

		this.BloodTypeButtonRender2[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonRender2[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
		this.BloodTypeButtonRender2[3].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.BloodTypeButtonEffect1Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.BloodTypeButtonEffect1Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
		this.BloodTypeButtonEffect1Render[3].SetPosition(LetterRenderPos);
		this.BloodTypeButtonEffect1Render[3].Off();

		this.BloodTypeButtonEffect2Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect2Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
		this.BloodTypeButtonEffect2Render[3].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect2Render[3].Off();

		this.BloodTypeButtonEffect3Render[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.BloodTypeButtonEffect3Render[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
		this.BloodTypeButtonEffect3Render[3].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		this.BloodTypeButtonEffect3Render[3].Off();

		this.BloodTypeButtonShadowRender[3] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.BloodTypeButtonShadowRender[3].SetText("AB", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
		this.BloodTypeButtonShadowRender[3].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = this.ExplainTextBoxScale.half().neg().sub(new float4(0, 36));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("딸의 혈액형 선택", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static ClickBloodType(_Button) {
		const Ptr = _Button; // 원본: dynamic_cast<Button_BloodType*>
		Olive.OlivePlayer.SetBloodType(Ptr.BloodTypeValue);
		Olive.OlivePlayer.UpdateZodiac();
		Olive.OlivePlayer.SetFirstStatus();
		Olive.OlivePlayer.SetFirstPhysicalCondition();
		GameEngineCore.GetInst().ChangeLevel("Opening");
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['ClickBloodType']) {
	Object.defineProperty(SetOliveBloodType.prototype, __m, { value: function (...args) { return SetOliveBloodType[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/SetOliveBloodType.js"] = {"SetOliveBloodType": SetOliveBloodType};
})();
(function () {

// ===== GameEngineContents/PlayerCalendar.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var Button = __PM2_EXPORTS__["GameEngineCore/Button.js"]["Button"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var GameEngineMath = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["GameEngineMath"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var Button_Date = __PM2_EXPORTS__["GameEngineContents/Button_Date.js"]["Button_Date"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var FirstSetLevel;
__PM2_LATE__.push(function () { FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"]; });
var ActorState;
__PM2_LATE__.push(function () { ActorState = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["ActorState"]; });
var SetOliveBloodType = __PM2_EXPORTS__["GameEngineContents/SetOliveBloodType.js"]["SetOliveBloodType"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
// PlayerCalendar.h / PlayerCalendar.cpp 의 전사

class PlayerCalendar extends GameEngineActor {
	static FirstUpdate = false;

	constructor() {
		super();		this.FirstUpdate = false; // 원본 PlayerCalendar.h: bool FirstUpdate = 선언

		this.OliveBirth = new Date();
		this.CalendarYear = 0;
		this.PlayerBirth = new Date();

		this.EcahMonthCalendarInterval = new float4(250, 105);

		// 원본 고정 크기 배열: Button_Date* DateButton[4][3][6][7] = {};
		this.DateButton = [];
		for (let w = 0; w < 4; w++) {
			this.DateButton.push([]);
			for (let z = 0; z < 3; z++) {
				this.DateButton[w].push([]);
				for (let y = 0; y < 6; y++) {
					this.DateButton[w][z].push([]);
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y].push(null);
					}
				}
			}
		}
		this.DateButtonScale = new float4(20, 14);
		this.FirstDaySetPos = new float4(-330, -177);
		this.EachDayNumInterval = new float4(30, 15);

		// 원본 고정 크기 배열: GameEngineRender* WeekRender[4][3] = {};
		this.WeekRender = [];
		for (let y = 0; y < 4; y++) {
			this.WeekRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.WeekRender[y].push(null);
			}
		}
		this.WeekRenderScale = new float4(210, 10);
		this.FirstWeekSetPos = new float4(-235, -192);

		// 원본 고정 크기 배열: GameEngineRender* YearRender[4][3][4] = {};
		this.YearRender = [];
		for (let z = 0; z < 4; z++) {
			this.YearRender.push([]);
			for (let y = 0; y < 3; y++) {
				this.YearRender[z].push([]);
				for (let x = 0; x < 4; x++) {
					this.YearRender[z][y].push(null);
				}
			}
		}
		this.YearRenderScale = new float4(8, 12);
		this.FirstYearSetPos = new float4(-370, -182);

		// 원본 고정 크기 배열: GameEngineRender* MonthRender[4][3] = {};
		this.MonthRender = [];
		for (let y = 0; y < 4; y++) {
			this.MonthRender.push([]);
			for (let x = 0; x < 3; x++) {
				this.MonthRender[y].push(null);
			}
		}
		this.MonthRenderScale = new float4(20, 16);
		this.FirstMonthSetPos = new float4(-360, -165);


		this.BackgroundRender = null;

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(106, 170, 126);

		this.HoverButtonDateRender_Year = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Year = new float4(-335, -221);
		this.HoverButtonDateRender_Month = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Month = new float4(-305, -221);
		this.HoverButtonDateRender_Day = new NumberRenderObject();
		this.Pos_HoverButtonDateRender_Day = new float4(-275, -221);
	}

	SetOliveBirth(_YYYY, _MM, _DD) {
		this.OliveBirth.SetDate(_YYYY, _MM, _DD);
	}

	SetCalendarYear(_YYYY) {
		this.CalendarYear = _YYYY;
	}

	On() {
		// 원본: GameEngineObject::On();
		super.On();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (0 !== this.DateButton[w][z][y][x].GetReleaseIndex()) {
							this.DateButton[w][z][y][x].On();
						}
					}
				}
			}
		}
	}

	Off() {
		// 원본: GameEngineObject::Off();
		super.Off();
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						this.DateButton[w][z][y][x].Off();
					}
				}
			}
		}
	}

	Start() {
		this.SetOliveBirth(1000, 1, 1);
		this.SetCalendarYear(1000);
		this.SetPos(GameEngineWindow.GetScreenSize().half());

		this.HoverButtonDateRender_Year.SetOwner(this);
		this.HoverButtonDateRender_Year.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Year.SetAlign(Align.Right);
		this.HoverButtonDateRender_Year.SetRenderPos(this.Pos_HoverButtonDateRender_Year);

		this.HoverButtonDateRender_Month.SetOwner(this);
		this.HoverButtonDateRender_Month.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Month.SetAlign(Align.Right);
		this.HoverButtonDateRender_Month.SetRenderPos(this.Pos_HoverButtonDateRender_Month);
		this.HoverButtonDateRender_Month.SetNumOfDigits(2);

		this.HoverButtonDateRender_Day.SetOwner(this);
		this.HoverButtonDateRender_Day.SetImage("BirthNum.bmp", new float4(10, 9), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.HoverButtonDateRender_Day.SetAlign(Align.Right);
		this.HoverButtonDateRender_Day.SetRenderPos(this.Pos_HoverButtonDateRender_Day);
		this.HoverButtonDateRender_Day.SetNumOfDigits(2);

		this.SetDateNumButton();
		this.SetMonthRender();
		this.SetYearRender();
		this.SetWeekdayRender();
		this.SetExplainRender();

		this.BackgroundRender = this.CreateRender("SetPlayerBirth.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!PlayerCalendar.FirstUpdate) {
			PlayerCalendar.FirstUpdate = true;
			this.OliveBirth = Olive.OlivePlayer.GetOliveBirthDay();
			this.CalendarYear = 1209 - Olive.OlivePlayer.GetFatherAge();

			this.UpdateDateNumButton();
			this.UpdateMonthRender();
			this.UpdateYearRender();
		}

		const Index = this.WichButtonNotRelease();
		if (
			0 > Index.x &&
			0 > Index.y &&
			0 > Index.z &&
			0 > Index.w
		) {
			this.HoverButtonDateRender_Year.Off();
			this.HoverButtonDateRender_Month.Off();
			this.HoverButtonDateRender_Day.Off();
		}
		else {
			this.HoverButtonDateRender_Year.On();
			this.HoverButtonDateRender_Month.On();
			this.HoverButtonDateRender_Day.On();

			this.HoverButtonDateRender_Year.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetYear());
			this.HoverButtonDateRender_Month.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetMonth());
			this.HoverButtonDateRender_Day.SetValue(this.DateButton[Index.iw()][Index.iz()][Index.iy()][Index.ix()].Value.GetDay());
		}
	}

	Render(_DeltaTime) {

	}

	WichButtonNotRelease() {
		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						if (ButtonState.Release !== this.DateButton[w][z][y][x].GetState()) {
							return new float4((x), (y), (z), (w));
						}
					}
				}
			}
		}
		return new float4(-1, -1, -1, -1);
	}

	SetDateNumButton() {
		let FirstMonth = this.OliveBirth.GetMonth();
		let Month = FirstMonth;
		let Year = this.CalendarYear;
		const MonthLen = new Array(12).fill(0);

		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			MonthLen[i] = Date.GetMonthLenth(Year, Month);
			Month++;
		}

		const FirstWeekday = Date.FindMonthFirstWeekday(this.CalendarYear, FirstMonth);
		let MonthFirstWeekday = FirstWeekday;
		Month = FirstMonth;
		Year = this.CalendarYear;
		const Level = this.GetLevel();

		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				if (Month === 13) {
					Month = 1;
					Year++;
				}
				let Day = 1;
				const FirstMonth = (z + 1) + (w * 3); // 원본: 외부 FirstMonth를 가리는 지역 변수
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						const fx = (x);
						const fy = (y);
						const fz = (z);
						const fw = (w);
						this.DateButton[w][z][y][x] = Level.CreateActor(Button_Date, PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
						this.DateButton[w][z][y][x].SetScale(this.DateButtonScale);
						this.DateButton[w][z][y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
						this.DateButton[w][z][y][x].SetPos(this.GetPos().add(this.FirstDaySetPos.add(this.EachDayNumInterval.mul(new float4(fx, fy))).add(this.EcahMonthCalendarInterval.mul(new float4(fz, fw)))));
						if (x + (y * 7) < MonthFirstWeekday) {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
						}
						else if (x + (y * 7) < MonthFirstWeekday + MonthLen[FirstMonth - 1]) {
							if (0 === x) {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 32 + Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
							}
							else {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
							}
						}
						else {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
						}
					}
				}
				Month++;
				MonthFirstWeekday = (MonthFirstWeekday + MonthLen[FirstMonth - 1]) % 7;
			}
		}
	}

	UpdateDateNumButton() {
		let FirstMonth = this.OliveBirth.GetMonth();
		let Month = FirstMonth;
		let Year = this.CalendarYear;
		const MonthLen = new Array(12).fill(0);

		for (let i = 0; i < 12; i++) {
			if (13 === Month) {
				Month = 1;
				Year++;
			}

			MonthLen[i] = Date.GetMonthLenth(Year, Month);
			Month++;
		}

		const FirstWeekday = Date.FindMonthFirstWeekday(this.CalendarYear, FirstMonth);
		let MonthFirstWeekday = FirstWeekday;
		Month = FirstMonth;
		Year = this.CalendarYear;

		for (let w = 0; w < 4; w++) {
			for (let z = 0; z < 3; z++) {
				if (Month === 13) {
					Month = 1;
					Year++;
				}
				let Day = 1;
				const FirstMonth = (z + 1) + (w * 3); // 원본: 외부 FirstMonth를 가리는 지역 변수
				for (let y = 0; y < 6; y++) {
					for (let x = 0; x < 7; x++) {
						const fx = (x);
						const fy = (y);
						const fz = (z);
						const fw = (w);
						if (x + (y * 7) < MonthFirstWeekday) {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].Off();
						}
						else if (x + (y * 7) < MonthFirstWeekday + MonthLen[FirstMonth - 1]) {
							if (0 === x) {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 32 + Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
								this.DateButton[w][z][y][x].On();
							}
							else {
								this.DateButton[w][z][y][x].Value.SetDate(Year, Month, Day);
								this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", Day);
								this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 64 + Day);
								this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 64 + Day++);
								this.DateButton[w][z][y][x].SetClickCallBack(PlayerCalendar.SetPlayerBirthDay);
								this.DateButton[w][z][y][x].On();
							}
						}
						else {
							this.DateButton[w][z][y][x].Value.SetNullDate();
							this.DateButton[w][z][y][x].SetReleaseImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetHoverImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].SetPressImage("PlayerCalendarNum.bmp", 0);
							this.DateButton[w][z][y][x].Off();
						}
					}
				}
				Month++;
				MonthFirstWeekday = (MonthFirstWeekday + MonthLen[FirstMonth - 1]) % 7;
			}
		}
	}

	SetYearRender() {
		let Month = this.OliveBirth.GetMonth();
		let Year = this.CalendarYear;
		let YearDigits = GameEngineMath.GetDigits(Year); // std::vector<unsigned int>

		for (let z = 0; z < 4; z++) {
			for (let y = 0; y < 3; y++) {

				if (Month === 13) {
					Month = 1;
					Year++;
					YearDigits = GameEngineMath.GetDigits(Year);
				}

				for (let x = 0; x < 4; x++) {
					const fx = (x);
					const fy = (y);
					const fz = (z);
					this.YearRender[z][y][x] = this.CreateRender("PlayerYearNum.BMP", PM2RenderOrder.Contents);
					this.YearRender[z][y][x].SetScale(this.YearRenderScale);
					this.YearRender[z][y][x].SetPosition(this.FirstYearSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fy, fz))).add(float4.Right.scale(fx).scale(this.YearRenderScale.x)));
				}

				this.YearRender[z][y][0].SetFrame(YearDigits[0]);
				this.YearRender[z][y][1].SetFrame(YearDigits[1]);
				this.YearRender[z][y][2].SetFrame(YearDigits[2]);
				this.YearRender[z][y][3].SetFrame(YearDigits[3]);

				Month++;
			}
		}
	}

	UpdateYearRender() {
		let Month = this.OliveBirth.GetMonth();
		let Year = this.CalendarYear;
		let YearDigits = GameEngineMath.GetDigits(Year); // std::vector<unsigned int>

		for (let z = 0; z < 4; z++) {
			for (let y = 0; y < 3; y++) {

				if (Month === 13) {
					Month = 1;
					Year++;
					YearDigits = GameEngineMath.GetDigits(Year);
				}

				this.YearRender[z][y][0].SetFrame(YearDigits[0]);
				this.YearRender[z][y][1].SetFrame(YearDigits[1]);
				this.YearRender[z][y][2].SetFrame(YearDigits[2]);
				this.YearRender[z][y][3].SetFrame(YearDigits[3]);

				Month++;
			}
		}
	}

	SetWeekdayRender() {
		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.WeekRender[y][x] = this.CreateRender("PlayerWeek.BMP", PM2RenderOrder.Contents);
				this.WeekRender[y][x].SetScale(this.WeekRenderScale);
				this.WeekRender[y][x].SetPosition(this.FirstWeekSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	SetMonthRender() {
		let Month = this.OliveBirth.GetMonth();

		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				this.MonthRender[y][x] = this.CreateRender("PlayerCalendarNum.BMP", PM2RenderOrder.Contents);
				if (13 === ((x + (y * 3)) + (Month))) {
					Month = -(12 - Month);
				}
				this.MonthRender[y][x].SetFrame((x + (y * 3)) + (Month));
				this.MonthRender[y][x].SetScale(new float4(20, 16));
				this.MonthRender[y][x].SetPosition(this.FirstMonthSetPos.add(this.EcahMonthCalendarInterval.mul(new float4(fx, fy))));
			}
		}
	}

	UpdateMonthRender() {
		let Month = this.OliveBirth.GetMonth();

		for (let y = 0; y < 4; y++) {
			for (let x = 0; x < 3; x++) {
				const fx = (x);
				const fy = (y);
				if (13 === ((x + (y * 3)) + (Month))) {
					Month = -(12 - Month);
				}
				this.MonthRender[y][x].SetFrame((x + (y * 3)) + (Month));
			}
		}
	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = new float4(this.ExplainTextBoxScale.hx(), 0).neg().sub(new float4(0, 223));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("당신의 생일은 언제 입니까?", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static SetPlayerBirthDay(_Btn) {
		// 원본: dynamic_cast<Button_Date*>(_Btn)
		const Ptr = _Btn;
		Olive.OlivePlayer.SetFatherBirthDay(Ptr.Value);
		FirstSetLevel.SetStateValue(ActorState.SetOliveBloodType);
		PlayerCalendar.FirstUpdate = false;
		SetOliveBloodType.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['SetPlayerBirthDay']) {
	Object.defineProperty(PlayerCalendar.prototype, __m, { value: function (...args) { return PlayerCalendar[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/PlayerCalendar.js"] = {"PlayerCalendar": PlayerCalendar};
})();
(function () {

// ===== GameEngineContents/SetOliveName.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var CharButton = __PM2_EXPORTS__["GameEngineContents/CharButton.js"]["CharButton"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var FirstSetLevel;
__PM2_LATE__.push(function () { FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"]; });
var ActorState;
__PM2_LATE__.push(function () { ActorState = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["ActorState"]; });
var OliveCalendar;
__PM2_LATE__.push(function () { OliveCalendar = __PM2_EXPORTS__["GameEngineContents/OliveCalendar.js"]["OliveCalendar"]; });
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// SetOliveName.h / SetOliveName.cpp 의 전사

class SetOliveName extends GameEngineActor {
	static FirstUpdate = false;

	static GetPrintLetter() {
		return SetOliveName.PrintLetter;
	}

	static PrintLetter = "\0";
	static ExplainRender1 = null;
	static ExplainRender2 = null;
	static ExplainRenderShadow = null;

	static ExplainText = "딸의 이름을 지어주세요(8자이내)";
	static ErrorText = "이름이 필요해요";
	static ExplainTextBoxScale = new float4(300, 18);
	static ErrorTextBoxScale = new float4(200, 18);

	constructor() {
		super();		this.ErrorText = ""; // 원본 SetOliveName.h: std::string ErrorText = 선언
		this.ExplainText = ""; // 원본 SetOliveName.h: std::string ExplainText = 선언
		this.FirstUpdate = false; // 원본 SetOliveName.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;

		this.PrintLetterRender1 = null;
		this.PrintLetterRender2 = null;
		this.PrintLetterRender3 = null;
		this.PrintLetterBoxScale = new float4(120, 18);

		// 원본: CharButton* UpperCaseButton[6][5] = {};
		this.UpperCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		// 원본: CharButton* LowerCaseButton[6][5] = {};
		this.LowerCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		this.CompleteButton = null;
		this.CompleteButton1Render = null;
		this.CompleteButton2Render = null;
		this.CompleteButtonEffect1Render = null;
		this.CompleteButtonEffect2Render = null;
		this.CompleteButtonEffect3Render = null;
		this.CompleteButtonShadowRender = null;

		this.LetterEraseButton = null;
		this.LetterEraseButton1Render = null;
		this.LetterEraseButton2Render = null;
		this.LetterEraseButtonEffect1Render = null;
		this.LetterEraseButtonEffect2Render = null;
		this.LetterEraseButtonEffect3Render = null;
		this.LetterEraseButtonShadowRender = null;

		this.ButtonScale = new float4(24, 24);
		this.ButtonScale2 = new float4(48, 24);
		this.ButtonInterval = new float4(16, 0);
		this.LetterRenderHeight = 18;
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(192, 120, 178);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
		this.TextType = "굴림";
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetOliveBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();

		this.SetExplainRender();

		this.SetPrintLetterRender();

		this.SetUpperCaseButton();
		this.SetUpperCaseRender();

		this.SetLowerCaseButton();
		this.SetLowerCaseRender();

		this.SetCompleteButton();
		this.SetCompleteButtonRender();

		this.SetLetterEraseButton();
		this.SetLetterEraseButtonRender();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!SetOliveName.FirstUpdate) {
			SetOliveName.FirstUpdate = true;
			SetOliveName.PrintLetter = "\0";
			SetOliveName.ExplainRender1.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
			SetOliveName.ExplainRender2.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
			SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetOliveName.ExplainTextBoxScale);
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.UpperCaseButton[y][x].GetState()) {
					this.UpperCaseLetterEffect1Render[y][x].Off();
					this.UpperCaseLetterEffect2Render[y][x].Off();
					this.UpperCaseLetterEffect3Render[y][x].Off();

					this.UpperCaseLetter1Render[y][x].On();
					this.UpperCaseLetter2Render[y][x].On();
					this.UpperCaseLetterShadowRender[y][x].On();
				}
				else {
					this.UpperCaseLetterEffect1Render[y][x].On();
					this.UpperCaseLetterEffect2Render[y][x].On();
					this.UpperCaseLetterEffect3Render[y][x].On();

					this.UpperCaseLetter1Render[y][x].Off();
					this.UpperCaseLetter2Render[y][x].Off();
					this.UpperCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.LowerCaseButton[y][x].GetState()) {
					this.LowerCaseLetterEffect1Render[y][x].Off();
					this.LowerCaseLetterEffect2Render[y][x].Off();
					this.LowerCaseLetterEffect3Render[y][x].Off();

					this.LowerCaseLetter1Render[y][x].On();
					this.LowerCaseLetter2Render[y][x].On();
					this.LowerCaseLetterShadowRender[y][x].On();
				}
				else {
					this.LowerCaseLetterEffect1Render[y][x].On();
					this.LowerCaseLetterEffect2Render[y][x].On();
					this.LowerCaseLetterEffect3Render[y][x].On();

					this.LowerCaseLetter1Render[y][x].Off();
					this.LowerCaseLetter2Render[y][x].Off();
					this.LowerCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		if (ButtonState.Release === this.CompleteButton.GetState()) {
			this.CompleteButtonEffect1Render.Off();
			this.CompleteButtonEffect2Render.Off();
			this.CompleteButtonEffect3Render.Off();

			this.CompleteButton1Render.On();
			this.CompleteButton2Render.On();
			this.CompleteButtonShadowRender.On();
		}
		else {
			this.CompleteButtonEffect1Render.On();
			this.CompleteButtonEffect2Render.On();
			this.CompleteButtonEffect3Render.On();

			this.CompleteButton1Render.Off();
			this.CompleteButton2Render.Off();
			this.CompleteButtonShadowRender.Off();
		}

		if (ButtonState.Release === this.LetterEraseButton.GetState()) {
			this.LetterEraseButtonEffect1Render.Off();
			this.LetterEraseButtonEffect2Render.Off();
			this.LetterEraseButtonEffect3Render.Off();

			this.LetterEraseButton1Render.On();
			this.LetterEraseButton2Render.On();
			this.LetterEraseButtonShadowRender.On();
		}
		else {
			this.LetterEraseButtonEffect1Render.On();
			this.LetterEraseButtonEffect2Render.On();
			this.LetterEraseButtonEffect3Render.On();

			this.LetterEraseButton1Render.Off();
			this.LetterEraseButton2Render.Off();
			this.LetterEraseButtonShadowRender.Off();
		}


		this.PrintLetterRender1.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect1Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect3Color, this.PrintLetterBoxScale);
	}

	Render(_DeltaTime) {
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}
				this.UpperCaseButton[y][x].On();
				this.LowerCaseButton[y][x].On();

			}
		}
		this.CompleteButton.On();
		this.LetterEraseButton.On();
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x].Off();
				this.LowerCaseButton[y][x].Off();
			}
		}
		this.CompleteButton.Off();
		this.LetterEraseButton.Off();
	}

	SetPrintLetterRender() {
		this.PrintLetterRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender1.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		const SetPrintLetterRenderPos = this.PrintLetterBoxScale.half().neg().sub(new float4(60, 60));
		this.PrintLetterRender1.SetPosition(SetPrintLetterRenderPos);

		this.PrintLetterRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender2.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetPosition(SetPrintLetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.PrintLetterRender3 = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.PrintLetterRender3.SetText(" " + SetOliveName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetPosition(SetPrintLetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetExplainRender() {
		SetOliveName.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetOliveName.ExplainRender1.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
		const SetExplainRenderPos = SetOliveName.ExplainTextBoxScale.half().neg().sub(new float4(36, 36));
		SetOliveName.ExplainRender1.SetPosition(SetExplainRenderPos);

		SetOliveName.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetOliveName.ExplainRender2.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetOliveName.ExplainTextBoxScale);
		SetOliveName.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		SetOliveName.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetOliveName.ExplainTextBoxScale);
		SetOliveName.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetUpperCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(182, 312);

		let Start = 'A'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.UpperCaseButton[y][x].SetScale(this.ButtonScale);
				this.UpperCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.UpperCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].Chracter = Start++;
				this.UpperCaseButton[y][x].SetClickCallBack(SetOliveName.PushBack_Button);
			}
		}
	}

	SetUpperCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "A";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);

				this.UpperCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.UpperCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.UpperCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.UpperCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.UpperCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.UpperCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.UpperCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.UpperCaseLetterEffect1Render[y][x].Off();

				this.UpperCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.UpperCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect2Render[y][x].Off();

				this.UpperCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.UpperCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect3Render[y][x].Off();

				this.UpperCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.UpperCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.UpperCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

				if ("Z" === Start) {
					break;
				}
			}
		}
	}

	SetLowerCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(422, 312);

		let Start = 'a'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.LowerCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.LowerCaseButton[y][x].SetScale(this.ButtonScale);
				this.LowerCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.LowerCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].Chracter = Start++;
				this.LowerCaseButton[y][x].SetClickCallBack(SetOliveName.PushBack_Button);
			}
		}
	}


	SetLowerCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "a";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);
				this.LowerCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.LowerCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.LowerCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.LowerCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.LowerCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.LowerCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.LowerCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.LowerCaseLetterEffect1Render[y][x].Off();

				this.LowerCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.LowerCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect2Render[y][x].Off();

				this.LowerCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.LowerCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect3Render[y][x].Off();

				this.LowerCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.LowerCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.LowerCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				if ("z" === Start) {
					break;
				}
			}
		}
	}

	SetCompleteButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(194, 448);

		this.CompleteButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.CompleteButton.SetScale(this.ButtonScale2);
		this.CompleteButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.CompleteButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetPos(ButtonStartPosition);
		this.CompleteButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetHoverImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetPressImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetClickCallBack(SetOliveName.ClickCompleteButton);
	}

	SetCompleteButtonRender() {
		this.CompleteButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.CompleteButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.CompleteButton1Render.SetPosition(ButtonStartPosition);

		this.CompleteButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.CompleteButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.CompleteButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButtonEffect1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.CompleteButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.CompleteButtonEffect1Render.Off();

		this.CompleteButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.CompleteButtonEffect2Render.Off();

		this.CompleteButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect3Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.CompleteButtonEffect3Render.Off();

		this.CompleteButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.CompleteButtonShadowRender.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.CompleteButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}

	SetLetterEraseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(266, 448);

		this.LetterEraseButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.LetterEraseButton.SetScale(this.ButtonScale2);
		this.LetterEraseButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.LetterEraseButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetPos(ButtonStartPosition);
		this.LetterEraseButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetHoverImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetPressImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetClickCallBack(SetOliveName.PopBack_PrintLetter);
	}

	SetLetterEraseButtonRender() {
		this.LetterEraseButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.LetterEraseButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.LetterEraseButton1Render.SetPosition(ButtonStartPosition);

		this.LetterEraseButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.LetterEraseButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.LetterEraseButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButtonEffect1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.LetterEraseButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.LetterEraseButtonEffect1Render.Off();

		this.LetterEraseButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect2Render.Off();

		this.LetterEraseButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect3Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect3Render.Off();

		this.LetterEraseButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.LetterEraseButtonShadowRender.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.LetterEraseButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}


	static PushBack_Button(_Button) {
		if (8 <= SetOliveName.PrintLetter.length) {
			return;
		}
		const Ptr = _Button; // 원본: dynamic_cast<CharButton*>

		// 원본: PrintLetter.push_back(Ptr->Chracter); (char를 문자열에 추가)
		SetOliveName.PrintLetter += String.fromCharCode(Ptr.Chracter);
	}

	static PopBack_PrintLetter(_Button) {
		if (0 >= SetOliveName.PrintLetter.length) {
			FirstSetLevel.SetStateValue(ActorState.SetPlayerName);
			return;
		}

		// 원본: PrintLetter.pop_back();
		SetOliveName.PrintLetter = SetOliveName.PrintLetter.slice(0, -1);
	}

	static ClickCompleteButton(_Button) {
		if (0 === SetOliveName.PrintLetter.length) {
			SetOliveName.ExplainRender1.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetOliveName.ErrorTextBoxScale);
			SetOliveName.ExplainRender2.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetOliveName.ErrorTextBoxScale);
			SetOliveName.ExplainRenderShadow.SetText(SetOliveName.ErrorText, 18, "굴림", TextAlign.Center, RGB(192, 120, 178), SetOliveName.ErrorTextBoxScale);
			return;
		}

		FirstSetLevel.SetStateValue(ActorState.OliveCalendar);
		Olive.OlivePlayer.SetOliveFirstName(SetOliveName.PrintLetter);
		SetOliveName.FirstUpdate = false;

		OliveCalendar.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetPrintLetter', 'PushBack_Button', 'PopBack_PrintLetter', 'ClickCompleteButton']) {
	Object.defineProperty(SetOliveName.prototype, __m, { value: function (...args) { return SetOliveName[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/SetOliveName.js"] = {"SetOliveName": SetOliveName};
})();
(function () {

// ===== GameEngineContents/SetPlayerAge.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var CharButton = __PM2_EXPORTS__["GameEngineContents/CharButton.js"]["CharButton"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var FirstSetLevel;
__PM2_LATE__.push(function () { FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"]; });
var ActorState;
__PM2_LATE__.push(function () { ActorState = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["ActorState"]; });
var PlayerCalendar;
__PM2_LATE__.push(function () { PlayerCalendar = __PM2_EXPORTS__["GameEngineContents/PlayerCalendar.js"]["PlayerCalendar"]; });
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// SetPlayerAge.h / SetPlayerAge.cpp 의 전사

class SetPlayerAge extends GameEngineActor {
	static FirstUpdate = false;

	static PrintLetter = "";

	constructor() {
		super();		this.FirstUpdate = false; // 원본 SetPlayerAge.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;
		// 원본: CharButton* AgeNumButton[10] = {};
		this.AgeNumButton = new Array(10).fill(null);
		this.AgeNumButtonRender1 = new Array(10).fill(null);
		this.AgeNumButtonRender2 = new Array(10).fill(null);
		this.AgeNumButtonEffect1Render = new Array(10).fill(null);
		this.AgeNumButtonEffect2Render = new Array(10).fill(null);
		this.AgeNumButtonEffect3Render = new Array(10).fill(null);
		this.AgeNumButtonShadowRender = new Array(10).fill(null);

		this.PrintLetterRender1 = null;
		this.PrintLetterRender2 = null;
		this.PrintLetterRender3 = null;
		this.PrintLetterBoxScale = new float4(100, 18);

		this.ExplainRender1 = null;
		this.ExplainRender2 = null;
		this.ExplainRenderShadow = null;
		this.ExplainTextBoxScale = new float4(300, 18);

		this.CompleteButton = null;
		this.CompleteButton1Render = null;
		this.CompleteButton2Render = null;
		this.CompleteButtonEffect1Render = null;
		this.CompleteButtonEffect2Render = null;
		this.CompleteButtonEffect3Render = null;
		this.CompleteButtonShadowRender = null;

		this.ButtonScale = new float4(24, 24);
		this.ButtonScale2 = new float4(48, 24);
		this.ButtonInterval = new float4(8, 0);
		this.LetterRenderHeight = 18;
		this.TextType = "굴림";
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(106, 170, 126);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i].On();
		}
		this.CompleteButton.On();
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i].Off();
		}
		this.CompleteButton.Off();

	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetPlayerBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();
		this.SetAgeNumButton();
		this.SetAgeNumRender();

		this.SetPrintLetterRender();
		this.SetExplainRender();

		this.SetCompleteButton();
		this.SetCompleteButtonRender();


		this.Off();
	}

	Update(_DeltaTime) {
		if (!SetPlayerAge.FirstUpdate) {
			SetPlayerAge.FirstUpdate = true;
			SetPlayerAge.PrintLetter = "\0";
		}

		for (let i = 0; i < 10; i++) {
			if (ButtonState.Release === this.AgeNumButton[i].GetState()) {
				this.AgeNumButtonEffect1Render[i].Off();
				this.AgeNumButtonEffect2Render[i].Off();
				this.AgeNumButtonEffect3Render[i].Off();

				this.AgeNumButtonRender1[i].On();
				this.AgeNumButtonRender2[i].On();
				this.AgeNumButtonShadowRender[i].On();
			}
			else {
				this.AgeNumButtonEffect1Render[i].On();
				this.AgeNumButtonEffect2Render[i].On();
				this.AgeNumButtonEffect3Render[i].On();

				this.AgeNumButtonRender1[i].Off();
				this.AgeNumButtonRender2[i].Off();
				this.AgeNumButtonShadowRender[i].Off();
			}
		}

		if (ButtonState.Release === this.CompleteButton.GetState()) {
			this.CompleteButtonEffect1Render.Off();
			this.CompleteButtonEffect2Render.Off();
			this.CompleteButtonEffect3Render.Off();

			this.CompleteButton1Render.On();
			this.CompleteButton2Render.On();
			this.CompleteButtonShadowRender.On();
		}
		else {
			this.CompleteButtonEffect1Render.On();
			this.CompleteButtonEffect2Render.On();
			this.CompleteButtonEffect3Render.On();

			this.CompleteButton1Render.Off();
			this.CompleteButton2Render.Off();
			this.CompleteButtonShadowRender.Off();
		}

		this.PrintLetterRender1.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect1Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect3Color, this.PrintLetterBoxScale);

	}

	Render(_DeltaTime) {
	}

	SetAgeNumButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(GameEngineWindow.GetScreenSize().x + float4.Left.x * 9 * (this.ButtonScale.hx() + this.ButtonInterval.hx()), 360);

		let Start = '0'.charCodeAt(0);

		for (let i = 0; i < 10; i++) {
			this.AgeNumButton[i] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
			this.AgeNumButton[i].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
			this.AgeNumButton[i].SetScale(this.ButtonScale);
			this.AgeNumButton[i].SetRenderOrder(PM2RenderOrder.Menu0_Button);
			this.AgeNumButton[i].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
			this.AgeNumButton[i].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(i, 0))));
			this.AgeNumButton[i].SetReleaseImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].SetHoverImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].SetPressImage("SelectButton_Release.Bmp");
			this.AgeNumButton[i].Chracter = Start++;
			this.AgeNumButton[i].SetClickCallBack(SetPlayerAge.PushBack_Button);
		}
	}

	SetAgeNumRender() {
		let Count = 0;
		for (let i = 0; i < 10; i++) {
			let Start = "0";
			// 원본: Start[0] += Count++;
			Start = String.fromCharCode(Start.charCodeAt(0) + Count++);

			this.AgeNumButtonRender1[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonRender1[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
			const LetterRenderPos = this.AgeNumButton[i].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
			this.AgeNumButtonRender1[i].SetPosition(LetterRenderPos);

			this.AgeNumButtonRender2[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonRender2[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
			this.AgeNumButtonRender2[i].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

			this.AgeNumButtonEffect1Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display);
			this.AgeNumButtonEffect1Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
			this.AgeNumButtonEffect1Render[i].SetPosition(LetterRenderPos);
			this.AgeNumButtonEffect1Render[i].Off();

			this.AgeNumButtonEffect2Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
			this.AgeNumButtonEffect2Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
			this.AgeNumButtonEffect2Render[i].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
			this.AgeNumButtonEffect2Render[i].Off();

			this.AgeNumButtonEffect3Render[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
			this.AgeNumButtonEffect3Render[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
			this.AgeNumButtonEffect3Render[i].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
			this.AgeNumButtonEffect3Render[i].Off();

			this.AgeNumButtonShadowRender[i] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
			this.AgeNumButtonShadowRender[i].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
			this.AgeNumButtonShadowRender[i].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
		}
	}

	SetPrintLetterRender() {
		this.PrintLetterRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender1.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect1Color, this.PrintLetterBoxScale);
		const SetPrintLetterRenderPos = this.PrintLetterBoxScale.half().neg().sub(new float4(30, 60));
		this.PrintLetterRender1.SetPosition(SetPrintLetterRenderPos);

		this.PrintLetterRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.PrintLetterRender2.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetPosition(SetPrintLetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.PrintLetterRender3 = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.PrintLetterRender3.SetText(" " + SetPlayerAge.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Right, this.TextEffect3Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetPosition(SetPrintLetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static PushBack_Button(_Button) {
		const Ptr = _Button; // 원본: dynamic_cast<CharButton*>

		if (2 <= SetPlayerAge.PrintLetter.length) {
			// 원본: PrintLetter[0] = PrintLetter[1]; PrintLetter[1] = Ptr->Chracter;
			SetPlayerAge.PrintLetter = SetPlayerAge.PrintLetter[1] + String.fromCharCode(Ptr.Chracter);
		}
		else {
			// 원본: PrintLetter.push_back(Ptr->Chracter);
			SetPlayerAge.PrintLetter += String.fromCharCode(Ptr.Chracter);
		}

		if ("00" === SetPlayerAge.PrintLetter) {
			SetPlayerAge.PrintLetter = "0";
		}
	}

	SetCompleteButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(194, 448);

		this.CompleteButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.CompleteButton.SetScale(this.ButtonScale2);
		this.CompleteButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.CompleteButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetPos(ButtonStartPosition);
		this.CompleteButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetHoverImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetPressImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetClickCallBack(SetPlayerAge.ClickCompleteButton);
	}

	SetCompleteButtonRender() {
		this.CompleteButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.CompleteButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.CompleteButton1Render.SetPosition(ButtonStartPosition);

		this.CompleteButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.CompleteButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.CompleteButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButtonEffect1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.CompleteButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.CompleteButtonEffect1Render.Off();

		this.CompleteButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.CompleteButtonEffect2Render.Off();

		this.CompleteButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect3Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.CompleteButtonEffect3Render.Off();

		this.CompleteButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.CompleteButtonShadowRender.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.CompleteButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}

	SetExplainRender() {
		this.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender1.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		const SetExplainRenderPos = this.ExplainTextBoxScale.half().neg().sub(new float4(0, 36));
		this.ExplainRender1.SetPosition(SetExplainRenderPos);

		this.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.ExplainRender2.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ExplainTextBoxScale);
		this.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.ExplainRenderShadow.SetText("당신의 나이를 가르쳐 주세요", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ExplainTextBoxScale);
		this.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	static ClickCompleteButton(_Button) {
		if (SetPlayerAge.PrintLetter.length === 0) {
			return;
		}
		// 원본: std::stoi(PrintLetter)
		const AgeValue = parseInt(SetPlayerAge.PrintLetter, 10);
		if (10 > AgeValue || 99 < AgeValue) {
			return;
		}
		FirstSetLevel.SetStateValue(ActorState.PlayerCalendar);
		Olive.OlivePlayer.SetFatherAge(AgeValue);
		SetPlayerAge.FirstUpdate = false;
		PlayerCalendar.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['PushBack_Button', 'ClickCompleteButton']) {
	Object.defineProperty(SetPlayerAge.prototype, __m, { value: function (...args) { return SetPlayerAge[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/SetPlayerAge.js"] = {"SetPlayerAge": SetPlayerAge};
})();
(function () {

// ===== GameEngineContents/SetPlayerName.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineObject = __PM2_EXPORTS__["GameEngineCore/GameEngineObject.js"]["GameEngineObject"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var ButtonState = __PM2_EXPORTS__["GameEngineCore/Button.js"]["ButtonState"];
var GlobalButton = __PM2_EXPORTS__["GameEngineContents/GlobalButton.js"]["GlobalButton"];
var CharButton = __PM2_EXPORTS__["GameEngineContents/CharButton.js"]["CharButton"];
var TextAlign = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["TextAlign"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var FirstSetLevel;
__PM2_LATE__.push(function () { FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"]; });
var ActorState;
__PM2_LATE__.push(function () { ActorState = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["ActorState"]; });
var SetOliveName;
__PM2_LATE__.push(function () { SetOliveName = __PM2_EXPORTS__["GameEngineContents/SetOliveName.js"]["SetOliveName"]; });
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
var PM2CollisionOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2CollisionOrder"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// SetPlayerName.h / SetPlayerName.cpp 의 전사

class SetPlayerName extends GameEngineActor {
	static GetPrintLetter() {
		return SetPlayerName.PrintLetter;
	}

	static FirstUpdate = false;

	static PrintLetter = "\0";
	static ExplainRender1 = null;
	static ExplainRender2 = null;
	static ExplainRenderShadow = null;

	static ExplainText = "당신의 성은 무엇입니까? (8자이내)";
	static ErrorText = "이름이 필요해요";
	static ExplainTextBoxScale = new float4(300, 18);
	static ErrorTextBoxScale = new float4(200, 18);

	constructor() {
		super();		this.ErrorText = ""; // 원본 SetPlayerName.h: std::string ErrorText = 선언
		this.ExplainText = ""; // 원본 SetPlayerName.h: std::string ExplainText = 선언
		this.FirstUpdate = false; // 원본 SetPlayerName.h: bool FirstUpdate = 선언

		this.BackgroundRender = null;

		this.PrintLetterRender1 = null;
		this.PrintLetterRender2 = null;
		this.PrintLetterRender3 = null;
		this.PrintLetterBoxScale = new float4(120, 18);

		// 원본: CharButton* UpperCaseButton[6][5] = {};
		this.UpperCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.UpperCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		// 원본: CharButton* LowerCaseButton[6][5] = {};
		this.LowerCaseButton = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetter2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect1Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect2Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterEffect3Render = new Array(6).fill(null).map(() => new Array(5).fill(null));
		this.LowerCaseLetterShadowRender = new Array(6).fill(null).map(() => new Array(5).fill(null));

		this.CompleteButton = null;
		this.CompleteButton1Render = null;
		this.CompleteButton2Render = null;
		this.CompleteButtonEffect1Render = null;
		this.CompleteButtonEffect2Render = null;
		this.CompleteButtonEffect3Render = null;
		this.CompleteButtonShadowRender = null;

		this.LetterEraseButton = null;
		this.LetterEraseButton1Render = null;
		this.LetterEraseButton2Render = null;
		this.LetterEraseButtonEffect1Render = null;
		this.LetterEraseButtonEffect2Render = null;
		this.LetterEraseButtonEffect3Render = null;
		this.LetterEraseButtonShadowRender = null;

		this.ButtonScale = new float4(24, 24);
		this.ButtonScale2 = new float4(48, 24);
		this.ButtonInterval = new float4(16, 0);
		this.LetterRenderHeight = 18;
		this.TextColor = RGB(0, 0, 0);
		this.TextShadowColor = RGB(106, 170, 126);
		this.TextEffect1Color = RGB(152, 134, 50);
		this.TextEffect2Color = RGB(202, 184, 84);
		this.TextEffect3Color = RGB(236, 212, 98);
		this.TextType = "굴림";
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.BackgroundRender = this.CreateRender("SetPlayerBackground.BMP", PM2RenderOrder.BackGround);
		this.BackgroundRender.SetScaleToImage();

		this.SetExplainRender();

		this.SetPrintLetterRender();

		this.SetUpperCaseButton();
		this.SetUpperCaseRender();

		this.SetLowerCaseButton();
		this.SetLowerCaseRender();

		this.SetCompleteButton();
		this.SetCompleteButtonRender();

		this.SetLetterEraseButton();
		this.SetLetterEraseButtonRender();

		this.Off();
	}

	Update(_DeltaTime) {
		if (!SetPlayerName.FirstUpdate) {
			SetPlayerName.FirstUpdate = true;
			SetPlayerName.PrintLetter = "\0";
			SetPlayerName.ExplainRender1.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetPlayerName.ExplainTextBoxScale);
			SetPlayerName.ExplainRender2.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetPlayerName.ExplainTextBoxScale);
			SetPlayerName.ExplainRenderShadow.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetPlayerName.ExplainTextBoxScale);
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.UpperCaseButton[y][x].GetState()) {
					this.UpperCaseLetterEffect1Render[y][x].Off();
					this.UpperCaseLetterEffect2Render[y][x].Off();
					this.UpperCaseLetterEffect3Render[y][x].Off();

					this.UpperCaseLetter1Render[y][x].On();
					this.UpperCaseLetter2Render[y][x].On();
					this.UpperCaseLetterShadowRender[y][x].On();
				}
				else {
					this.UpperCaseLetterEffect1Render[y][x].On();
					this.UpperCaseLetterEffect2Render[y][x].On();
					this.UpperCaseLetterEffect3Render[y][x].On();

					this.UpperCaseLetter1Render[y][x].Off();
					this.UpperCaseLetter2Render[y][x].Off();
					this.UpperCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}

				if (ButtonState.Release === this.LowerCaseButton[y][x].GetState()) {
					this.LowerCaseLetterEffect1Render[y][x].Off();
					this.LowerCaseLetterEffect2Render[y][x].Off();
					this.LowerCaseLetterEffect3Render[y][x].Off();

					this.LowerCaseLetter1Render[y][x].On();
					this.LowerCaseLetter2Render[y][x].On();
					this.LowerCaseLetterShadowRender[y][x].On();
				}
				else {
					this.LowerCaseLetterEffect1Render[y][x].On();
					this.LowerCaseLetterEffect2Render[y][x].On();
					this.LowerCaseLetterEffect3Render[y][x].On();

					this.LowerCaseLetter1Render[y][x].Off();
					this.LowerCaseLetter2Render[y][x].Off();
					this.LowerCaseLetterShadowRender[y][x].Off();
				}
			}
		}

		if (ButtonState.Release === this.CompleteButton.GetState()) {
			this.CompleteButtonEffect1Render.Off();
			this.CompleteButtonEffect2Render.Off();
			this.CompleteButtonEffect3Render.Off();

			this.CompleteButton1Render.On();
			this.CompleteButton2Render.On();
			this.CompleteButtonShadowRender.On();
		}
		else {
			this.CompleteButtonEffect1Render.On();
			this.CompleteButtonEffect2Render.On();
			this.CompleteButtonEffect3Render.On();

			this.CompleteButton1Render.Off();
			this.CompleteButton2Render.Off();
			this.CompleteButtonShadowRender.Off();
		}

		if (ButtonState.Release === this.LetterEraseButton.GetState()) {
			this.LetterEraseButtonEffect1Render.Off();
			this.LetterEraseButtonEffect2Render.Off();
			this.LetterEraseButtonEffect3Render.Off();

			this.LetterEraseButton1Render.On();
			this.LetterEraseButton2Render.On();
			this.LetterEraseButtonShadowRender.On();
		}
		else {
			this.LetterEraseButtonEffect1Render.On();
			this.LetterEraseButtonEffect2Render.On();
			this.LetterEraseButtonEffect3Render.On();

			this.LetterEraseButton1Render.Off();
			this.LetterEraseButton2Render.Off();
			this.LetterEraseButtonShadowRender.Off();
		}


		this.PrintLetterRender1.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect1Color, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect2Color, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextEffect3Color, this.PrintLetterBoxScale);
	}

	Render(_DeltaTime) {
	}

	On() {
		GameEngineObject.prototype.On.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				if (y === 5 && x === 1) {
					break;
				}
				this.UpperCaseButton[y][x].On();
				this.LowerCaseButton[y][x].On();
			}
		}
		this.CompleteButton.On();
		this.LetterEraseButton.On();
	}

	Off() {
		GameEngineObject.prototype.Off.call(this);
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x].Off();
				this.LowerCaseButton[y][x].Off();
			}
		}
		this.CompleteButton.Off();
		this.LetterEraseButton.Off();
	}

	SetPrintLetterRender() {
		this.PrintLetterRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender1.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		const SetPrintLetterRenderPos = this.PrintLetterBoxScale.half().neg().sub(new float4(60, 60));
		this.PrintLetterRender1.SetPosition(SetPrintLetterRenderPos);

		this.PrintLetterRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.PrintLetterRender2.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextColor, this.PrintLetterBoxScale);
		this.PrintLetterRender2.SetPosition(SetPrintLetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

		this.PrintLetterRender3 = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.PrintLetterRender3.SetText(" " + SetPlayerName.PrintLetter, this.LetterRenderHeight, this.TextType, TextAlign.Left, this.TextShadowColor, this.PrintLetterBoxScale);
		this.PrintLetterRender3.SetPosition(SetPrintLetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetExplainRender() {
		SetPlayerName.ExplainRender1 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetPlayerName.ExplainRender1.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetPlayerName.ExplainTextBoxScale);
		const SetExplainRenderPos = SetPlayerName.ExplainTextBoxScale.half().neg().sub(new float4(36, 36));
		SetPlayerName.ExplainRender1.SetPosition(SetExplainRenderPos);

		SetPlayerName.ExplainRender2 = this.CreateRender(PM2RenderOrder.Menu0_Display);
		SetPlayerName.ExplainRender2.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, SetPlayerName.ExplainTextBoxScale);
		SetPlayerName.ExplainRender2.SetPosition(SetExplainRenderPos.add(float4.Up.mul(new float4(0, 1))));

		SetPlayerName.ExplainRenderShadow = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		SetPlayerName.ExplainRenderShadow.SetText(SetPlayerName.ExplainText, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, SetPlayerName.ExplainTextBoxScale);
		SetPlayerName.ExplainRenderShadow.SetPosition(SetExplainRenderPos.add(float4.Down.mul(new float4(0, 1))));
	}

	SetUpperCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(182, 312);

		let Start = 'A'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.UpperCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.UpperCaseButton[y][x].SetScale(this.ButtonScale);
				this.UpperCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.UpperCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.UpperCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.UpperCaseButton[y][x].Chracter = Start++;
				this.UpperCaseButton[y][x].SetClickCallBack(SetPlayerName.PushBack_Button);
			}
		}
	}

	SetUpperCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "A";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);

				this.UpperCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.UpperCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.UpperCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.UpperCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.UpperCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.UpperCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.UpperCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.UpperCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.UpperCaseLetterEffect1Render[y][x].Off();

				this.UpperCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.UpperCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect2Render[y][x].Off();

				this.UpperCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.UpperCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.UpperCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.UpperCaseLetterEffect3Render[y][x].Off();

				this.UpperCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.UpperCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.UpperCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));

				if ("Z" === Start) {
					break;
				}
			}
		}
	}

	SetLowerCaseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(422, 312);

		let Start = 'a'.charCodeAt(0);

		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				this.LowerCaseButton[y][x] = Level.CreateActor(CharButton, PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
				this.LowerCaseButton[y][x].SetScale(this.ButtonScale);
				this.LowerCaseButton[y][x].SetRenderOrder(PM2RenderOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetCollisionOrder(PM2ActorOrder.Menu0_Button);
				this.LowerCaseButton[y][x].SetPos(ButtonStartPosition.add(this.ButtonScale.add(this.ButtonInterval).mul(new float4(y, x))));
				this.LowerCaseButton[y][x].SetReleaseImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetHoverImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].SetPressImage("SelectButton_Release.Bmp");
				this.LowerCaseButton[y][x].Chracter = Start++;
				this.LowerCaseButton[y][x].SetClickCallBack(SetPlayerName.PushBack_Button);
			}
		}
	}


	SetLowerCaseRender() {
		let Count = 0;
		for (let y = 0; y < 6; y++) {
			for (let x = 0; x < 5; x++) {
				let Start = "a";
				// 원본: Start[0] += Count++;
				Start = String.fromCharCode(Start.charCodeAt(0) + Count++);
				this.LowerCaseLetter1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				const LetterRenderPos = this.LowerCaseButton[y][x].GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale.hx(), this.LetterRenderHeight / 2));
				this.LowerCaseLetter1Render[y][x].SetPosition(LetterRenderPos);

				this.LowerCaseLetter2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetter2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale);
				this.LowerCaseLetter2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));

				this.LowerCaseLetterEffect1Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display);
				this.LowerCaseLetterEffect1Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale);
				this.LowerCaseLetterEffect1Render[y][x].SetPosition(LetterRenderPos);
				this.LowerCaseLetterEffect1Render[y][x].Off();

				this.LowerCaseLetterEffect2Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect2Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale);
				this.LowerCaseLetterEffect2Render[y][x].SetPosition(LetterRenderPos.add(float4.Up.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect2Render[y][x].Off();

				this.LowerCaseLetterEffect3Render[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
				this.LowerCaseLetterEffect3Render[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect3Color, this.ButtonScale);
				this.LowerCaseLetterEffect3Render[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				this.LowerCaseLetterEffect3Render[y][x].Off();

				this.LowerCaseLetterShadowRender[y][x] = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
				this.LowerCaseLetterShadowRender[y][x].SetText(Start, this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale);
				this.LowerCaseLetterShadowRender[y][x].SetPosition(LetterRenderPos.add(float4.Down.mul(new float4(0, 1))));
				if ("z" === Start) {
					break;
				}
			}
		}
	}

	SetCompleteButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(194, 448);

		this.CompleteButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.CompleteButton.SetScale(this.ButtonScale2);
		this.CompleteButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.CompleteButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.CompleteButton.SetPos(ButtonStartPosition);
		this.CompleteButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetHoverImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetPressImage("SelectButton_Release.Bmp");
		this.CompleteButton.SetClickCallBack(SetPlayerName.ClickCompleteButton);
	}

	SetCompleteButtonRender() {
		this.CompleteButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.CompleteButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.CompleteButton1Render.SetPosition(ButtonStartPosition);

		this.CompleteButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButton2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.CompleteButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.CompleteButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.CompleteButtonEffect1Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.CompleteButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.CompleteButtonEffect1Render.Off();

		this.CompleteButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect2Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.CompleteButtonEffect2Render.Off();

		this.CompleteButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.CompleteButtonEffect3Render.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.CompleteButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.CompleteButtonEffect3Render.Off();

		this.CompleteButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.CompleteButtonShadowRender.SetText("완료", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.CompleteButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}

	SetLetterEraseButton() {
		const Level = this.GetLevel();
		const ButtonStartPosition = new float4(266, 448);

		this.LetterEraseButton = Level.CreateActor(GlobalButton, PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetTargetCollisionGroup(PM2CollisionOrder.MousePoint);
		this.LetterEraseButton.SetScale(this.ButtonScale2);
		this.LetterEraseButton.SetRenderOrder(PM2RenderOrder.Menu0_Button);
		this.LetterEraseButton.SetCollisionOrder(PM2ActorOrder.Menu0_Button);
		this.LetterEraseButton.SetPos(ButtonStartPosition);
		this.LetterEraseButton.SetReleaseImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetHoverImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetPressImage("SelectButton_Release.Bmp");
		this.LetterEraseButton.SetClickCallBack(SetPlayerName.PopBack_PrintLetter);
	}

	SetLetterEraseButtonRender() {
		this.LetterEraseButton1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		const ButtonStartPosition = this.LetterEraseButton.GetPos().sub(this.GetPos()).sub(new float4(this.ButtonScale2.hx(), this.LetterRenderHeight / 2));
		this.LetterEraseButton1Render.SetPosition(ButtonStartPosition);

		this.LetterEraseButton2Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButton2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextColor, this.ButtonScale2);
		this.LetterEraseButton2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));

		this.LetterEraseButtonEffect1Render = this.CreateRender(PM2RenderOrder.Menu0_Display);
		this.LetterEraseButtonEffect1Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect1Color, this.ButtonScale2);
		this.LetterEraseButtonEffect1Render.SetPosition(ButtonStartPosition);
		this.LetterEraseButtonEffect1Render.Off();

		this.LetterEraseButtonEffect2Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect2Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect2Render.SetPosition(ButtonStartPosition.add(float4.Up.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect2Render.Off();

		this.LetterEraseButtonEffect3Render = this.CreateRender(PM2RenderOrder.Menu0_Display_Effect);
		this.LetterEraseButtonEffect3Render.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextEffect2Color, this.ButtonScale2);
		this.LetterEraseButtonEffect3Render.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
		this.LetterEraseButtonEffect3Render.Off();

		this.LetterEraseButtonShadowRender = this.CreateRender(PM2RenderOrder.Menu0_Display_Shadow);
		this.LetterEraseButtonShadowRender.SetText("뒤로", this.LetterRenderHeight, this.TextType, TextAlign.Center, this.TextShadowColor, this.ButtonScale2);
		this.LetterEraseButtonShadowRender.SetPosition(ButtonStartPosition.add(float4.Down.mul(new float4(0, 1))));
	}


	static PushBack_Button(_Btn) {
		if (8 <= SetPlayerName.PrintLetter.length) {
			return;
		}
		const Ptr = _Btn; // 원본: dynamic_cast<CharButton*>

		// 원본: PrintLetter.push_back(Ptr->Chracter); (char를 문자열에 추가)
		SetPlayerName.PrintLetter += String.fromCharCode(Ptr.Chracter);
	}

	static PopBack_PrintLetter(Button) {
		if (0 >= SetPlayerName.PrintLetter.length) {
			return;
		}
		// 원본: PrintLetter.pop_back();
		SetPlayerName.PrintLetter = SetPlayerName.PrintLetter.slice(0, -1);
	}

	static ClickCompleteButton(_Btn) {
		if (0 === SetPlayerName.PrintLetter.length) {
			SetPlayerName.ExplainRender1.SetText(SetPlayerName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetPlayerName.ErrorTextBoxScale);
			SetPlayerName.ExplainRender2.SetText(SetPlayerName.ErrorText, 18, "굴림", TextAlign.Center, RGB(0, 0, 0), SetPlayerName.ErrorTextBoxScale);
			SetPlayerName.ExplainRenderShadow.SetText(SetPlayerName.ErrorText, 18, "굴림", TextAlign.Center, RGB(106, 170, 126), SetPlayerName.ErrorTextBoxScale);
			return;
		}
		FirstSetLevel.SetStateValue(ActorState.SetOliveName);
		Olive.OlivePlayer.SetOliveLastName(SetPlayerName.PrintLetter);
		SetPlayerName.FirstUpdate = false;

		SetOliveName.FirstUpdate = false;
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetPrintLetter', 'PushBack_Button', 'PopBack_PrintLetter', 'ClickCompleteButton']) {
	Object.defineProperty(SetPlayerName.prototype, __m, { value: function (...args) { return SetPlayerName[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/SetPlayerName.js"] = {"SetPlayerName": SetPlayerName};
})();
(function () {

// ===== GameEngineContents/FirstSetLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineSoundPlayer = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineSoundPlayer"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var VK = __PM2_EXPORTS__["WinAPI.js"]["VK"];
var MousePoint = __PM2_EXPORTS__["GameEngineContents/MousePoint.js"]["MousePoint"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var SetPlayerName;
__PM2_LATE__.push(function () { SetPlayerName = __PM2_EXPORTS__["GameEngineContents/SetPlayerName.js"]["SetPlayerName"]; });
var SetOliveName;
__PM2_LATE__.push(function () { SetOliveName = __PM2_EXPORTS__["GameEngineContents/SetOliveName.js"]["SetOliveName"]; });
var OliveCalendar;
__PM2_LATE__.push(function () { OliveCalendar = __PM2_EXPORTS__["GameEngineContents/OliveCalendar.js"]["OliveCalendar"]; });
var PlayerCalendar;
__PM2_LATE__.push(function () { PlayerCalendar = __PM2_EXPORTS__["GameEngineContents/PlayerCalendar.js"]["PlayerCalendar"]; });
var SetPlayerAge;
__PM2_LATE__.push(function () { SetPlayerAge = __PM2_EXPORTS__["GameEngineContents/SetPlayerAge.js"]["SetPlayerAge"]; });
var SetOliveBloodType = __PM2_EXPORTS__["GameEngineContents/SetOliveBloodType.js"]["SetOliveBloodType"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// FirstSetLevel.h / FirstSetLevel.cpp 의 전사

// enum class ActorState
const ActorState = Object.freeze({
	NULLSTATE: 0,
	SetPlayerName: 1,
	SetOliveName: 2,
	OliveCalendar: 3,
	SetPlayerAge: 4,
	PlayerCalendar: 5,
	SetOliveBloodType: 6
});

class FirstSetLevel extends GameEngineLevel {
	static SetStateValue(_State) {
		FirstSetLevel.CurStateValue = _State;
	}

	constructor() {
		super();
		this.UpdateActor = null;

		this.AcOlive = null;
		this.AcSetPlayerName = null;
		this.AcSetOliveName = null;
		this.AcOliveCalendar = null;
		this.AcSetPlayerAge = null;
		this.AcPlayerCalendar = null;
		this.AcSetOliveBloodType = null;

		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	static CurStateValue = ActorState.NULLSTATE;
	static PrevStateValue = ActorState.NULLSTATE;

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);

		this.AcOlive = this.CreateActor(Olive, PM2ActorOrder.Olive);

		this.AcSetPlayerName = this.CreateActor(SetPlayerName, ActorState.SetPlayerName);
		this.AcSetOliveName = this.CreateActor(SetOliveName, ActorState.SetOliveName);
		this.AcOliveCalendar = this.CreateActor(OliveCalendar, ActorState.OliveCalendar);
		this.AcSetPlayerAge = this.CreateActor(SetPlayerAge, ActorState.SetPlayerAge);
		this.AcPlayerCalendar = this.CreateActor(PlayerCalendar, ActorState.PlayerCalendar);
		this.AcSetOliveBloodType = this.CreateActor(SetOliveBloodType, ActorState.SetOliveBloodType);

		FirstSetLevel.CurStateValue = ActorState.SetPlayerName;
		FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;

		if (true !== GameEngineInput.IsKey("ESC")) {
			GameEngineInput.CreateKey("ESC", VK.ESCAPE);
		}
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("Opening");
		}

		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}

		switch (FirstSetLevel.CurStateValue) {
			case ActorState.NULLSTATE:
				break;
			case ActorState.SetPlayerName:
				this.AcSetPlayerName.On();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;
				break;
			case ActorState.SetOliveName:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.On();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerName;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetPlayerName->FirstUpdate = false; (정적 멤버 접근)
					SetPlayerName.FirstUpdate = false;
				}
				break;
			case ActorState.OliveCalendar:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.On();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetOliveName;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetOliveName->FirstUpdate = false; (정적 멤버 접근)
					SetOliveName.FirstUpdate = false;
				}
				break;
			case ActorState.SetPlayerAge:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.On();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.OliveCalendar;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcOliveCalendar->FirstUpdate = false; (정적 멤버 접근)
					OliveCalendar.FirstUpdate = false;
				}
				break;
			case ActorState.PlayerCalendar:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.On();
				this.AcSetOliveBloodType.Off();
				FirstSetLevel.PrevStateValue = ActorState.SetPlayerAge;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcSetPlayerAge->FirstUpdate = false; (정적 멤버 접근)
					SetPlayerAge.FirstUpdate = false;
				}
				break;
			case ActorState.SetOliveBloodType:
				this.AcSetPlayerName.Off();
				this.AcSetOliveName.Off();
				this.AcOliveCalendar.Off();
				this.AcSetPlayerAge.Off();
				this.AcPlayerCalendar.Off();
				this.AcSetOliveBloodType.On();
				FirstSetLevel.PrevStateValue = ActorState.PlayerCalendar;
				if (true === GameEngineInput.IsDown("ESC")) {
					FirstSetLevel.CurStateValue = FirstSetLevel.PrevStateValue;
					// 원본: AcPlayerCalendar->FirstUpdate = false; (정적 멤버 접근)
					PlayerCalendar.FirstUpdate = false;
				}
				break;
			default:
				break;
		}
	}

	LevelChangeEnd(_NextLevel) {
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("01_Profile_determination.mp3");
		this.BGMPlayer.LoopCount(10000);
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("01_Profile_determination.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("ReleaseButton.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("HoverButton.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PressButton.BMP"));

		Dir.Move("Olive");
		Dir.Move("Head");
		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Body");
		Dir.Move("Body");

		// 원본: AllFile.clear();
		AllFile = [];
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("FirstSetLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BirthNum.BMP")).Cut(10, 1);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveCalendarNum.BMP")).Cut(32, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveYearNum.BMP")).Cut(10, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerYearNum.BMP")).Cut(10, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerCalendarNum.BMP")).Cut(32, 3);

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OliveWeek.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("PlayerWeek.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetOliveBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetOliveBirth.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetPlayerBackground.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SetPlayerBirth.BMP"));
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['SetStateValue']) {
	Object.defineProperty(FirstSetLevel.prototype, __m, { value: function (...args) { return FirstSetLevel[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"] = {"ActorState": ActorState, "FirstSetLevel": FirstSetLevel};
})();
(function () {

// ===== GameEngineContents/Logo.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// Logo.h / Logo.cpp 의 전사 (원본 h의 전방 선언 "class GameEnigneRender;" — 오타 포함 원문)

class Logo extends GameEngineActor {
	constructor() {
		super();
		this.PM2Logo = null;
	}

	Start() {
		this.PM2Logo = this.CreateRender("TitleLogo.BMP", PM2RenderOrder.TitleLogo);
		this.PM2Logo.SetScaleToImage();
		this.SetPos(new float4(400, 250));
		this.Off();
	}
}

__PM2_EXPORTS__["GameEngineContents/Logo.js"] = {"Logo": Logo};
})();
(function () {

// ===== GameEngineContents/Menu.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
// Menu.h / Menu.cpp 의 전사

class Menu extends GameEngineActor {
	constructor() {
		super();
		this.LowMenu = [];
	}
}

__PM2_EXPORTS__["GameEngineContents/Menu.js"] = {"Menu": Menu};
})();
(function () {

// ===== GameEngineContents/OpeningCredit.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// OpeningCredit.h / OpeningCredit.cpp 의 전사

class OpeningCredit extends GameEngineActor {
	constructor() {
		super();
		this.MoveSpeed = 100.0;
		this.Time = 0.0;
		this.ScrollTime = 20.0;
		this.StartPos = float4.Zero;
		this.EndPos = float4.Zero;

		this.CreditRender = null;
	}

	UpdateScroll(_DeltaTime) {
		this.Time += _DeltaTime / this.ScrollTime;
		this.CreditRender.SetPosition(float4.LerpClamp(this.StartPos, this.EndPos, this.Time));
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.CreditRender = this.CreateRender("Credit.BMP", PM2RenderOrder.BackGroundObj);
		this.CreditRender.SetScaleToImage();
		this.StartPos = new float4(0, 700);
		this.EndPos = new float4(0, -700);
		const TopBox = this.CreateRender("BlackBox.BMP", PM2RenderOrder.CaptionBox);
		TopBox.SetScale(new float4(800, 100));
		TopBox.SetPosition(new float4(0, -250));
		const BotBox = this.CreateRender("BlackBox.BMP", PM2RenderOrder.CaptionBox);
		BotBox.SetScale(new float4(800, 100));
		BotBox.SetPosition(new float4(0, 250));
		this.Off();
	}

	Update(_DeltaTime) {
	}

	Render(_Time) {
	}
}

__PM2_EXPORTS__["GameEngineContents/OpeningCredit.js"] = {"OpeningCredit": OpeningCredit};
})();
(function () {

// ===== GameEngineContents/OpeningDate.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var NumberRenderObject = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["NumberRenderObject"];
var Align = __PM2_EXPORTS__["GameEngineCore/NumberRenderObject.js"]["Align"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var RGB = __PM2_EXPORTS__["WinAPI.js"]["RGB"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// OpeningDate.h / OpeningDate.cpp 의 전사

class OpeningDate extends GameEngineActor {
	constructor() {
		super();
		this.OpeningDateRender = null;
		this.MonthNum = new NumberRenderObject();
		this.DayNum = new NumberRenderObject();
		this.OliveBirthDay = new Date();
	}

	UpdateOliveBirthDay() {
		this.OliveBirthDay = Olive.OlivePlayer.GetOliveBirthDay();
		this.MonthNum.SetValue(this.OliveBirthDay.GetMonth());
		this.DayNum.SetValue(this.OliveBirthDay.GetDay());
		this.MonthNum.SetMove(new float4(120, 0));
		this.DayNum.SetMove(new float4(250, 0));
	}

	Start() {
		this.SetPos(new float4(400, 300));

		this.OpeningDateRender = this.CreateRender("OpeningDate.bmp", PM2RenderOrder.Menu0);
		this.OpeningDateRender.SetScaleToImage();

		this.MonthNum.SetOwner(this);
		this.MonthNum.SetImage("OpeningDayNum.bmp", new float4(40, 63), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.MonthNum.SetAlign(Align.Right);
		this.MonthNum.SetValue(11);
		this.MonthNum.SetMove(new float4(120, 0));

		this.DayNum.SetOwner(this);
		this.DayNum.SetImage("OpeningDayNum.bmp", new float4(40, 63), PM2RenderOrder.Menu0_Display, RGB(255, 0, 255));
		this.DayNum.SetAlign(Align.Right);
		this.DayNum.SetValue(11);
		this.DayNum.SetMove(new float4(250, 0));

		this.Off();
	}
}

__PM2_EXPORTS__["GameEngineContents/OpeningDate.js"] = {"OpeningDate": OpeningDate};
})();
(function () {

// ===== GameEngineContents/UpperDialog.js =====
var Dialog = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["Dialog"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// UpperDialog.h / UpperDialog.cpp 의 전사

class UpperDialog extends Dialog {
	constructor() {
		super();
	}

	Start() {
		// 원본: Dialog::Start();
		super.Start();
		this.SetPos(GameEngineWindow.GetScreenSize().half());
	}
}

__PM2_EXPORTS__["GameEngineContents/UpperDialog.js"] = {"UpperDialog": UpperDialog};
})();
(function () {

// ===== GameEngineContents/OpeningLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineSoundPlayer = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineSoundPlayer"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MousePoint = __PM2_EXPORTS__["GameEngineContents/MousePoint.js"]["MousePoint"];
var Olive = __PM2_EXPORTS__["GameEngineContents/Olive.js"]["Olive"];
var Caption = __PM2_EXPORTS__["GameEngineContents/Caption.js"]["Caption"];
var UpperDialog = __PM2_EXPORTS__["GameEngineContents/UpperDialog.js"]["UpperDialog"];
var BottomDialog = __PM2_EXPORTS__["GameEngineContents/BottomDialog.js"]["BottomDialog"];
var Cutscene = __PM2_EXPORTS__["GameEngineContents/Cutscene.js"]["Cutscene"];
var BackgroundColor = __PM2_EXPORTS__["GameEngineContents/Cutscene.js"]["BackgroundColor"];
var OpeningCredit = __PM2_EXPORTS__["GameEngineContents/OpeningCredit.js"]["OpeningCredit"];
var OpeningDate = __PM2_EXPORTS__["GameEngineContents/OpeningDate.js"]["OpeningDate"];
var Logo = __PM2_EXPORTS__["GameEngineContents/Logo.js"]["Logo"];
var MugShotLR = __PM2_EXPORTS__["GameEngineContents/Dialog.js"]["MugShotLR"];
var Date = __PM2_EXPORTS__["GameEngineContents/Date.js"]["Date"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PatronGod = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PatronGod"];
// OpeningLevel.h / OpeningLevel.cpp 의 전사

class OpeningLevel extends GameEngineLevel {
	constructor() {
		super();
		this.AcOlive = null;
		this.FatherName = "";

		this.GodPicImageString = "";
		this.GodName = "";
		this.PatronGodSex = 0;

		this.AcCaption = null;
		this.AcCutScene = null;
		this.AcUpperDialog = null;
		this.AcBottomDialog = null;
		this.AcOpeningCredit = null;
		this.AcOpeningDate = null;
		this.AcLogo = null;
		this.Time = 0.0;

		this.BGMPlayer = new GameEngineSoundPlayer();
		this.BGMChange = false;
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.AcCaption = this.CreateActor(Caption);
		this.AcUpperDialog = this.CreateActor(UpperDialog);
		this.AcBottomDialog = this.CreateActor(BottomDialog);
		this.AcCutScene = this.CreateActor(Cutscene);
		this.AcOpeningCredit = this.CreateActor(OpeningCredit);
		this.AcOpeningDate = this.CreateActor(OpeningDate);
		this.AcLogo = this.CreateActor(Logo);

		if (false === GameEngineInput.IsKey("2")) {
			GameEngineInput.CreateKey("2", '2'.charCodeAt(0));
		}
	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}

		let LocalDeltaTime = _DeltaTime;

		if (GameEngineInput.IsPress("2")) {
			LocalDeltaTime *= 16;
			this.Time += LocalDeltaTime;
		}
		else {
			this.Time += LocalDeltaTime;
		}

		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}

		if (0 <= this.Time && 20 > this.Time) {
			this.AcCutScene.On();
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.Black);
			this.AcCutScene.OffCutScene();

			this.AcOpeningCredit.On();
			this.AcOpeningCredit.UpdateScroll(LocalDeltaTime);
		}
		else if (20 <= this.Time && 35 > this.Time) {
			this.AcOpeningCredit.Off();
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.White);
			this.AcCutScene.OnCutScene(0);
			if (22 <= this.Time && 26 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그것은 일방적인 싸움이었다…");
			}
			else if (26 <= this.Time && 27 > this.Time) {
				this.AcCaption.Off();
			}
			else if (27 <= this.Time && 31 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("평화에 길들여진 수도의 군대는\n막강한 마왕군 앞에 추풍낙엽처럼 쓰러져갔다.");
			}
			else if (31 <= this.Time && 32 > this.Time) {
				this.AcCaption.Off();
			}
			else if (32 <= this.Time && 35 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("성벽은 무너지고 거리는 불길에 휩싸였다.\n수도의 함락은 목전까지 닥친 상황이었다.");
			}
		}
		else if (35 <= this.Time && 75 > this.Time) {
			this.AcCaption.Off();
			this.AcCutScene.OnCutScene(1);

			if (37 <= this.Time && 41 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그때 그 참상을 목격한 방랑검사가 있었다. 그의 이름은 " + this.FatherName + "." + "\n그는 스스로 마왕과의 싸움에 몸을 던졌다");
			}
			else if (41 <= this.Time && 42 > this.Time) {
				this.AcCaption.Off();
			}
			else if (42 <= this.Time && 46 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("초승달이 뜬 밤, 마왕의 진영에 잠입한 " + this.FatherName + "." + "\n그는 1대1의 결투 끝에 마왕에게 승리했다.");
			}
			else if (46 <= this.Time && 47 > this.Time) {
				this.AcUpperDialog.On();
				this.AcUpperDialog.SetMugPic("Mug_Devil.bmp");
				this.AcUpperDialog.SetMugLoc(MugShotLR.Left);
				this.AcUpperDialog.SetUpdateText("「우우… 나의 패배다」");
			}
			else if (51 <= this.Time && 56 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「그러나 용자여. 너는 어째서\n싸우는가?」");
			}
			else if (56 <= this.Time && 64 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「타락한 도시를 벌함은 하늘의 뜻.\n 너와는 아무 상관 없는 어리석은\n 자들이 멸망할 뿐이다」");
			}
			else if (64 <= this.Time && 65 > this.Time) {
				this.AcUpperDialog.Off();
			}
			else if (65 <= this.Time && 69 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그 질문에 대한 " + this.FatherName + "의 대답은 전해지지 않는다.");
			}
			else if (69 <= this.Time && 70 > this.Time) {
				this.AcCaption.Off();
			}
			else if (70 <= this.Time && 74 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("얼마 후 마왕은 상처 입은 몸을 치료하기 위해\n군대를 이끌고 지저로 돌아갔다…");
			}
			else if (74 <= this.Time && 75 > this.Time) {
				this.AcCaption.Off();
			}
		}
		else if (75 <= this.Time && 115 > this.Time) {
			this.AcCutScene.OnCutScene(2);
			if (77 <= this.Time && 83 > this.Time) {
				this.AcUpperDialog.On();
				this.AcUpperDialog.SetMugPic("Mug_King.bmp");
				this.AcUpperDialog.SetMugLoc(MugShotLR.Right);
				this.AcUpperDialog.SetUpdateText("「오오, 용사여. 훌륭하게 이 도시를 \n구해주셨소」");
			}
			else if (83 <= this.Time && 92 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「이번 전쟁은 어리석은 짐에게 \n내려진신벌이오. 귀공이 없었다면 \n시민들과 함께 멸망했을 게요…」");
			}
			else if (92 <= this.Time && 102 > this.Time) {
				this.AcBottomDialog.On();
				this.AcBottomDialog.SetMugPic("Mug_Queen.bmp");
				this.AcBottomDialog.SetMugLoc(MugShotLR.Left);
				this.AcBottomDialog.SetUpdateText("「이 일은 우리들에게 내려진 \n신벌… 저도 왕도 이제부터 마음을 \n바꾸어 이곳이 좋은 도읍이 \n되도록 일하겠습니다」");
			}
			else if (102 <= this.Time && 114 > this.Time) {
				this.AcUpperDialog.SetUpdateText("「보아하니 귀공도 부상을 당했\n구려. 이곳에 머물며 도읍의 재\n건을 도와줄 순 없겠는지. 짐이 \n간곡히 부탁하겠소」");
			}
			else if (114 <= this.Time && 115 > this.Time) {
				this.AcUpperDialog.Off();
				this.AcBottomDialog.Off();
			}
		}
		else if (115 <= this.Time && 119 > this.Time) {
			this.AcCutScene.SelectBackgroundColor(BackgroundColor.Black);
			this.AcCutScene.OffCutScene();
			if (116 <= this.Time && 119 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("이리하여 도시에 정착해 왕의 녹봉을 받게 된 용사 " + this.FatherName + ".");
			}
		}
		else if (119 <= this.Time && 122 > this.Time) {
			this.AcCaption.Off();
			this.AcOpeningDate.On();
		}
		else if (122 <= this.Time && 144 > this.Time) {
			if (false === this.BGMChange) {
				this.BGMChange = true;
				this.BGMPlayer.Stop();
				this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("03_Opening_2.mp3");
			}
			this.AcCutScene.OnCutScene(3);
			this.AcOpeningDate.Off();
			if (125 <= this.Time && 130 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그러던 어느 아름다운 밤, " + this.FatherName + "의 이름을 부르는 듯한 느낌이 들었다…");
			}
			else if (130 <= this.Time && 134 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("「용사여……」");
			}
			else if (134 <= this.Time && 135 > this.Time) {
				this.AcCaption.Off();
			}
			else if (135 <= this.Time && 140 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("하늘에서 " + this.FatherName + "의 이름을 부르는 목소리가 들린다…");
			}
			else if (140 <= this.Time && 141 > this.Time) {
				this.AcCaption.Off();
			}
			else if (141 <= this.Time && 144 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("올려다보니, 한 줄기의 유성이 긴 꼬리를 끌며 천천히 눈앞의 언덕에 떨어졌다.");
			}
		}
		else if (144 <= this.Time && 149 > this.Time) {
			this.AcCaption.SetUpdateText("언덕으로 달려간 " + this.FatherName + ". 그곳에는 커다란 빛덩어리가 떠 있었다.");
			this.AcCutScene.OffCutScene();
		}
		else if (149 <= this.Time && 172 > this.Time) {
			this.AcCutScene.OnCutScene(4);
			if (149 <= this.Time && 150 > this.Time) {
				this.AcCaption.Off();
			}
			else if (150 <= this.Time && 155 > this.Time) {
				this.AcCaption.SetUpdateText("그리고, 빛속에는 어린 여자아이가…");
			}
			else if (155 <= this.Time && 156 > this.Time) {
				this.AcCaption.Off();
			}
			else if (156 <= this.Time && 161 > this.Time) {
				this.AcBottomDialog.On();
				this.AcBottomDialog.SetMugPic(this.GodPicImageString);
				this.AcBottomDialog.SetMugLoc(MugShotLR.Right);
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「용사여…나는 이 소녀의 수호\n자 " + this.GodName + "」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「용사여…나는 이 소녀의 수호\n자 " + this.GodName + "...」");
				}
			}
			else if (161 <= this.Time && 171 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이는 태어나서 오늘에 \n이르기까지 성스러운 빛의 안에\n서 자라 현세의 더러움을 일절 \n알지 못하는 순수한 영혼을 지\n닌 자다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이는 태어나서 오늘에 \n이르기까지 성스러운 빛의 안에\n서 자라 현세의 더러움을 일절 \n알지 못하는 순수한 영혼을 지\n닌 자…」");
				}
			}
			else if (171 <= this.Time && 172 > this.Time) {
				this.AcBottomDialog.Off();
			}
		}
		else if (172 <= this.Time && 200 > this.Time) {
			this.AcCutScene.OnCutScene(5);
			if (174 <= this.Time && 178 > this.Time) {
				this.AcBottomDialog.On();
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「바로 지금 그대에게 이 아이\n를 맡기겠다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「바로 지금 당신에게 이 아이\n를 맡기겠습니다」");
				}
			}
			else if (178 <= this.Time && 185 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이의 생과 사, 또한 어\n떠한 인생을 보내게 될 것인지\n도, 모두 그대에게 달렸다」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그 아이가 사는 것도 죽는 것\n도 또한 어떠한 인생을 보내게\n 되는 지도, 전부 당신 하기 나\n름」");
				}
			}
			else if (185 <= this.Time && 191 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「모든것이 그대에게 달려있는 \n것이다. 그래, 모든 것이 말이지\n…」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「모든 것이 당신에게 달려있는 \n겁니다. 그래요, 모든 것이…」");
				}
			}
			else if (191 <= this.Time && 198 > this.Time) {
				if (0 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그럼 부탁하네. \n나는 항상 하늘에서 그대들 부\n녀를 지켜보고 있겠다……」");
				}
				else if (1 === this.PatronGodSex) {
					this.AcBottomDialog.SetUpdateText("「그럼 부탁드립니다. \n저는 항상 하늘에서 당신들 부\n녀를 지켜보겠습니다……」");
				}
			}
			else if (198 <= this.Time && 199 > this.Time) {
				this.AcBottomDialog.Off();
			}
		}
		else if (200 <= this.Time && 205 > this.Time) {
			this.AcCutScene.OffCutScene();
			if (200 <= this.Time && 205 > this.Time) {
				this.AcCaption.On();
				this.AcCaption.SetUpdateText("그리고 1년이 지났다……");
			}
		}
		else if (205 <= this.Time && 215 > this.Time) {
			this.AcCaption.Off();
			this.AcCutScene.OnCutScene(6);
			if (208 <= this.Time && 215 > this.Time) {
				this.AcLogo.On();
			}
		}
		else {
			GameEngineCore.GetInst().ChangeLevel("RaisingSim");
		}
	}

	LevelChangeEnd(_NextLevel) {
		// 원본: dynamic_cast<RaisingSimLevel*>(_NextLevel)->SetToday(...)
		_NextLevel.SetToday(new Date(1210, Olive.OlivePlayer.GetOliveBirthDay().GetMonth(), Olive.OlivePlayer.GetOliveBirthDay().GetDay()));
		this.BGMPlayer.Stop();
	}

	LevelChangeStart(_PrevLevel) {
		this.BGMPlayer = GameEngineResources.GetInst().SoundPlayToControl("02_Opening_1.mp3");
		this.AcOlive = Olive.OlivePlayer;
		this.AcOpeningDate.UpdateOliveBirthDay();
		this.FatherName = this.AcOlive.GetOliveLastName();
		if (PatronGod["태양신_솔"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Sol_God.bmp";
			this.GodName = "태양신 솔";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["달신_더문"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_TheMoon_God.bmp";
			this.GodName = "달의신 더 문";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["화성신_마르스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Mars_God.bmp";
			this.GodName = "화성신 마르스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["수성신_머큐리"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Mercury_God.bmp";
			this.GodName = "수성신 머큐리";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["목성신_주피터"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Jupiter_God.bmp";
			this.GodName = "목성신 주피터";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["금성신_비너스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Venus_God.bmp";
			this.GodName = "금성신 비너스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["토성신_새턴"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Saturn_God.bmp";
			this.GodName = "토성신 새턴";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["천왕성신_우라누스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Uranus_God.bmp";
			this.GodName = "천왕성신 우라누스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["해왕성신_넵튠"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Neptune_God.bmp";
			this.GodName = "해왕성신 넵튠";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
		else if (PatronGod["명왕성신_하데스"] === this.AcOlive.GetPatronGod()) {
			this.GodPicImageString = "Mug_Hades_God.bmp";
			this.GodName = "명왕성신 하데스";
			this.PatronGodSex = this.AcOlive.GetPatronGodSex();
		}
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("02_Opening_1.mp3"));
		GameEngineResources.GetInst().SoundLoad(Dir.GetPlusFileName("03_Opening_2.mp3"));
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MugShotFrame_God.BMP"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("MugShotFrame_Nomal.BMP"));

		Dir.Move("OpeningLevel");

		let AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.Move("MugShot");
		AllFile = Dir.GetAllFile();
		for (let i = 0; i < AllFile.length; i++) {
			GameEngineResources.GetInst().ImageLoad(AllFile[i].GetFullPath());
		}

		Dir.MoveParentToDirectory("Num");
		Dir.Move("Num");
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("OpeningDayNum.BMP")).Cut(10, 1);
	}
}

__PM2_EXPORTS__["GameEngineContents/OpeningLevel.js"] = {"OpeningLevel": OpeningLevel};
})();
(function () {

// ===== GameEngineContents/RPGOlive.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var FrameAnimationParameter = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["FrameAnimationParameter"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// RPGOlive.h / RPGOlive.cpp 의 전사

// enum class PlayerState
const PlayerState = Object.freeze({
	IDLE: 0,
	MOVE: 1,
});


class RPGOlive extends GameEngineActor {
	static MainPlayer = null;

	constructor() {
		super();
		this.AccTime = 0.0;
		this.StartFrame = 0;
		this.MoveSpeed = 100.0;
		this.AnimationRender = null;
		this.StateValue = PlayerState.IDLE;
		this.DirString = "Right_";
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		RPGOlive.MainPlayer = this;
		if (false === GameEngineInput.IsKey("LeftMove"))
		{
			GameEngineInput.CreateKey("LeftMove", 'A'.charCodeAt(0));
			GameEngineInput.CreateKey("RightMove", 'D'.charCodeAt(0));
			GameEngineInput.CreateKey("DownMove", 'S'.charCodeAt(0));
			GameEngineInput.CreateKey("UpMove", 'W'.charCodeAt(0));
		}

		this.AnimationRender = this.CreateRender(1);
		this.AnimationRender.SetScale(new float4(40, 60));

		// 원본: CreateAnimation({ .AnimationName = "Down_Move", .ImageName = "Olive.bmp", .Start = 0, .End = 1, .InterTime = 0.2f });
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Down_Move", "Olive.bmp", 0, 1, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Down_Idle", "Olive.bmp", 0, 0, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Up_Move", "Olive.bmp", 2, 3, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Up_Idle", "Olive.bmp", 2, 2, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Left_Move", "Olive.bmp", 4, 5, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Left_Idle", "Olive.bmp", 4, 4, 0, 0.2, true));

		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Right_Move", "Olive.bmp", 6, 7, 0, 0.2, true));
		this.AnimationRender.CreateAnimation(new FrameAnimationParameter("Right_Idle", "Olive.bmp", 6, 6, 0, 0.2, true));

		this.ChangeState(PlayerState.IDLE);
	}

	Update(_DeltaTime) {
		this.UpdateState(_DeltaTime);

	}

	Render(_Time) {
	}


	DirCheck(_AnimationName) {
		const PrevDirString = this.DirString;
		this.AnimationRender.ChangeAnimation(this.DirString + _AnimationName);

		if (GameEngineInput.IsPress("LeftMove"))
		{
			this.DirString = "Left_";
		}
		else if (GameEngineInput.IsPress("RightMove"))
		{
			this.DirString = "Right_";
		}
		else if (GameEngineInput.IsPress("UpMove"))
		{
			this.DirString = "Up_";
		}
		else if (GameEngineInput.IsPress("DownMove"))
		{
			this.DirString = "Down_";
		}

		if (PrevDirString !== this.DirString)
		{
			this.AnimationRender.ChangeAnimation(this.DirString + _AnimationName);
		}
	}


	ChangeState(_State) {
		const NextState = _State;
		const PrevState = this.StateValue;

		this.StateValue = NextState;

		switch (NextState)
		{
			case PlayerState.IDLE:
				this.IdleStart();
				break;

			case PlayerState.MOVE:
				this.MoveStart();
				break;

			default:
				break;
		}
	}

	UpdateState(_Time) {
		switch (this.StateValue)
		{
			case PlayerState.IDLE:
				this.IdleUpdate(_Time);
				break;

			case PlayerState.MOVE:
				this.MoveUpdate(_Time);
				break;

			default:
				break;
		}
	}

	IdleStart() {
		this.DirCheck("Idle");
	}

	IdleUpdate(_DeltaTime) {
		if (GameEngineInput.IsPress("LeftMove") || GameEngineInput.IsPress("RightMove") || GameEngineInput.IsPress("UpMove") || GameEngineInput.IsPress("DownMove"))
		{
			this.ChangeState(PlayerState.MOVE);
			return;
		}
	}

	IdleEnd() {
	}

	MoveStart() {
		this.DirCheck("Move");
	}

	MoveUpdate(_DeltaTime) {
		if (false === GameEngineInput.IsPress("LeftMove") &&
			false === GameEngineInput.IsPress("RightMove") &&
			false === GameEngineInput.IsPress("UpMove") &&
			false === GameEngineInput.IsPress("DownMove"))
		{
			this.ChangeState(PlayerState.IDLE);
			return;
		}

		if (GameEngineInput.IsPress("LeftMove"))
		{
			this.SetMove(float4.Left.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("RightMove"))
		{
			this.SetMove(float4.Right.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("UpMove"))
		{
			this.SetMove(float4.Up.scale(this.MoveSpeed * _DeltaTime));
		}
		else if (GameEngineInput.IsPress("DownMove"))
		{
			this.SetMove(float4.Down.scale(this.MoveSpeed * _DeltaTime));
		}
		this.DirCheck("Move");
	}

	MoveEnd() {
	}
}

__PM2_EXPORTS__["GameEngineContents/RPGOlive.js"] = {"PlayerState": PlayerState, "RPGOlive": RPGOlive};
})();
(function () {

// ===== GameEngineContents/RPGLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var MousePoint = __PM2_EXPORTS__["GameEngineContents/MousePoint.js"]["MousePoint"];
var RPGOlive = __PM2_EXPORTS__["GameEngineContents/RPGOlive.js"]["RPGOlive"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// RPGLevel.h / RPGLevel.cpp 의 전사

class RPGLevel extends GameEngineLevel {
	constructor() {
		super();
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();
	}

	Update(_DeltaTime) {
	}

	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	SoundLoad() {
	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();
		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");
		Dir.Move("RPGLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Olive.BMP")).Cut(8, 1);

		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.CreateActor(RPGOlive);
	}
}

__PM2_EXPORTS__["GameEngineContents/RPGLevel.js"] = {"RPGLevel": RPGLevel};
})();
(function () {

// ===== GameEngineContents/TitleBackground.js =====
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
// TitleBackground.h / TitleBackground.cpp 의 전사

class TitleBackground extends GameEngineActor {
	constructor() {
		super();
		this.Render = null;
	}

	Start() {
		this.SetPos(GameEngineWindow.GetScreenSize().half());
		this.Render = this.CreateRender("blackbackground.BMP", 0);
		this.Render.SetScaleToImage();
	}
}

__PM2_EXPORTS__["GameEngineContents/TitleBackground.js"] = {"TitleBackground": TitleBackground};
})();
(function () {

// ===== GameEngineContents/TitleMenu.js =====
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var Button = __PM2_EXPORTS__["GameEngineCore/Button.js"]["Button"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var SelectionMenu = __PM2_EXPORTS__["GameEngineContents/SelectionMenu.js"]["SelectionMenu"];
var GaugeRenderObject = __PM2_EXPORTS__["GameEngineContents/GaugeRenderObject.js"]["GaugeRenderObject"];
var MenuFrameStyleEnum = __PM2_EXPORTS__["GameEngineContents/MenuFrame.js"]["MenuFrameStyleEnum"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
var PM2RenderOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2RenderOrder"];
// TitleMenu.h / TitleMenu.cpp 의 전사

class TitleMenu extends SelectionMenu {
	constructor() {
		super();
		this.TextRender = null;
	}

	static LevelChangeToFirstSet(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("FirstSet");
	}

	static LevelChangeToOpening(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("Opening");
	}

	static LevelChangeToRaisingSim(_Btn) {
		GameEngineCore.GetInst().ChangeLevel("RaisingSim");
	}

	Start() {
		this.InitMenuFrameRender(PM2RenderOrder.Menu0, MenuFrameStyleEnum.Gold);
		this.SetSelectionMenu(3, new float4(400, 250), 230.0, PM2ActorOrder.Menu0_Button, PM2RenderOrder.Menu0_Button);
		this.GetSelectButtons()[0].SetClickCallBack(TitleMenu.LevelChangeToFirstSet);
		this.GetSelectButtons()[1].SetClickCallBack(TitleMenu.LevelChangeToOpening);
		this.GetSelectButtons()[2].SetClickCallBack(TitleMenu.LevelChangeToRaisingSim);
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 0, "처음부터 시작");
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 1, "처음부터 (오프닝 스킵)");
		this.SetButtonString(PM2RenderOrder.Menu0_Display, 2, "시간을 되돌린다");
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['LevelChangeToFirstSet', 'LevelChangeToOpening', 'LevelChangeToRaisingSim']) {
	Object.defineProperty(TitleMenu.prototype, __m, { value: function (...args) { return TitleMenu[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/TitleMenu.js"] = {"TitleMenu": TitleMenu};
})();
(function () {

// ===== GameEngineContents/TitleLevel.js =====
var GameEngineLevel = __PM2_EXPORTS__["GameEngineCore/GameEngineLevel.js"]["GameEngineLevel"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineSoundPlayer = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineSoundPlayer"];
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var GameEngineInput = __PM2_EXPORTS__["GameEnginePlatform/GameEngineInput.js"]["GameEngineInput"];
var GameEngineDirectory = __PM2_EXPORTS__["GameEngineBase/GameEngineDirectory.js"]["GameEngineDirectory"];
var TitleMenu = __PM2_EXPORTS__["GameEngineContents/TitleMenu.js"]["TitleMenu"];
var TitleBackground = __PM2_EXPORTS__["GameEngineContents/TitleBackground.js"]["TitleBackground"];
var MousePoint = __PM2_EXPORTS__["GameEngineContents/MousePoint.js"]["MousePoint"];
var PM2ActorOrder = __PM2_EXPORTS__["GameEngineContents/ContentsEnums.js"]["PM2ActorOrder"];
// TitleLevel.h / TitleLevel.cpp 의 전사

class TitleLevel extends GameEngineLevel {
	constructor() {
		super();
		this.TitleSelectionMenu = null;
		this.BGMPlayer = new GameEngineSoundPlayer();
	}

	Loading() {
		this.SoundLoad();
		this.ImageLoad();

		if (false === GameEngineInput.IsKey("LevelChange")) {
			GameEngineInput.CreateKey("LevelChange", 'P'.charCodeAt(0));
		}

		if (false === GameEngineInput.IsKey("1")) {
			GameEngineInput.CreateKey("1", '1'.charCodeAt(0));
		}

		this.CreateActor(TitleBackground, PM2ActorOrder.BackGround);
		this.CreateActor(MousePoint, PM2ActorOrder.MousePoint);
		this.TitleSelectionMenu = this.CreateActor(TitleMenu, PM2ActorOrder.Menu0);

	}

	Update(_DeltaTime) {
		if (true === GameEngineInput.IsDown("LevelChange")) {
			GameEngineCore.GetInst().ChangeLevel("FirstSet");
		}

		if (true === GameEngineInput.IsDown("1")) {
			GameEngineCore.GetInst().DebugSwitch();
		}
	}

	// 원본 h에서 inline {}: void LevelChangeEnd(...) override {}; / void LevelChangeStart(...) override {};
	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	SoundLoad() {
		const Dir = new GameEngineDirectory();
		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Sound");

	}

	ImageLoad() {
		const Dir = new GameEngineDirectory();

		Dir.MoveParentToDirectory("ContentsResources");
		Dir.Move("ContentsResources");
		Dir.Move("Image");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SelectButton_Release.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("SelectButton_Hover.bmp"));
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample1.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample2.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("FrameSample3.BMP")).Cut(3, 3);
		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("Cursor.bmp"));

		Dir.Move("TitleLevel");

		GameEngineResources.GetInst().ImageLoad(Dir.GetPlusFileName("BlackBackground.BMP"));
	}
}

__PM2_EXPORTS__["GameEngineContents/TitleLevel.js"] = {"TitleLevel": TitleLevel};
})();
(function () {

// ===== GameEngineContents/PM2Core.js =====
var GameEngineCore = __PM2_EXPORTS__["GameEngineCore/GameEngineCore.js"]["GameEngineCore"];
var TitleLevel = __PM2_EXPORTS__["GameEngineContents/TitleLevel.js"]["TitleLevel"];
var FirstSetLevel = __PM2_EXPORTS__["GameEngineContents/FirstSetLevel.js"]["FirstSetLevel"];
var OpeningLevel = __PM2_EXPORTS__["GameEngineContents/OpeningLevel.js"]["OpeningLevel"];
var RaisingSimLevel = __PM2_EXPORTS__["GameEngineContents/RaisingSimLevel.js"]["RaisingSimLevel"];
var RPGLevel = __PM2_EXPORTS__["GameEngineContents/RPGLevel.js"]["RPGLevel"];
var EndingLevel = __PM2_EXPORTS__["GameEngineContents/EndingLevel.js"]["EndingLevel"];
// PM2Core.h / PM2Core.cpp 의 전사

class PM2Core extends GameEngineCore {
	static Core = new PM2Core();

	static GetInst() {
		return this.Core;
	}

	constructor() {
		super();
	}

	Start() {
		this.CreateLevel("Title", TitleLevel);
		this.CreateLevel("FirstSet", FirstSetLevel);
		this.CreateLevel("Opening", OpeningLevel);
		this.CreateLevel("RaisingSim", RaisingSimLevel);
		this.CreateLevel("RPG", RPGLevel);
		this.CreateLevel("Ending", EndingLevel);

		this.ChangeLevel("Title");
	}

	Update() {
	}

	End() {
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetInst']) {
	Object.defineProperty(PM2Core.prototype, __m, { value: function (...args) { return PM2Core[__m](...args); }, writable: true, configurable: true });
}


__PM2_EXPORTS__["GameEngineContents/PM2Core.js"] = {"PM2Core": PM2Core};
})();
(function () {

// ===== GameEngineCore/GameEngineTileMap.js =====
var float4 = __PM2_EXPORTS__["GameEngineBase/GameEngineMath.js"]["float4"];
var MsgAssert = __PM2_EXPORTS__["GameEngineBase/GameEngineDebug.js"]["MsgAssert"];
var GameEngineActor = __PM2_EXPORTS__["GameEngineCore/GameEngineActor.js"]["GameEngineActor"];
var GameEngineWindow = __PM2_EXPORTS__["GameEnginePlatform/GameEngineWindow.js"]["GameEngineWindow"];
var GameEngineResources = __PM2_EXPORTS__["GameEngineCore/GameEngineResources.js"]["GameEngineResources"];
var GameEngineRender = __PM2_EXPORTS__["GameEngineCore/GameEngineRender.js"]["GameEngineRender"];
var GameEngineCollision = __PM2_EXPORTS__["GameEngineCore/GameEngineCollision.js"]["GameEngineCollision"];
// GameEngineTileMap.h / GameEngineTileMap.cpp 의 전사

class FloorInfo {
}

class GameEngineTileMap extends GameEngineActor {
	constructor() {
		super();
		this.ScreenSize = new float4(0, 0, 0, 1); // float4::Zero
		this.TileScale = new float4(0, 0, 0, 1);
		this.X = -1;
		this.Y = -1;
		this.Z = -1;
		this.FloorImageName = [];
		this.TileRenders = [];
		this.TileCollision = [];
	}

	CreateTileMap(_X, _Y, _Z, _Order, _TileSize) {
		const ScreenSize = GameEngineWindow.GetScreenSize();

		this.TileScale = _TileSize;

		this.TileRenders.length = _Z;
		this.FloorImageName.length = _Z;

		this.X = _X;
		this.Y = _Y;
		this.Z = _Z;

		for (let z = 0; z < _Z; z++) {
			this.TileRenders[z] = this.TileRenders[z] || [];
			for (let y = 0; y < _Y; y++) {
				this.TileRenders[z][y] = this.TileRenders[z][y] || [];
				for (let x = 0; x < _X; x++) {
					const Render = this.CreateRender(0);

					const TilePos = new float4(_TileSize.x, _TileSize.y, _TileSize.z, _TileSize.w);
					TilePos.x = _TileSize.x * x;
					TilePos.y = _TileSize.y * y;
					TilePos.x += _TileSize.hx();
					TilePos.y += _TileSize.hy();
					Render.SetPosition(TilePos);
					Render.SetScale(this.TileScale);
					Render.SetOrder(_Order + z);
					Render.Off();
					this.TileRenders[z][y][x] = Render;
				}
			}
		}
	}

	CreateTileMapCollision(_X, _Y, _Z, _Order, _TileSize) {
		const ScreenSize = GameEngineWindow.GetScreenSize();

		this.TileScale = _TileSize;

		this.TileCollision.length = _Z;
		this.FloorImageName.length = _Z;

		this.X = _X;
		this.Y = _Y;
		this.Z = _Z;

		for (let z = 0; z < _Z; z++) {
			this.TileCollision[z] = this.TileCollision[z] || [];
			for (let y = 0; y < _Y; y++) {
				this.TileCollision[z][y] = this.TileCollision[z][y] || [];
				for (let x = 0; x < _X; x++) {
					const Collision = this.CreateCollision(0);

					const TilePos = new float4(_TileSize.x, _TileSize.y, _TileSize.z, _TileSize.w);
					TilePos.x = _TileSize.x * x;
					TilePos.y = _TileSize.y * y;
					TilePos.x += _TileSize.hx();
					TilePos.y += _TileSize.hy();
					Collision.SetPosition(TilePos);
					Collision.SetScale(this.TileScale);
					Collision.SetOrder(_Order + z);
					Collision.Off();
					this.TileCollision[z][y][x] = Collision;
				}
			}
		}
	}

	SetFloorSetting(_ZIndex, _ImageName) {
		if (this.TileRenders.length <= _ZIndex) {
			MsgAssert("타일을 설치할 floor 이상의 접근을 하려고 했습니다.");
			return;
		}

		const Image = GameEngineResources.GetInst().ImageFind(_ImageName);

		if (null === Image) {
			MsgAssert("존재하지 않는 이미지로 floor를 만들수  없습니다.");
		}

		if (false === Image.IsImageCutting()) {
			MsgAssert("자르지 않은 이미지는 타일맵에 놓일 수  없습니다.");
		}

		this.FloorImageName[_ZIndex] = _ImageName;

		const FloorRenders = this.TileRenders[_ZIndex];

		for (let y = 0; y < FloorRenders.length; y++) {
			const XLineRenders = FloorRenders[y];
			for (let x = 0; x < XLineRenders.length; x++) {
				const Render = XLineRenders[x];
				Render.SetImage(_ImageName);
			}
		}
	}

	SetTileFrame(...args) {
		if (3 === args.length && args[1] instanceof float4) {
			const _ZIndex = args[0];
			const _Pos = args[1];
			const _ImageFrame = args[2];
			const Index = this.GetIndex(_Pos);
			this.SetTileFrame(_ZIndex, Index.ix(), Index.iy(), _ImageFrame);
			return;
		}
		const _ZIndex = args[0];
		const _X = args[1];
		const _Y = args[2];
		const _ImageFrame = args[3];

		this.IsValidIndex(_ZIndex, _Y, _X);

		const FloorRenders = this.TileRenders[_ZIndex];
		const TileRender = FloorRenders[_Y][_X];

		TileRender.On();
		TileRender.SetFrame(_ImageFrame);
	}

	ConvertIndexToTilePosition(...args) {
		if (1 === args.length) {
			const _Pos = args[0];
			const Index = this.GetIndex(_Pos);
			return this.ConvertIndexToTilePosition(Index.ix(), Index.iy());
		}
		const _X = args[0];
		const _Y = args[1];
		return new float4(_X * this.TileScale.x + this.TileScale.hx(), _Y * this.TileScale.y + this.TileScale.hy(), 0.0, 0.0).add(this.GetPos());
	}

	GetTileFrame(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		const FloorRenders = this.TileRenders[_ZIndex];
		const TileRender = FloorRenders[Index.iy()][Index.ix()];
		if (false === TileRender.IsUpdate()) {
			return -1;
		}
		return TileRender.GetFrame();
	}

	GetTile(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		return this.TileRenders[_ZIndex][Index.iy()][Index.ix()];
	}

	GetTileCollision(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		return this.TileCollision[_ZIndex][Index.iy()][Index.ix()];
	}

	IsValidIndex(_Z, _Y, _X) {
		if (0 > _Z) { return false; }
		if (0 > _Y) { return false; }
		if (0 > _X) { return false; }
		if (this.TileRenders.length <= _Z) { return false; }
		if (this.TileRenders[_Z].length <= _Y) { return false; }
		if (this.TileRenders[_Z][Math.trunc(_Y)].length <= _X) { return false; }
		return true;
	}

	GetIndex(_Pos) {
		const Index = _Pos.sub(this.GetPos());
		Index.x /= this.TileScale.x;
		Index.y /= this.TileScale.y;
		return Index;
	}
}

__PM2_EXPORTS__["GameEngineCore/GameEngineTileMap.js"] = {"FloorInfo": FloorInfo, "GameEngineTileMap": GameEngineTileMap};
})();
(function () {

// ===== main.js =====
var PM2Core = __PM2_EXPORTS__["GameEngineContents/PM2Core.js"]["PM2Core"];
// main.cpp 의 전사
// int APIENTRY wWinMain(...) { PM2Core::GetInst().CoreStart(hInstance); return 0; }

function wWinMain() {
	PM2Core.GetInst().CoreStart(null);
	return 0;
}

__PM2_EXPORTS__["main.js"] = {"wWinMain": wWinMain};
})();
for (var li = 0; li < __PM2_LATE__.length; li++) { __PM2_LATE__[li](); }
__PM2_EXPORTS__["main.js"].wWinMain();
})();