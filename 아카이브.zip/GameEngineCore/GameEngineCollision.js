// GameEngineCollision.h / GameEngineCollision.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineComponent } from "./GameEngineComponent.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export const CollisionType = Object.freeze({
	CT_Point: 0,
	CT_CirCle: 1,
	CT_Rect: 2,
	CT_Max: 3
});

export class CollisionCheckParameter {
	constructor() {
		this.TargetGroup = -342367842;
		this.TargetColType = CollisionType.CT_CirCle;
		this.ThisColType = CollisionType.CT_CirCle;
	}
}

export class CollisionData {
	constructor() {
		this.Position = new float4(0, 0, 0, 1);
		this.Scale = new float4(0, 0, 0, 1);
	}

	Left() { return this.Position.x - this.Scale.hx(); }
	Right() { return this.Position.x + this.Scale.hx(); }
	Top() { return this.Position.y - this.Scale.hy(); }
	Bot() { return this.Position.y + this.Scale.hy(); }
}

// static bool(*ColFunctionPtr[CT_Max][CT_Max])(...) 대응 테이블
const ColFunctionPtr = [];

class CollisionFunctionInit {
	constructor() {
		ColFunctionPtr[CollisionType.CT_CirCle] = [];
		ColFunctionPtr[CollisionType.CT_CirCle][CollisionType.CT_CirCle] = GameEngineCollision.CollisionCirCleToCirCle;
		ColFunctionPtr[CollisionType.CT_CirCle][CollisionType.CT_Point] = GameEngineCollision.CollisionCirCleToPoint;
		ColFunctionPtr[CollisionType.CT_Rect] = [];
		ColFunctionPtr[CollisionType.CT_Rect][CollisionType.CT_Rect] = GameEngineCollision.CollisionRectToRect;
		ColFunctionPtr[CollisionType.CT_Rect][CollisionType.CT_Point] = GameEngineCollision.CollisionRectToPoint;
	}
}


export class GameEngineCollision extends GameEngineComponent {
	constructor() {
		super();
		this.DebugRenderType = CollisionType.CT_CirCle;
	}

	static CollisionCirCleToPoint(_Left, _Right) {
		const Len = _Left.Position.sub(_Right.Position);
		const Size = Len.Size();
		const RadiusSum = _Left.Scale.hx();
		return RadiusSum > Size;
	}

	static CollisionCirCleToCirCle(_Left, _Right) {
		const Len = _Left.Position.sub(_Right.Position);
		const Size = Len.Size();
		const RadiusSum = _Left.Scale.hx() + _Right.Scale.hx();
		return RadiusSum > Size;
	}

	static CollisionRectToRect(_Left, _Right) {
		if (_Left.Bot() <= _Right.Top()) {
			return false;
		}
		if (_Left.Top() >= _Right.Bot()) {
			return false;
		}
		if (_Left.Left() >= _Right.Right()) {
			return false;
		}
		if (_Left.Right() <= _Right.Left()) {
			return false;
		}
		return true;
	}

	static CollisionRectToPoint(_Left, _Right) {
		if (_Left.Bot() <= _Right.Position.y) {
			return false;
		}
		if (_Left.Top() >= _Right.Position.y) {
			return false;
		}
		if (_Left.Left() >= _Right.Position.x) {
			return false;
		}
		if (_Left.Right() <= _Right.Position.x) {
			return false;
		}
		return true;
	}

	SetOrder(_Order) {
		this.GetActor().GetLevel().PushCollision(this, _Order);
	}

	// Collision(parameter) / Collision(parameter, outArray)
	Collision(...args) {
		const _Parameter = args[0];
		if (1 === args.length) {
			if (false === this.IsUpdate()) {
				return false;
			}

			const _TargetGroup = this.GetActor().GetLevel().GetCollisionGroup(_Parameter.TargetGroup);

			for (const OtherCollision of _TargetGroup) {
				if (OtherCollision === this) {
					continue;
				}
				if (false === OtherCollision.IsUpdate()) {
					continue;
				}
				const Type = _Parameter.ThisColType;
				const OtherType = _Parameter.TargetColType;
				if (null == ColFunctionPtr[Type] || null == ColFunctionPtr[Type][OtherType]) {
					MsgAssert("지원 하지않는 충돌 함수이거나 잘못 된 충돌 타입입니다");
				}
				if (ColFunctionPtr[Type] && ColFunctionPtr[Type][OtherType] && true === ColFunctionPtr[Type][OtherType](this.GetCollisionData(), OtherCollision.GetCollisionData())) {
					return true;
				}
			}
			return false;
		}

		const _Collision = args[1];
		if (false === this.IsUpdate()) {
			return false;
		}

		_Collision.length = 0;

		const _TargetGroup = this.GetActor().GetLevel().GetCollisionGroup(_Parameter.TargetGroup);

		this.SetDebugRenderType(_Parameter.ThisColType);

		for (const OtherCollision of _TargetGroup) {
			if (false === OtherCollision.IsUpdate()) {
				continue;
			}
			const Type = _Parameter.ThisColType;
			const OtherType = _Parameter.TargetColType;

			OtherCollision.SetDebugRenderType(OtherType);

			if (null == ColFunctionPtr[Type] || null == ColFunctionPtr[Type][OtherType]) {
				MsgAssert("지원 하지않는 충돌 함수이거나 잘못 된 충돌 타입입니다");
			}
			if (ColFunctionPtr[Type] && ColFunctionPtr[Type][OtherType] && true === ColFunctionPtr[Type][OtherType](this.GetCollisionData(), OtherCollision.GetCollisionData())) {
				_Collision.push(OtherCollision);
			}
		}

		return 0 !== _Collision.length;
	}

	GetCollisionData() {
		const Data = new CollisionData();
		Data.Position = this.GetActorPlusPos();
		Data.Scale = this.GetScale();
		return Data;
	}

	SetDebugRenderType(_DebugRenderType) {
		this.DebugRenderType = _DebugRenderType;
	}

	DebugRender() {
		const BackBufferDc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
		const DebugRenderPos = this.GetActorPlusPos().sub(this.GetActor().GetLevel().GetCameraPos());
		switch (this.DebugRenderType) {
			case CollisionType.CT_Point:
				break;
			case CollisionType.CT_CirCle:
				{
					const Radius = this.GetScale().hix();
					BackBufferDc.beginPath();
					BackBufferDc.ellipse(
						DebugRenderPos.ix(), DebugRenderPos.iy(),
						Radius, Radius, 0, 0, Math.PI * 2
					);
					BackBufferDc.stroke();
					break;
				}
			case CollisionType.CT_Rect:
				{
					BackBufferDc.strokeRect(
						DebugRenderPos.ix() - this.GetScale().hix(),
						DebugRenderPos.iy() - this.GetScale().hiy(),
						this.GetScale().ix(), this.GetScale().hiy()
					);
					break;
				}
			case CollisionType.CT_Max:
				break;
			default:
				break;
		}
	}
}

// 원본: 정적 충돌 함수 테이블 초기화 — C++의 정적 초기화 순서(클래스 정의 이후)와 동일하게 클래스 선언 뒤에서 실행
const Init = new CollisionFunctionInit();
