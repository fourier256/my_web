// NumberRenderObject.h / NumberRenderObject.cpp 의 전사
import { float4, GameEngineMath } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineObject } from "./GameEngineObject.js";
import { GameEngineRender } from "./GameEngineRender.js";
import { GameEngineResources } from "./GameEngineResources.js";

// enum class Align
export const Align = Object.freeze({
	Left: 0,
	Right: 1,
	Center: 2
});

export class NumberRenderObject extends GameEngineObject {
	constructor() {
		super();
		this.Order = 0;
		this.NumberScale = new float4(0, 0, 0, 1);
		this.Pos = new float4(0, 0, 0, 1);
		this.Value = 0;
		this.TransColor = 0xff00ff; // RGB(255, 0, 255)
		this.AlignState = Align.Left;
		this.Negative = false;
		this.NumOfDigits = -1;
		this.CameraEffect = false;
		this.ImageName = "";
		this.NegativeName = "";
		this.NumberRenders = [];
		this.NegativeRender = null;
	}

	SetImage(_ImageName, _Scale, _Order, _TransColor, _NegativeName = "") {
		const FindNumberImage = GameEngineResources.GetInst().ImageFind(_ImageName);

		if (FindNumberImage.GetImageCuttingCount() !== 10) {
			MsgAssert("숫자 이미지는 반드시 10개로 짤라줘야 됩니다.");
		}

		if (0 >= _Scale.x || 0 >= _Scale.y) {
			MsgAssert("크기가 0보다 작으면 숫자를 만들 수 없습니다.");
		}

		this.ImageName = _ImageName;
		this.NumberScale = _Scale;
		this.Order = _Order;
		this.TransColor = _TransColor;
		this.NegativeName = _NegativeName;
	}

	SetNumberRenders(_Index, _TransColor, _Pos, _ImageName, _Scale, _CameraEffect, _Frame = -1) {
		const Render = this.NumberRenders[_Index];
		if (null === Render || undefined === Render) {
			MsgAssert("렌더러레스가 nullptr 입니다");
		}
		Render.SetTransColor(_TransColor);
		Render.SetPosition(_Pos);
		Render.SetImage(_ImageName);
		Render.SetScale(_Scale);
		Render.SetEffectCamera(_CameraEffect);
		if (-1 !== _Frame) {
			Render.SetFrame(_Frame);
		}
	}

	On() {
		super.On();
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].On();
		}
	}

	Off() {
		super.Off();
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].Off();
		}
	}

	SetValue(_Value) {
		const Actor = this.GetOwner();
		this.Value = _Value;

		const Numbers = GameEngineMath.GetDigits(this.Value);

		if (null === Actor) {
			MsgAssert("액터만이 NumberRenderObject의 부모 될 수 있습니다.");
		}

		if (-1 !== this.NumOfDigits && Numbers.length > this.NumOfDigits) {
			MsgAssert("Digits 보다 큰 value가 들어왔습니다.");
		}

		if (-1 !== this.NumOfDigits && _Value < 0) {
			this.ResetDigits();
			MsgAssert("Value가 음수인 경우에는 Digits의값이 설정되었습니다.");
		}

		this.Negative = _Value >= 0 ? false : true;

		const Digits = (this.NumOfDigits === -1 ? Numbers.length : this.NumOfDigits) + (this.Negative ? 1 : 0);

		if (this.NumberRenders.length < Digits) {
			const CurRenderSize = this.NumberRenders.length;
			for (let i = 0; i < (Digits - CurRenderSize); ++i) {
				this.NumberRenders.push(Actor.CreateRender(this.Order));
			}
		} else {
			const CurRenderSize = this.NumberRenders.length;
			for (let i = 0; i < (CurRenderSize - Digits); ++i) {
				const LastRender = this.NumberRenders[this.NumberRenders.length - 1];
				this.NumberRenders.pop();
				LastRender.Death();
			}
		}

		let RenderPos = this.Pos.copy();
		let NumRenderIndex = 0;

		switch (this.AlignState) {
			case Align.Left:
				break;
			case Align.Right:
				RenderPos = RenderPos.sub(new float4((Digits - 1) * this.NumberScale.x, 0, 0, 0));
				break;
			case Align.Center:
				RenderPos = RenderPos.sub(new float4(((Digits - 1) * this.NumberScale.x) / 2, 0, 0, 0));
				break;
			default:
				break;
		}

		if (true === this.Negative && null === this.NegativeRender) {
			this.SetNumberRenders(NumRenderIndex++, this.TransColor, RenderPos, this.NegativeName, this.NumberScale, this.CameraEffect);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
		for (; NumRenderIndex < Digits - Numbers.length; ++NumRenderIndex) {
			this.SetNumberRenders(NumRenderIndex, this.TransColor, RenderPos, this.ImageName, this.NumberScale, this.CameraEffect, 0);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
		for (let i = 0; NumRenderIndex < this.NumberRenders.length; ++NumRenderIndex) {
			this.SetNumberRenders(NumRenderIndex, this.TransColor, RenderPos, this.ImageName, this.NumberScale, this.CameraEffect, Numbers[i++]);
			RenderPos = RenderPos.add(new float4(this.NumberScale.x, 0, 0, 0));
		}
	}

	SetMove(_RenderPos) {
		for (let i = 0; i < this.NumberRenders.length; i++) {
			this.NumberRenders[i].SetMove(_RenderPos);
		}
	}

	SetAlign(_Align) {
		this.AlignState = _Align;
	}

	SetRenderPos(_Pos) {
		this.Pos = _Pos;
		this.SetValue(this.Value);
	}

	GetValue() {
		return this.Value;
	}

	SetNumOfDigits(_Num) {
		this.NumOfDigits = _Num;
	}

	ResetDigits() {
		this.SetNumOfDigits(-1);
	}

	SetCameraEffect(_EffectSetting) {
		this.CameraEffect = _EffectSetting;
	}
}
