// GameEngineTileMap.h / GameEngineTileMap.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineActor } from "./GameEngineActor.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { GameEngineResources } from "./GameEngineResources.js";
import { GameEngineRender } from "./GameEngineRender.js";
import { GameEngineCollision } from "./GameEngineCollision.js";

export class FloorInfo {
}

export class GameEngineTileMap extends GameEngineActor {
	constructor() {
		super();
		this.ScreenSize = new float4(0, 0, 0, 1); // float4::Zero
		this.TileScale = new float4(0, 0, 0, 1);
		this.X = -1;
		this.Y = -1;
		this.Z = -1;
		this.FloorImageName = [];
		this.TileRenders = [];
		this.TileCollision = [];
	}

	CreateTileMap(_X, _Y, _Z, _Order, _TileSize) {
		const ScreenSize = GameEngineWindow.GetScreenSize();

		this.TileScale = _TileSize;

		this.TileRenders.length = _Z;
		this.FloorImageName.length = _Z;

		this.X = _X;
		this.Y = _Y;
		this.Z = _Z;

		for (let z = 0; z < _Z; z++) {
			this.TileRenders[z] = this.TileRenders[z] || [];
			for (let y = 0; y < _Y; y++) {
				this.TileRenders[z][y] = this.TileRenders[z][y] || [];
				for (let x = 0; x < _X; x++) {
					const Render = this.CreateRender(0);

					const TilePos = new float4(_TileSize.x, _TileSize.y, _TileSize.z, _TileSize.w);
					TilePos.x = _TileSize.x * x;
					TilePos.y = _TileSize.y * y;
					TilePos.x += _TileSize.hx();
					TilePos.y += _TileSize.hy();
					Render.SetPosition(TilePos);
					Render.SetScale(this.TileScale);
					Render.SetOrder(_Order + z);
					Render.Off();
					this.TileRenders[z][y][x] = Render;
				}
			}
		}
	}

	CreateTileMapCollision(_X, _Y, _Z, _Order, _TileSize) {
		const ScreenSize = GameEngineWindow.GetScreenSize();

		this.TileScale = _TileSize;

		this.TileCollision.length = _Z;
		this.FloorImageName.length = _Z;

		this.X = _X;
		this.Y = _Y;
		this.Z = _Z;

		for (let z = 0; z < _Z; z++) {
			this.TileCollision[z] = this.TileCollision[z] || [];
			for (let y = 0; y < _Y; y++) {
				this.TileCollision[z][y] = this.TileCollision[z][y] || [];
				for (let x = 0; x < _X; x++) {
					const Collision = this.CreateCollision(0);

					const TilePos = new float4(_TileSize.x, _TileSize.y, _TileSize.z, _TileSize.w);
					TilePos.x = _TileSize.x * x;
					TilePos.y = _TileSize.y * y;
					TilePos.x += _TileSize.hx();
					TilePos.y += _TileSize.hy();
					Collision.SetPosition(TilePos);
					Collision.SetScale(this.TileScale);
					Collision.SetOrder(_Order + z);
					Collision.Off();
					this.TileCollision[z][y][x] = Collision;
				}
			}
		}
	}

	SetFloorSetting(_ZIndex, _ImageName) {
		if (this.TileRenders.length <= _ZIndex) {
			MsgAssert("타일을 설치할 floor 이상의 접근을 하려고 했습니다.");
			return;
		}

		const Image = GameEngineResources.GetInst().ImageFind(_ImageName);

		if (null === Image) {
			MsgAssert("존재하지 않는 이미지로 floor를 만들수  없습니다.");
		}

		if (false === Image.IsImageCutting()) {
			MsgAssert("자르지 않은 이미지는 타일맵에 놓일 수  없습니다.");
		}

		this.FloorImageName[_ZIndex] = _ImageName;

		const FloorRenders = this.TileRenders[_ZIndex];

		for (let y = 0; y < FloorRenders.length; y++) {
			const XLineRenders = FloorRenders[y];
			for (let x = 0; x < XLineRenders.length; x++) {
				const Render = XLineRenders[x];
				Render.SetImage(_ImageName);
			}
		}
	}

	SetTileFrame(...args) {
		if (3 === args.length && args[1] instanceof float4) {
			const _ZIndex = args[0];
			const _Pos = args[1];
			const _ImageFrame = args[2];
			const Index = this.GetIndex(_Pos);
			this.SetTileFrame(_ZIndex, Index.ix(), Index.iy(), _ImageFrame);
			return;
		}
		const _ZIndex = args[0];
		const _X = args[1];
		const _Y = args[2];
		const _ImageFrame = args[3];

		this.IsValidIndex(_ZIndex, _Y, _X);

		const FloorRenders = this.TileRenders[_ZIndex];
		const TileRender = FloorRenders[_Y][_X];

		TileRender.On();
		TileRender.SetFrame(_ImageFrame);
	}

	ConvertIndexToTilePosition(...args) {
		if (1 === args.length) {
			const _Pos = args[0];
			const Index = this.GetIndex(_Pos);
			return this.ConvertIndexToTilePosition(Index.ix(), Index.iy());
		}
		const _X = args[0];
		const _Y = args[1];
		return new float4(_X * this.TileScale.x + this.TileScale.hx(), _Y * this.TileScale.y + this.TileScale.hy(), 0.0, 0.0).add(this.GetPos());
	}

	GetTileFrame(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		const FloorRenders = this.TileRenders[_ZIndex];
		const TileRender = FloorRenders[Index.iy()][Index.ix()];
		if (false === TileRender.IsUpdate()) {
			return -1;
		}
		return TileRender.GetFrame();
	}

	GetTile(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		return this.TileRenders[_ZIndex][Index.iy()][Index.ix()];
	}

	GetTileCollision(_ZIndex, _Pos) {
		const Index = this.GetIndex(_Pos);
		this.IsValidIndex(_ZIndex, Index.y, Index.x);
		return this.TileCollision[_ZIndex][Index.iy()][Index.ix()];
	}

	IsValidIndex(_Z, _Y, _X) {
		if (0 > _Z) { return false; }
		if (0 > _Y) { return false; }
		if (0 > _X) { return false; }
		if (this.TileRenders.length <= _Z) { return false; }
		if (this.TileRenders[_Z].length <= _Y) { return false; }
		if (this.TileRenders[_Z][Math.trunc(_Y)].length <= _X) { return false; }
		return true;
	}

	GetIndex(_Pos) {
		const Index = _Pos.sub(this.GetPos());
		Index.x /= this.TileScale.x;
		Index.y /= this.TileScale.y;
		return Index;
	}
}
