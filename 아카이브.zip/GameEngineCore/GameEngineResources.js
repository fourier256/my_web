// GameEngineResources.h / GameEngineResources.cpp 의 전사
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineImage } from "../GameEnginePlatform/GameEngineImage.js";
import { GameEngineSound, SoundChannel } from "../GameEnginePlatform/GameEngineSound.js";

export class GameEngineSoundPlayer {
	constructor(_Channel = null) {
		this.ControlChannel = _Channel;
	}

	LoopCount(_Count) {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.setLoopCount(_Count - 1);
	}

	Volume(_Volume) {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.setVolume(_Volume);
	}

	Stop() {
		if (null === this.ControlChannel) {
			MsgAssert("가지고 있지 않는 사운드를 컨트롤하겠다고 했습니다.");
		}
		this.ControlChannel.stop();
	}
}

export class GameEngineResources {
	static Inst = new GameEngineResources();

	constructor() {
		this.AllImage = new Map();
		this.AllSound = new Map();
	}


	// 원본은 파일시스템의 .bmp 파일을 그대로 사용했으나, 웹 빌드는 무손실 .png로 변환한다.
	// 코드는 원본 그대로 .bmp로 참조하므로 저장/조회 키를 하나의 표기로 정규화한다(.PNG → .BMP).
	static KeyOf(_Name) {
		return GameEngineString.ToUpper(_Name).replace(/\.PNG$/, ".BMP");
	}

	static GetInst() {
		return this.Inst;
	}

	Relase() {
		for (const [, Pair] of this.AllImage) {
			if (null === Pair) {
				continue;
			}
		}
		this.AllImage.clear();

		for (const [, Pair] of this.AllSound) {
			if (null === Pair) {
				continue;
			}
		}
		this.AllSound.clear();
	}

	ImageLoad(_Path, _Name) {
		// 원본 오버로딩: ImageLoad(GameEnginePath) → (path, filename)
		if (undefined === _Name || null === _Name) {
			const PathStr = "string" === typeof _Path ? _Path : _Path.GetPathToString();
			const FileName = "string" === typeof _Path ? _Path.split("/").pop() : _Path.GetFileName();
			return this.ImageLoad(PathStr, FileName);
		}

		const UpperName = GameEngineResources.KeyOf(_Name);
		if (this.AllImage.has(UpperName)) {
			MsgAssert("이미 로딩된 이미지를 다시 로딩하려고 했습니다." + UpperName);
			return null;
		}

		const NewImage = new GameEngineImage();
		NewImage.ImageLoad("string" === typeof _Path ? _Path : _Path.GetPathToString());
		this.AllImage.set(UpperName, NewImage);
		return NewImage;
	}

	ImageFind(_Name) {
		const UpperName = GameEngineResources.KeyOf(_Name);
		if (false === this.AllImage.has(UpperName)) {
			MsgAssert("로딩되지 않은 이미지를 찾으려고 했습니다" + UpperName);
			return null;
		}
		return this.AllImage.get(UpperName);
	}

	SoundLoad(_Path, _Name) {
		if (undefined === _Name || null === _Name) {
			const PathStr = "string" === typeof _Path ? _Path : _Path.GetPathToString();
			const FileName = "string" === typeof _Path ? _Path.split("/").pop() : _Path.GetFileName();
			return this.SoundLoad(PathStr, FileName);
		}

		const UpperName = GameEngineResources.KeyOf(_Name);
		if (this.AllSound.has(UpperName)) {
			MsgAssert("이미 로딩된 이미지를 다시 로딩하려고 했습니다." + UpperName);
			return null;
		}

		const NewSound = new GameEngineSound();
		NewSound.SoundLoad("string" === typeof _Path ? _Path : _Path.GetPathToString());
		this.AllSound.set(UpperName, NewSound);
		return NewSound;
	}

	SoundFind(_Name) {
		const UpperName = GameEngineResources.KeyOf(_Name);
		if (false === this.AllSound.has(UpperName)) {
			MsgAssert("로딩되지 않은 이미지를 찾으려고 했습니다" + UpperName);
			return null;
		}
		return this.AllSound.get(UpperName);
	}

	SoundPlay(_Name) {
		const Sound = this.SoundFind(_Name);
		const Ch = Sound.Play();
		Ch.setLoopCount(0);
	}

	SoundPlayToControl(_Name) {
		const Sound = this.SoundFind(_Name);
		return new GameEngineSoundPlayer(Sound.Play());
	}
}
