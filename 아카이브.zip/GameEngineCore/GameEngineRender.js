// GameEngineRender.h / GameEngineRender.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineString } from "../GameEngineBase/GameEngineString.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineComponent } from "./GameEngineComponent.js";
import { GameEngineResources } from "./GameEngineResources.js";
import { GameEngineCore } from "./GameEngineCore.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { RGB, ColorRefToCss } from "../WinAPI.js";

// enum class TextAlign { Left = DT_LEFT, Right = DT_RIGHT, Center = DT_CENTER }
export const TextAlign = Object.freeze({
	Left: 0,  // DT_LEFT
	Right: 2, // DT_RIGHT
	Center: 1 // DT_CENTER
});

export class FrameAnimationParameter {
	constructor(AnimationName = "", ImageName = "", Start = 0, End = 0, CurrentIndex = 0, InterTime = 0.1, Loop = true, FrameIndex = [], FrameTime = []) {
		this.AnimationName = AnimationName;
		this.ImageName = ImageName;
		this.Start = Start;
		this.End = End;
		this.CurrentIndex = CurrentIndex;
		this.InterTime = InterTime;
		this.Loop = Loop;
		this.FrameIndex = FrameIndex;
		this.FrameTime = FrameTime;
	}
}

export class GameEngineRender extends GameEngineComponent {
	constructor() {
		super();
		this.Image = null;
		this.IsEffectCamera = true;
		this.TransColor = 0xff00ff; // RGB(255, 0, 255)
		this.Frame = 0;
		this.Alpha = 255;
		this.Animation = new Map();
		this.CurrentAnimation = null;
		this.RenderText = "";
		this.TextHeight = 0;
		this.TextType = "";
		this.Align = TextAlign.Left;
		this.TextColor = RGB(0, 0, 0);
		this.TextBoxScale = new float4(0, 0, 0, 1);
	}

	GetImage() {
		return this.Image;
	}

	GetFrame() {
		return this.Frame;
	}

	GetTextBoxScale() {
		return this.TextBoxScale;
	}

	SetTransColor(_Color) {
		this.TransColor = _Color;
	}

	SetEffectCamera(_Effect) {
		this.IsEffectCamera = _Effect;
	}

	EffectCameraOff() {
		this.SetEffectCamera(false);
	}

	EffectCameraOn() {
		this.SetEffectCamera(true);
	}

	GetTextHeight() {
		return this.TextHeight;
	}

	SetAlpha(_Alpha) {
		this.Alpha = _Alpha;
	}

	SetTextBoxScale(_TextBoxScale) {
		this.TextBoxScale = _TextBoxScale;
	}

	SetImage(_ImageName) {
		this.Image = GameEngineResources.GetInst().ImageFind(_ImageName);
	}

	SetImageToScaleToImage(_ImageName) {
		this.Image = GameEngineResources.GetInst().ImageFind(_ImageName);
		this.SetScaleToImage();
	}

	SetScaleToImage() {
		if (null === this.Image) {
			MsgAssert("이미지가 할당되지 않았는데 이미지의 크기를 변경하려고 했습니다.");
		}
		this.SetScale(this.Image.GetImageScale());
	}

	SetOrder(_Order) {
		// 원본: GetActor()->GetLevel()->PushRender(this, _Order);
		const Level = this.GetActor().GetLevel();
		if (null !== Level && undefined !== Level) {
			Level.PushRender(this, _Order);
		} else {
			this.Order = _Order;
		}
	}

	SetFrame(_Frame) {
		if (null === this.Image) {
			MsgAssert("이미지가 설정되지 않는 렌더러가 프레임을 변경하려고 했습니다.");
		}
		if (false === this.Image.IsImageCutting()) {
			MsgAssert("잘라놓은 이미지가 아니면 프레임을 지정할 수  없습니다.");
		}
		if (false === this.Image.IsCutIndexValid(_Frame)) {
			MsgAssert("범위를 벗어난 이미지인덱스 입니다.");
		}
		this.Frame = _Frame;
	}

	IsAnimationEnd() {
		return this.CurrentAnimation.IsEnd();
	}

	CreateAnimation(_Paramter) {
		const Image = GameEngineResources.GetInst().ImageFind(_Paramter.ImageName);
		if (null === Image) {
			MsgAssert("존재하지 않는 이미지로 애니메이션을 만들려고 했습니다.");
		}
		if (false === Image.IsImageCutting()) {
			MsgAssert("잘라놓은 이미지가 아니면 애니메이션을 만들 수 없습니다.");
		}
		const UpperName = GameEngineString.ToUpper(_Paramter.AnimationName);
		if (this.Animation.has(UpperName)) {
			MsgAssert("이미 존재하는 이름의 애니메이션 입니다." + UpperName);
		}

		const NewAnimation = new GameEngineRender.FrameAnimation();
		this.Animation.set(UpperName, NewAnimation);

		NewAnimation.Image = Image;

		if (0 !== _Paramter.FrameIndex.length) {
			NewAnimation.FrameIndex = _Paramter.FrameIndex.slice();
		} else {
			for (let i = _Paramter.Start; i <= _Paramter.End; ++i) {
				NewAnimation.FrameIndex.push(i);
			}
		}

		if (0 !== _Paramter.FrameTime.length) {
			NewAnimation.FrameTime = _Paramter.FrameTime.slice();
		} else {
			for (let i = 0; i < NewAnimation.FrameIndex.length; ++i) {
				NewAnimation.FrameTime.push(_Paramter.InterTime);
			}
		}

		NewAnimation.Loop = _Paramter.Loop;
		NewAnimation.Parent = this;
	}

	ChangeAnimation(_AnimationName, _ForceChange = false) {
		const UpperName = GameEngineString.ToUpper(_AnimationName);
		if (false === this.Animation.has(UpperName)) {
			MsgAssert("존재하지 않는 애니메이션으로 바꾸려고 했습니다." + UpperName);
		}
		if (false === _ForceChange && this.CurrentAnimation === this.Animation.get(UpperName)) {
			return;
		}
		this.CurrentAnimation = this.Animation.get(UpperName);
		this.CurrentAnimation.CurrentIndex = 0;
		this.CurrentAnimation.CurrentTime = this.CurrentAnimation.FrameTime[this.CurrentAnimation.CurrentIndex];
	}

	SetText(_Text, _TextHeight = 20, _TextType = "바탕", _TextAlign = TextAlign.Center, _TextColor = RGB(0, 0, 0), _TextBoxScale = new float4(0, 0, 0, 1)) {
		this.RenderText = _Text;
		this.TextHeight = _TextHeight;
		this.TextType = _TextType;
		this.Align = _TextAlign;
		this.TextColor = _TextColor;
		this.TextBoxScale = _TextBoxScale;
	}

	Render(_DeltaTime) {
		if (this.RenderText !== "") {
			this.TextRender(_DeltaTime);
		} else {
			this.ImageRender(_DeltaTime);
		}
	}

	TextRender(_DeltaTime) {
		let CameraPos = new float4(0, 0, 0, 1);
		if (true === this.IsEffectCamera) {
			CameraPos = this.GetActor().GetLevel().GetCameraPos();
		}
		const RenderPos = this.GetActorPlusPos().sub(CameraPos);

		const hdc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();

		// 원본: LOGFONTA(HANGEUL_CHARSET) + DrawTextA(Rect, Align)
		hdc.font = `${this.TextHeight}px "${this.TextType}", "바탕", sans-serif`;
		hdc.textBaseline = "top";
		hdc.fillStyle = ColorRefToCss(this.TextColor);

		const Left = RenderPos.ix();
		const Top = RenderPos.iy();
		const Right = RenderPos.ix() + this.TextBoxScale.ix();
		const Bottom = RenderPos.iy() + this.TextBoxScale.iy();

		if (GameEngineCore.GetInst().IsDebug()) {
			// 원본: 점선 사각형 테두리
			hdc.strokeStyle = "rgb(255, 0, 255)";
			hdc.setLineDash([4, 3]);
			hdc.strokeRect(Left, Top, Right - Left, Bottom - Top);
			hdc.setLineDash([]);
		}

		switch (this.Align) {
			case TextAlign.Left:
				hdc.textAlign = "left";
				hdc.fillText(this.RenderText, Left, Top);
				break;
			case TextAlign.Center:
				hdc.textAlign = "center";
				hdc.fillText(this.RenderText, Left + (Right - Left) / 2, Top);
				break;
			case TextAlign.Right:
				hdc.textAlign = "right";
				hdc.fillText(this.RenderText, Right, Top);
				break;
		}
	}

	ImageRender(_DeltaTime) {
		if (null !== this.CurrentAnimation) {
			this.CurrentAnimation.Render(_DeltaTime);
			this.Frame = this.CurrentAnimation.FrameIndex[this.CurrentAnimation.CurrentIndex];
			this.Image = this.CurrentAnimation.Image;
		}

		if (null === this.Image) {
			MsgAssert("이미지가 설정되지 않았습니다.");
		}

		let CameraPos = new float4(0, 0, 0, 1);
		if (true === this.IsEffectCamera) {
			CameraPos = this.GetActor().GetLevel().GetCameraPos();
		}

		const RenderPos = this.GetActorPlusPos().sub(CameraPos);

		const DoubleImage = GameEngineWindow.GetDoubleBufferImage();

		if (true === this.Image.IsImageCutting()) {
			if (255 === this.Alpha) {
				DoubleImage.TransCopy(this.Image, this.Frame, RenderPos, this.GetScale(), this.TransColor);
			} else if (255 > this.Alpha) {
				DoubleImage.AlphaCopy(this.Image, this.Frame, RenderPos, this.GetScale(), this.Alpha);
			}
		} else {
			if (255 === this.Alpha) {
				DoubleImage.TransCopy(this.Image, RenderPos, this.GetScale(), new float4(0, 0), this.Image.GetImageScale(), this.TransColor);
			} else if (255 > this.Alpha) {
				DoubleImage.AlphaCopy(this.Image, RenderPos, this.GetScale(), new float4(0, 0), this.Image.GetImageScale(), this.Alpha);
			}
		}
	}
}

// 원본 GameEngineRender::FrameAnimation 내부 클래스
GameEngineRender.FrameAnimation = class FrameAnimation {
	constructor() {
		this.Parent = null;
		this.Image = null;
		this.FrameIndex = [];
		this.FrameTime = [];
		this.CurrentIndex = 0;
		this.CurrentTime = 0.0;
		this.Loop = true;
	}

	IsEnd() {
		const Value = (this.FrameIndex.length - 1);
		return this.CurrentIndex === Value;
	}

	Render(_DeltaTime) {
		this.CurrentTime -= _DeltaTime;
		if (this.CurrentTime <= 0.0) {
			++this.CurrentIndex;
			if (this.FrameIndex.length <= this.CurrentIndex) {
				if (true === this.Loop) {
					this.CurrentIndex = 0;
				} else {
					this.CurrentIndex = this.FrameIndex.length - 1;
				}
			}
			this.CurrentTime += this.FrameTime[this.CurrentIndex];
		}
	}

	Reset() {
		this.CurrentIndex = 0;
		this.CurrentTime = 0.0;
	}
};
