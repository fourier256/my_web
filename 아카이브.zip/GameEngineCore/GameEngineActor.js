// GameEngineActor.h / GameEngineActor.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineObject } from "./GameEngineObject.js";
import { GameEngineRender } from "./GameEngineRender.js";
import { GameEngineCollision } from "./GameEngineCollision.js";

export class GameEngineActor extends GameEngineObject {
	constructor() {
		super();
		this.TimeScale = 0.0;
		this.LiveTime = 0.0;
		this.Pos = new float4(0.0, 0.0, 0.0, 1.0);
		this.RenderList = [];
		this.CollisionList = [];
	}

	GetPos() {
		return this.Pos;
	}

	SetPos(_MovePos) {
		this.Pos = _MovePos;
	}

	SetMove(_MovePos) {
		this.Pos = this.Pos.add(_MovePos);
	}

	GetLevel() {
		return this.GetOwner();
	}

	CreateRender(_ImageOrOrder, _Order) {
		// 원본 오버로딩: CreateRender(string, int) / CreateRender(int)
		if (null !== _Order && undefined !== _Order) {
			const Render = this.CreateRender(_Order);
			Render.SetImage(_ImageOrOrder);
			return Render;
		}
		const Render = new GameEngineRender();
		Render.SetOwner(this);
		Render.SetOrder(_ImageOrOrder);
		this.RenderList.push(Render);
		return Render;
	}

	CreateCollision(_GroupIndex = 0) {
		const Collision = new GameEngineCollision();
		Collision.SetOwner(this);
		Collision.SetOrder(_GroupIndex);
		this.CollisionList.push(Collision);
		return Collision;
	}

	GetLiveTime() {
		return this.LiveTime;
	}

	LevelChangeEnd(_PrevLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	Release() {
		{
			for (let i = this.RenderList.length - 1; i >= 0; i--) {
				const ReleaseRender = this.RenderList[i];
				if (null === ReleaseRender) {
					MsgAssert("nullptr 는 렌더 리스트에 있어서는 안됩니다.");
				}
				if (false === ReleaseRender.IsDeath()) {
					continue;
				}
				this.RenderList.splice(i, 1);
			}
		}
		{
			for (let i = this.CollisionList.length - 1; i >= 0; i--) {
				const ReleaseCollision = this.CollisionList[i];
				if (null === ReleaseCollision) {
					MsgAssert("nullptr 는 렌더 리스트에 있어서는 안됩니다.");
				}
				if (false === ReleaseCollision.IsDeath()) {
					continue;
				}
				this.CollisionList.splice(i, 1);
			}
		}
	}

	Start() {
	}

	Update(_DeltaTime) {
	}

	LateUpdate(_DeltaTime) {
	}

	Render(_DeltaTime) {
	}
}
