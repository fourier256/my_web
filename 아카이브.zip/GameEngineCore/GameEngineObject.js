// GameEngineObject.h / GameEngineObject.cpp 의 전사
export class GameEngineObject {
	constructor() {
		this.Order = -123123;
		this.Parent = null;
		this.ObjectDeath = false;
		this.ObjectUpdate = true;
		this.Name = "";
	}

	IsUpdate() {
		return null !== this.Parent ? ((this.ObjectUpdate && false === this.IsDeath()) && this.Parent.IsUpdate()) : (this.ObjectUpdate && false === this.IsDeath());
	}

	IsDeath() {
		return null !== this.Parent ? (true === this.ObjectDeath || this.Parent.IsDeath()) : (true === this.ObjectDeath);
	}

	Death() {
		this.ObjectDeath = true;
	}

	On() {
		this.ObjectUpdate = true;
	}

	Off() {
		this.ObjectUpdate = false;
	}

	OnOffSwtich() {
		this.ObjectUpdate = !this.ObjectUpdate;
	}

	SetOwner(_Parent) {
		this.Parent = _Parent;
	}

	GetOwner() {
		return this.Parent;
	}

	SetOrder(_Order) {
		this.Order = _Order;
	}

	GetOrder() {
		return this.Order;
	}

	SetName(_View) {
		this.Name = _View;
	}

	GetName() {
		return this.Name;
	}

	GetNameCopy() {
		return this.Name;
	}
}
