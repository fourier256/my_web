// Button.h / Button.cpp 의 전사
import { GameEngineActor } from "./GameEngineActor.js";
import { GameEngineCollision, CollisionType } from "./GameEngineCollision.js";
import { GameEngineRender } from "./GameEngineRender.js";
import { GameEngineLevel } from "./GameEngineLevel.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { float4 } from "../GameEngineBase/GameEngineMath.js";

// enum class ButtonState
export const ButtonState = Object.freeze({
	Release: 0,
	Press: 1,
	Hover: 2,
});

// 원본 파일 전역: GameEngineCollision* CurCollision;
let CurCollision = null;

export class Button extends GameEngineActor {
	constructor() {
		super();
		this.ButtonRender = null;
		this.ButtonCollision = null;
		this.PointTargetGroup = 0;
		this.ButtonCollisionType = CollisionType.CT_Rect;
		this.ClickPtr = null;
		this.Scale = new float4(0, 0, 0, 1);
		this.State = ButtonState.Release;
		this.CurImageName = "";
		this.HoverImageName = "";
		this.HoverIndex = -1;
		this.ReleaseImageName = "";
		this.ReleaseIndex = -1;
		this.PressImageName = "";
		this.PressIndex = -1;

		this.State = ButtonState.Release;
	}

	SetClickCallBack(_ClickPtr) {
		this.ClickPtr = _ClickPtr;
	}

	SetTargetCollisionGroup(_PointTargetGroup) {
		this.PointTargetGroup = _PointTargetGroup;
		if (null === this.ButtonCollision) {
			this.ButtonCollision = this.CreateCollision(this.PointTargetGroup);
		}
	}

	SetButtonCollisionType(_ButtonCollisionType) {
		this.ButtonCollisionType = _ButtonCollisionType;
	}

	// 원본: SetHoverImage / SetReleaseImage / SetPressImage — 동일한 switch 본문
	SetImageByState() {
		switch (this.State) {
			case ButtonState.Release:
				this.CurImageName = this.ReleaseImageName;
				this.ButtonRender.SetImage(this.ReleaseImageName);
				if (-1 !== this.ReleaseIndex) {
					this.ButtonRender.SetFrame(this.ReleaseIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			case ButtonState.Press:
				this.CurImageName = this.PressImageName;
				this.ButtonRender.SetImage(this.PressImageName);
				if (-1 !== this.PressIndex) {
					this.ButtonRender.SetFrame(this.PressIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			case ButtonState.Hover:
				this.CurImageName = this.HoverImageName;
				this.ButtonRender.SetImage(this.HoverImageName);
				if (-1 !== this.HoverIndex) {
					this.ButtonRender.SetFrame(this.HoverIndex);
				}
				this.ButtonRender.SetScale(this.Scale);
				break;
			default:
				break;
		}
	}

	SetHoverImage(_Name, _HoverIndex = -1) {
		this.HoverImageName = _Name;
		this.HoverIndex = _HoverIndex;
		this.SetImageByState();
	}

	SetReleaseImage(_Name, _ReleaseIndex = -1) {
		this.ReleaseImageName = _Name;
		this.ReleaseIndex = _ReleaseIndex;
		this.SetImageByState();
	}

	SetPressImage(_Name, _PressIndex = -1) {
		this.PressImageName = _Name;
		this.PressIndex = _PressIndex;
		this.SetImageByState();
	}

	GetButtonRender() {
		return this.ButtonRender;
	}

	GetButtonCollision() {
		return this.ButtonCollision;
	}

	GetState() {
		return this.State;
	}

	GetHoverIndex() {
		return this.HoverIndex;
	}

	GetReleaseIndex() {
		return this.ReleaseIndex;
	}

	GetPressIndex() {
		return this.PressIndex;
	}

	SetRenderOrder(_Value) {
		this.ButtonRender.SetOrder(_Value);
	}

	SetScale(_Scale) {
		this.Scale = _Scale;
		this.ButtonCollision.SetScale(this.Scale);
	}

	SetCollisionOrder(_Order) {
		this.ButtonCollision.SetOrder(_Order);
	}

	GetScale() {
		return this.Scale;
	}

	Off() {
		// 원본: GameEngineActor::Off();
		GameEngineActor.prototype.Off.call(this);

		if (CurCollision === this.ButtonCollision) {
			CurCollision = null;
		}
	}

	Start() {
		this.ButtonRender = this.CreateRender(0);
		this.ButtonCollision = this.CreateCollision(0);
	}

	Update(_DeltaTime) {
		this.State = ButtonState.Release;

		const CheckParam = new CollisionCheckParameterLike();
		CheckParam.TargetGroup = this.PointTargetGroup;
		CheckParam.TargetColType = CollisionType.CT_Point;
		CheckParam.ThisColType = this.ButtonCollisionType;

		if (true === this.ButtonCollision.Collision(CheckParam)) {
			if (true === GameEngineInput.IsPress("EngineMouseLeft") && null !== CurCollision) {
				this.State = ButtonState.Press;
			} else if (true === GameEngineInput.IsUp("EngineMouseLeft") && null !== this.ClickPtr && this.ButtonCollision === CurCollision) {
				CurCollision = null;
				this.ClickPtr(this);
			} else if ((true === GameEngineInput.IsFree("EngineMouseLeft") && null === CurCollision) || this.ButtonCollision === CurCollision) {
				CurCollision = this.ButtonCollision;
				this.State = ButtonState.Hover;
			}
		} else {
			if (CurCollision === this.ButtonCollision) {
				CurCollision = null;
			}
		}

		this.SetImageByState();
	}

	LevelChangeEnd(_Level) {
	}
}

// 원본: Button.cpp의 Collision({ .TargetGroup = ..., .TargetColType = ..., .ThisColType = ... })
// 지정 초기화자 대응용 헬퍼 (GameEngineCollision.CollisionCheckParameter와 동일 구조)
import { CollisionCheckParameter } from "./GameEngineCollision.js";
function CollisionCheckParameterLike() {
	return new CollisionCheckParameter();
}
