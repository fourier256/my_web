// GameEngineLevel.h / GameEngineLevel.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineObject } from "./GameEngineObject.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";

export class GameEngineLevel extends GameEngineObject {
	static IsDebugRender = false;
	static TextOutStart = new float4(0, 0, 0, 1);
	static DebugTexts = [];

	static DebugRenderSwitch() {
		GameEngineLevel.IsDebugRender = !GameEngineLevel.IsDebugRender;
	}

	static DebugTextPush(_DebugText) {
		GameEngineLevel.DebugTexts.push(_DebugText);
	}

	constructor() {
		super();
		this.CameraPos = new float4(0, 0, 0, 1); // float4::Zero
		this.Actors = new Map();      // int → Array<GameEngineActor>
		this.Renders = new Map();     // int → Array<GameEngineRender>
		this.Collisions = new Map();  // int → Array<GameEngineCollision>
		this.TimeScales = new Map();  // int → float
	}

	// std::map<K,V>::operator[] 대응 — 없으면 만들어 꺼낸다
	static GroupRef(MapRef, _Key) {
		if (false === MapRef.has(_Key)) {
			MapRef.set(_Key, []);
		}
		return MapRef.get(_Key);
	}

	GetMousePos() {
		return GameEngineWindow.GetMousePosition();
	}

	GetMousePosToCamera() {
		return GameEngineWindow.GetMousePosition().add(this.CameraPos);
	}

	SetCameraMove(_MoveValue) {
		this.CameraPos = this.CameraPos.add(_MoveValue);
	}

	SetCameraPos(_CameraPos) {
		this.CameraPos = _CameraPos;
	}

	GetCameraPos() {
		return this.CameraPos;
	}

	GetConvertActors(_GroupIndex) {
		return this.GetActors(_GroupIndex);
	}

	GetActors(_GroupIndex) {
		const Result = [];
		const Group = GameEngineLevel.GroupRef(this.Actors, _GroupIndex);
		for (const ActorPtr of Group) {
			Result.push(ActorPtr);
		}
		return Result;
	}

	SetTimeScale(_GroupIndex, _Time) {
		this.TimeScales.set(_GroupIndex, _Time);
	}

	Loading() {
	}

	Update(_DeltaTime) {
	}

	LevelChangeEnd(_NextLevel) {
	}

	LevelChangeStart(_PrevLevel) {
	}

	CreateActor(ActorType, _Order = 0) {
		const Actor = new ActorType();
		this.ActorStart(Actor, _Order);
		GameEngineLevel.GroupRef(this.Actors, _Order).push(Actor);
		return Actor;
	}

	ActorStart(_Actor, _Order) {
		if (null === _Actor) {
			MsgAssert("nullptr 액터를 Start하려고 했습니다.");
			return;
		}
		_Actor.SetOwner(this);
		_Actor.SetOrder(_Order);
		_Actor.Start();
	}

	ActorsUpdate(_DeltaTime) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				let CurTimeScale = 1.0;
				if (this.TimeScales.has(Order)) {
					CurTimeScale = this.TimeScales.get(Order);
				}
				for (const Actor of ActorList) {
					if (null === Actor || false === Actor.IsUpdate()) {
						continue;
					}
					Actor.TimeScale = CurTimeScale;
					Actor.LiveTime += _DeltaTime;
					Actor.Update(_DeltaTime * CurTimeScale);
				}
			}
		}
	}

	Release() {
		{
			const GroupKeys = [...this.Collisions.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const CollisionList = this.Collisions.get(Order);
				for (let i = CollisionList.length - 1; i >= 0; i--) {
					const ReleaseCollision = CollisionList[i];
					if (null !== ReleaseCollision && false === ReleaseCollision.IsDeath()) {
						continue;
					}
					CollisionList.splice(i, 1);
				}
			}
		}

		{
			const GroupKeys = [...this.Renders.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const RenderList = this.Renders.get(Order);
				for (let i = RenderList.length - 1; i >= 0; i--) {
					const ReleaseRender = RenderList[i];
					if (null !== ReleaseRender && false === ReleaseRender.IsDeath()) {
						continue;
					}
					RenderList.splice(i, 1);
				}
			}
		}

		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (let i = ActorList.length - 1; i >= 0; i--) {
					const ReleaseActor = ActorList[i];
					if (null !== ReleaseActor && false === ReleaseActor.IsDeath()) {
						ReleaseActor.Release();
						continue;
					}
					ActorList.splice(i, 1);
				}
			}
		}
	}

	ActorsRender(_DeltaTime) {
		{
			const GroupKeys = [...this.Renders.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const RenderList = this.Renders.get(Order);
				for (const Renderer of RenderList) {
					if (null === Renderer || false === Renderer.IsUpdate()) {
						continue;
					}
					Renderer.Render(_DeltaTime * Renderer.GetActor().TimeScale);
				}
			}
		}

		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					if (null === Actor || false === Actor.IsUpdate()) {
						continue;
					}
					// C++ 의 Actor->Render() 는 가상함수 호출이라 데이터 멤버에 가려지지 않는다
					// (예: TitleBackground 의 GameEngineRender* Render 멤버 — 원본 .h 23행).
					// JS 에서는 인스턴스 프로퍼티가 메서드를 가릴 수 있으므로, 원본 가상 호출
					// 의미대로 프로토타입 체인의 메서드를 직접 호출한다.
					const ActorRender = Object.getPrototypeOf(Actor).Render;
					ActorRender.call(Actor, _DeltaTime);
				}
			}
		}

		{
			if (true === GameEngineLevel.IsDebugRender) {
				const GroupKeys = [...this.Collisions.keys()].sort((a, b) => a - b);
				for (const Order of GroupKeys) {
					const CollisionList = this.Collisions.get(Order);
					for (const DebugCollision of CollisionList) {
						if (null === DebugCollision || false === DebugCollision.IsUpdate()) {
							continue;
						}
						DebugCollision.DebugRender();
					}
				}
			}
		}

		{
			GameEngineLevel.TextOutStart = new float4(0, 0, 0, 1);
			for (let i = 0; i < GameEngineLevel.DebugTexts.length; i++) {
				const ImageDc = GameEngineWindow.GetDoubleBufferImage().GetImageDC();
				ImageDc.font = "15px sans-serif";
				ImageDc.textBaseline = "top";
				ImageDc.textAlign = "left";
				ImageDc.fillStyle = "#ffffff";
				ImageDc.fillText(GameEngineLevel.DebugTexts[i], GameEngineLevel.TextOutStart.ix(), GameEngineLevel.TextOutStart.iy());
				GameEngineLevel.TextOutStart = GameEngineLevel.TextOutStart.add(new float4(0, 20.0, 0, 0));
			}
			GameEngineLevel.DebugTexts.length = 0;
		}
	}

	ActorLevelChangeEnd(_NextLevel) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					Actor.LevelChangeEnd(_NextLevel);
				}
			}
		}
	}

	ActorLevelChangeStart(_PrevLevel) {
		{
			const GroupKeys = [...this.Actors.keys()].sort((a, b) => a - b);
			for (const Order of GroupKeys) {
				const ActorList = this.Actors.get(Order);
				for (const Actor of ActorList) {
					Actor.LevelChangeStart(_PrevLevel);
				}
			}
		}
	}

	PushRender(_Render, _ChangeOrder) {
		const OldGroup = this.Renders.get(_Render.GetOrder());
		if (undefined !== OldGroup && null !== OldGroup) {
			const idx = OldGroup.indexOf(_Render);
			if (-1 !== idx) {
				OldGroup.splice(idx, 1);
			}
		}

		// 원본: _Render->GameEngineObject::SetOrder(_ChangeOrder);
		_Render.Order = _ChangeOrder;

		if (null === _Render) {
			MsgAssert("nullptr이 있는 렌더를 렌더 그룹에 넣지 말아 주세요.");
		}

		GameEngineLevel.GroupRef(this.Renders, _Render.GetOrder()).push(_Render);
	}

	PushCollision(_Collision, _ChangeOrder) {
		const OldGroup = this.Collisions.get(_Collision.GetOrder());
		if (undefined !== OldGroup && null !== OldGroup) {
			const idx = OldGroup.indexOf(_Collision);
			if (-1 !== idx) {
				OldGroup.splice(idx, 1);
			}
		}

		// 원본: _Collision->GameEngineObject::SetOrder(_ChangeOrder);
		_Collision.Order = _ChangeOrder;

		if (null === _Collision) {
			MsgAssert("nullptr인 충돌체를 충돌 그룹에 넣지 말아 주세요.");
		}

		GameEngineLevel.GroupRef(this.Collisions, _Collision.GetOrder()).push(_Collision);
	}

	GetCollisionGroup(_TargetGroup) {
		return GameEngineLevel.GroupRef(this.Collisions, _TargetGroup);
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['DebugRenderSwitch', 'DebugTextPush', 'GroupRef']) {
	Object.defineProperty(GameEngineLevel.prototype, __m, { value: function (...args) { return GameEngineLevel[__m](...args); }, writable: true, configurable: true });
}

