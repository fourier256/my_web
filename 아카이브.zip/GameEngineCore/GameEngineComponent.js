// GameEngineComponent.h / GameEngineComponent.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { GameEngineObject } from "./GameEngineObject.js";

export class GameEngineComponent extends GameEngineObject {
	constructor() {
		super();
		this.Position = new float4(0, 0, 0, 1); // float4::Zero
		this.Scale = new float4(0, 0, 0, 1);     // float4::Zero
	}

	SetPosition(_Position) {
		this.Position = _Position;
	}

	SetMove(_Position) {
		this.Position = this.Position.add(_Position);
	}

	SetScale(_Scale) {
		this.Scale = _Scale;
	}

	GetPosition() {
		return this.Position;
	}

	GetScale() {
		return this.Scale;
	}

	GetActor() {
		return this.GetOwner();
	}

	GetActorPlusPos() {
		return this.GetActor().GetPos().add(this.Position);
	}
}
