// GameEngineCore.h / GameEngineCore.cpp 의 전사
import { float4 } from "../GameEngineBase/GameEngineMath.js";
import { MsgAssert, GameEngineDebug } from "../GameEngineBase/GameEngineDebug.js";
import { GameEngineTime } from "../GameEngineBase/GameEngineTime.js";
import { GameEngineWindow } from "../GameEnginePlatform/GameEngineWindow.js";
import { GameEngineInput } from "../GameEnginePlatform/GameEngineInput.js";
import { GameEngineSound } from "../GameEnginePlatform/GameEngineSound.js";
import { GameEngineLevel } from "./GameEngineLevel.js";
import { GameEngineResources } from "./GameEngineResources.js";

let Core = null;

export class GameEngineCore {
	constructor() {
		GameEngineDebug.LeakCheck();
		Core = this;
		this.Levels = new Map();
		this.MainLevel = null;
		this.NextLevel = null;
		this.IsDebugValue = false;
	}

	static GetInst() {
		return Core;
	}

	DebugSwitch() {
		this.IsDebugValue = !this.IsDebugValue;
	}

	SetDebugMode(_IsDebug) {
		this.IsDebugValue = _IsDebug;
	}

	IsDebug() {
		return this.IsDebugValue;
	}

	CreateLevel(_Name, LevelType) {
		if (this.Levels.has(_Name)) {
			MsgAssert(`${_Name}이미 존재하는 이름의 레벨을 생성하려고 했습니다`);
			return;
		}
		const Level = new LevelType();
		this.LevelLoading(Level, _Name);
		this.Levels.set(_Name, Level);
	}

	ChangeLevel(_Name) {
		if (false === this.Levels.has(_Name)) {
			MsgAssert(`${_Name}존재하지 않는 레벨을 변경키려고 했습니다`);
			return;
		}
		this.NextLevel = this.Levels.get(_Name);
	}

	LevelLoading(_Level, _Name) {
		if (null === _Level) {
			MsgAssert("nullptr 은 레벨을 로딩하려고 했습니다.");
			return;
		}
		_Level.SetName(_Name);
		_Level.Loading();
	}

	CoreStart(_instance) {
		if (false === GameEngineInput.IsKey("EngineMouseLeft")) {
			GameEngineInput.CreateKey("EngineMouseLeft", 0x01); // VK_LBUTTON
			GameEngineInput.CreateKey("EngineMouseRight", 0x02); // VK_RBUTTON
		}

		GameEngineWindow.WindowCreate(_instance, "PrincessMaker2", new float4(800, 600), new float4(0, 0));
		GameEngineWindow.WindowLoop(GameEngineCore.GlobalStart, GameEngineCore.GlobalUpdate, GameEngineCore.GlobalEnd);
	}

	static GlobalStart() {
		Core.Start();
		GameEngineTime.GlobalTime.Reset();
	}

	static GlobalUpdate() {
		if (null !== Core.NextLevel) {
			const PrevLevel = Core.MainLevel;
			const NextLevel = Core.NextLevel;

			if (null !== PrevLevel) {
				PrevLevel.LevelChangeEnd(NextLevel);
				PrevLevel.ActorLevelChangeEnd(NextLevel);
			}

			Core.MainLevel = NextLevel;
			Core.NextLevel = null;

			if (null !== NextLevel) {
				NextLevel.LevelChangeStart(PrevLevel);
				NextLevel.ActorLevelChangeStart(PrevLevel);
			}
		}

		GameEngineSound.SoundUpdate();
		const TimeDeltaTime = GameEngineTime.GlobalTime.TimeCheck();
		GameEngineInput.Update(TimeDeltaTime);

		Core.Update();
		if (null === Core.MainLevel) {
			MsgAssert("멤버 레벨이 없는 상태로 레벨매니저를 업데이트 했습니다");
			return;
		}

		Core.MainLevel.Update(TimeDeltaTime);
		Core.MainLevel.ActorsUpdate(TimeDeltaTime);
		GameEngineWindow.DoubleBufferClear();
		Core.MainLevel.ActorsRender(TimeDeltaTime);
		GameEngineWindow.DoubleBufferRender();
		Core.MainLevel.Release();
	}

	static GlobalEnd() {
		Core.End();
		GameEngineResources.GetInst().Relase();
	}

	Start() {
	}

	Update() {
	}

	End() {
	}
}
// C++ 정적 메서드의 인스턴스 호출(ParentLevel->GetAcCubeDialog() 등) 합법성 보존 — 프로토타입 위임
for (const __m of ['GetInst', 'GlobalStart', 'GlobalUpdate', 'GlobalEnd']) {
	Object.defineProperty(GameEngineCore.prototype, __m, { value: function (...args) { return GameEngineCore[__m](...args); }, writable: true, configurable: true });
}

